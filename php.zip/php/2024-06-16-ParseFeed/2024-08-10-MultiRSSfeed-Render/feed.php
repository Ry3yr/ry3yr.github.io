<?php
if (isset($_GET['url'])) {
    $feedUrl = $_GET['url'];

    // Initialize a cURL session
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $feedUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification for demo purposes

    // Set a user-agent to mimic a browser request
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3');

    // Execute the request
    $response = curl_exec($ch);

    // Check for errors
    if(curl_errno($ch)) {
        echo json_encode(['error' => 'Error fetching the feed: ' . curl_error($ch)]);
        curl_close($ch);
        exit();
    }

    curl_close($ch);

    if ($response) {
        $rss = simplexml_load_string($response);

        if ($rss === false) {
            echo json_encode(['error' => 'Failed to parse the feed']);
            exit();
        }

        $feedData = [];

        // Determine whether this is a YouTube feed (Atom) or a standard RSS feed
        if ($rss->getName() === 'feed' && isset($rss->entry)) {
            // Handle YouTube (Atom) feed
            foreach ($rss->entry as $entry) {
                $namespaces = $entry->getNameSpaces(true);
                $media = $entry->children($namespaces['media']);

                $feedData[] = [
                    'title' => (string) $entry->title,
                    'link' => (string) $entry->link['href'],
                    'pubDate' => (string) $entry->published,
                    'image' => isset($media->group->thumbnail) ? (string) $media->group->thumbnail->attributes()->url : null,
                ];

                if (count($feedData) >= 10) {
                    break;
                }
            }
        } elseif (isset($rss->channel->item)) {
            // Handle standard RSS feed
            foreach ($rss->channel->item as $item) {
                $namespaces = $item->getNameSpaces(true);
                $mediaContent = null;

                // Check for media:content or other image tags
                if (isset($namespaces['media'])) {
                    $media = $item->children($namespaces['media']);
                    if (isset($media->content)) {
                        $mediaContent = (string) $media->content->attributes()->url;
                    }
                }

                // Handle cases where the image might be within an enclosure
                if (!$mediaContent && isset($item->enclosure)) {
                    $mediaContent = (string) $item->enclosure['url'];
                }

                $feedData[] = [
                    'title' => (string) $item->title,
                    'link' => (string) $item->link,
                    'pubDate' => (string) $item->pubDate,
                    'image' => $mediaContent,
                ];

                if (count($feedData) >= 10) {
                    break;
                }
            }
        }

        header('Content-Type: application/json');
        echo json_encode(['items' => $feedData]);
    } else {
        echo json_encode(['error' => 'Unable to fetch feed']);
    }
} else {
    echo json_encode(['error' => 'No URL provided']);
}
?>
