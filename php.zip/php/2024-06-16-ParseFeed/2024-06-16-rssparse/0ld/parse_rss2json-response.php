<?php
// Get the RSS URL from the query string
$rss_url = isset($_GET['rss_url']) ? $_GET['rss_url'] : '';

if (!empty($rss_url)) {
    // Fetch the RSS feed
    $rss_feed = file_get_contents($rss_url);

    // Parse the RSS feed
    $rss = new SimpleXMLElement($rss_feed);

    // Convert the RSS feed to an array
    $rss_array = json_decode(json_encode($rss), true);

    // Return the response
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode($rss_array);
    exit;
} else {
    // Return an error response
    http_response_code(400);
    echo 'No RSS URL provided.';
    exit;
}
?>
