<?php
// Get the RSS URL from the query string
$rss_url = isset($_GET['rss_url']) ? $_GET['rss_url'] : '';

if (!empty($rss_url)) {
    // Fetch the RSS feed
    $rss_feed = file_get_contents($rss_url);

    // Parse the RSS feed
    $rss = new SimpleXMLElement($rss_feed);

    // Return the resulting DOM
    echo $rss->asXML();
} else {
    echo "No RSS URL provided.";
}
?>