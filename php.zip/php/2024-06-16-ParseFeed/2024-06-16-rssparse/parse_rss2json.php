<?php
// Get the RSS URL from the query string
$rss_url = isset($_GET['rss_url']) ? $_GET['rss_url'] : '';

if (!empty($rss_url)) {
    // Fetch the RSS feed
    $rss_feed = file_get_contents($rss_url);

    // Parse the RSS feed
    $rss = new SimpleXMLElement($rss_feed);

    // Convert the RSS feed to an array
    $rss_array = json_decode(json_encode($rss), true);

    // Convert the array to JSON and output it
    header('Content-Type: application/json');
    echo json_encode($rss_array);
} else {
    echo "No RSS URL provided.";
}
?>