Get link to paste from <a href="https://notube.cc/de/youtube-app-v158" target="_blank">here</a> (long hold the "Download" Button, paste link here)
<hr>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the URL from the input
    $fileUrl = $_POST['url'];

    // Set the save path and filename
    $savePath = __DIR__ . '/out.mp3';

    // Download the file using cURL
    $ch = curl_init($fileUrl);
    $file = fopen($savePath, 'wb');
    curl_setopt($ch, CURLOPT_FILE, $file);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_exec($ch);
    curl_close($ch);
    fclose($file);

    echo 'File downloaded successfully.';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>File Downloader</title>
</head>
<body>
    <form method="POST">
        <label for="url">Enter the file URL:</label>
        <input type="text" name="url" id="url" required>
        <button type="submit">Download</button>
    </form>
</body>
</html>