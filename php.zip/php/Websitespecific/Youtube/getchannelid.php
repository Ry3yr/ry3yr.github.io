
<?php

$url = "https://www.youtube.com/@diarykeeper";
function get_youtube_channel_ID($url){
  $html = file_get_contents($url);
  preg_match("'<meta itemprop=\"channelId\" content=\"(.*?)\"'si", $html, $match);
  if($match && $match[1])
    return $match[1];

echo $match;
}
?>
