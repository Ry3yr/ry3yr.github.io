<?php
$currentDir = __DIR__; // Get the current directory
$targetDir = dirname(dirname($currentDir)) . '/downloads'; // Two directories up

// Get a list of all files in the current directory
$files = glob($currentDir . '/*');

// Iterate through each file
foreach ($files as $file) {
    // Check if the file is a regular file and not a directory
    if (is_file($file) && pathinfo($file, PATHINFO_EXTENSION) !== 'php') {
        // Get the filename
        $filename = basename($file);

        // Move the file to the target directory
        $targetFile = $targetDir . '/' . $filename;
        rename($file, $targetFile);

        // Output the status
        echo "Moved: $file -> $targetFile\n";
    }
}
?>