https://github.com/Ry3yr/OSTR/releases.atom<br>

<?php

$feedUrl = 'https://github.com/Ry3yr/OSTR/releases.atom';

// Fetch the Atom feed using file_get_contents
$feedXml = file_get_contents($feedUrl);

// Parse the Atom feed using SimpleXMLElement
$feed = new SimpleXMLElement($feedXml);

// Extract the updated date of the feed
$updatedDate = (string) $feed->updated;

echo $updatedDate;
?>
