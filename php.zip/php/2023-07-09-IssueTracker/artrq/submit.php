<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = htmlspecialchars($_POST["title"]);
    $description = htmlspecialchars($_POST["description"]);
    $image = $_FILES["image"];
    
    // Handle image upload
    $uploadDirectory = "uploads/";
    if (!is_dir($uploadDirectory)) {
        mkdir($uploadDirectory, 0777, true);
    }
    
    $targetFile = $uploadDirectory . basename($image["name"]);
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    
    // Check if image file is an actual image or fake image
    $check = getimagesize($image["tmp_name"]);
    if ($check !== false) {
        if (move_uploaded_file($image["tmp_name"], $targetFile)) {
            $imagePath = $targetFile;
        } else {
            echo "Sorry, there was an error uploading your file.";
            exit;
        }
    } else {
        echo "File is not an image.";
        exit;
    }

    // Create HTML content
    $htmlContent = "
<!DOCTYPE html>
<html>
<head>
    <title>$title</title>
</head>
<body>
    <h1>$title</h1>
    <p>$description</p>
    <img src='$imagePath' alt='$title'>
</body>
</html>
";

    // Save the content to a file named with the current date and time
    $date = date("Ymd_His");
    $filename = "$date.html";
    $file = fopen($filename, "w");

    if ($file) {
        fwrite($file, $htmlContent);
        fclose($file);
        echo "File created: <a href='$filename'>$filename</a>";
    } else {
        echo "Unable to write to file.";
    }
}
?>
