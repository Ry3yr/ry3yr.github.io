<!DOCTYPE html>
<html>
<head>
    <title>ArtRequest</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            //background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background-color: #ffffff;
            padding: 20px;
            //border-radius: 8px;
            //box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }
        .form-container h2 {
            margin-top: 0;
            //color: #333;
        }
        .form-container label {
            display: block;
            margin-bottom: 8px;
            //color: #555;
        }
        .form-container input[type="text"],
        .form-container textarea,
        .form-container input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-container input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 4px;
        }
        .form-container input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

    <div class="form-container">
[<a target="_blank" href="https://postimages.org/#https://my.hidrive.com/share/zdbapu2k-s" style=color:blue>Upload</a>]<br><hr><br>
<a target="_blank" href="parsehtml.php" style=color:blue>link</a>
<details><summary>REQUESTS</summary><hr>
<object type="text/html" data="parsehtml.php" style="width:800px; height:100%"></object>
</details><br><br>



        <h2>Submit Form</h2>


        <form action="submit.php" method="post" enctype="multipart/form-data">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" value="-">
            
            <label for="description">Description:</label>
            <textarea id="description" name="description" required></textarea>
            
            <label for="image">Upload Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required>
            
            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>
