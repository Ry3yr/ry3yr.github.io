<!DOCTYPE html>
<html>
<head>
    <title>Requests</title>
    <style>
        table {
            width: 80%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        img {
            width: 50%;
        }
    </style>
</head>
<body>
<?php
$dir = opendir('.');
$htmlFiles = [];
while (($file = readdir($dir)) !== false) {
    // Check if the file is a .html file and does not contain "private"
    if (pathinfo($file, PATHINFO_EXTENSION) === 'html' && strpos($file, 'private') === false) {
        $htmlFiles[] = $file;
    }
}
closedir($dir);
function extractFields($filename) {
    $content = file_get_contents($filename);
    preg_match('/<h1>(.*?)<\/h1>/s', $content, $h1);
    preg_match('/<p>(.*?)<\/p>/s', $content, $p);
    preg_match('/<img src=[\'"](.*?)[\'"] alt=[\'"](.*?)[\'"]>/s', $content, $img);
    return [
        'h1' => $h1[1] ?? 'N/A',
        'p' => isset($p[1]) ? nl2br(htmlspecialchars($p[1])) : 'N/A',
        'img_src' => $img[1] ?? 'N/A',
        'img_alt' => $img[2] ?? 'N/A',
    ];
}
if (!empty($htmlFiles)) {
    echo '<table>';
    echo '<tr><th>Filename</th><th>Title</th><th>Description</th><th>Image Source</th></tr>';
    foreach ($htmlFiles as $file) {
        $fields = extractFields($file);
        echo '<tr>';
        echo '<td>' . htmlspecialchars($file) . '</td>';
        echo '<td>' . htmlspecialchars($fields['h1']) . '</td>';
        echo '<td>' . $fields['p'] . '</td>'; // Already escaped
        echo '<td><a href="' . htmlspecialchars($fields['img_src']) . '" target="_blank"><img src="' . htmlspecialchars($fields['img_src']) . '" alt="' . htmlspecialchars($fields['img_alt']) . '"></a></td>';
        //echo '<td>' . htmlspecialchars($fields['img_alt']) . '</td>';
        echo '</tr>';}
    echo '</table>';
} else {
    echo '<p>No HTML files found.</p>';
}
?>
