<?php
// Step 1: Include the Snoopy class
require_once 'snoopy.class.php';

// Step 2: Create a Snoopy object
$snoopy = new Snoopy();

// Step 3: Set the target URL and fetch the page
$url = 'https://vgmdb.net/artist/1';  // Replace with the URL you want to save
$snoopy->fetch($url);

// Step 4: Save the page
if ($snoopy->status == 200) {
    $html = $snoopy->results;
    $output_file = 'path/to/save/page.html';  // Replace with the desired output file path
    file_put_contents($output_file, $html);
    echo "Page saved successfully!";
} else {
    echo "Failed to fetch the page.";
}
?>