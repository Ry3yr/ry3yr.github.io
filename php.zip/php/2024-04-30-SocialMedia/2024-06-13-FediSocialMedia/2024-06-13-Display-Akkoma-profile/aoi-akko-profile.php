<?php

$url = 'https://yusaao.com/api/v1/accounts/ao';

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($statusCode == 200) {
    $data = json_decode($response, true);

    echo "@" . $data['acct'] . "<br>";
    echo "<img src='" . $data['avatar'] . "' alt='Avatar' width='100'><br>";
    //echo "<img src='" . $data['header'] . "' alt='Header' width='200'><br>";
        echo " " . $data['note'] . "<br><br>";
     echo " Notes: " . $data['statuses_count'] . " ";
    echo "Followers: " . $data['followers_count'] . " ";
    echo "Following: " . $data['following_count'] . "<br>";
    //echo "Created At: " . $data['created_at'] . "<br>";
} else {
    echo "Error fetching data: " . $statusCode;
}

curl_close($ch);
