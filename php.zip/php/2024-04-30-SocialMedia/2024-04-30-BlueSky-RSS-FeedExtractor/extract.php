<?php
if (isset($_POST['submit'])) {
    // Retrieve the URL from the textbox
    $url = $_POST['textbox_url'];

    // Fetch the contents of the webpage
    $html = file_get_contents($url);

    // Create a DOMDocument object and load the HTML
    $dom = new DOMDocument();
    libxml_use_internal_errors(true); // Disable error reporting for invalid HTML
    $dom->loadHTML($html);
    libxml_use_internal_errors(false); // Enable error reporting

    // Create a DOMXPath object
    $xpath = new DOMXPath($dom);

    // Find all <link> elements with rel="alternate" and type="application/rss+xml"
    $query = '//link[@rel="alternate" and @type="application/rss+xml"]';
    $links = $xpath->query($query);

    // Display the extracted links
    foreach ($links as $link) {
        $href = $link->getAttribute('href');
        echo "RSS Link: $href";
    }
}
?>

<!-- HTML form with a textbox -->
<form method="post" action="">
    <input type="text" name="textbox_url" placeholder="Enter URL">
    <input type="submit" name="submit" value="Extract RSS">
</form>