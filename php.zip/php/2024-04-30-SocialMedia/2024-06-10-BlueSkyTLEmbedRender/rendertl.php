<a href="https://alcea-wisteria.de/PHP//0demo/00-PHP-Test/current.php?bskyurl=https://bsky.app/profile/did:plc:aa23o5w4w2afknay44oqxqz6/rss" style=color:blue>test</a><br>

<?php
$bskyUrl = isset($_GET['bskyurl']) ? $_GET['bskyurl'] : 'https://bsky.app/profile/did:plc:nc45m3kcywjhyr4tgsbmea64/rss';

// Fetch the RSS feed
$feed = file_get_contents($bskyUrl);
$doc = new DOMDocument();
$doc->loadXML($feed);
$items = $doc->getElementsByTagName('item');
foreach ($items as $item) {
    $link = $item->getElementsByTagName('link')->item(0);
    $linkUrl = $link->textContent;
    $lastSlashPos = strrpos($linkUrl, '/');
    $postId = substr($linkUrl, $lastSlashPos + 1);

    $guid = $item->getElementsByTagName('guid')->item(0);
    if ($guid->getAttribute('isPermaLink') === 'false') {
        $guidValue = $guid->textContent;
        $startPos = strpos($guidValue, 'plc:') + 4;
        $endPos = strpos($guidValue, '/app.bsky');
        $guidPart = substr($guidValue, $startPos, $endPos - $startPos);
        $didPrefix = 'did:plc:';
    }

    echo "<blockquote class=\"bluesky-embed\" data-bluesky-uri=\"at://$didPrefix$guidPart/app.bsky.feed.post/$postId\" data-bluesky-cid=\"\"></blockquote>";
    echo "<script async src=\"https://embed.bsky.app/static/embed.js\" charset=\"utf-8\"></script>";
}