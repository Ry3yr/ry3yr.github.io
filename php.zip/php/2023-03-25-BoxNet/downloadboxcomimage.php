<php

$url = 'https://public.boxcloud.com/api/2.0/internal_files/1219519426384/versions/1330804687984/representations/png_paged_2048x2048/content/1.png?access_token=1!x9a7Yi9DOa4CvW2op_bVt8ToaXOzFd3fI22wYt20PPAfptt4mDVwm1Fzs7wtnX7WJ9ntVKhFcV4BuRIPvadK7xzLviki6Gs_a0GLXbt4C_6S_y6i8CbWgpS4u_GlVBA4l8HwSzjiTdiAF5fYwbTJyTbJFM4DiiaYbOfxnpazrVyrj3mjmMucY9xCfsVYccsATThOmDDuTC0YSz_fBJ2jKQ4Td6ieP3XFhIg7Ki7ntmOW3L4o-U9vLJhPvHhXSNbjwWdy6d7Ye4w7BDCXu3sVgKVkX1D2bRGIyurzwV7-naJrm59coLYrnVnZBSJ7xRGXxBSYVyWBTKV0R4r1ZvixQi1gHKSDc45mQOE9wzXbOs4OCkYkGIeDzCuelhSzIfoURKpCgG5rII3MPledZ_jCU_v_NpgME3mtZ_9aKQ9uzKydBSudO4wEEgJ_cJRQ_xpxzjQ2z2Hcj8Uioaxv9QFaJglaUQLiTvbTN9kdyV5yzSY0hq3K2k3FGYe1u7zbi1Hc-HYTnhyHv2j8LW8jjPkm3TFNY7DzXBF6Iy3urEQjW2xZsH7MPHLMTj98Tvt4TRODkMU6&shared_link=https%3A%2F%2Fapp.box.com%2Fs%2Fj7i88s6jb4yyk4wmiti4tol8ejoikdhl&box_client_name=box-content-preview&box_client_version=2.93.0';

$file = '1.png';

// Open the file to write the downloaded content.
$fp = fopen($file, 'w');

// Initialize cURL session.
$ch = curl_init($url);

// Set cURL options for file download.
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_HEADER, 0);

// Execute cURL session.
curl_exec($ch);

// Close cURL session and file.
curl_close($ch);
fclose($fp);

?>