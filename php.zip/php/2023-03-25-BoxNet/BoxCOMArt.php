


<br>
<?php
$filename = 'yourpage.html';
if (file_exists($filename)) {
    echo "$filename was last modified: " . date ("F d Y H:i:s.", filemtime($filename));
}
?> <a target="_blank" href="delete.php">REFRESH</a>
<br><br>



<br><br>    
<a target="_blank" href="https://codeberg.org/alceawisteria/pages/src/branch/main/images/arthost">CODEBERG</a>&nbsp;<a target="_blank" href="https://codeberg.org/alceawisteria/pages/_upload/main/images/arthost">[Upload]</a>&nbsp;<br><br>




<?php
//require 'simple_html_dom.php';
//unlink("yourpage.html");
ob_start();
?>


<meta http-equiv="Cache-Control" content="max-age=18000">
<style>
img{
    width: 35%;
    //height: 80%;
    margin-top: .4rem;
    //border-radius: 50rem;
    }
</style>
<script>
// Set the Cache-Control header to prevent caching
window.addEventListener("load", function() {
  fetch(window.location.href, { cache: "no-store" });
});
</script>


<?php
$rss = simplexml_load_file('https://rsshub.app/pixiv/user/75406576');
$count = 0;
foreach ($rss->channel->item as $item) {
    $description = (string) $item->description;
    if (preg_match('/https:\/\/pixiv\.rsshub\.app\/\S+/', $description, $matches)) {
    //if (preg_match('/https:\/\/\S+/', $description, $matches)) {
        $link = rtrim($matches[0], '"');
        echo '<br><img src="' . htmlspecialchars($link) . '">';
        $count++;
        if ($count >= 4) {
            break;
        }
    }
}
?>


<?php
//echo '1';
file_put_contents('yourpage.html', ob_get_contents());

$path_to_file = 'yourpage.html';
$file_contents = file_get_contents($path_to_file);
$file_contents = str_replace("alceawisteria/pages/src/branch/main/", "", $file_contents);
file_put_contents($path_to_file, $file_contents);

$dom = new DOMDocument;
@$dom->loadHTML($html);
$links = $dom->getElementsByTagName('a');
$html = file_get_contents($url);
$dom = new DOMDocument();
@$dom->loadHTML($html);
$xpath = new DOMXPath($dom);
$nodes = $xpath->query('//a[@class="files-item-anchor"]');

foreach ($nodes as $node){
    echo $link->nodeValue;
    echo "<a target='_blank' href=https://m.box.com";
    echo $node-> getAttribute('href'), ">";

    echo $node-> getAttribute('href'), "</a>", '<br>';
}
$fileContents = file_get_contents('yourpage.html');
$modifiedContents = str_replace('<img', '<br><img', $fileContents);
file_put_contents('yourpage.html', $modifiedContents);
?><br>


<?php
$fileContents = file_get_contents('yourpage.html');
$modifiedContents = str_replace('<img', '<br><img', $fileContents);
file_put_contents('yourpage.html', $modifiedContents);
echo 'Replacement complete.';
?>



<?php 
//echo '<script type="text/javascript"> window.open("yourpage.html"); </script>'; 
echo "<a href=http://alceawisteria.byethost7.com/PHP/0demo/2023-03-25-BoxNet/yourpage.html>LINK</a>";
?>

<!---<a target="_blank" href="http://alceawisteria.byethost7.com/PHP/0demo/2023-03-25-BoxNet/lastimage.html">Last3</a>--->

<!--<object type="text/html" data="yourpage.html" style="width:100%; height:100%"></object>-->
<!--<iframe src="yourpage.html" name="boxnetgallery" style=" display:block; position: absolute; height: 100%; width: 100%" frameborder="0" ></iframe>--><br><br>

<?php
unlink("yourpagereverse.html");
//ob_start();
$file = file("yourpage.html");
$file = array_reverse($file);
foreach($file as $f){
    //echo $f."<br />";
    file_put_contents('yourpagereverse.html', $f."<br />",FILE_APPEND);
}
//file_put_contents('yourpagereverse.html', ob_get_contents());
//ob_end_flush();
?>


<a href="javascript:myeditFunction()"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/VisualEditor_icon_image-thumbnail.svg/1200px-VisualEditor_icon_image-thumbnail.svg.png" height="90" width="90"></a>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>function myeditFunction() {
$("#editor").load("http://alceawisteria.byethost7.com/PHP/0demo/2023-06-09-RSSHub_Pixiv_Parse/RSSHubPixivImages.php");
}</script>
<div class="formClass"><div id="editor"></div></div>



