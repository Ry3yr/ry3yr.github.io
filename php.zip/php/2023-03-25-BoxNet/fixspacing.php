<?php
$fileContents = file_get_contents('yourpage.html');
$modifiedContents = str_replace('<img', '<br><img', $fileContents);
file_put_contents('yourpage.html', $modifiedContents);
echo 'Replacement complete.';
?>

<iframe src="yourpage.html?timestamp=<?= time(); ?>" width="1200" height="2400" frameborder="0"></iframe>
