


<iframe src="BoxCOMArt.php" style=" display:block; position: absolute; height: 1%; width: 100%" frameborder="0" ></iframe>


<!doctype html>
<!--https://allwebco-templates.com/support/S_script_newsfeed.htm-->
<html lang="en">
<head>
<meta charset="utf-8">
<base target="_parent">
<title>rollingyourpage</title>

<style>
img{
    width: 80%;
    //height: 80%;
    margin-top: .4rem;
    //border-radius: 50rem;
    }
</style>

<style>
@import url(https://fonts.googleapis.com/css?family=Droid+Sans:400,700);#news_iframe_scroll{width:100%;max-width:250px;min-width:400px;margin:0 auto 10px;border:1px solid #000;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box}#news_iframe_scroll iframe{width:100%;height:176px;display:block;margin:0;padding:0;overflow:hidden}.news_scroll-title{color:#fff;font:20px "Droid Sans",arial,sans-serif;text-align:left;background-color:#276396;padding:5px;border-bottom:5px solid silver}#NewsDiv{position:absolute;left:0;top:0;width:100%}body.news-scroll{background-color:#fff;margin:0;padding:0;border:0}.scroll-text-if{color:#666;font:12px "Droid Sans",arial,sans-serif;text-align:left;padding:8px 7px 0}.scroll-title-if{color:#000;font:bold 15px "Droid Sans",arial,sans-serif;text-align:left;border-bottom:0 solid #666}.news-scroll a:active,.news-scroll a:link{color:#03f;text-decoration:none}.news-scroll a:visited{color:#63f;text-decoration:none}.news-scroll a:hover{color:#69f;text-decoration:underline}
</style>
</head>
<body class="news-scroll" onMouseover="scrollspeed=0" onMouseout="scrollspeed=current" OnLoad="NewsScrollStart();">
<!-- START NEWS FEED -->
<div id="NewsDiv">
<div class="scroll-text-if">
<!-- SCROLLER CONTENT STARTS HERE -->
<span class="scroll-title-if">





<a id="linky" onclick="this.href='data:text/html;charset=UTF-8,'+encodeURIComponent(document.documentElement.outerHTML)" id="linky" href="#" download=rollingyourpage.html style="color:transparent"><font size="+5">Download</font></a>

<a target="_blank" href="http://alceawisteria.byethost7.com/PHP/0demo/2023-03-25-BoxNet/rolling.php#download?i=1"><font size="+9">(↓)</font></a>
<br>
		      
		      

<br><br>
<a target="_blank" href="http://alceawisteria.byethost7.com/PHP/0demo/2023-03-25-BoxNet/rolling.php">refresh</a>
&nbsp;
<a target="_blank" href="http://alceawisteria.byethost7.com/PHP/0demo/2023-03-25-BoxNet/rollingyourpage.html" style="color:lightgrey">rollingyourpage</a>
<br><br>
<a target="_blank" href="https://codeberg.org/alceawisteria/pages/src/branch/main/images/arthosthttps://github.com/Ry3yr/OSTR/tree/main/Diarykeepers_Homepage/extrafiles/images/arthost">CODEBERG</a>&nbsp;<a target="_blank" href="https://codeberg.org/alceawisteria/pages/_upload/main/images/arthost">[Upload]</a>&nbsp;<br>
<br>

<?php
file_put_contents("rollingyourpage.html", file_get_contents("yourpage.html"));

define("TEXT_FILE", "rollingyourpage.html");
define("LINES_COUNT", 4);
function read_file($file, $lines) {
    //global $fsize;
    $handle = fopen($file, "r");
    $linecounter = $lines;
    $pos = -2;
    $beginning = false;
    $text = array();
    while ($linecounter > 0) {
        $t = " ";
        while ($t != "\n") {
            if(fseek($handle, $pos, SEEK_END) == -1) {
                $beginning = true; 
                break; 
            }
            $t = fgetc($handle);
            $pos --;
        }
        $linecounter --;
        if ($beginning) {
            rewind($handle);
        }
        $text[$lines-$linecounter-1] = fgets($handle);
        if ($beginning) break;
    }
    fclose ($handle);
    return array_reverse($text);
}
$fsize = round(filesize(TEXT_FILE)/1024/1024,2);
$lines = read_file(TEXT_FILE, LINES_COUNT);
foreach ($lines as $line) {
    echo $line;
}
?>



<br><br>
<iframe src="https://app.box.com/s/j7i88s6jb4yyk4wmiti4tol8ejoikdhl#https://drive.google.com/drive/folders/1DhpyJZExNv8MC0AstQKTyIWWR3NDxa84?usp=share_link" style=" display:block; position: absolute; height: 80%; width: 80%" frameborder="0" ></iframe>


<!-- END SCROLLER CONTENT -->
</div>
</div>
<!-- END NEWS FEED -->
<!-- YOU DO NOT NEED TO EDIT BELOW THIS LINE -->
<script type="text/javascript">
var startdelay 		= 1; 		// START SCROLLING DELAY IN SECONDS
var scrollspeed		= 2.5;		// ADJUST SCROLL SPEED
var scrollwind		= 1;		// FRAME START ADJUST
var speedjump		= 30;		// ADJUST SCROLL JUMPING = RANGE 20 TO 40
var nextdelay		= 0; 		// SECOND SCROLL DELAY IN SECONDS 0 = QUICKEST
var topspace		= "2px";	// TOP SPACING FIRST TIME SCROLLING
var frameheight		= 70;		// IF YOU RESIZE THE CSS HEIGHT, EDIT THIS HEIGHT TO MATCH
current = (scrollspeed);
function HeightData(){
AreaHeight=dataobj.offsetHeight
if (AreaHeight===0){
setTimeout("HeightData()",( startdelay * 1000 ))
}
else {
ScrollNewsDiv()
}}
function NewsScrollStart(){
dataobj=document.all? document.all.NewsDiv : document.getElementById("NewsDiv")
dataobj.style.top=topspace
setTimeout("HeightData()",( startdelay * 1000 ))
}
function ScrollNewsDiv(){
dataobj.style.top=scrollwind+'px';
scrollwind-=scrollspeed;
if (parseInt(dataobj.style.top)<AreaHeight*(-1)) {
dataobj.style.top=frameheight+'px';
scrollwind=frameheight;
setTimeout("ScrollNewsDiv()",( nextdelay * 1000 ))
}
else {
setTimeout("ScrollNewsDiv()",speedjump)
}}
</script>
</body>
</html>



<?php
file_put_contents('rollingyourpage.html', ob_get_contents());
?>



<script src="jqueryzz.min.js"></script>
<script>
  $(document).ready(function() {
    if (window.location.href.indexOf("alceawisteria") > -1) {
      //alert("your url contains the name franky");
      document.getElementById('linky').click();
      window.history.back();	 
      window.close();
    }
  });
</script>





