<?php
// Set the default API key and channel options
$defaultApiKey = 'YOUR_API_KEY';
$defaultChannelId = 'UCrltGih11A_Nayz6hG5XtIw';

// Get the API key from the form input or use the default value
$apiKey = isset($_POST['api_key']) ? $_POST['api_key'] : $defaultApiKey;

// Get the selected channel ID from the dropdown or use the default value
$channelId = isset($_POST['channel_id']) ? $_POST['channel_id'] : $defaultChannelId;

// Number of comments to display
$commentCount = 5;

// API endpoint URL
$apiUrl = "https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&allThreadsRelatedToChannelId=$channelId&maxResults=$commentCount&order=time&key=$apiKey";

// Fetch comments from the YouTube API
$response = file_get_contents($apiUrl);
$comments = json_decode($response, true)['items'];

// Display the fetched comments
foreach ($comments as $comment) {
    $snippet = $comment['snippet']['topLevelComment']['snippet'];
    $author = $snippet['authorDisplayName'];
    $text = $snippet['textDisplay'];
    $videoId = $snippet['videoId'];

    $videoUrl = "https://www.youtube.com/watch?v=$videoId";

    echo "<p><strong>$author</strong>: $text</p>";
    echo "<p>From Video: <a href=\"$videoUrl\">$videoUrl</a></p>";
}
?>

<!-- HTML form for API key and channel selection -->
<form method="POST" action="">
    <label for="api_key">API Key:</label>
    <input type="text" name="api_key" id="api_key" value="<?php echo $apiKey; ?>">

    <label for="channel_id">Channel:</label>
    <select id="channel_id" name="channel_id" required>
        <option value="UCrltGih11A_Nayz6hG5XtIw" <?php if ($channelId === 'UCrltGih11A_Nayz6hG5XtIw') echo 'selected'; ?>>Diarykeeper</option>
        <option value="UCmIpOnd5BVx5Si2hp0WNKZw" <?php if ($channelId === 'UCmIpOnd5BVx5Si2hp0WNKZw') echo 'selected'; ?>>Repeekyraid_Cero</option>
    </select>

    <button type="submit">Fetch Comments</button>
</form>