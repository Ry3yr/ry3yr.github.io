<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the YouTube URL from the text box
    $youtubeUrl = $_POST["youtube_url"];

    // Create a new DOMDocument instance
    $dom = new DOMDocument();

    // Load the HTML content from the YouTube URL
    $dom->loadHTMLFile($youtubeUrl);

    // Create a new DOMXPath instance
    $xpath = new DOMXPath($dom);

    // Search for the itemprop="identifier" attribute
    $channelId = "";
    $channelIdNodes = $xpath->query('//meta[@itemprop="identifier"]/@content');
    if ($channelIdNodes->length > 0) {
        $channelId = $channelIdNodes[0]->nodeValue;
    }
    $channelId = substr_replace($channelId, "UU", 0, 2);
    $embedUrl = "https://www.youtube.com/embed/videoseries?list=" . $channelId;
}

    echo "Channel ID: " . $channelId;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Extract Channel ID</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="youtube_url">YouTube URL:</label>
        <input type="text" name="youtube_url" id="youtube_url">
        <input type="submit" value="Extract Channel ID">
    </form>

    <?php if (isset($embedUrl)) : ?>
        <iframe width="560" height="315" src="<?php echo $embedUrl; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
    <?php endif; ?>
</body>
</html>
