<?php
if (isset($_POST['submit'])) {
  $input = '';
  $url = isset($_POST['url']) ? $_POST['url'] : '';
  if ($url) {
    $input = strip_tags(file_get_contents($url));
  } else {
    $input = $_POST['input'];
  }
  $total = 0;
  $keyword = isset($_POST['keyword']) ? $_POST['keyword'] : '';
  $lines = explode("\n", $input);
  $matching_lines = array(); // initialize an array to collect matching lines
  $is_first_line = true; // flag to track whether the first line has been processed or not
  $replace_character = isset($_POST['replace_character']) ? $_POST['replace_character'] : '€'; // get the replace character from the form
  $remove_decimal = isset($_POST['remove_decimal']) ? true : false; // check if the "Remove Decimal" checkbox is checked
  $divide_by_100 = isset($_POST['divide_by_100']) ? true : false; // check if the "Divide by 100" checkbox is checked
  foreach ($lines as $line) {
    if (!$keyword || strpos($line, $keyword) !== false) {
      if ($is_first_line && $url) {
        $is_first_line = false; // set flag to false to skip the first matching line
        continue; // skip the first matching line
      }
      $line = str_replace($replace_character, '€', $line); // replace the specified character with € symbol
      if ($remove_decimal) {
        $line = preg_replace('/(\d+)[.,]\d+€/', '$1€', $line); // remove the decimal part (",xx" or ".xx") from values
      }
      preg_match_all('/(\d+)[€]/', $line, $matches);
      if ($matches) {
        foreach ($matches[1] as $match) {
          $value = $match;
          if ($divide_by_100) {
            if (strpos($value, '.') === false && strpos($value, ',') === false) {
              $value .= '00'; // add two zeros to values without a comma or period
            }
            $value = $value / 100; // divide the value by 100
          }
          $total += $value;
        }
      }
      // add the matching line to the array
      $matching_lines[] = $line;
    }
  }
  $replace_character_display = htmlentities($replace_character); // convert the replace character to HTML entities for display
  echo "Total value for '" . ($keyword ?: 'all') . "' lines: €" . $total . " (with replace character: " . $replace_character_display . ")";
}
?>
<form method="post" action="">
  <label for="url">URL:</label>
  <input type="text" name="url" id="url">
  <br>
  <textarea name="input"></textarea>
  <br>
  Keyword: <input type="text" name="keyword">
  <br>
  Replace Character: <input type="text" name="replace_character" value="€"> <!-- Add the replace character textbox with a default value of € -->
  <br>
  <label for="remove_decimal">Remove Decimal:</label>
  <input type="checkbox" name="remove_decimal" id="remove_decimal"> <!-- Add the "Remove Decimal" checkbox -->
  <br>
  <label for="divide_by_100">Divide by 100:</label>
  <input type="checkbox" name="divide_by_100" id="divide_by_100"> <!-- Add the "Divide by 100" checkbox -->
  <br>
  <button type="submit" name="submit">Calculate total</button>
</form>

<?php if (isset($matching_lines) && $keyword) : // output the matching lines section if there are matching lines and a keyword is set ?>
  <br>
  <h2>Matching lines:</h2>
  <ul>
    <?php foreach ($matching_lines as $line) : ?>
      <li><?php echo htmlentities($line); ?></li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>


<?php
//Allow or disallow source viewing
define("ALLOW_SOURCE", TRUE);
define("ALLOW_TITLE", TRUE);
if (ALLOW_SOURCE && isset($_GET['source'])) {
  highlight_file(__FILE__);
  exit(0);
}
?>


<a target="_blank" href="?source">Source Code</a>&nbsp; <a target="_blank" href="https://thinfi.com/0am60" style="color: transparent; text-decoration: none;">Bought</a>
<div class="pre-spoiler"><input name="Deutsch" type="button" onClick="if (this.parentNode.getElementsByTagName('div')[0].style.display != 'none') { this.parentNode.getElementsByTagName('div')[0].style.display = 'none'; this.value = 'ButtontextSpoiler'; } else { this.parentNode.getElementsByTagName('div')[0].style.display = 'block'; this.value = 'ButtontextSpoiler';}" value="ButtontextSpoiler" style="background:lightgray; border:none; color:transparent;"><div class="spoiler" style="display: none;" >
<!DOCTYPE html>
<html>
<head>
  <script>
    function fetchValues() {
  const inputText = document.getElementById('inputText').value;
  const regex = /-(\d+(?:,\d+)?)\s*EUR/g;
  const matches = Array.from(inputText.matchAll(regex), match => match[1]);
  let result = '';
  for (const value of matches) {
    result += value + '€<br>';
  }
  document.getElementById('result').innerHTML = result;
}
  </script>
</head>
<body>
  <textarea id="inputText" rows="10" cols="50" placeholder="Bank Saldo Fetch"></textarea><br>
  <button onclick="fetchValues()">Fetch Values</button><br>
  <div id="result"></div>
</body>
</html>
<div>
