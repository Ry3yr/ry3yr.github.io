<?php
function scanDirectories($dir)
{
    $fileList = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST,
        RecursiveIteratorIterator::CATCH_GET_CHILD // Ignore "Permission denied" errors
    );

    foreach ($iterator as $path => $fileInfo) {
        if ($fileInfo->isFile()) {
            $size = $fileInfo->getSize();
            $fileList[$size][] = $path;
        }
    }

    return $fileList;
}

function deleteFile($filePath)
{
    if (is_file($filePath)) {
        unlink($filePath);
        echo "Deleted: " . $filePath . "\n";
    }
}

// Usage example
$user = "alcea";
$rss_url = "https://urusai.social/@{$user}.rss";
$rss = simplexml_load_file($rss_url);
$image_url = (string) $rss->channel->image->url;
$filename = basename($image_url);

if (strpos($filename, '.jpg') !== false) {
    $filename = $user . '_' . date('Y-m-d') . '.jpg';
} elseif (strpos($filename, '.png') !== false) {
    $filename = $user . '_' . date('Y-m-d') . '.png';
} elseif (strpos($filename, '.gif') !== false) {
    $filename = $user . '_' . date('Y-m-d') . '.gif';
}

$dir = "./" . strtolower($user) . "/";
if (!file_exists($dir)) {
    mkdir($dir);
}

$fp = fopen($dir . $filename, 'wb');
$ch = curl_init($image_url);
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_exec($ch);
curl_close($ch);
fclose($fp);

$directory = getcwd(); // Set the starting path to the current directory
$fileList = scanDirectories($directory); // Scan the subdirectories from the current directory

$filesToDelete = [];

foreach ($fileList as $size => $files) {
    if (count($files) > 1) {
        $fileCount = count($files);
        for ($i = 1; $i < $fileCount; $i++) {
            $filePath = $files[$i];
            if (is_file($filePath)) {
                $filesToDelete[] = $filePath;
            }
        }
    }
}

if (count($filesToDelete) > 0) {
    echo "Found duplicate files:<br>";
    foreach ($filesToDelete as $filePath) {
        deleteFile($filePath);
    }
} else {
    echo "No duplicate files found.\n";
}
