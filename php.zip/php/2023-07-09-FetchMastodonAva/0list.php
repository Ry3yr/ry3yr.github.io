<div class="pre-spoiler"><input name="Deutsch" type="button" onClick="if (this.parentNode.getElementsByTagName('div')[0].style.display != 'none') { this.parentNode.getElementsByTagName('div')[0].style.display = 'none'; this.value = 'Mstdn'; } else { this.parentNode.getElementsByTagName('div')[0].style.display = 'block'; this.value = 'Mstdn';}" value="Mstdn" style="background:transparent; border:none; color:transparent;"><div class="spoiler" style="display: none;" >
<br><a target="_blank" href="alcea-pbtodonde.php">Refresh Alcea</a>&nbsp;
<br><a target="_blank" href="ao-yusaao.php">Refresh AoYusaao</a><br>
<a target="_blank" href="deldups.php">RMDups</a><br>
</div>

<?php
$dir = getcwd();
$websiteUrl = 'http';
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    $websiteUrl .= 's';
}
$websiteUrl .= '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
$images = glob($dir . '/**/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
// Sort the images array in reverse order
rsort($images);
$imageGroups = array();
foreach ($images as $image) {
    $dirName = dirname($image);
    $fileName = basename($image);
    if (!isset($imageGroups[$dirName])) {
        $imageGroups[$dirName] = array();
    }
    $imageGroups[$dirName][] = $fileName;
}
foreach ($imageGroups as $dirName => $images) {
    // Replace the directory path with the website URL
    $dirName = str_replace($dir, $websiteUrl, $dirName);
    echo '<h2>' . $dirName . '</h2>';
    foreach ($images as $image) {
        echo '<img src="' . $dirName . '/' . $image . '" width=400px>';
    }
}
?>
