<?php

// Retrieve the HTML content from the URL
$baseurl = 'https://www.alanwsmith.com';
$htmlContent = file_get_contents($baseurl);

// Create a DOMDocument object
$dom = new DOMDocument();
libxml_use_internal_errors(true); // Disable libxml errors
$dom->loadHTML($htmlContent);
libxml_clear_errors();

// Find all <li><a> elements
$links = $dom->getElementsByTagName('li');

// Create an array of link hrefs
$linkArray = [];
foreach ($links as $link) {
    $href = $link->getElementsByTagName('a')[0]->getAttribute('href');
    $decodedHref = html_entity_decode($href); // Decode HTML entities
    $linkArray[] = $decodedHref;
}

// Prepend baseurl to the linkArray
$linkArray = array_map(function ($link) use ($baseurl) {
    return $baseurl . $link;
}, $linkArray);

// Handle search request
$searchTerm = $_GET['searchTerm'] ?? '';
$filteredLinks = [];
if (!empty($searchTerm)) {
    $searchTerm = strtolower($searchTerm);

    // Filter the linkArray based on search term
    $filteredLinks = array_filter($linkArray, function ($link) use ($searchTerm) {
        return stripos(strtolower($link), $searchTerm) !== false;
    });
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Searchable Links</title>
</head>
<body>
    <input type="text" id="search-input" placeholder="Search Links">
    <ul id="search-results">
        <?php foreach ($filteredLinks as $link) : ?>
            <li><a href="<?php echo $link; ?>"><?php echo $link; ?></a></li>
        <?php endforeach; ?>
    </ul>

    <script>
        var searchInput = document.getElementById('search-input');
        var searchResults = document.getElementById('search-results');
        var linkArray = <?php echo json_encode($linkArray); ?>;

        searchInput.addEventListener('input', function () {
            var searchTerm = searchInput.value.toLowerCase();

            var filteredLinks = linkArray.filter(function (link) {
                return link.toLowerCase().includes(searchTerm);
            });

            searchResults.innerHTML = '';

            filteredLinks.forEach(function (link) {
                var li = document.createElement('li');
                var a = document.createElement('a');
                a.href = link;
                a.textContent = link;
                li.appendChild(a);
                searchResults.appendChild(li);
            });
        });
    </script>
</body>
</html>

<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
</body>
</html>