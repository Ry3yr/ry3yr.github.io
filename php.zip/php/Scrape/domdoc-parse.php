<?php
$html = <<<HTML
<div class="address adr">
    <span class="street-address"><span class="no_ds"> CONTENT1</span>
        <span class="postal-code">CONTENT2</span>
        <span class="locality">CONTENT3</span>
    /span>
</div>
HTML;

$dom = new DOMDocument;
$dom->loadHTML($html);
foreach ($dom->getElementsByTagName('div') as $tag) {
    echo $tag->getAttribute('class'), PHP_EOL;
}
?>

<!--https://stackoverflow.com/questions/22272777/how-does-preg-match-work-for-html-using-simple-html-dom-php-->