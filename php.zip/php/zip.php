<a target="_blank" href="2024-03-04-ZipSafetyCheck/0chck0bytefiles/chck0byte.php" style=color:blue>Check for 0b files</a>
<a target=_blank href=https://alcea-wisteria.de/PHP/0demo/php.zip>dld</a>
<br><br>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="filename" value="php.zip">
        <input type="submit" name="submit" value="Unlink php.zip">
    </form>
<?php
$url = '2024-03-05-ZipCurrDirWithExceptions/unchecked_paths.txt';
$fileContent = file_get_contents($url);
if ($fileContent !== false) {
    $lines = explode("\n", $fileContent);
    $filenames = array();
    echo '<ul>';
    foreach ($lines as $line) {
        $parts = explode('/', $line);
        $finalPart = end($parts);
        $filenames[] = $finalPart;
        echo '<li>' . htmlspecialchars($finalPart) . '</li>';
    }
    echo '</ul>';
    echo '<pre>';
    print_r($filenames);
    echo '</pre>';
    $zipFile = 'php.zip';
    $zip = new ZipArchive();
    if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        $baseDirectory = 'php';
        $relativeBasePath = $baseDirectory . '/';
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(
                __DIR__,
                RecursiveDirectoryIterator::SKIP_DOTS | RecursiveDirectoryIterator::FOLLOW_SYMLINKS
            ),
            RecursiveIteratorIterator::SELF_FIRST,
            RecursiveIteratorIterator::CATCH_GET_CHILD
        );
        foreach ($iterator as $file) {
            if ($file->isFile() && !in_array($file->getFilename(), $filenames)) {
                $filePath = $file->getPathname();
                $relativePath = $relativeBasePath . substr($filePath, strlen(__DIR__) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
        echo 'Zip archive created successfully.';
    } else {
        echo 'Failed to create the zip archive.';
    }
} else {
    echo 'Failed to read the file.';
}
?>
