<!DOCTYPE html>
<html>
<head>
  <title>DNS Resolver</title>
</head>
<body>
  <h1>DNS Resolver</h1>
  <form method="post" action="">
    <label for="url-input">Enter URL:</label>
    <input type="text" id="url-input" name="url" placeholder="example.com">
    <input type="checkbox" id="remove-path" name="remove_path" checked>
    <label for="remove-path">Remove Path</label>
    <button type="submit" name="submit">Resolve</button>
  </form>
  <div id="output">
    <?php
    function removeHttpProtocol($url) {
      return preg_replace('#^https?://#', '', $url);
    }

    if (isset($_POST['submit'])) {
      $url = $_POST['url'];
      $modifiedUrl = removeHttpProtocol($url); // Remove "http://" or "https://" from the URL
      echo '<p>Modified URL:</p>';
      
      if (isset($_POST['remove_path'])) {
        $url_parts = explode('/', $modifiedUrl);
        $modifiedUrl = $url_parts[0]; // Keep only the part before the first "/"
      }
      
      echo '<p>' . htmlspecialchars($modifiedUrl) . '</p>'; // Echo the modified URL

      $ip_addresses = dns_get_record($modifiedUrl, DNS_A);
      if ($ip_addresses) {
        echo '<p>IP Addresses:</p>';
        echo '<ul>';
        foreach ($ip_addresses as $record) {
          echo '<li><a target="_blank" href="http://' . $record['ip'] . '">' . $record['ip'] . '</a></li>';
        }
        echo '</ul>';
      } else {
        echo 'No IP addresses found for the provided URL.';
      }
    }
    ?>
  </div>
</body>
</html>