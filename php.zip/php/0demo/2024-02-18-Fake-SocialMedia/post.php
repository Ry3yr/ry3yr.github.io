<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the value from the textbox
    $value = $_POST["textbox"];
    // Retrieve the user from the URL query string
    $user = $_GET["user"];
    // Get the current date in Yyyymmdd format
    $date = date("Ymd");
    // Create an array with the new value and date
    $newData = array($date => array("value" => $value));

    // Extract hashtags from the post text
    $hashtags = array();
    preg_match_all('/#(\w+)/', $value, $matches);
    if (!empty($matches[1])) {
        $hashtags = $matches[1];
    }
    // Add the hashtags to the new data array
    if (!empty($hashtags)) {
        $newData[$date]["hashtags"] = implode(", ", $hashtags);
    }
    // Read the existing JSON data from the file
    $filename = "data_" . $user . ".json";
    if (file_exists($filename)) {
        $existingData = json_decode(file_get_contents($filename), true);
    } else {
        $existingData = array();
    }
    // Prepend the new data to the existing data
    array_unshift($existingData, $newData);
    // Save the updated data to the file
    file_put_contents($filename, json_encode($existingData, JSON_PRETTY_PRINT));
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Save to JSON</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"] . "?user=" . $_GET["user"]; ?>">
        <label for="textbox">Enter Value:</label>
        <br>
        <textarea id="textbox" name="textbox" rows="4" cols="50"></textarea>
        <br>
        <input type="submit" value="Save">
    </form>
</body>
</html>



<?php
$user = $_GET['user'];
$uniqueId = uniqid();
$iframeSrc = "data_{$user}.json?v={$uniqueId}";
echo '<iframe src="' . $iframeSrc . '" style="border:0px #ffffff none;" name="statusit" scrolling="no" frameborder="0" marginheight="0px" marginwidth="0px" height="250px" width="800" allowfullscreen></iframe>';
?>
