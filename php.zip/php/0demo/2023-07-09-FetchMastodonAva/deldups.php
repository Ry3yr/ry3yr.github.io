<?php
function scanDirectories($dir)
{
    $fileList = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST,
        RecursiveIteratorIterator::CATCH_GET_CHILD // Ignore "Permission denied" errors
    );

    foreach ($iterator as $path => $fileInfo) {
        if ($fileInfo->isFile()) {
            $size = $fileInfo->getSize();
            $fileList[$size][] = $path;
        }
    }

    return $fileList;
}

function deleteFile($filePath)
{
    if (is_file($filePath)) {
        unlink($filePath);
        echo "Deleted: " . $filePath . "\n";
    }
}

function deleteDuplicateFiles($dir)
{
    $currentDir = getcwd(); // Get the current working directory
    chdir($dir); // Change the current working directory to the specified directory
    $fileList = scanDirectories('.'); // Scan the subdirectories from the current directory

    $filesToDelete = [];

    foreach ($fileList as $size => $files) {
        if (count($files) > 1) {
            $fileCount = count($files);
            for ($i = 1; $i < $fileCount; $i++) {
                $filePath = $files[$i];
                if (is_file($filePath)) {
                    $filesToDelete[] = $filePath;
                }
            }
        }
    }

    if (count($filesToDelete) > 0) {
        echo "Found duplicate files:<br>";
        foreach ($filesToDelete as $filePath) {
            echo '<a href="?delete=' . urlencode($filePath) . '">' . $filePath . '</a><br>';
        }

        if (isset($_GET['delete'])) {
            $fileToDelete = urldecode($_GET['delete']);
            deleteFile($fileToDelete);
        }
    } else {
        echo "No duplicate files found.\n";
    }

    chdir($currentDir); // Change the working directory back to the original directory
}

// Usage example
$directory = getcwd(); // Set the starting path to the current directory
deleteDuplicateFiles($directory);
?>