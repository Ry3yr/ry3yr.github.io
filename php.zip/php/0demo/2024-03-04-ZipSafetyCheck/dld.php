<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the URL from the submitted form
    $url = $_POST['url'];

    // Parse the URL to extract the destination path
    $parsedUrl = parse_url($url);
    $destination = basename($parsedUrl['path']);

    $ch = curl_init($url);
    $fp = fopen($destination, "w");
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    curl_close($ch);
    fclose($fp);

    $zip = new ZipArchive;
    if ($zip->open($destination) === TRUE) {
        $extractFolder =  pathinfo($destination, PATHINFO_FILENAME);
        mkdir($extractFolder);
        $zip->extractTo($extractFolder);
        $zip->close();

        $output = generateDirectoryStructure($extractFolder);
        $outputFile = $extractFolder . "_" . date("Y-m-d") . ".txt";
        file_put_contents($outputFile, $output);

        echo "Directory structure and file sizes have been written to $outputFile.";

        // Remove the extracted folder
        removeDirectory($extractFolder);

        // Remove the ZIP file
        unlink($destination);
    } else {
        echo "Failed to open the ZIP file.";
    }
}

function generateDirectoryStructure($basePath, $level = 0)
{
    $output = "";
    $indent = str_repeat("  ", $level);

    $files = scandir($basePath);

    foreach ($files as $file) {
        if ($file != "." && $file != "..") {
            $path = $basePath . '/' . $file;

            if (is_dir($path)) {
                $output .= $indent . "- " . $file . " (Directory)\n";
                $output .= generateDirectoryStructure($path, $level + 1);
            } else {
                $output .= $indent . "- " . $file . " (Size: " . formatFileSize(filesize($path)) . ")\n";
            }
        }
    }

    return $output;
}

function formatFileSize($size)
{
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    $i = 0;

    while ($size >= 1024 && $i < count($units) - 1) {
        $size /= 1024;
        $i++;
    }

    return round($size, 2) . ' ' . $units[$i];
}

function removeDirectory($dir)
{
    if (is_dir($dir)) {
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file != "." && $file != "..") {
                $path = $dir . '/' . $file;
                if (is_dir($path)) {
                    removeDirectory($path);
                } else {
                    unlink($path);
                }
            }
        }
        rmdir($dir);
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>ZIP Extraction</title>
</head>
<body>
    <form method="POST" action="">
        <label for="url">URL:</label>
        <input type="text" name="url" id="url" value="https://ry3yr.github.io/php.zip" />
        <input type="submit" value="Extract" />
    </form>
</body>
</html>