<?php
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the YouTube API key from the user input
    $apiKey = $_POST['api_key'];

    // Create the API request URL
    $apiUrl = "https://www.googleapis.com/youtube/v3/search?key=$apiKey&part=id&type=video&q=test";

    // Make the API request
    $response = file_get_contents($apiUrl);

    // Check if the API request was successful
    if ($response !== false) {
        $responseData = json_decode($response, true);

        // Check if the response contains any error
        if (isset($responseData['error'])) {
            echo "Invalid API key. Error message: " . $responseData['error']['message'];
        } else {
            echo "Valid API key.";
        }
    } else {
        echo "Failed to connect to the YouTube Data API.";
    }
}
?>

<!-- HTML form for user input -->
<form method="POST" action="">
    <label for="api_key">YouTube API Key:</label>
    <input type="text" id="api_key" name="api_key" required>
    <button type="submit">Submit</button>
</form>