<?php
$username = "ryedai1";
if (isset($_GET['dauser'])) {
    $queryUsername = $_GET['dauser'];
    if (!empty($queryUsername)) {
        $username = $queryUsername;
    }
}
$url = "https://www.deviantart.com/$username/gallery/";
$html = file_get_contents($url);
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($html);
$xpath = new DOMXPath($dom);
$query = '//a[@data-hook="deviation_link"]';

$links = $xpath->query($query);

$uniqueLinks = [];
foreach ($links as $link) {
    $href = $link->getAttribute('href');
    if (!in_array($href, $uniqueLinks)) {
        $uniqueLinks[] = $href;
        $htmlLink = '<a href="' . $href . '" target="_blank">' . $href . '</a>';
        echo $htmlLink . "<br>";
        
        $deviationHTML = file_get_contents($href);  // Fetch the HTML content of the indidial deviation page
        $deviationDOM = new DOMDocument();
        libxml_use_internal_errors(true);
        $deviationDOM->loadHTML($deviationHTML);
        $deviationXPath = new DOMXPath($deviationDOM);
        $deviationImgQuery = '//img[contains(@src, "https://images-wixmp")]';
        $deviationImg = $deviationXPath->query($deviationImgQuery)->item(0);
        if ($deviationImg) {
            $imgSrc = $deviationImg->getAttribute('src');
            $htmlImg = '<img src="' . $imgSrc . '">';
            echo $htmlImg . "<br>";
        }
    }
}
?>
