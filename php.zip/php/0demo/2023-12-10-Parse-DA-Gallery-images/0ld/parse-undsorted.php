<?php
// Replace 'ryedai1' with the desired DeviantArt account name
$accountName = 'ryedai1';

// URL of the DeviantArt gallery page
$url = 'https://www.deviantart.com/' . $accountName . '/gallery/';

// Create a new DOMDocument instance
$dom = new DOMDocument();

// Load the HTML content from the gallery page
$dom->loadHTMLFile($url);

// Find all image elements in the DOM
$imageElements = $dom->getElementsByTagName('img');

// Array to store unique image URLs
$uniqueImageUrls = [];

// Iterate over the image elements
foreach ($imageElements as $imageElement) {
    // Get the source attribute of the image
    $imageSrc = $imageElement->getAttribute('src');

    // Ignore links containing "st.deviantart" and "a.deviantart"
    if (strpos($imageSrc, 'st.deviantart') !== false || strpos($imageSrc, 'a.deviantart') !== false) {
        continue;
    }

    // Check if the image URL is a duplicate using fuzziness
    $isDuplicate = false;

    foreach ($uniqueImageUrls as $uniqueUrl) {
        // Calculate the similarity score between the image URLs
        $similarity = similar_text($uniqueUrl, $imageSrc, $percent);

        // Set a threshold for similarity (adjust as needed)
        $similarityThreshold = 85;

        // If the similarity score is above the threshold, consider it a duplicate
        if ($percent > $similarityThreshold) {
            $isDuplicate = true;
            break;
        }
    }

    // If it's not a duplicate, add it to the unique image URLs array and display the image as a target_blank link
    if (!$isDuplicate) {
        $uniqueImageUrls[] = $imageSrc;
        echo "<a href='$imageSrc' target='_blank'><img src='$imageSrc'></a>";
        echo '<br>';
    }
}

// Array to store unique data-hook links
$uniqueDataHookLinks = [];

// Find all anchor elements in the DOM
$anchorElements = $dom->getElementsByTagName('a');

// Iterate over the anchor elements
foreach ($anchorElements as $anchorElement) {
    // Get the data-hook attribute value
    $dataHookValue = $anchorElement->getAttribute('data-hook');

    // Check if the data-hook attribute value is "deviation_link"
    if ($dataHookValue === 'deviation_link') {
        // Get the href attribute value
        $hrefValue = $anchorElement->getAttribute('href');

        // Ignore duplicate data-hook links
        if (in_array($hrefValue, $uniqueDataHookLinks)) {
            continue;
        }

        // Add the href value to the unique data-hook links array and display it as a target_blank link
        $uniqueDataHookLinks[] = $hrefValue;
        echo "<a href='$hrefValue' target='_blank'>$hrefValue</a>";
        echo '<br>';
    }
}

?>