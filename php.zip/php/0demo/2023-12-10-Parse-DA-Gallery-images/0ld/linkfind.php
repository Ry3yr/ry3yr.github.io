<?php
// User's DeviantArt username
$username = "ryedai1";

// URL of the user's DeviantArt gallery
$url = "https://www.deviantart.com/$username/gallery/";

// Fetch the HTML content of the gallery page
$html = file_get_contents($url);

// Create a DOM document
$dom = new DOMDocument();
libxml_use_internal_errors(true);

// Load the HTML content into the DOM document
$dom->loadHTML($html);

// Create a DOMXPath object
$xpath = new DOMXPath($dom);

// XPath query to select all <a> elements with data-hook attribute set to "deviation_link"
$query = '//a[@data-hook="deviation_link"]';

// Execute the XPath query
$links = $xpath->query($query);

// Array to store unique links
$uniqueLinks = [];

// Loop through the matched links
foreach ($links as $link) {
    $href = $link->getAttribute('href');
    
    // Check if the link is already in the array
    if (!in_array($href, $uniqueLinks)) {
        // Add the link to the array of unique links
        $uniqueLinks[] = $href;
        
        // Generate the <a> tag with target="_blank" attribute
        $htmlLink = '<a href="' . $href . '" target="_blank">' . $href . '</a>';
        
        // Display the generated link
        echo $htmlLink . "<br>";
    }
}
?>