<?php
$url = 'dauserinfo.html';
$content = file_get_contents($url);

// Search for lines containing the desired information
$lines = explode("\n", $content);
$matchingLines = [];
$keywords = ['[prettyName]', '[url]', '[comments]',  '[favourites]', '[views]', '[downloads]'];

foreach ($lines as $line) {
    foreach ($keywords as $keyword) {
        if (strpos($line, $keyword) !== false) {
            $line = str_replace('u002F', '', $line);
            $matchingLines[] = $line;
            break;
        }
    }
}

// Display the matching lines
foreach ($matchingLines as $line) {
    echo $line . '<br>';
}
?>