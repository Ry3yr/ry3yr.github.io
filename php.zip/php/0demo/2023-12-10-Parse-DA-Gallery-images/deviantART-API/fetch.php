aoikurayami1 <a target="_blank" href="?artist=aoikurayami1&galleryid=87908428" style=color:blue>other</a><br>
ryedai1 <a target="_blank" href="?artist=ryedai1&galleryid=83209853" style=color:blue>VRAINS</a> <a target="_blank" href="?artist=ryedai1&galleryid=90829331" style=color:blue>RNR</a> <a target="_blank" href="?artist=ryedai1&galleryid=83734114" style=color:blue>Animations</a>

<br><br>


<link rel="stylesheet" type="text/css" href="styles.css" />
<div class="deviations">
<?php
    require_once('getDeviations.php');
    $artist = $_GET['artist'];
    $galleryid = $_GET['galleryid'];
    $deviations = getDeviations("https://backend.deviantart.com/rss.xml?q=gallery:{$artist}/{$galleryid}");
    foreach($deviations as $key => $deviation): ?>
        <div class="deviation">
            <div class="col col-p">
                <a target=_blank href="<?= $deviations[$key]->url; ?>"><h2><?= $deviations[$key]->title; ?></h2></a>
                <img src="<?= $deviations[$key]->image; ?>" alt="<?= $deviations[$key]->title; ?>" class="deviation_image"/>
                <p>Thumbnail src: <a target=_blank href="<?= $deviations[$key]->thumbS; ?>">150px</a> | <a target=_blank href="<?= $deviations[$key]->thumbL; ?>">300px</a>
            </div>
            <div class="col col-s">
                <h2>Deviation Info</h2>
                <p><small><?= $deviations[$key]->date; ?></small></p>
                <p><strong><?= $deviations[$key]->desc; ?></strong></p>
                <p>Rating: <?= $deviations[$key]->rating; ?></p>
                <p>Category: <a target=_blank href="http://browse.deviantart.com/<?= $deviations[$key]->categoryUrl; ?>"><?= $deviations[$key]->category; ?></a></p>
                <p>By <a target=_blank href="<?= $deviations[$key]->deviantUrl; ?>"><?= $deviations[$key]->deviantName; ?></a></p>
                <img src="<?= $deviations[$key]->deviantAvatar; ?>"/>
                <p><?= $deviations[$key]->copyright; ?></p>
            </div>
        </div>
<?php endforeach; ?>
