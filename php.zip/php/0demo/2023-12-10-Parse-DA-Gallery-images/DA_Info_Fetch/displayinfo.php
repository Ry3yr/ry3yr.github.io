<?php
// Get the username from the URL query string
$username = $_GET['username'];
$url = 'dauserinfo_' . $username . '.html';
// Retrieve the content from the URL
$content = file_get_contents($url);
$lines = explode("\n", $content);
$matchingLines = [];
$keywords = ['[url]', '[comments]', '[favourites]', '[views]', '[publishedTime]'];

foreach ($lines as $line) {
    foreach ($keywords as $keyword) {
        if (strpos($line, $keyword) !== false) {
            if ($keyword === '[url]' && strpos($line, $username) === false) {
            //if ($keyword === '[url]' && strpos($line, 'art') === false) {
                break;
            }
            $matchingLines[$line] = true;
            break;
        }
    }
}
// Display the matching lines
foreach ($matchingLines as $line => $value) {
    echo $line . '<br>';
}
?>