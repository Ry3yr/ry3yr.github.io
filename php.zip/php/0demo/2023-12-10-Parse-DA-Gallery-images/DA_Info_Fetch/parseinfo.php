<?php
ob_start();
$ch = curl_init();
$username = $_GET['username']; // Get the username from the query string
$url = 'https://www.deviantart.com/' . $username . '/gallery'; // Use the username in the URL
$userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36';
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
$response = curl_exec($ch);
curl_close($ch);
$regex = '/window\.__INITIAL_STATE__ = (.*);$/m';
preg_match($regex, $response, $matches);
$json = $matches[1];
$json = str_replace('JSON.parse("', '', $json);
$json = substr($json, 0, -2);
$json = str_replace('\"', '"', $json);
$data = json_decode($json, true);
if (isset($data['comments']['threaded']['results'])) {
    $comments = $data['comments']['threaded']['results'];
    foreach ($comments as $comment) {
        $commentId = $comment['commentId'];
        $commentBody = $comment['body'];
        echo "Comment ID: $commentId\n";
        echo "Comment Body: $commentBody\n";
        echo "----------------\n";
    }
}
echo "<pre>";
echo "Data:\n";
print_r($data);
echo "</pre>";
file_put_contents('dauserinfo_' . $username . '.html', ob_get_contents());
?>


<!--<  ?php
$url = 'dauserinfo.html';
$content = file_get_contents($url);
// Search for lines containing the desired information
$lines = explode("\n", $content);
$matchingLines = [];
$keywords = ['[prettyName]', '[comments]',  '[favourites]', '[views]', '[downloads]'];
foreach ($lines as $line) {
    foreach ($keywords as $keyword) {
        if (strpos($line, $keyword) !== false) {
            $matchingLines[] = $line;
            break;
        }
    }
}
// Display the matching lines
foreach ($matchingLines as $line) {
    echo $line . '<br>';
}
?>-->
