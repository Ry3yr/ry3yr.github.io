<?php
// Default DeviantArt username
$username = "aoikurayami1";

// Check if the "dauser" query string parameter is set
if (isset($_GET['dauser'])) {
    // Get the value of "dauser" query string parameter
    $queryUsername = $_GET['dauser'];
    
    // Validate and assign the new username if it's not empty
    if (!empty($queryUsername)) {
        $username = $queryUsername;
    }
}

// URL of the user's DeviantArt gallery
$url = "https://www.deviantart.com/$username/gallery/";

// Fetch the HTML content of the gallery page
$html = file_get_contents($url);

// Create a DOM document
$dom = new DOMDocument();
libxml_use_internal_errors(true);

// Load the HTML content into the DOM document
$dom->loadHTML($html);

// Create a DOMXPath object
$xpath = new DOMXPath($dom);

// XPath query to select all <a> elements with data-hook attribute set to "deviation_link"
$query = '//a[@data-hook="deviation_link"]';

// Execute the XPath query
$links = $xpath->query($query);

// Array to store unique links
$uniqueLinks = [];

// Loop through the matched links
foreach ($links as $link) {
    $href = $link->getAttribute('href');
    
    // Check if the link is already in the array
    if (!in_array($href, $uniqueLinks)) {
        // Add the link to the array of unique links
        $uniqueLinks[] = $href;
        
        // Generate the <a> tag with target="_blank" attribute
        $htmlLink = '<a href="' . $href . '" target="_blank">' . $href . '</a>';
        
        // Display the generated link
        echo $htmlLink . "<br>";
        
        // Fetch the HTML content of the individual deviation page
        $deviationHTML = file_get_contents($href);
        
        // Create a new DOM document for the individual deviation page
        $deviationDOM = new DOMDocument();
        libxml_use_internal_errors(true);
        
        // Load the HTML content into the DOM document
        $deviationDOM->loadHTML($deviationHTML);
        
        // Create a new DOMXPath object for the individual deviation page
        $deviationXPath = new DOMXPath($deviationDOM);
        
        // XPath query to select the <img> tag with src attribute containing "https://images-wixmp"
        $deviationImgQuery = '//img[contains(@src, "https://images-wixmp")]';
        
        // Execute the XPath query on the individual deviation page
        $deviationImg = $deviationXPath->query($deviationImgQuery)->item(0);
        
        // Check if the <img> tag is found
        if ($deviationImg) {
            // Get the src attribute value
            $imgSrc = $deviationImg->getAttribute('src');
            
            // Generate the <img> tag to embed the image
            $htmlImg = '<img src="' . $imgSrc . '">';
            
            // Display the embedded image
            echo $htmlImg . "<br>";
        }
    }
}
?>
