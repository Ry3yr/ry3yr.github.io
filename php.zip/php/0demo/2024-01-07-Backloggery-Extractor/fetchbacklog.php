<!--https://github.com/jimmyhillis/backloggery/blob/master/src/bin/cli.js-->

<?php
if (isset($_GET['user'])) {
    // Sanitize and prepare the user input
    $user = urlencode($_GET['user']);
    $url = 'https://backloggery.com/' . $user;
    $baseurl = 'https://backloggery.com';

    // Get the HTML content from the URL
    $html = file_get_contents($url);

    // Check if the user page exists
    if ($html !== false) {
        // Create a DOMDocument object
        $dom = new DOMDocument();
        libxml_use_internal_errors(true); // Disable libxml errors

        // Load the HTML content into the DOMDocument object
        $dom->loadHTML($html);
        libxml_clear_errors();

        // Create a DOMXPath object to query the DOMDocument
        $xpath = new DOMXPath($dom);

        // Extract game systems
        $gameSystems = [];
        $systemsTable = $xpath->query('//table[@id="sysgrid"]');
        if ($systemsTable->length > 0) {
            $rows = $systemsTable[0]->getElementsByTagName('tr');

            foreach ($rows as $row) {
                $systemElement = $row->getElementsByTagName('a')->item(0);
                if ($systemElement) {
                    $system = $systemElement->nodeValue;
                    $totalGames = $row->lastChild->nodeValue;
                    $href = $baseurl . '/' . $systemElement->getAttribute('href');
                    $gameSystems[$system] = [
                        'totalGames' => $totalGames,
                        'href' => $href
                    ];
                }
            }
        }

        // Output the extracted data
        echo "Game Systems for User: " . $user . "<br>";
        foreach ($gameSystems as $system => $data) {
            $totalGames = $data['totalGames'];
            $href = $data['href'];
            echo '<a href="' . $href . '" target="_blank">' . $system . '</a>: ' . $totalGames . "<br>";
        }
    } else {
        echo "User not found.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Backloggery Game Systems</title>
</head>
<body>
    <form method="GET" action="">
        <input type="text" name="user" placeholder="Enter Backloggery username">
        <input type="submit" value="Search">
