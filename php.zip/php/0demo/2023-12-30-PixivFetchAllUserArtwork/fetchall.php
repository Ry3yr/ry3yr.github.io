<a target="_blank" href="?userId=18233080" style="color:blue">custom</a> <a target="_blank" href="?random" style="color:blue">(Random)</a><br>


<div id="linkCount"></div><br>

<?php
function getPixivUserArt($userId, $random) {
    $apiUrl = "https://www.pixiv.net/ajax/user/{$userId}/profile/all?useid={$userId}";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    if (isset($data['body']['illusts'])) {
        $artworks = $data['body']['illusts'];
        $numLinks = 0; // Variable to keep track of the number of links

        if ($random) {
            // Get a random artwork
            $randomArtId = array_rand($artworks);
            $randomArt = $artworks[$randomArtId];
            $artLink = "https://www.pixiv.net/artworks/{$randomArtId}";
            echo "Link: <a target=_blank href=\"{$artLink}\">{$artLink}</a><br>\n";
            $numLinks++; // Increment the link counter
        } else {
            foreach ($artworks as $artId => $art) {
                $artLink = "https://www.pixiv.net/artworks/{$artId}";
                echo "Link: <a target=_blank href=\"{$artLink}\">{$artLink}</a><br>\n";
                $numLinks++; // Increment the link counter
            }
        }

        // Display the number of links found within the div
        echo "<script>document.getElementById('linkCount').innerHTML = 'Number of artworks: $numLinks';</script>";
    } else {
        echo "No artworks found for the given user.";
    }
}

// Usage example
$userId = isset($_GET['userId']) ? $_GET['userId'] : '75406576';
$random = isset($_GET['random']);
getPixivUserArt($userId, $random);
?>