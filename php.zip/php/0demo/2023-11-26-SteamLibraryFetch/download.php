<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['libraryData'])) {
    $libraryData = $_POST['libraryData'];

    // Set the appropriate headers for file download
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="steam_library.json"');

    // Output the library data as a JSON file
    echo $libraryData;
    exit;
  }
}

// Redirect back to the previous page if the library data is not available
header('Location: ' . $_SERVER['HTTP_REFERER']);