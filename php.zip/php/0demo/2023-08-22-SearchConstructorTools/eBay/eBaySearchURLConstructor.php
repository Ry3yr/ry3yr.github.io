<html>
<head>
    <title>eBay Search</title>
</head>
<body>
    <h1>eBay Search</h1>
    <form method="GET" action="">
        <label for="query">Search Query:</label>
        <input type="text" name="query" id="query" required><br><br>
        
        <label for="country">Country:</label>
        <select name="country" id="country">
            <option value="EBAY-US">United States</option>
            <option value="EBAY-UK">United Kingdom</option>
            <option value="EBAY-AU">Australia</option>
            <option value="EBAY-DE">Germany</option>
            <!-- Add more country options here -->
        </select><br><br>
        
        <label for="sortBy">Sort By:</label>
        <select name="sortBy" id="sortBy">
            <option value="BestMatch">Best Match</option>
            <option value="15">Price + Shipping: Lowest First</option>
            <option value="16">Price + Shipping: Highest First</option>
            <!-- Add more sorting options here -->
        </select><br><br>
        
        <label for="buyNow">Buy Now/Bid:</label>
        <select name="buyNow" id="buyNow">
            <option value="BuyNow">Buy Now</option>
            <option value="Auction">Bid</option>
        </select><br><br>
        
        <label for="minPrice">Minimum Price:</label>
        <input type="number" name="minPrice" id="minPrice"><br><br>
        
        <label for="maxPrice">Maximum Price:</label>
        <input type="number" name="maxPrice" id="maxPrice"><br><br>
        
        <label for="preferredLocation">Preferred Location:</label>
        <select name="preferredLocation" id="preferredLocation">
            <option value="">Any</option>
            <option value="1">Home</option>
            <option value="2">Worldwide</option>
            <option value="3">EU</option>
            <!-- Add more preferred location options here -->
        </select><br><br>
        
        <input type="submit" value="Search">
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['query'])) {
            $query = $_GET['query'];
            $country = $_GET['country'];
            $sortBy = $_GET['sortBy'];
            $buyNow = $_GET['buyNow'];
            $minPrice = $_GET['minPrice'];
            $maxPrice = $_GET['maxPrice'];
            $preferredLocation = $_GET['preferredLocation'];

            // Construct the search URL
            $baseUrl = '';
            if ($country === 'EBAY-DE') {
                $baseUrl = 'https://www.ebay.de';
            } else if ($country === 'EBAY-UK') {
                $baseUrl = 'https://www.ebay.co.uk';
            } else {
                $baseUrl = 'https://www.ebay.com';
            }

            $sortingOption = '';
            if ($sortBy === '15') {
                $sortingOption = '&_sop=15';
            } else if ($sortBy === '16') {
                $sortingOption = '&_sop=16';
            }

            $priceOption = '';
            if ($minPrice !== '') {
                $priceOption .= '&_udlo=' . $minPrice;
            }
            if ($maxPrice !== '') {
                $priceOption .= '&_udhi=' . $maxPrice;
            }

            $prefLocationOption = '';
            if ($preferredLocation !== '') {
                $prefLocationOption .= '&LH_PrefLoc=' . $preferredLocation;
            }

            $searchUrl = $baseUrl . '/sch/i.html?_nkw=' . urlencode($query) .
                '&_ipg=50' .
                $sortingOption .
                '&LH_BIN=' . ($buyNow === 'BuyNow' ? '1' : '0') .
                '&LH_LocatedIn=' . urlencode($country) .
                $priceOption .
                $prefLocationOption;

            // Display the search URL
            echo '<h2>Search URL:</h2>';
            echo '<a href="' . $searchUrl . '" target="_blank">' . $searchUrl . '</a>';
        }
    }
    ?>
</body>
</html>