<a href="?search=https://sunny.garden/@Iva852/109293246960188756&pbUrl=https://pb.todon.de&apikey=apikey">test</a><br>



<?php
// Check if the API key is submitted
if (isset($_POST['apikey'])) {
    $apiKey = $_POST['apikey'];
    $pbUrl = $_POST['pbUrl'];
    $search = $_POST['url'];
    $url = $pbUrl . '/api/v2/search/?q=' . urlencode($search) . '&limit=1&resolve=true';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error: ' . curl_error($ch);
    }
    curl_close($ch);
    $data = json_decode($response, true);
    if (isset($data['statuses'][0]['id'])) {
        $id = $data['statuses'][0]['id'];
        $urlParts = parse_url($search);
        $pathParts = explode('/', trim($urlParts['path'], '/'));
        $username = $pathParts[0];
        $domain = $urlParts['host'];
        $newUrl = $pbUrl . '/' . $username . '@' . $domain . '/' . $id;
        echo 'New URL: <a id="newUrlLink" href="' . $newUrl . '">' . $newUrl . '</a>';
echo '<script>document.getElementById("newUrlLink").click();</script>';
    } else {
        echo 'Please enter a URL';
        echo '<br>cURL Result: ' . $response;
        echo '<br>' . $url;
        echo '<br><a target="_blank" href="https://codepen.io/ryedai1/full/WNYZBya">Lookup</a>';
    }
}
?>

<!-- HTML form to input the API key, $pbUrl, and URL -->
<form method="POST" action="">
    <label for="apikey">API Key:</label>
    <input type="text" id="apikey" name="apikey" required>
    <br>
    <label for="pbUrl">pbUrl:</label>
    <input type="text" id="pbUrl" name="pbUrl" required>
    <br>
    <label for="url">URL:</label>
    <input type="text" id="url" name="url" pattern="https://.*" required>
    <input type="submit" value="Submit">
</form>

<script>
  window.onload = function () {
    const urlParams = new URLSearchParams(window.location.search);
    const search = urlParams.get("search");
    const pbUrl = urlParams.get("pbUrl");
    const apiKey = urlParams.get("apikey");
    if (search && pbUrl && apiKey) {
      document.getElementById("apikey").value = apiKey;
      document.getElementById("pbUrl").value = pbUrl;
      if (search.includes("http")) {document.getElementById("url").value = search;}
      // Check if query parameter 'submitted' is present
      if (!urlParams.has("submitted")) {
        // Add 'submitted' query parameter to prevent resubmission
        urlParams.set("submitted", "true");
        const newUrl = window.location.pathname + "?" + urlParams.toString();
        window.history.replaceState(null, null, newUrl);
        document.forms[0].submit();
      }
    }
    const observer = new MutationObserver(function (mutationsList) {
      for (let mutation of mutationsList) {
        if (
          mutation.type === "childList" &&
          mutation.addedNodes.length > 0
        ) {
          const newUrlElements = document.querySelectorAll(
            'body :not(script):not(style):not(link):not(meta):not(base):not(title):contains("New URL:")'
          );
          for (let element of newUrlElements) {
            const linkElement = element.nextElementSibling;
            if (linkElement.tagName === "A") {
              linkElement.addEventListener("click", function (event) {
                event.preventDefault();
                window.open(linkElement.href, "_blank");
              });
            }
          }
        }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  };
</script>


<!----FillFromClipboard--->
    <button class="button" onclick="fillTextbox()">Fill Textbox</button>
<script>
    function fillTextbox() {
        navigator.clipboard.readText().then(function(clipboardText) {
            document.getElementById("url").value = clipboardText;
            var submitButton = document.querySelector('input[type="submit"], button[type="submit"]');
            submitButton?.click();
        }).catch(function(error) {
            console.error('Failed to read clipboard contents: ', error);
        });
    }
</script><br>



<?php
    //Allow or disallow source viewing
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
