<?php
// Get the URL, price, title, and query strings from the query parameters
$url = isset($_GET['url']) ? $_GET['url'] : '';
$price = $_GET['price'];
$title = $_GET['title'];

// Check if ebayurl is present
if (isset($_GET['ebayurl']) && !isset($_GET['url'])) {
    $url = $_GET['ebayurl'];
    $marketplace = 'ebay';
} else {
    $marketplace = '';
}

// Get the current date
$date = date('Y-m-d');

// Load the existing buylist JSON file
$buylistFile = 'buylist.json';
$currentBuylist = [];
if (file_exists($buylistFile)) {
    $currentBuylist = json_decode(file_get_contents($buylistFile), true);
}

// Check if the entry with the same date and title already exists
$isDuplicate = false;
foreach ($currentBuylist as $item) {
    if ($item['date'] === $date && $item['title'] === $title) {
        $isDuplicate = true;
        break;
    }
}

// Add the new item to the buylist if it's not a duplicate
if (!$isDuplicate) {
    // Create a new item for the buylist
    $newItem = [
        'url' => $url,
        'price' => $price,
        'title' => $title,
        'marketplace' => $marketplace,
        'date' => $date
    ];

    // Prepend the new item to the buylist
    array_unshift($currentBuylist, $newItem);

    // Save the updated buylist back to the JSON file with pretty formatting
    file_put_contents($buylistFile, json_encode($currentBuylist, JSON_PRETTY_PRINT));

    // Output a success message
    echo 'Item added to the <a target=_blank href=buylist.json>buylist</a>!';
} else {
    // Output a message indicating that the item is a duplicate
    echo 'Item is a duplicate and not added to the <a target=_blank href=buylist.json>buylist</a>.';
}
?>
