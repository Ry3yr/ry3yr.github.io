<?php
// Get the URL from the query string parameter
$url = isset($_GET['url']) ? $_GET['url'] : '';

// Check if the URL is provided
if (empty($url)) {
    echo 'URL parameter is missing.';
    exit;
}

// Initialize cURL
$curl = curl_init();

// Set cURL options
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36');

// Execute the cURL request
$response = curl_exec($curl);

// Check if the request was successful
if ($response === false) {
    echo 'Error: ' . curl_error($curl);
    exit;
}

// Close the cURL session
curl_close($curl);

// Extract the page title
$pageTitle = '';
if (preg_match('/<title>(.*?)<\/title>/', $response, $matches)) {
    $pageTitle = $matches[1];
}

// Search for the specific string in the HTML content to extract the currency and price
$searchString = ',"priceCurrency":"';
$pos = strpos($response, $searchString);

// Extract the currency and price
$currency = '';
$price = '';
if ($pos !== false) {
    $currencyStartPos = $pos + strlen($searchString);
    $currencyEndPos = strpos($response, '"', $currencyStartPos);
    $currency = substr($response, $currencyStartPos, $currencyEndPos - $currencyStartPos);

    $priceSearchString = ',"price":"';
    $pricePos = strpos($response, $priceSearchString, $currencyEndPos);
    if ($pricePos !== false) {
        $priceStartPos = $pricePos + strlen($priceSearchString);
        $priceEndPos = strpos($response, '"', $priceStartPos);
        $price = substr($response, $priceStartPos, $priceEndPos - $priceStartPos);
    }
}

// Construct the URL for write.php and open it as a URL
$writeUrl = 'write.php?ebayurl=' . urlencode($url) . '&title=' . urlencode($pageTitle) . '&price=' . urlencode($price . ' ' . $currency);

// Open the URL
header('Location: ' . $writeUrl);
exit;
?>