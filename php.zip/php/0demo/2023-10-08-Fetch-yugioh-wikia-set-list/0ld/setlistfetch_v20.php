<!DOCTYPE html>
<html>
<head>
    <title>Table Sorting</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<button id="sort_by_name_button">Sort by Name</button>
<button id="sort_by_category_button">Sort by Category</button>
    <script>
        function sortTableRowsByName() {
            var $tableRows = $('.table-row');

            $tableRows.sort(function(a, b) {
                var aValue = $(a).data('sort-value');
                var bValue = $(b).data('sort-value');
                return aValue.localeCompare(bValue);
            });

            $('.table-body').empty().append($tableRows);
        }

        function sortTableRowsByCategory() {
            var $tableRows = $('.table-row');

            $tableRows.sort(function(a, b) {
                var aValue = $(a).data('sort-category');
                var bValue = $(b).data('sort-category');
                return aValue.localeCompare(bValue);
            });

            $('.table-body').empty().append($tableRows);
        }

        $(document).on('click', '#sort_by_name_button', function() {
            sortTableRowsByName();
        });

        $(document).on('click', '#sort_by_category_button', function() {
            sortTableRowsByCategory();
        });
    </script>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="url">Enter the URL:</label>
        <input type="text" name="url" id="url" required>
        <input type="submit" value="Retrieve">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $url = $_POST['url'];

        $doc = new DOMDocument();
        $doc->loadHTMLFile($url);

        $xpath = new DOMXPath($doc);
        $table = $xpath->query('//table[@id="Top_table"]')->item(0);

        if ($table) {
            $parsedUrl = parse_url($url);
            $baseUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];

            $tableRows = [];

            $rows = $table->getElementsByTagName('tr');
            foreach ($rows as $row) {
                $cells = $row->getElementsByTagName('td');

                if ($cells->length >= 3) {
                    $nameCell = $cells->item(1);
                    $nameLink = $nameCell->getElementsByTagName('a')->item(0);
                    $name = '';
                    $nameUrl = '';
                    if ($nameLink) {
                        $name = trim($nameLink->textContent);
                        $nameRelativeUrl = $nameLink->getAttribute('href');
                        $nameUrl = $baseUrl . $nameRelativeUrl;
                    }

                    $categoryCell = $cells->item(3);
                    $category = '';
                    if ($categoryCell) {
                        $category = trim($categoryCell->textContent);
                    }

                    $tableRows[] = [
                        'name' => $name,
                        'category' => $category,
                        'nameUrl' => $nameUrl
                    ];
                }
            }

            echo '<div class="table-body">';
            foreach ($tableRows as $row) {
                echo '<div class="table-row" data-sort-value="' . $row['name'] . '" data-sort-category="' . $row['category'] . '">';
                echo 'Name: <a href="' . $row['nameUrl'] . '" target="_blank">' . $row['name'] . '</a> | Category: ' . $row['category'];
                echo '</div>';
            }
            echo '</div>';

            //echo '<button id="sort_by_name_button">Sort by Name</button>';
            //echo '<button id="sort_by_category_button">Sort by Category</button>';
        } else {
            echo "Table not found.";
        }
    }
    ?>
</body>
</html>