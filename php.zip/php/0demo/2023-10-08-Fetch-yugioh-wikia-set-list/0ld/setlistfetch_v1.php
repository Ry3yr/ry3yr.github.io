    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="url">Enter the URL:</label>
        <input type="text" name="url" id="url" required>
        <input type="submit" value="Retrieve">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the URL from user input
        $url = $_POST['url'];

        // Create a new DOMDocument object
        $doc = new DOMDocument();

        // Load the HTML content from the URL
        $doc->loadHTMLFile($url);

        // Create a new DOMXPath object
        $xpath = new DOMXPath($doc);

        // Find the table element with the id "Top_table"
        $table = $xpath->query('//table[@id="Top_table"]')->item(0);

        // Check if the table exists
        if ($table) {
            // Get the base URL from the user input
            $parsedUrl = parse_url($url);
            $baseUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];

            // Iterate over the rows of the table
            $rows = $table->getElementsByTagName('tr');
            foreach ($rows as $row) {
                // Get the cells in each row
                $cells = $row->getElementsByTagName('td');

                // Check if row contains the required number of cells
                if ($cells->length >= 3) {
                    // Extract the "name" and "category" values from the cells
                    $nameCell = $cells->item(1);
                    $nameLink = $nameCell->getElementsByTagName('a')->item(0);
                    $name = '';
                    $nameUrl = '';
                    if ($nameLink) {
                        $name = trim($nameLink->textContent);
                        $nameRelativeUrl = $nameLink->getAttribute('href');
                        $nameUrl = $baseUrl . $nameRelativeUrl;
                    }

                    $categoryCell = $cells->item(3);
                    $category = '';
                    if ($categoryCell) {
                        $category = trim($categoryCell->textContent);
                    }

                    // Print the "name" and "category" values with the link
                    echo "Name: <a href=\"$nameUrl\" target=\"_blank\">$name</a><br>";
                    echo "Category: $category<br><br>";
                }
            }
        } else {
            echo "Table not found.";
        }
    }
    ?>
</body>
</html>