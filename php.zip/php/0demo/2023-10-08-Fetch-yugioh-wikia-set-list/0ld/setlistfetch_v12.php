<!DOCTYPE html>
<html>
<head>
    <title>Table Sorting</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="url">Enter the URL:</label>
        <input type="text" name="url" id="url" required>
        <br><br>
        <label for="sort_option">Sort by:</label>
        <select name="sort_option" id="sort_option">
            <option value="name">Name</option>
            <option value="category">Category</option>
        </select>
        <br><br>
        <input type="submit" value="Retrieve">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the URL from user input
        $url = $_POST['url'];

        // Create a new DOMDocument object
        $doc = new DOMDocument();

        // Load the HTML content from the URL
        $doc->loadHTMLFile($url);

        // Create a new DOMXPath object
        $xpath = new DOMXPath($doc);

        // Find the table element with the id "Top_table"
        $table = $xpath->query('//table[@id="Top_table"]')->item(0);

        // Check if the table exists
        if ($table) {
            // Get the base URL from the user input
            $parsedUrl = parse_url($url);
            $baseUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];

            // Create an array to store the table rows
            $tableRows = [];

            // Iterate over the rows of the table
            $rows = $table->getElementsByTagName('tr');
            foreach ($rows as $row) {
                // Get the cells in each row
                $cells = $row->getElementsByTagName('td');

                // Check if row contains the required number of cells
                if ($cells->length >= 3) {
                    // Extract the "name" and "category" values from the cells
                    $nameCell = $cells->item(1);
                    $nameLink = $nameCell->getElementsByTagName('a')->item(0);
                    $name = '';
                    $nameUrl = '';
                    if ($nameLink) {
                        $name = trim($nameLink->textContent);
                        $nameRelativeUrl = $nameLink->getAttribute('href');
                        $nameUrl = $baseUrl . $nameRelativeUrl;
                    }

                    $categoryCell = $cells->item(3);
                    $category = '';
                    if ($categoryCell) {
                        $category = trim($categoryCell->textContent);
                    }

                    // Store the "name" and "category" values in an array
                    $tableRows[] = [
                        'name' => $name,
                        'category' => $category,
                        'nameUrl' => $nameUrl
                    ];
                }
            }

            // Sort the table rows based on the selected option
            $sortOption = $_POST['sort_option'];
            if ($sortOption === 'name') {
                usort($tableRows, function($a, $b) {
                    return strcmp($a['name'], $b['name']);
                });
            } elseif ($sortOption === 'category') {
                usort($tableRows, function($a, $b) {
                    return strcmp($a['category'], $b['category']);
                });
            }

            // Print the sorted table rows
            foreach ($tableRows as $row) {
                echo "Name: <a href=\"" . $row['nameUrl'] . "\" target=\"_blank\">" . $row['name'] . "</a> | Category: " . $row['category'] . "<br><br>";
            }
        } else {
            echo "Table not found.";
        }
    }
    ?>
</body>
</html>