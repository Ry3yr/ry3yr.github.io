
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $targetURL = $_POST['url']; // Get the URL from the submitted form
    $html = file_get_contents($targetURL);
    $dom = new DOMDocument();
    $dom->loadHTML($html);
    $linkElements = $dom->getElementsByTagName('a');
    $data = [];
    foreach ($linkElements as $index => $linkElement) {
        if ($linkElement->getAttribute('class') === 'main-link') {
            $href = $linkElement->getAttribute('href');
            $absoluteURL = makeAbsoluteURL($targetURL, $href);
            $text = $linkElement->nodeValue;
            $linkHTML = '<a href="' . $absoluteURL . '" target="_blank">' . $text . '</a>';
            $detailsHTML = '';
            $detailsElement = $linkElement->nextSibling;
            while ($detailsElement && $detailsElement->nodeName !== 'ul' && $detailsElement !== $linkElement) {
                $detailsHTML .= $dom->saveHTML($detailsElement);
                $detailsElement = $detailsElement->nextSibling;
            }
            $linkHTMLContent = file_get_contents($absoluteURL);
            $linkDOM = new DOMDocument();
            $linkDOM->loadHTML($linkHTMLContent);
            $downloadSize = '';
            $liElements = $linkDOM->getElementsByTagName('li');
            foreach ($liElements as $liElement) {
                if ($liElement->getAttribute('class') === 'list-group-item') {
                    $strongElement = $liElement->getElementsByTagName('strong')->item(0);
                    if ($strongElement && $strongElement->nodeValue === 'Download size:') {
                        $downloadSize = trim($liElement->textContent);
                        break;
                    }
                }
            }
            $data[] = [
                'Link' => $linkHTML,
                'Details' => $detailsHTML,
                'DownloadSize' => $downloadSize
            ];
        }
    }
    foreach ($data as $item) {
        echo $item['Link'] . '<br>';
        echo $item['Details'] . '<br>';
        echo $item['DownloadSize'] . '<br><br>';
    }
}
function makeAbsoluteURL($baseURL, $relativeURL) {
    $parsedBaseURL = parse_url($baseURL);
    $scheme = $parsedBaseURL['scheme'];
    $host = $parsedBaseURL['host'];
    $basePath = isset($parsedBaseURL['path']) ? $parsedBaseURL['path'] : '';
    if (substr($relativeURL, 0, 2) === '//') {
        return $scheme . ':' . $relativeURL;
    } elseif (substr($relativeURL, 0, 1) === '/') {
        return $scheme . '://' . $host . $relativeURL;
    } else {
        return $scheme . '://' . $host . $basePath . '/' . $relativeURL;
    }
}
?>


 <a href="#" data-url="https://www.dekudeals.com/highest-rated">Highly Rated</a>
  <a href="#" data-url="https://www.dekudeals.com/recently-released">Recently Released</a>
  <a href="#" data-url="https://www.dekudeals.com/recent-drops">Recent Price Drops</a>
  <a href="#" data-url="https://www.dekudeals.com/bang-for-your-buck">Bang for your Buck</a>
  <a href="#" data-url="https://www.dekudeals.com/upcoming-releases">Upcoming Releases</a>
    <form method="POST">
        <input type="text" name="url" placeholder="Enter URL" required>
        <button type="submit">Submit</button>
    </form>
    <?php
    if (isset($data)) {
        foreach ($data as $item) {
            echo $item['Link'] . '<br>';
            echo $item['Details'] . '<br>';
            echo $item['DownloadSize'] . '<br><br>';}}
    ?>
<script>
    //Fill textbox
    var inputElement = document.querySelector('input[name="url"]');
    var linkElements = document.querySelectorAll('a[data-url]');
    linkElements.forEach(function(linkElement) {
      linkElement.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent the default link behavior
        var clickedUrl = linkElement.getAttribute('data-url');
        inputElement.value = clickedUrl; });});
  </script>
