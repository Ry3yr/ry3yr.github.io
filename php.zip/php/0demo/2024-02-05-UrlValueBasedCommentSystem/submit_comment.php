<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $url = $_SERVER["HTTP_REFERER"]; // Get the current URL
  $filename = preg_replace("/[^A-Za-z0-9]/", "", $url); // Remove non-alphanumeric characters from the URL
  $name = $_POST["name"]; // Get the submitted name
  $comment = $_POST["comment"]; // Get the submitted comment
  $jsonFilename = $_POST["jsonFilename"]; // Get the submitted jsonFilename

  // Read the existing JSON data from the file
  $existingData = file_get_contents($jsonFilename);
  $existingJson = json_decode($existingData, true);

  if (!$existingJson) {
    // If the JSON file doesn't exist or is not valid JSON, create an empty array
    $existingJson = [];
  }

  // Create a new data entry with the submitted name and comment
  $newData = array(
    "name" => $name,
    "comment" => $comment
  );

  // Append the new data to the existing JSON data
  $existingJson[] = $newData;

  // Encode the merged data as JSON
  $json = json_encode($existingJson);

  // Write the updated JSON back to the file
  file_put_contents($jsonFilename, $json);

  echo "<a href=javascript:history.back()>[View Comment]</a>";
}
?>