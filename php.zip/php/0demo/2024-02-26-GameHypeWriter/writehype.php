<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    //$gameName = str_pad($_POST['gamename'], 45, '_');
    $gameName = $_POST['gamename'];
    $url = $_POST['url'];
    $moreInfo = $_POST['moreinfo'];
    $releaseDate = $_POST['releasedate'];
    $rating = $_POST['rating'];
    $system = $_POST['system'];
    $underscoreCount = max(0, 45 - strlen($gameName));
    $padded = str_repeat('_', $underscoreCount);

    // Remove commas and periods from the rating
    $rating = str_replace(',', '', $rating);
    $rating = str_replace('.', '', $rating);

    // Convert rating to a number between 1 and 10
    $rating = max(1, min(10, $rating));

    // Generate the rating image HTML
    $ratingImages = "";
    for ($i = 1; $i <= 10; $i++) {
    $class = ($i <= $rating) ? "filled" : "greyed";
    $style = ($i > $rating) ? "filter: grayscale(100%);" : "";
    $ratingImages .= "<img class='$class' style='$style' src='https://alcea-wisteria.de/z_files/emoji/ablobdj.gif' alt='Rating' width='20px'>";
    }

    // Create the game link
    $gameLink = "<a target=_blank href='$url'>$gameName</a>";

    // Format the game information
    $gameInfo = "
        <tr>
            <td>$releaseDate</td>
            <td>$gameLink</td>
            <td>$padded</td>
            <td>$moreInfo</td>
            <td>$ratingImages</td>
            <td>$system</td>
        </tr>
    ";

    // Read the existing content of game.html
    $existingContent = file_get_contents("game.html");

    // Prepend the game information to the existing content
    $newContent = "
        <table>
            <tr>
            </tr>
            $gameInfo
            <tr><td colspan='5' style='border-bottom: 1px solid black;'></td></tr>
            $existingContent
        </table>
    ";

    // Write the updated content back to game.html
    file_put_contents("game.html", $newContent);
}
?>

<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="gamename">Game Name:</label>
        <input type="text" id="gamename" name="gamename" required><br>

        <label for="url">URL:</label>
        <input type="text" id="url" name="url" required><br>

        <label for="moreinfo">More Info:</label>
        <input type="text" id="moreinfo" name="moreinfo" required><br>

        <label for="releasedate">Release Date:</label>
        <input type="date" id="releasedate" name="releasedate" value="<?php echo date('Y-m-d'); ?>" required><br>

        <label for="rating">Rating:</label>
        <input type="number" id="rating" name="rating" min="1" max="10" required><br>

        <label for="system">System:</label>
        <select id="system" name="system" required>
            <option value="NSwitch">NSwitch</option>
            <option value="PS4">PS4</option>
            <option value="PC">PC</option>
        </select><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
