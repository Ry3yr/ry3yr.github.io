<?php
// URL of the webpage
$url = 'https://aoikurayami.imgbb.com/';
$html = file_get_contents($url);
$pattern = '/ibb\.co\/[^\/"\']+/'; // Updated pattern
preg_match_all($pattern, $html, $matches);
$ibbcoLinks = array_unique($matches[0]); // Remove duplicates
foreach ($ibbcoLinks as $link) {
    echo $link . "<br>";

    // Find i.ibb.co links within each $link
    $innerHtml = file_get_contents($link);
    $innerPattern = '/i\.ibb\.co\/[^"\']+/';
    preg_match_all($innerPattern, $innerHtml, $innerMatches);
    $iibbcoLinks = $innerMatches[0];
    foreach ($iibbcoLinks as $innerLink) {
        echo $innerLink . "<br>";
    }
}
?>