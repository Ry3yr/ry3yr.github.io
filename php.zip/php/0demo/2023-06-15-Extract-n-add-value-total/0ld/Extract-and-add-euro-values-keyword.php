<?php
if(isset($_POST['submit'])) {
  $input = $_POST['input'];
  $total = 0;
  $keyword = isset($_POST['keyword']) ? $_POST['keyword'] : '';
  $lines = explode("\n", $input);
  foreach($lines as $line) {
    if (!$keyword || strpos($line, $keyword) !== false) {
      preg_match_all('/(\d+)[€]/', $line, $matches);
      if ($matches) {
        foreach($matches[1] as $match) {
          $total += $match;
        }
      }
    }
  }
  echo "Total value for '".($keyword ?: 'all')."' lines: €".$total;
}
?>
<form method="post" action="">
  <textarea name="input"></textarea>
  <br>
  Keyword: <input type="text" name="keyword">
  <br>
  <button type="submit" name="submit">Calculate total</button>
</form>