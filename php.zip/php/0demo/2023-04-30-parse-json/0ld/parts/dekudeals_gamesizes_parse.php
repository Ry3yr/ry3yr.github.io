Using https://ry3yr.github.io/OSTR/Diarykeepers_Homepage/collection.json as base..<br><br>

<?php
// Fetch the JSON data from the URL
$jsonData = file_get_contents('https://ry3yr.github.io/OSTR/Diarykeepers_Homepage/collection.json');

// Decode the JSON data into an associative array
$data = json_decode($jsonData, true);

// Check if the JSON decoding was successful
if ($data !== null) {
    // Iterate over each item in the collection
    foreach ($data['items'] as $item) {
        // Check if the item has a "link" key
        if (isset($item['link'])) {
            // Fetch the content of the URL
            $url = $item['link'];
            $html = file_get_contents($url);

            // Create a DOMDocument object and load the HTML content
            $dom = new DOMDocument();
            @$dom->loadHTML($html);

            // Create a DOMXPath object to query the HTML
            $xpath = new DOMXPath($dom);

            // Find the download size element using XPath
            $query = "//strong[contains(text(), 'Download size:')]/following-sibling::text()";
            $downloadSize = $xpath->query($query)->item(0)->nodeValue;

            // Output the extracted value
            echo "Size for {$item['link']}: {$downloadSize}<br>";
        }
    }
} else {
    // JSON decoding failed
    echo "Failed to decode JSON data.";
}
?>