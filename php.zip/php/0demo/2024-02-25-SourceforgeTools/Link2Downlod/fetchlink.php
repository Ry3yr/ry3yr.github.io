<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $url = $_POST['url'];

    if (strpos($url, 'download') === false) {
        $modifiedUrl = rtrim($url, '/') . '/files/latest/download';

        if (isset($_POST['choice']) && $_POST['choice'] === 'yes') {
            $ch = curl_init($modifiedUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);

            if ($response === false) {
                die('Error occurred: ' . curl_error($ch));
            }

            $urls = array();
            preg_match_all('/(https?:\/\/[^\s]+)/', $response, $urls);

            echo "Extracted URLs:<br>";
            foreach ($urls[0] as $url) {
                $cleanUrl = $url;
                $pos = strpos($url, '>');
                if ($pos !== false) {
                    $cleanUrl = substr($url, 0, $pos);
                }
                echo '<a href="' . htmlspecialchars($cleanUrl) . '" target="_blank">' . htmlspecialchars($cleanUrl) . '</a><br>';
            }

            curl_close($ch);
            exit(); // Stop execution after processing the cURL request
        }

        ?>
        Modified URL: <?php echo $modifiedUrl; ?><br>
        Do you want to continue?<br>
        <form method="post" action="">
            <input type="hidden" name="url" value="<?php echo htmlspecialchars($modifiedUrl); ?>">
            <button type="submit" name="choice" value="yes">Yes</button>
        </form>
        <form method="post" action="">
            <button type="submit" name="choice" value="no" onclick="window.location.href = window.location.href">No</button>
        </form>
        <?php
        exit(); // Stop execution until the user provides a choice
    } else {
        $modifiedUrl = $url;
    }

    $ch = curl_init($modifiedUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);

    if ($response === false) {
        die('Error occurred: ' . curl_error($ch));
    }
    $urls = array();
    preg_match_all('/(https?:\/\/[^\s]+)/', $response, $urls);
    echo "Extracted URLs:<br>";
    foreach ($urls[0] as $url) {
        $cleanUrl = $url;
        $pos = strpos($url, '>');
        if ($pos !== false) {
            $cleanUrl = substr($url, 0, $pos);
        }
        echo '<a href="' . htmlspecialchars($cleanUrl) . '" target="_blank">' . htmlspecialchars($cleanUrl) . '</a><br>';
    }

    curl_close($ch);
    exit(); // Stop execution after processing the cURL request
}
?>

<form method="post" action="">
    <label for="url">Enter URL:</label>
    <input type="text" name="url" id="url" required>
    <button type="submit">Submit</button>
</form>
