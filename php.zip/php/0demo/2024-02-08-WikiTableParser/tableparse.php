<a target="_blank" href="?tablecolumn=Firm&tablecontent=Nintendo" style=color:blue>txmpl</a><br><br>

<?php
header('Content-Type: text/html; charset=utf-8');
$url = 'https://en.m.wikipedia.org/wiki/List_of_best-selling_game_consoles';
$html = file_get_contents($url);
$table_regex = '/<table[^>]*class="wikitable sortable"[^>]*>(.*?)<\/table>/s';
if (preg_match($table_regex, $html, $matches)) {
    $table_html = $matches[0];
    $column = $_GET['tablecolumn'] ?? '';
    $content = $_GET['tablecontent'] ?? '';
    if (!empty($column) && !empty($content)) {
        $filtered_table_html = filterTable($table_html, $column, $content);
        if ($filtered_table_html) {
            echo $filtered_table_html;
        } else {
            echo 'No matching rows found.';
        }
    } else {
        echo $table_html;
    }
    addCopyButtons();
} else {
    echo 'Table not found.';
}

/**
 * Filters the table rows based on the specified column and content.
 *
 * @param string $tableHtml The HTML content of the table.
 * @param string $column    The column name to filter on.
 * @param string $content   The content to filter by.
 *
 * @return string|false The filtered table HTML, or false if no matches are found.
 */
function filterTable($tableHtml, $column, $content)
{
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML(mb_convert_encoding($tableHtml, 'HTML-ENTITIES', 'UTF-8'));
    libxml_clear_errors();
    $xpath = new DOMXPath($dom);
    $rows = $xpath->query('//table/tbody/tr');
    $columnIndex = -1;
    $headerRow = $rows->item(0);
    $headerCells = $headerRow->getElementsByTagName('th');
    foreach ($headerCells as $index => $cell) {
        if (trim($cell->nodeValue) === $column) {
            $columnIndex = $index;
            break;
        }
    }
    $filteredRows = [];
    foreach ($rows as $row) {
        $cells = $row->getElementsByTagName('td');
        $cellContent = $cells->item($columnIndex)->nodeValue;
        if (stripos($cellContent, $content) !== false) {
            $filteredRows[] = $row;
        }
    }

    // Build the filtered table HTML
    $filteredTableHtml = '<table class="wikitable sortable">';
    $filteredTableHtml .= $headerRow->ownerDocument->saveHTML($headerRow);
    foreach ($filteredRows as $row) {
        $filteredTableHtml .= $row->ownerDocument->saveHTML($row);
    }
    $filteredTableHtml .= '</table>';

    return count($filteredRows) > 0 ? $filteredTableHtml : false;
}

function addCopyButtons() {
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    global $table_html;
    $dom->loadHTML($table_html);
    libxml_clear_errors();
    $xpath = new DOMXPath($dom);
    $headerRow = $xpath->query('//table/tbody/tr[1]')->item(0);
    $headerCells = $headerRow->getElementsByTagName('th');
    echo '<div>';
    foreach ($headerCells as $index => $cell) {
        $columnName = trim($cell->nodeValue);
        echo '<button onclick="copyColumnData(' . $index . ')">Copy ' . $columnName . '</button>';
    }
    echo '</div>';
}
?>

<script>
// Function to copy the column data to the clipboard
function copyColumnData(columnIndex) {
  var table = document.querySelector('.wikitable');
  var columnData = '';
  var rows = table.getElementsByTagName('tr');
  for (var i = 0; i < rows.length; i++) {
    var row = rows[i];
    var cells = row.getElementsByTagName('td');
    var cell = cells[columnIndex];
    if (cell) {
      columnData += cell.innerText.trim() + '\n';
    }
  }
  navigator.clipboard.writeText(columnData);
  //alert('Column data copied to clipboard.');
}
</script>


<!---ChartJS-->
<!DOCTYPE html>
<html>
<head>
  <title>Dynamic Chart Plotting</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <textarea id="dataInput" rows="10" cols="50"></textarea>
  <button onclick="plotChart()">Plot Chart</button>
  <canvas id="myChart"></canvas>

  <script>
    function plotChart() {
      // Get the data from the textarea
      const inputData = document.getElementById('dataInput').value;

      // Split the input data into separate lines
      const lines = inputData.split('\n');

      // Arrays for labels and data
      const labels = [];
      const data = [];

      // Parse the input data and extract labels and data
      lines.forEach(line => {
        const columns = line.split('\t');
        if (columns.length >= 6) {
          const label = columns[0];
          const value = parseFloat(columns[4]);
          labels.push(label);
          data.push(value);
        }
      });

      // Create a chart using Chart.js
      const ctx = document.getElementById('myChart').getContext('2d');
      const chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{
            label: 'Units Sold',
            data: data,
            backgroundColor: 'rgba(75, 192, 192, 0.5)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    }
  </script>
</body>
