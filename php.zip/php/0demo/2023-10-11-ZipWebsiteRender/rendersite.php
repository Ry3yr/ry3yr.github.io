 <?php
$files = glob("*.zip"); // Get all zip files in the current folder
if (!empty($files)) {
    $zipFile = $files[0]; // Assuming you want to delete the first zip file found
    unlink($zipFile);
   // echo "The zip file '$zipFile' has been deleted.";
} else {
    //echo "No zip files found in the current folder.";
}
?>



   <form method="post" action="">
        <label for="zipUrl">Enter ZIP URL:</label>
        <input type="text" name="zipUrl" id="zipUrl" value="http://ry3yr.github.io/alceawis.de.zip" required>
        <br>
        <!---<label for="downloadPath">Download Path:</label>--->
        <!--<input type="text" name="downloadPath" id="downloadPath" placeholder="Enter download path (optional)">-->
        <br>
        <input type="submit" name="download" value="Download and Render">
    </form>
    <?php
    if (isset($_POST['download'])) {
        $url = $_POST['zipUrl'];
        $filename = basename($url);
        // Check if the download path textbox is filled
        if (!empty($_POST['downloadPath'])) {
            $downloadPath = $_POST['downloadPath'];
            $filename = $downloadPath . '/' . $filename;
        }
        else {
            $filename = './' . $filename; // Set a default path if download path is not specified
        }
        // Validate the URL
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            try {
                // Use cURL to download the file
                $ch = curl_init($url);
                $fp = fopen($filename, 'w');
                curl_setopt($ch, CURLOPT_FILE, $fp);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
                curl_setopt($ch, CURLOPT_MAXREDIRS, 5); // Maximum number of redirects to follow
                curl_exec($ch);
                // Check if the download was successful
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($httpCode == 200) {
                    $message = "File downloaded successfully.";
                } else {
                    $message = "Failed to download the file. HTTP code: " . $httpCode;
                }
                curl_close($ch);
                fclose($fp);
            } catch (Exception $e) {
                $message = "An error occurred during the download: " . $e->getMessage();
            }
            // Check for cURL errors
            if (curl_errno($ch)) {
                $message = "cURL error: " . curl_error($ch);
            }
        } else {
            $message = "Invalid URL.";
        }
    }
    ?>
    <p><?php echo $message ?? ''; ?></p>
</body>
</html>


<?php
$zipFiles = glob("*.zip"); // Get all ZIP files in the current directory
if (!empty($zipFiles)) {
    $extractPath = "website"; // Destination folder
    // Make sure the extraction path exists
    if (!is_dir($extractPath)) {
        mkdir($extractPath, 0777, true);
    }
    foreach ($zipFiles as $zipFile) {
        $zip = new ZipArchive;
        if ($zip->open($zipFile) === TRUE) {
            // Extract the files directly into the destination folder
            $zip->extractTo($extractPath);
            $zip->close();
            //echo "ZIP file '$zipFile' extracted successfully.<br>";
        } else {
            echo "Failed to open the ZIP file '$zipFile'.<br>";
        }
    }
} else {
    echo "No ZIP files found in the current directory.";
}
?>


<?php
$websiteFolder = "website"; // Replace with the name of the "website" folder
// Check if the "website" folder exists
if (is_dir($websiteFolder)) {
    // Get the first subfolder inside the "website" folder
    $subfolders = glob($websiteFolder . '/*', GLOB_ONLYDIR);
    if (!empty($subfolders)) {
        $firstSubfolder = $subfolders[0];
        // Find the "index.html" file inside the subfolder
        $indexFile = $firstSubfolder . '/index.html';
        if (file_exists($indexFile)) {
            // Open the "index.html" file as a URL in a new tab or window
            //echo '<script>window.open("' . $indexFile . '", "_blank");</script>';
        } else {
            echo 'The "index.html" file was not found.';
        }
    } else {
        echo 'No subfolders found inside the "website" folder.';
    }
} else {
    echo 'The "website" folder does not exist.';
}
?>


<!---last-site-->
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $websiteFolder = 'website';
    // Retrieve the subfolders within the website folder
    $subfolders = array_diff(scandir($websiteFolder), array('..', '.'));
    // Get the first subfolder
    $firstSubfolder = reset($subfolders);
    $indexUrl = $websiteFolder . '/' . $firstSubfolder . '/index.html';
    echo '<a href="' . $indexUrl . '" target="_blank">Open ' . $indexUrl . '</a>';
}
?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <button type="submit">Get First Subfolder</button>
</form>
