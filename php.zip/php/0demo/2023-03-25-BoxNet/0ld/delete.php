<?php
unlink("yourpage.html");
?> 

DELETED yourpage.html !

<?php echo "<script>window.close();</script>"; ?>