<?php
function getFolderSize($folderPath) {
    $totalSize = 0;
    $files = glob(rtrim($folderPath, '/') . '/*');
    foreach ($files as $file) {
        if (is_file($file)) {
            $totalSize += filesize($file);
        }
        if (is_dir($file)) {
            $totalSize += getFolderSize($file);
        }
    }
    return $totalSize;
}
$currentDir = __DIR__;
if (isset($_POST['submit'])) {
    $selectedFolders = $_POST['folders'];
    $fileLists = [];
    foreach ($selectedFolders as $folder) {
        $folderPath = $currentDir . '/' . $folder;
        //$files = glob($folderPath . '/*.txt');
        $files = glob($folderPath . '/*');
        $fileNames = array_map('basename', $files);
        $fileLists[$folder] = $fileNames;
    }
    echo '<table>';
    echo '<tr>';
    echo '<th>File Name</th>';
    // Display folder names as table headers
    foreach ($selectedFolders as $folder) {
        echo '<th>' . $folder . '</th>';
    }
    echo '</tr>';
    $allFiles = array_reduce($fileLists, 'array_merge', []);
    $uniqueFiles = array_unique($allFiles);
    foreach ($uniqueFiles as $fileName) {
        echo '<tr>';
        echo '<td>' . $fileName . '</td>';
        $firstFolder = $selectedFolders[0];
        $firstFolderPath = $currentDir . '/' . $firstFolder;
        $firstFilePath = $firstFolderPath . '/' . $fileName;
        $firstFileSize = file_exists($firstFilePath) ? filesize($firstFilePath) : 0;
        foreach ($selectedFolders as $folder) {
            $folderPath = $currentDir . '/' . $folder;
            $filePath = $folderPath . '/' . $fileName;
            if (file_exists($filePath)) {
                $fileSize = filesize($filePath);
                echo '<td>';
                if ($fileSize === $firstFileSize) {
                    echo '<a target="_blank" href="" style=color:green>[OK]</a>';
                } elseif ($fileSize > $firstFileSize) {
                    echo '<a target="_blank" href="" style=color:darkgreen>[OK - GREATER]</a>';
                } else {
                    echo '<a target="_blank" href="" style=color:red>[NO - LESSER]</a>';
                }
                echo ' ' . $fileSize . ' bytes</td>';
            } else {
                echo '<td>-</td>'; // Display "-" for missing files
            }
        }
        echo '</tr>';
    }
    echo '</table>';
}
// Get the folders in the current directory
$folders = array_filter(glob('*'), 'is_dir');
echo '<form method="post">';
foreach ($folders as $index => $folder) {
    $checked = ($index === 0) ? 'checked' : '';
    echo '<input type="checkbox" name="folders[]" value="' . $folder . '" ' . $checked . '>' . $folder . '<br>';
    $folderPath = $currentDir . '/' . $folder;
    $folderSize = getFolderSize($folderPath);
    echo '<input type="hidden" name="folder_sizes[' . $folder . ']" value="' . $folderSize . '">';
}
echo '<input type="submit" name="submit" value="Submit">';
echo '</form>';
?>
<a target="_blank" href="download.php" style=color:transparent>DLD</a>
