<?php
$currentDirectory = getcwd();
$deletedFolders = [];

// Step 1: Retrieve a list of all directories in the current directory
$directories = glob($currentDirectory . '/*', GLOB_ONLYDIR);

// Step 2: Filter out directories that match the yyyy-mm-dd format
$filteredDirectories = array_filter($directories, function($directory) {
    return preg_match('/\d{4}-\d{2}-\d{2}/', basename($directory));
});

// Step 3: Sort the remaining directories in ascending order
usort($filteredDirectories, function($a, $b) {
    return filemtime($a) - filemtime($b);
});

// Step 4: Delete all directories except the newest one
$directoriesToDelete = array_slice($filteredDirectories, 0, -1);
foreach ($directoriesToDelete as $directory) {
    // Recursive deletion to delete all files and subdirectories within the directory
    $files = glob($directory . '/*');
    foreach ($files as $file) {
        unlink($file);
    }
    rmdir($directory);
    $deletedFolders[] = basename($directory);
}

// Display the deleted folders
if (!empty($deletedFolders)) {
    echo "Deleted folders: " . implode(", ", $deletedFolders);
} else {
    echo "No folders were deleted.";
}
?>