<?php
$html = file_get_contents('https://alceawis.de/other/Computerstuff/Commands/');
$pattern = '/<tr>(.*?)<\/tr>/s';
preg_match_all($pattern, $html, $matches);

$urls = array();

foreach ($matches[1] as $match) {
    preg_match('/<a href="(.*?)">/', $match, $urlMatch);
    if (isset($urlMatch[1])) {
        $url = $urlMatch[1];
        if (pathinfo($url, PATHINFO_EXTENSION) === "txt") {
            $urls[] = 'https://alceawis.de' . $url;
        }
    }
}

$destinationFolder = date("Y-m-d");
if (!is_dir($destinationFolder)) {
    mkdir($destinationFolder);
}

// Download the .txt files
$downloadedFiles = array();

foreach ($urls as $url) {
    $fileName = basename($url);
    $destinationPath = $destinationFolder . '/' . $fileName;
    file_put_contents($destinationPath, file_get_contents($url));
    $downloadedFiles[] = $destinationPath;
}

// Output the downloaded .txt files as links in the DOM
echo '<ul>';
foreach ($downloadedFiles as $filePath) {
    echo '<li><a href="' . $filePath . '">' . basename($filePath) . '</a></li>';
}
echo '</ul>';

echo 'Download completed.';
?>