<?php
$url = 'https://urusai.social/api/v1/accounts/111417582756052979/statuses';
$parsedUrl = parse_url($url);
$domain = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
// Fetch data from the URL
$response = file_get_contents($url);
if ($response === false) {
    echo 'Error: Unable to fetch data.';
    exit;
}
$previewCards = extractPreviewCardLinks($response);
$html = generateImageTags($previewCards, $domain);
echo 'Domain: ' . $domain . '<br>';
echo 'Preview Card Images:<br>';
echo $html;
function extractPreviewCardLinks($responseText)
{
    //$pattern = '/\/system\/cache\/preview_cards\/images\/\d+\/\d+\/\d+\/original\/[a-f0-9]+\.(?:jpg|jpeg|png|gif)/i';  //normal masstodon
        $pattern = '/\/cache\/preview_cards\/images\/\d{3}\/\d{3}\/\d{3}\/original\/[a-f0-9]+\.(?:jpg|jpeg|png|gif)/i';     //glitchfork suchas urusai.social
         preg_match_all($pattern, $responseText, $matches);


    return $matches[0] ?? [];
}
function generateImageTags($imageUrls, $domain)
{
    $html = '';
    foreach ($imageUrls as $imageUrl) {
        $domain = " https://files.urusai.social";
        $html .= '<img src="' .$domain . $imageUrl . '" alt="Preview Card Image"><br>';
    }

    return $html;
}
