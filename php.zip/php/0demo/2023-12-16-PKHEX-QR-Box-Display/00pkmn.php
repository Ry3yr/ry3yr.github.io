<!DOCTYPE html>
<html>
<head>
    <style>
        .grid {
            display: grid;
            grid-template-columns: repeat(10, 1fr);
            //grid-column-gap: -50px;
            grid-row-gap: 20px; /* Spaces between grid elements on the y-axis */
        }
        .grid .image {
            width: 45px;
            height: 45px;
            background-size: 800% 800%;
            background-repeat: no-repeat;
            background-position: center -137px;
            cursor: pointer;
            transition: transform 0.2s;
            position: relative;
            margin-right: -5px;
        }
        .grid .image:hover {
            transform: scale(2);
            z-index: 2; //always hover above
        }
        .pokemon-name {
            position: absolute;
            bottom: -20px;
            left: 0;
            width: 100%;
            text-align: center;
            font-size: 12px;
        }
        #iframe-container {
            position: fixed;
            bottom: 10px;
            right: 10px;
            width: 300px;
            height: 200px;
            background-color: #f2f2f2;
        }
        #image-preview {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
    </style>
</head>
<body>
    <div class="grid">
        <?php
        $folder = 'pkmn';
        $files = glob($folder . '/*.jpg');
        foreach ($files as $file) {
            $filename = basename($file);
            $pokemonName = substr($filename, 0, strpos($filename, '_'));
            echo '<div class="image" style="background-image: url(\'' . $file . '\');" onclick="displayImage(\'' . $file . '\')">';
            echo '<div class="pokemon-name">' . $pokemonName . '</div>';
            echo '</div>';
        }
        ?>
    </div>
    <div id="iframe-container">
        <a href="#" onclick="window.open(document.getElementById('image-preview').src, '_blank').focus(); return false;"><img id="image-preview" src="" alt="Preview"></a>
    </div>
    <script>
        function displayImage(imageUrl) {
            var imagePreview = document.getElementById('image-preview');
            imagePreview.src = imageUrl;
        }
    </script>
</body>
</html>