<?php
$file = 'src/DiDom/Document.php';

// Check if the file exists
if (!file_exists($file)) {
    echo 'Error: Document.php file not found.';
    exit;
}
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Try to include the file
require_once $file;
// Check if Document class is defined
if (class_exists('DiDom\Document')) {
    echo 'Document.php is properly loaded.';
} else {
    echo 'Error: Document.php failed to load.';
    echo 'Please check if the file is correct and the necessary dependencies are installed.';
}
?> 
<?php
if (extension_loaded('libxml')) {
    echo "libxml extension is enabled.";
} else {
    echo "libxml extension is not enabled.";
}
?><br><br>


<?php
// Define LIBXML_HTML_NODEFDTD constant if it's not already defined
if (!defined('LIBXML_HTML_NODEFDTD')) {
    define('LIBXML_HTML_NODEFDTD', 8192);
}
require_once 'src/DiDom/Node.php';
//require_once 'src/DiDom/Encoder.php';
//require_once 'src/DiDom/Errors.php';
$files = glob('src/DiDom/*.php');
foreach ($files as $file) {
    require_once $file;
}

use DiDom\Document;

// Create a new DiDom document
$url = 'https://www.pixiv.net/en/users/75406576/illustrations';
$document = new Document($url, true);

// Display the webpage content
echo $document->html();
?>