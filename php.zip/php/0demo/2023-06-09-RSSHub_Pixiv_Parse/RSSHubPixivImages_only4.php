<?php
$rss = simplexml_load_file('https://rsshub.app/pixiv/user/75406576');
$count = 0;
foreach ($rss->channel->item as $item) {
    $description = (string) $item->description;
    if (preg_match('/https:\/\/\S+/', $description, $matches)) {
        $link = rtrim($matches[0], '"');
        echo '<img src="' . htmlspecialchars($link) . '">';
        $count++;
        if ($count >= 4) {
            break;
        }
    }
}
?>