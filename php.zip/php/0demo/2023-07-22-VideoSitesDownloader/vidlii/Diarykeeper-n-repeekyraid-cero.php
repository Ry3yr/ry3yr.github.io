Repeekyraid_Cero:<br>
<?php
$url = 'https://www.vidlii.com/user/repeekyraidcero/videos';
$html = file_get_contents($url);
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($html);
libxml_clear_errors();
$links = $dom->getElementsByTagName('a');
$displayedLinks = array();
foreach ($links as $link) {
    $href = $link->getAttribute('href');
    $class = $link->getAttribute('class');
    if (strpos($href, '/watch?v=') === 0 && $class === 'ln2' && !in_array($href, $displayedLinks)) {
        $title = $link->nodeValue;
        echo '<a href="https://www.vidlii.com' . $href . '" target="_blank">' . $title . '</a><br><br>' . PHP_EOL;
        $displayedLinks[] = $href;
    }
}
?>

<br>Diarykeeper:<br>
<?php
$url = 'https://www.vidlii.com/user/diarykeeper/videos';
$html = file_get_contents($url);
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($html);
libxml_clear_errors();
$links = $dom->getElementsByTagName('a');
$displayedLinks = array();
foreach ($links as $link) {
    $href = $link->getAttribute('href');
    $class = $link->getAttribute('class');
    if (strpos($href, '/watch?v=') === 0 && $class === 'ln2' && !in_array($href, $displayedLinks)) {
        $title = $link->nodeValue;
        echo '<a href="https://www.vidlii.com' . $href . '" target="_blank">' . $title . '</a><br><br>' . PHP_EOL;
        $displayedLinks[] = $href;
    }
}
?>