<?php
if(isset($_GET['gamename'])) {
    $gamename = $_GET['gamename'];
    $currentDateTime = date('Y-m-d H:i:s');
    $htmlContent = "<html><head><title>Current Game</title></head><body><u>LastPlayed:</u> $gamename - ($currentDateTime)</p></body></html>";
    file_put_contents('current.html', $htmlContent);
    //echo "Successfully updated current.html with the game name: $gamename and current date and time.";

    // Output the iframe with cache busting
    echo "<iframe src='current.html?" . time() . "' style='width: 100%; border: none;'></iframe>";
} else {
    echo "<iframe src='current.html?" . time() . "' style='width: 100%; border: none;'></iframe>";
}
?>
