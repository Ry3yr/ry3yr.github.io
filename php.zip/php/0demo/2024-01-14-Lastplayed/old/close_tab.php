<?php
// close_tab.php
?>
<script type="text/javascript">
    window.close();
</script>