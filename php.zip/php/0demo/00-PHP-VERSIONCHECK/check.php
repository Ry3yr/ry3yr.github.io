<?php
$parentDirectory = dirname(__DIR__); // Get the parent directory

$folders = scandir($parentDirectory); // Get all folders within the parent directory

echo '<table>';
echo '<tr><th>Folder</th><th>.htaccess</th><th>PHP Version</th></tr>';

foreach ($folders as $folder) {
    if ($folder === '.' || $folder === '..' || !is_dir($parentDirectory . '/' . $folder)) {
        continue; // Skip current and parent directory and non-folders
    }

    $folderPath = $parentDirectory . '/' . $folder; // Get the full path of the folder

    // Check if .htaccess file exists
    $htaccessPath = $folderPath . '/.htaccess';
    $htaccessExists = file_exists($htaccessPath);

    // Get PHP version
    $phpVersion = '';
    if ($htaccessExists) {
        $htaccessContents = file_get_contents($htaccessPath);
        preg_match('/AddHandler\s+application\/x-httpd-php(\d+)\s+\.php/', $htaccessContents, $matches);
        if (isset($matches[1])) {
            $phpVersion = $matches[1];
        }
    }

    // Fallback to default PHP version if line not found
    if (empty($phpVersion)) {
        $phpVersion = phpversion();
    }

    // Extract domain base from folder path
    $folderUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname(dirname($_SERVER['REQUEST_URI'])) . '/' . basename($folderPath);

    // Output folder name as a hyperlink, .htaccess existence, and PHP version (wrapped in a hyperlink)
    echo '<tr>';
    echo '<td><a target="_blank" href="' . htmlspecialchars($folderUrl) . '" target="_blank">' . htmlspecialchars($folder) . '</a></td>';
    echo '<td>' . ($htaccessExists ? '<span style="color: green;">Exists</span>' : '<span style="color: gray;">[no .htaccess found]</span>') . '</td>';
    echo '<td><a target="_blank" href="change.php?folder=' . urlencode($folder) . '">' . ($phpVersion ? $phpVersion : '[unknown]') . '</a></td>';
    echo '</tr>';
}

echo '</table>';
?>