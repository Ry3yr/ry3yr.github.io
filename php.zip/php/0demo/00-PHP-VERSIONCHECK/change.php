<!--<?php
$folder = $_GET['folder'] ?? '';
$path = '../' . $folder;
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$domain = $_SERVER['HTTP_HOST'];
$currentPath = rtrim(dirname($_SERVER['REQUEST_URI']), '/');
$fullLink = $protocol . $domain . $currentPath . '/' . $path;
echo '<a href="' . htmlspecialchars($fullLink) . '">Link</a><br>';
?>-->
<!--
<?php
$folder = $_GET['folder'];
$currentDir = __DIR__;
$baseDir = dirname($currentDir);
$combinedPath = $baseDir . '/' . $folder;
echo $combinedPath;
?>-->



<?php
$folder = isset($_GET['folder']) ? $_GET['folder'] : '';
$currentDir = __DIR__;
$baseDir = dirname($currentDir);
$combinedPath = $baseDir . '/' . $folder;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phpVersion = $_POST['php_version'];
    $phpVersion2 = substr_replace($phpVersion, "", -1);



    $handlerLine = "AddHandler application/x-httpd-php{$phpVersion} .php .php{$phpVersion2}";

    $htaccessFile = $combinedPath . '/.htaccess';
    $htaccessContent = file_get_contents($htaccessFile);

    if (strpos($htaccessContent, $handlerLine) === false) {
        // Append the handler line to the .htaccess file
        file_put_contents($htaccessFile, PHP_EOL . $handlerLine, FILE_APPEND);
        $message = "PHP version $phpVersion has been added to the .htaccess file in the folder: $combinedPath";
    } else {
        $message = "PHP version $phpVersion already exists in the .htaccess file in the folder: $combinedPath";
    }
}
?>
    <?php if (isset($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>

    <form action="" method="POST">
        <label for="php_version">Select PHP Version:</label>
        <select name="php_version" id="php_version">
            <option value="56">PHP 5.6</option>
            <option value="70">PHP 7.0</option>
            <option value="71">PHP 7.1</option>
            <option value="72">PHP 7.2</option>
            <option value="73">PHP 7.3</option>
            <option value="74">PHP 7.4</option>
            <option value="80">PHP 8.0</option>
            <option value="81">PHP 8.1</option>
        </select>
        <br><br>
        <label for="folder">Select Folder:</label>
        <input type="text" name="folder" id="folder" placeholder="Enter folder path" value="<?php echo htmlspecialchars($folder); ?>">
        <br><br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
