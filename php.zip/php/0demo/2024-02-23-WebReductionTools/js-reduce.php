<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the JavaScript code from the uploaded file or the textarea
    if (!empty($_FILES['js']['tmp_name'])) {
        $js = file_get_contents($_FILES['js']['tmp_name']);
    } elseif (!empty($_POST['js_code'])) {
        $js = $_POST['js_code'];
    } else {
        echo 'Please upload a JavaScript file or enter JavaScript code in the textarea.';
        exit();
    }

    // Minify the JavaScript code
    $minifiedJs = minifyJavaScript($js);

    // Output the minified JavaScript to a textbox if the checkbox is checked
    if (isset($_POST['output_to_textbox']) && $_POST['output_to_textbox'] === 'on') {
        echo '<textarea id="minified_js" rows="10" cols="50" readonly>' . htmlspecialchars($minifiedJs) . '</textarea><br>';
        echo '<button onclick="copyToClipboard()">Copy</button>';
        echo '<script>function copyToClipboard() { var copyText = document.getElementById("minified_js"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copied to clipboard!"); }</script>';
    } else {
        // Save the minified JavaScript to a file with a timestamp in the filename
        $filename = date('YmdHis') . '_minified.js';
        file_put_contents($filename, $minifiedJs);

        // Output the link to download the minified JavaScript file
        echo 'Minified JavaScript file has been created. Download the file: <a href="' . $filename . '">Download</a><br>';
    }
}

function minifyJavaScript($js) {
    // Minify the JavaScript code (implement your own minification logic here)
    // For example, using a library like JSMin or UglifyJS

    // Dummy implementation: Remove all comments and unnecessary whitespace
    $js = preg_replace('/\/\/.*$/m', '', $js); // Remove single-line comments
    $js = preg_replace('/\/\*.*?\*\//s', '', $js); // Remove multi-line comments
    $js = preg_replace('/\s+/', ' ', $js); // Remove unnecessary whitespace

    return $js;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>JavaScript Minifier</title>
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <label for="js">JavaScript File:</label><br>
        <input type="file" id="js" name="js"><br><br>
        <label for="js_code">JavaScript Code:</label><br>
        <textarea id="js_code" name="js_code" rows="10" cols="50"></textarea><br><br>
        <input type="checkbox" id="output_to_textbox" name="output_to_textbox">
        <label for="output_to_textbox">Output minified JavaScript to textbox</label><br><br>
        <input type="submit" value="Minify JavaScript">
    </form>
</body>
</html>