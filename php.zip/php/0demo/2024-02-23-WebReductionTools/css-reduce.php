<a href="https://www.giftofspeed.com/css-compressor" target="_blank">Compress even more</a>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the uploaded CSS file or the CSS code from textarea
    if (!empty($_FILES['css']['tmp_name'])) {
        $css = file_get_contents($_FILES['css']['tmp_name']);
    } elseif (!empty($_POST['css_code'])) {
        $css = $_POST['css_code'];
    } else {
        echo 'Please upload a CSS file or paste CSS code in the textarea.';
        exit();
    }

    // Replace "93.33333333%" with rounded whole numbers like "93"
    $css = preg_replace_callback('/(\d+\.\d+)%/', function ($matches) {
        return round($matches[1]);
    }, $css);

    // Simplify all selectors
    $css = preg_replace_callback('/[^\{\}]+\{/', function ($matches) {
        $selector = $matches[0];
        $selector = preg_replace('/\s+/', ' ', $selector);
        $selector = preg_replace('/([>+~])\s+/', '$1', $selector);
        return $selector;
    }, $css);

    // Remove old and redundant vendor prefixes
    $css = preg_replace('/-(moz|ms|webkit|o)-/', '', $css);

    // Remove unused styles
    $unusedStyles = array(
        '.unused-class',
        '#unused-id',
        'unused-selector'
    );
    $css = str_replace($unusedStyles, '', $css);

    // Combine and consolidate selectors
    $css = preg_replace('/(selector1|selector2|selector3)\s*\{\s*property1: value;\s*property2: value;\s*\}/', '.combined-selector{property1: value;property2: value;}', $css);

    // Use shorthand properties
    $css = preg_replace('/margin-top: 10px;margin-bottom: 10px;margin-left: 10px;margin-right: 10px;/', 'margin: 10px;', $css);

    // Remove duplicate declarations
    $css = preg_replace('/property: value;\s*property: value;/', 'property: value;', $css);

    // Minimize colors
    $css = preg_replace_callback('/#([a-fA-F0-9]{6}|[a-fA-F0-9]{3})/', function ($matches) {
        $color = $matches[1];
        if (strlen($color) === 6) {
            $color = substr($color, 0, 3);
        }
        return '#' . strtolower($color);
    }, $css);

    // Remove font-related styles if checkbox is checked
    if (isset($_POST['remove_font']) && $_POST['remove_font'] === 'on') {
        $css = preg_replace('/font-family:.*?;/i', '', $css);
        $css = preg_replace('/@font-face\s*{.*?}/si', '', $css);
    }

    // Minify the CSS by removing unnecessary whitespace and comments
    $css = preg_replace('/\/\*.*\*\//sU', '', $css);
    $css = preg_replace('/\s*([{}|:;,])\s*/', '$1', $css);

    if (isset($_POST['output_to_textbox']) && $_POST['output_to_textbox'] === 'on') {
        echo '<textarea rows="10" cols="50" readonly>' . htmlspecialchars($css) . '</textarea>';
        echo '<br>';
        echo '<button onclick="copyToClipboard()">Copy</button>';
        echo '<script>function copyToClipboard() { var copyText = document.querySelector("textarea"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copied to clipboard!"); }</script>';
    } else {
        // Save the modified CSS to the new file
        $currentTime = date('YmdHis');
        $newFilename = $currentTime . (isset($_POST['remove_font']) && $_POST['remove_font'] === 'on' ? '_fontrm' : '') . '_new.css';
        file_put_contents($newFilename, $css);

        echo 'CSS file has been modified. Download the modified file: <a href="' . $newFilename . '">Download</a>';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>CSS Modifier</title>
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <label for="css">CSS File:</label><br>
        <input type="file" id="css" name="css"><br><br>
        <labelfor="css_code">CSS Code:</label><br>
        <textarea id="css_code" name="css_code" rows="10" cols="50"></textarea><br><br>
        <input type="checkbox" id="remove_font" name="remove_font">
        <label for="remove_font">Remove font-related styles</label><br><br>
        <input type="checkbox" id="output_to_textbox" name="output_to_textbox">
        <label for="output_to_textbox">Output modified CSS to textbox</label><br><br>
        <input type="submit" value="Modify CSS">
    </form>
</body>
</html>