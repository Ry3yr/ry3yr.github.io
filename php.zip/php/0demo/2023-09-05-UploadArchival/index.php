<?php
/*
 * Download-Archiv (index.php)
 * - https://werner-zenk.de
 */


/*

// Benutzer überprüfen
session_start();

if (!isset($_SESSION["benutzername"])) {
 header("Location: anmeldung.php");
 exit;
}

*/

include __DIR__ . "/konfiguration.php";

// Ausgabe
$output = '<table id="tabelle" class="benutzertabelle sortierbar">
<thead>
 <tr>
  <th class="sortierbar">#</th>
  <th class="sortierbar">Name</th>
  <th class="sortierbar">Beschrei<wbr>bung</th>
  <th class="sortierbar">Größe</th>
  <th class="sortierbar">Datum</th>
 </tr>
</thead><tbody>';
 
$select = $db->query("SELECT `id`, `name`, `description`, `size`, `date` FROM `download-archiv`");
$filelist = $select->fetchAll();

$unique = date("dYm");
foreach ($filelist as $nr => $file) {
 $output .= '<tr><td title="Nummer ' . ($nr+1) . '">' . ($nr+1) . '</td>' .
  '<td class="langertext"><span class="link speichern" onClick="dl(`' . base64_encode($unique . '|' . $file["id"]) . '`)" title="Die Datei: &#8220;' . $file["name"] . '&#8220; herunterladen"> ' . $file["name"] . '</span></td>' .
  '<td class="langertext" title="Beschreibung">' . htmlspecialchars($file["description"], ENT_HTML5) . '</td>' .
  '<td class="nummer" title="Dateigröße">' . size($file["size"]) . '</td>' .
  '<td title="Datum">' . $file["date"] . '</td></tr>';
}
$output .= '<tbody></table><div id="laden"></div>';
?>
<!DOCTYPE html>
<html lang="de">
 <head>
  <meta charset="UTF-8">
  <title>Download-Archiv</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="tabletsort.js"></script>
  <script src="resizable.js"></script>
  <script src="javascript.js"></script>
  <link rel="stylesheet" href="style.css">
 </head>
<body>

<h2>Download-Archiv</h2>

<?=$output;?>

</body>
</html>