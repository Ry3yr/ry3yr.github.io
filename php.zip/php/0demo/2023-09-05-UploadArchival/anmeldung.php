<?php
/*
 * Download-Archiv - Anmeldung (anmeldung.php)
 * - https://werner-zenk.de
 */

session_start();
include "konfiguration.php";

// Anmeldung überprüfen
if (isset($_POST["anmeldung"])) {
 if (isset($BENUTZER_PASS[trim($_POST["name"])]) && 
     $BENUTZER_PASS[trim($_POST["name"])] === $_POST["passwort"]) {

  // Session setzen
  session_regenerate_id();
  $_SESSION["benutzername"] = trim($_POST["name"]);

  // Weiterleitung
  if ($_SESSION["benutzername"] == $ADMINISTRATOR) {
   header("Location: verwaltung.php");
  }
  else {
   // Die Weiterleitung ist nur sinnvoll wenn die Seite: "index.php" geschützt ist!
   header("Location: index.php");
  }
 }
}

// Abmeldung
if (isset($_GET["abmeldung"])) {

  // Session und Cookies löschen
 unset($_SESSION["benutzername"]);
  $_SESSION = [];
  if (ini_get("session.use_cookies")) {
   $params = session_get_cookie_params();
   setcookie(session_name(), '', time() - 42000, $params["path"],
    $params["domain"], $params["secure"], $params["httponly"]);
  }
  session_destroy();

   // Zur Anmeldung weiterleiten
   header("Location: anmeldung.php?abmeldungOK");
}
?>
<!DOCTYPE html>
<html lang="de">
 <head>
  <meta charset="UTF-8">
  <title>Download-Archiv - Anmeldung</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="style.css">
  <script src="javascript.js"></script>
 </head>
<body>

<form method="post">
<fieldset>
 <legend>Download-Archiv - Anmeldung</legend>
 <p>
  <label>Benutzer:
  <input type="text" name="name" required="required" autocomplete="username" autofocus="autofocus">
  </label>
 </p>

 <p>
  <label>Passwort:
  <input type="password" name="passwort" required="required" autocomplete="current-password">
  </label>
 </p>

 <p>
  <input type="submit" name="anmeldung" value="Anmelden">
 </p>

<?=isset($_GET["abmeldungOK"]) ? '<p class="status code">&#10004;  Die Abmeldung war erfolgreich.</p>' : '';?>

<p>
 <a href="index.php">Download-Archiv anzeigen</a>
</p>
</fieldset>

</form>

</body>
</html>