<?php
/*
 * Download-Archiv - Konfiguration (konfiguration.php)
 * - https://werner-zenk.de
 */


// Benutzer (Administrator)
$ADMINISTRATOR = "user";

// Passwort (Administrator)
// Aus Sicherheitsgründen sollte das Passwort min. 8 Zeichen enthalten!
$BENUTZER_PASS[$ADMINISTRATOR] = "0000";

// Weitere Benutzer und Passwörter hinzufügen (Optional).
// Die Kommentarzeichen (//) müssen entfernt werden
// um neue Benutzer hinzufügen zu können!

// $BENUTZER_PASS["Ann Stecknaddel"] = "aua";
// $BENUTZER_PASS["Kai Serschmarn"] = "lecker";
// $BENUTZER_PASS["Donna Wetter"] = "regen";


// Download-Archiv (Verzeichnis)
$archiv = "archiv/";

// Pfad zur Datenbank
$datenbank = __DIR__ . "/db/datenbank.db";

 /* Datenbank-Datei erstellen
 https://www.sqlite.org/datatype3.html */
if (!file_exists($datenbank)) {
 $db = new PDO('sqlite:' . $datenbank);
 $db->exec("CREATE TABLE `download-archiv`(
  id INTEGER PRIMARY KEY,
  name TEXT,
  description TEXT,
  size INTEGER,
  hits INTEGER,
  date TEXT)");
}
else {
 // Verbindung
 $db = new PDO('sqlite:' . $datenbank);
}

function size($bytes) {
 return ($bytes < 1024) ? $bytes ." Byte" : (($bytes >= 1048576) ? number_format(round($bytes / 1024 / 1024 ,1), 1, ",", ".") ." MB" : number_format(round($bytes / 1024 ,1), 1, ",", ".") ." KB");
}