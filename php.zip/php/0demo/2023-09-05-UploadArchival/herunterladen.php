<?php
/*
 * Download-Archiv - Herunterladen (herunterladen.php)
 * - https://werner-zenk.de
 */


/*

// Benutzer überprüfen
session_start();

if (!isset($_SESSION["benutzername"])) {
 exit;
}

*/

if (isset($_GET["id"])) {

 include __DIR__ . "/konfiguration.php";

 $id = base64_decode($_GET["id"]);
 list($dYm, $id) = explode("|", $id);

 // Nur am gleichen Tag herunterladen!
// if ($dYm != date("dYm")) exit;

 // Hits erhöhen
 $update = $db->prepare("UPDATE `download-archiv`
                                       SET `hits` = `hits` + '1'
                                       WHERE `id` = :id");
 $update->execute([':id' => $id]);

 if ($update->rowCount() == 1) {

  // Dateiname auslesen
  $select = $db->query("SELECT `name` FROM `download-archiv`
                                    WHERE `id` = :id");
  $select->execute([':id' => $id]);
  $file = $select->fetch();

  // Datei an den Client (Browser) senden
  if (file_exists($archiv . $file["name"])) {

   header("Content-Type: application/octet-stream");
   header("Content-Disposition: attachment; filename=" . basename($archiv . $file["name"]));
   header("Content-Length: " . filesize($archiv . $file["name"]));
   header("Content-Transfer-Encoding: binary");
   header("Cache-Control: post-check=0, pre-check=0");
   readfile($archiv . $file["name"]);
  }
 }
 else {
  header("HTTP/1.0 404 Not Found");
 }
}
exit;

