<details><a target="_blank" href="z_listgen.php" style=color:blue>Refresh list</a></details><br><br>

<?php
// Path to the z_list.txt report
$reportPath = './z_list.txt';
// Read the contents of the z_list.txt report
$reportContent = file_get_contents($reportPath);
// Get the current directory
$currentDir = getcwd();
// Explode the report content into an array of filenames
$reportFiles = explode("\n", $reportContent);
// Initialize counters for files and folders
$fileCount = 0;
$folderCount = 0;
$okCount = 0;
$missingCount = 0;
// Create separate arrays to store files and folders
$files = [];
$folders = [];
// Iterate over the files in the z_list.txt report
foreach ($reportFiles as $filename) {
    // Exclude empty lines
    if (empty($filename)) {
        continue;
    }
    // Check if the file is a directory
    if (is_dir($filename)) {
        // Increment folder count
        $folderCount++;
        // Store the folder in the folders array
        $folders[] = $filename;
        continue;
    }
    // Exclude "error_log" and "alceawis.de.zip" files
    if ($filename === 'error_log' || $filename === 'alceawis.de.zip') {
        continue;
    }
    // Check if the file exists in the current directory
    if (file_exists($filename)) {
        // Increment file count
        $fileCount++;
        // Increment [ok] count
        $okCount++;
        // Display [ok] in green for matching files
        $files[] = '<span style="color: green;">[ok]</span> <a href="' . $filename . '" target="_blank">' . $filename . '</a>';
    } else {
        // Increment missing count
        $missingCount++;
        // Display [missing] in red for non-matching files
        $files[] = '<span style="color: red;">[missing]</span> ' . $filename;
    }
}

// Iterate over the files in the current directory
foreach (scandir($currentDir) as $filename) {
    // Exclude hidden files, directories, and z_listcheck.php
    if ($filename[0] === '.' || is_dir($filename) || $filename === 'z_listcheck.php' ) {
        continue;
    }
    // Exclude "error_log" and "alceawis.de.zip" files
    if ($filename === 'error_log' || $filename === 'alceawis.de.zip') {
        continue;
    }
    // Check if the file is listed in the z_list.txt report
    if (!in_array($filename, $reportFiles)) {
        // Increment file count
        $fileCount++;
        // Increment missing count
        $missingCount++;
        // Display [missing] in red for non-listed files
        $files[] = '<span style="color: red;">[missing]</span> ' . $filename;
    }
}

// Display folders
foreach ($folders as $folder) {
    echo '<span style="color: green;">[ok]</span> <a href="' . $folder . '" target="_blank">' . $folder . '</a><br>';
}

// Display files
foreach ($files as $file) {
    echo $file . '<br>';
}

echo '<p>Total Files: ' . $fileCount . ' Total Folders: ' . $folderCount . '</p>';
echo '<hr>';
// Display the count of [ok] and missing files
echo '<p>Number [ok]: ' . $okCount;
if ($okCount === $fileCount) {
    echo ' (all)';
}
echo '</p>';
echo '<p>Number of missing: ' . $missingCount . '</p>';
?>