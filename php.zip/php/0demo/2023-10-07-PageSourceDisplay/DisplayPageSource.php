<?php
if(isset($_POST['submit'])) {
    // Get the URL from the textbox
    $url = $_POST['url'];

    // Fetch the source code of the URL
    $sourceCode = file_get_contents($url);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>URL Source Code Viewer</title>
</head>
<body>
    <form method="POST">
        <label for="url">Enter URL:</label>
        <input type="text" name="url" id="url" required>
        <br>
        <input type="submit" name="submit" value="Submit">
    </form>

    <?php if(isset($_POST['submit'])): ?>
      <div style="margin-top: 20px;">
          <h2>Source Code:</h2>
          <div><textarea cols="80" rows="10"><?php echo $sourceCode; ?></textarea></div>
      </div>
    <?php endif; ?>
</body>
</html>