<?php
$allowSource = true; // Allow saving the source code snippet by default
$allowErrorHandler = true; // Allow adding error handling to the code by default

if (isset($_POST['code'])) {
    // Get the code from the text area
    $code = $_POST['code'];

    // Get the current date and time
    $now = new DateTime();
    $date = $now->format('Y-m-d');
    $time = $now->format('H-i-s');

    // Create the new file name
    $filename = $date . '-' . $time . '.php';

    // Add the error handler to the code if allowed
    if ($allowErrorHandler && isset($_POST['allowErrorHandler'])) {
        $errorHandler = "<?php\n" .
                        "// Custom error handler function\n" .
                        "function errorHandler(\$errno, \$errstr, \$errfile, \$errline) {\n" .
                        "    echo \"Error: \$errstr in \$errfile on line \$errline\";\n" .
                        "    exit;\n" .
                        "}\n\n" .
                        "// Set the custom error handler\n" .
                        "set_error_handler(\"errorHandler\");\n\n" .
                        "?>"; // Appending the closing tag
        $code = $errorHandler . $code;
    }

    // Add the source code link to the bottom of the code if allowed
    if ($allowSource && isset($_POST['allowSource'])) {
        $sourceCodeLink = "<?php\n" .
                          "    define(\"ALLOW_SOURCE\",TRUE);\n" .
                          "    define(\"ALLOW_TITLE\",TRUE);\n" .
                          "    if(ALLOW_SOURCE && isset(\$_GET['source'])){\n" .
                          "        highlight_file(__FILE__);\n" .
                          "        exit(0);\n" .
                          "    }\n" .
                          "?>\n" .
                          "<a target=\"_blank\" href=\"?source\">Source Code</a>\n" .
                          "</body>\n</html>";
        $code .= "\n\n" . $sourceCodeLink;
    }

    // Write the code to the new file
    file_put_contents($filename, $code);

    // Write the code to the "current" PHP file
    file_put_contents('current.php', $code);

    echo "Code saved to $filename and current.php";
}

// Handle the "Move Files" button click
if (isset($_POST['move'])) {
    // Get a list of all files in the current directory
    $files = glob('*');

    // Create the "0ld" directory if it doesn't exist
    if (!is_dir('0ld')) {
        mkdir('0ld');
    }

    // Move all files except "0test.php" and "current.php" to the "0ld" directory
    foreach ($files as $file) {
        if ($file != '0test.php' && $file != 'current.php') {
            rename($file, '0ld/' . $file);
        }
    }

    echo "Files moved to 0ld directory";
}
?>

<form method="post">
    <textarea name="code" cols="60" rows="15"></textarea>
    <br>
    <label>
        <input type="checkbox" name="allowSource">
        Add ALLOW SOURCE VIEW <a href="javascript:void(0);" style="text-decoration: none;color: black;" onclick="document.getElementById('Save').disabled = false;">snippet</a>
    </label>
    <br>
    <label>
        <input type="checkbox" name="allowErrorHandler">
        Add Error Handling
    </label>
    <br>
 <input type="submit" id=Save value="Save" disabled>




</form>
<?php
if ($allowSource && isset($_POST['allowSource'])) {
    echo "\n\n" . $sourceCodeLink;
}
?>
<form method="post">
    <input type="submit" name="move" value="Move Files">
</form>
<br>
<br><a target="_blank" href="current.php">CURRENT.PHP</a>&nbsp;<a target="_blank" href="https://alcea-wisteria.de/PHP/0demo/00-PHP-Test/">[FOLDER]</a>



<!--AES--BoilerPlate--https://codepen.io/ryedai1/pen/gOEqVzV--
<script> function stringToArrayBuffer(str) { var encoder = new TextEncoder(); return encoder.encode(str); } function arrayBufferToString(buffer) { var decoder = new TextDecoder(); return decoder.decode(buffer); } async function decryptAES(ciphertext, key, iv) { var decrypted = await crypto.subtle.decrypt( { name: "AES-CBC", iv: iv }, key, ciphertext ); return new Uint8Array(decrypted); } async function handleDecrypt(event) { event.preventDefault(); var password = document.getElementById("password").value; var encryptedHex = document.getElementById("encryptedOutput").value; var passwordBuffer = stringToArrayBuffer(password); var keyMaterial = await crypto.subtle.importKey( "raw", passwordBuffer, { name: "PBKDF2" }, false, ["deriveKey"] ); var aesKey = await crypto.subtle.deriveKey( { name: "PBKDF2", salt: new Uint8Array(16), // Use a random salt for real-world scenarios iterations: 100000, hash: "SHA-256" }, keyMaterial, { name: "AES-CBC", length: 256 }, true, ["encrypt", "decrypt"] ); var ivHex = encryptedHex.substr(0, 32); var ciphertextHex = encryptedHex.substr(32); var ivBytes = new Uint8Array(ivHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16))); var ciphertextBytes = new Uint8Array(ciphertextHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16))); var decryptedBytes = await decryptAES(ciphertextBytes, aesKey, ivBytes); var decryptedHTML = arrayBufferToString(decryptedBytes); document.getElementById("decryptedOutput").innerHTML = decryptedHTML; } </script> <form onsubmit="handleDecrypt(event)"> <input type="password" id="password" required> <textarea id="encryptedOutput" rows="10" cols="50" style="display: none;">3a89c921bc7d3a731fa1b499823724084e388e770e8f2099ad179ef843c99cabd27e52077aa5b7875f790e6a3af6496e4149d436ac6424c10ccc2b8b78383e78 </textarea> <input type="submit" value="Decrypt"> </form><div><div id="decryptedOutput"></div></div> -->
