<iframe src="finduser.php"  width="300" height="45" frameborder="0" scrolling="no"></iframe><br><hr>

<a target="_blank" href="?creator=https://www.animexx.de/fanart/zeichner/1049853/" style=color:lightorange>custom</a><br><br>
<!---<a target="_blank" href="https://www.animexx.de/fanart/zeichner/1248943/" style=color:blue>Cea</a>-->

<?php
ini_set('display_errors', 0);
?>




<?php
if (isset($_GET['creator'])) {
    $creator = $_GET['creator'];
    $url = "$creator";
} else {
    $url = 'https://www.animexx.de/fanart/zeichner/1248943/';
}
//$url = 'https://www.animexx.de/fanart/zeichner/1248943/';
// Get the HTML content from the URL
$html = file_get_contents($url);
$doc = new DOMDocument();
$doc->loadHTML($html);
$xpath = new DOMXPath($doc);
$fathumbTags = $xpath->query('//td[@class="fathumb"]');
$fatitelTags = $xpath->query('//td[@class="fatitel"]');

// Extract the <td> tags for "faextinfo"
$faextinfoTags = $xpath->query('//td[@class="faextinfo"]');

// Iterate over the extracted tags and display the images and create links
foreach ($fathumbTags as $index => $fathumbTag) {
    // Extract the href attribute
    $href = $fathumbTag->getElementsByTagName('a')->item(0)->getAttribute('href');
    
    // Extract the image source URL
    $imgSrc = $fathumbTag->getElementsByTagName('img')->item(0)->getAttribute('src');
    
    echo "<a href='$imgSrc$href' target='_blank'>";
    //echo "<img src='$imgSrc' alt='' style='width: 64px; height: 100px;'>";
    echo "</a>";
    
    // Find the corresponding fatitel tag
    $fatitelTag = $fatitelTags->item($index);
    
    // Extract the title text
    $title = $fatitelTag->getElementsByTagName('b')->item(0)->textContent;
    
    echo "<br><a href='$url$href' target='_blank'><b>$title</b></a>";
    
    // Follow the link and extract the image from the linked page
    $linkedHtml = file_get_contents("$url$href");
    $linkedDoc = new DOMDocument();
    $linkedDoc->loadHTML($linkedHtml);
    
    // Find the image tag in the linked page
    $linkedImgTag = $linkedDoc->getElementsByTagName('img')->item(0);
    
    // Extract the image source URL from the linked page
    $linkedImgSrc = $linkedImgTag->getAttribute('src');
    
    echo "<br><img src='$linkedImgSrc' alt='Linked Image' style='width: 200px; height: auto;'>";
    
    // Find the corresponding faextinfo tag
    $faextinfoTag = $faextinfoTags->item($index);
    
    // Extract the faextinfo text
    $faextinfo = $faextinfoTag->textContent;
    
    echo "<br>$faextinfo";
    
    echo "<br><br>";
}
?>





<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
