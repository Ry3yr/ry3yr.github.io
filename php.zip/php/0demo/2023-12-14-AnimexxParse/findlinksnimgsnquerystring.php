<iframe src="finduser.php"  width="300" height="45" frameborder="0" scrolling="no"></iframe><br><hr>

<a target="_blank" href="?creator=1049853/" style=color:lightorange>custom</a><br><br>
<!---<a target="_blank" href="https://www.animexx.de/fanart/zeichner/1248943/" style=color:blue>Cea</a>-->
<a href="findlinksnimgsnquerystring.php" style=color:blue>[[0]]</a> 
<a href="?creator=1248943?seite=1" style=color:blue>[1]</a> 
<a href="?creator=1248943?seite=2" style=color:blue>[2]</a> 
<a href="?creator=1248943?seite=3" style=color:blue>[3]</a> 
<br><br>


<?php
error_reporting(0); // Disable error reporting
if (@isset($_GET['seite']) && @isset($_GET['creator'])) {
    $seite = $_GET['seite'];
    $creator = $_GET['creator'];
    $url = '';
} elseif (@isset($_GET['seite'])) {
    $seite = $_GET['seite'];
    $url = 'https://www.animexx.de/fanart/zeichner/1248943/?seite=' . $seite;
} elseif (@isset($_GET['creator'])) {
    $creator = $_GET['creator'];
    $url = 'https://www.animexx.de/fanart/zeichner/' . $creator . '/';
} else {
    $url = 'https://www.animexx.de/fanart/zeichner/1248943/';
}
$baseurl = preg_replace('/\?.*/', '', $url);
$newurl = str_replace("?seite=", "/?seite=", $url);

echo "<a href='$newurl' target='_blank'>$newurl</a>";
//echo "<a href='$url' target='_blank'>$baseurl/?seite=' . $seite'</a>";
$html = @file_get_contents($url);
$doc = new DOMDocument();
@$doc->loadHTML($html);
$xpath = new DOMXPath($doc);
$fathumbTags = $xpath->query('//td[@class="fathumb"]');
$fatitelTags = $xpath->query('//td[@class="fatitel"]');
$faextinfoTags = $xpath->query('//td[@class="faextinfo"]');
foreach ($fathumbTags as $index => $fathumbTag) {
    $href = @$fathumbTag->getElementsByTagName('a')->item(0)->getAttribute('href');
    $imgSrc = @$fathumbTag->getElementsByTagName('img')->item(0)->getAttribute('src');
    echo "<a href='$imgSrc$href' target='_blank'></a>";
    $fatitelTag = @$fatitelTags->item($index);
    $title = @$fatitelTag->getElementsByTagName('b')->item(0)->textContent;
    echo "<br><a href='$baseurl/$href' target='_blank'><b>$title</b></a>";


    $linkedHtml = @file_get_contents("$url$href");
    $linkedDoc = new DOMDocument();
    @$linkedDoc->loadHTML($linkedHtml);
    $linkedImgTag = @$linkedDoc->getElementsByTagName('img')->item(0);
    $linkedImgSrc = @$linkedImgTag->getAttribute('src');
    echo "<br><img src='$linkedImgSrc' alt='Linked Image' style='width: 200px; height: auto;'>";
    $faextinfoTag = @$faextinfoTags->item($index);
    $faextinfo = @$faextinfoTag->textContent;
    $faextinfo = preg_replace('/(\d)(?![\d.])/', '<br>$1', $faextinfo);
    $faextinfo = preg_replace("/(Note)/", "<br>$1", $faextinfo);
    echo "<br>$faextinfo";
    echo "<br><br>";
}
?>






<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
