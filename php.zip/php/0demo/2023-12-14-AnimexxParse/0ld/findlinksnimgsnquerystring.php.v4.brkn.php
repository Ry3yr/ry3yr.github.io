<iframe src="finduser.php"  width="300" height="45" frameborder="0" scrolling="no"></iframe><br><hr>

<a target="_blank" href="?creator=https://www.animexx.de/fanart/zeichner/1049853/" style=color:lightorange>custom</a><br><br>
<!---<a target="_blank" href="https://www.animexx.de/fanart/zeichner/1248943/" style=color:blue>Cea</a>-->

<?php
ini_set('display_errors', 0);
?>


<?php
$defaultUrl = 'https://www.animexx.de/fanart/zeichner/1248943/';
if (isset($_GET['creator'])) {
    $creator = $_GET['creator'];
    $url = $creator;
} else {
    $url = $defaultUrl;
}
$html = file_get_contents($url);
$pattern = '/<td class="fathumb" rowspan="2"><a\s+href="([^"]+)"\s+target="([^"]+)"[^>]*>/';
preg_match_all($pattern, $html, $matches, PREG_SET_ORDER);

// Create a DOMXPath object
$dom = new DOMDocument();
$dom->loadHTML($html);
$xpath = new DOMXPath($dom);
$query = '//td[@class="faextinfo"]';
$tdElements = $xpath->query($query);

// Iterate over the <td> elements and display their content
$tdContentArray = [];
foreach ($tdElements as $tdElement) {
    $tdContent = $tdElement->ownerDocument->saveHTML($tdElement);
    $tdContentArray[] = $tdContent;
}

foreach ($matches as $index => $match) {
    $link = $match[1];
    $target = $match[2];
    $validLink = $url . ltrim($link, '/');
    $linkHtml = file_get_contents($validLink);
    $imgPattern = '/<img\s+src="([^"]+)"\s+id="fanart_img_gross"\s+alt="([^"]+)"[^>]*>/';
    preg_match($imgPattern, $linkHtml, $imgMatch);
    if (isset($imgMatch[1]) && isset($imgMatch[2])) {
        $imgSrc = $imgMatch[1];
        $imgAlt = $imgMatch[2];
        echo '<br><br><a href="' . $validLink . '" target="' . $target . '">' . $validLink . '</a><br>';
        echo '<img src="' . $imgSrc . '" alt="' . $imgAlt . '" width=50%><br>';
    }

    // Check if there is a corresponding faextinfo entry
    if (isset($tdContentArray[$index])) {
        echo $tdContentArray[$index];
    }
}
?>

<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
