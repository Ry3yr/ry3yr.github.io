<a target="_blank" href="?artistname=Nudelchen" style=color:lightgray>custom</a><br>
<?php
$url = 'https://www.animexx.de/fanart/zeichner/A/';
if (isset($_GET['artistname'])) {
    $artistname = $_GET['artistname'];
    $firstLetter = strtoupper(substr($artistname, 0, 1));
    $url = str_replace('/zeichner/A/', '/zeichner/' . $firstLetter . '/', $url);
} else {
    $artistname = 'Alcea';
}

$html = file_get_contents($url);
$pattern = '/<b><a href="\/fanart\/zeichner\/\d+\/">' . $artistname . '<\/a><\/b> \(\d+\)/';
preg_match_all($pattern, $html, $matches);

if (!empty($matches[0])) {
    $artistLines = $matches[0];
    $parsedUrl = parse_url($url);
    $domain = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
    foreach ($artistLines as $line) {
        // Prepend the domain to the href attribute within the $line
        $line = str_replace('href="/', 'href="' . $domain . '/', $line);
        $line = str_replace('<a ', '<a target="_blank" ', $line);
        echo $line . "<br>";
    }
} else {
    echo "No matching lines found for '{$artistname}'.";
}
?>
