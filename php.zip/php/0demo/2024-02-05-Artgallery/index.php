<?php
$galleriesPath = "./galleries";
$galleries = array_filter(glob($galleriesPath . '/*'), 'is_dir');
echo '<div style="display: grid; grid-template-columns: repeat(5, 1fr); grid-gap: 10px;">';
foreach ($galleries as $gallery) {
    $images = glob($gallery . '/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
    $newestImage = end($images);
    $galleryName = basename($gallery);
    $displayUrl = 'display.php?gallery=' . urlencode($galleryName);
    echo '<a href="' . $displayUrl . '" style="text-decoration: none; color: inherit;">';
    echo '<div style="text-align: center;">';
    $isNSFW = stripos($galleryName, 'nsfw') !== false;
    // Apply blur if the image is NSFW
    $imageStyle = $isNSFW ? 'filter: blur(10px);' : '';
    echo '<img src="' . $newestImage . '" alt="' . $galleryName . '" width="250" height="250" style="margin-bottom: 5px;' . $imageStyle . '">';
    echo '<div>' . $galleryName . '</div>';
    echo '</div>';
    echo '</a>';
}
echo '</div>';
?>
