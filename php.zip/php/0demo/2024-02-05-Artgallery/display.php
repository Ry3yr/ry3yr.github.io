<a href="<?php echo dirname($_SERVER['REQUEST_URI']); ?>"><img src="https://www.downloadclipart.net/large/19185-back-button-design.png" style="width:40px;" /></a>

<?php
// Retrieve the gallery name from the query string
$galleryName = $_GET['gallery'];
$galleryPath = './galleries/' . $galleryName;
$images = glob($galleryPath . '/*.{jpg,jpeg,png,gif}', GLOB_BRACE);

// Custom sort function to sort images by basename
usort($images, function($a, $b) {
    $basenameA = pathinfo($a, PATHINFO_FILENAME);
    $basenameB = pathinfo($b, PATHINFO_FILENAME);
    return strcmp($basenameB, $basenameA);
});

$numColumns = 5;
$numImages = count($images);
$numRows = ceil($numImages / $numColumns);

echo '<div style="display: grid; grid-template-columns: repeat(' . $numColumns . ', 1fr); grid-gap: 10px;">';

foreach ($images as $key => $image) {
    echo '<div style="display: flex; flex-direction: column; align-items: center;">';
    echo '<img src="' . $image . '" alt="' . basename($image) . '" style="width: 250px; height: 250px; object-fit: cover; cursor: pointer;" onclick="openPopup(' . $key . ');" loading="lazy">';
    echo '<div style="text-align: center;">' . basename($image) . '</div>';
    echo '</div>';
}

echo '</div>';
?>


<!-- CSS Popup -->
<style>
    .popup {
        display: none;
        position: fixed;
        z-index: 9999;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(255, 255, 255, 0.9);
    }
    
    .popup-image {
        display: block;
        max-width: 90%;
        max-height: 80%;
        margin: 50px auto;
    }
    .popup-close {
        position: absolute;
        top: 10px;
        right: 10px;
        color: #000;
        cursor: pointer;
        font-size: 24px;
    }
    .popup-nav {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: #000;
        font-size: 30px;
    }
    .popup-prev,
    .popup-next {
        padding: 20px;
        cursor: pointer;
    }
</style>
<!-- JavaScript -->
<script>
    var currentImageIndex = 0;
    var images = <?php echo json_encode($images); ?>;
    function openPopup(index) {
        currentImageIndex = index;
        var popup = document.getElementById('popup');
        var popupImage = document.getElementById('popup-image');
        
        popupImage.src = images[currentImageIndex];
        popup.style.display = 'block';
    }
    function closePopup() {
        var popup = document.getElementById('popup');
        popup.style.display = 'none';
    }
    function showPrevImage() {
        currentImageIndex = (currentImageIndex - 1 + images.length) % images.length;
        var popupImage = document.getElementById('popup-image');
        popupImage.src = images[currentImageIndex];
    }
    function showNextImage() {
        currentImageIndex = (currentImageIndex + 1) % images.length;
        var popupImage = document.getElementById('popup-image');
        popupImage.src = images[currentImageIndex];
    }
</script>
<!-- HTML Popup -->
<div id="popup" class="popup">
    <span class="popup-close" onclick="closePopup()">&times;</span>
    <div class="popup-nav">
        <span class="popup-prev" onclick="showPrevImage()">&#10094;</span>
        <span class="popup-next" onclick="showNextImage()">&#10095;</span>
    </div>
    <img id="popup-image" class="popup-image" src="" alt="">
</div>

<!-----CommentSystem--><br><br>
  <form action="https://alcea-wisteria.de/PHP/0demo/2024-02-05-UrlValueBasedCommentSystem/submit_comment.php" method="POST">
    <input type="text" name="name" placeholder="Your Name"><br>
    <textarea name="comment" rows="4" cols="50"></textarea>
    <input type="hidden" name="jsonFilename" value="" id="jsonFilenameInput"> <!-- Add the hidden input field -->
    <input type="submit" value="Submit"><br>
  </form>
  <div id="filename"></div>
  <script>
    window.addEventListener("DOMContentLoaded", function() {
      var url = window.location.href;
      var jsonFilename = url.replace(/[^A-Za-z0-9]/g, "") + ".json";
      var jsonUrl = "https://alcea-wisteria.de/PHP/0demo/2024-02-05-UrlValueBasedCommentSystem/" + jsonFilename;

    //var filenameElement = document.getElementById("filename");
    //filenameElement.innerHTML = "<strong>JSON Filename:</strong> " + jsonFilename;

      // Set the jsonFilename value to the hidden input field
      document.getElementById("jsonFilenameInput").value = jsonFilename;

      fetch(jsonUrl)
        .then(response => response.json())
        .then(data => {
          if (Array.isArray(data)) {
            data.reverse(); // Reverse the order of the comments
            data.forEach(entry => {
              var comment = entry.comment;
              var name = entry.name;
              renderComment(name, comment);
            });
          } else {
            console.log("No comments found for the current URL.");
          }
        })
        .catch(error => {
          console.log("Error fetching JSON file:", error);
        });
    });

    function renderComment(name, comment) {
      var commentElement = document.createElement("div");
      commentElement.innerHTML = "<strong>" + name + "</strong>: " + comment;
      document.body.appendChild(commentElement);
    }
  </script>
</body>
</html>
