<a href="<?php echo dirname($_SERVER['REQUEST_URI']); ?>"><img src="https://www.downloadclipart.net/large/19185-back-button-design.png" style="width:40px;" /></a>

<?php
// Retrieve the gallery name from the query string
$galleryName = $_GET['gallery'];
$galleryPath = './galleries/' . $galleryName;
$images = glob($galleryPath . '/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
$numColumns = 5;
$numImages = count($images);
$numRows = ceil($numImages / $numColumns);
echo '<div style="display: grid; grid-template-columns: repeat(' . $numColumns . ', 1fr); grid-gap: 10px;">';
foreach ($images as $key => $image) {
    echo '<div style="display: flex; flex-direction: column; align-items: center;">';
    echo '<img src="' . $image . '" alt="' . basename($image) . '" style="width: 250px; height: 250px; object-fit: cover; cursor: pointer;" onclick="openPopup(' . $key . ');">';
    echo '<div style="text-align: center;">' . basename($image) . '</div>';
    echo '</div>';
}
echo '</div>';
?>
<!-- CSS Popup -->
<style>
    .popup {
        display: none;
        position: fixed;
        z-index: 9999;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
    }
    
    .popup-image {
        display: block;
        max-width: 90%;
        max-height: 80%;
        margin: 50px auto;
    }
    .popup-close {
        position: absolute;
        top: 10px;
        right: 10px;
        color: #fff;
        cursor: pointer;
        font-size: 24px;
    }
    .popup-nav {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: #fff;
        font-size: 30px;
    }
    .popup-prev,
    .popup-next {
        padding: 20px;
        cursor: pointer;
    }
</style>
<!-- JavaScript -->
<script>
    var currentImageIndex = 0;
    var images = <?php echo json_encode($images); ?>;
    function openPopup(index) {
        currentImageIndex = index;
        var popup = document.getElementById('popup');
        var popupImage = document.getElementById('popup-image');
        
        popupImage.src = images[currentImageIndex];
        popup.style.display = 'block';
    }
    function closePopup() {
        var popup = document.getElementById('popup');
        popup.style.display = 'none';
    }
    function showPrevImage() {
        currentImageIndex = (currentImageIndex - 1 + images.length) % images.length;
        var popupImage = document.getElementById('popup-image');
        popupImage.src = images[currentImageIndex];
    }
    function showNextImage() {
        currentImageIndex = (currentImageIndex + 1) % images.length;
        var popupImage = document.getElementById('popup-image');
        popupImage.src = images[currentImageIndex];
    }
</script>
<!-- HTML Popup -->
<div id="popup" class="popup">
    <span class="popup-close" onclick="closePopup()">&times;</span>
    <div class="popup-nav">
        <span class="popup-prev" onclick="showPrevImage()">&#10094;</span>
        <span class="popup-next" onclick="showNextImage()">&#10095;</span>
    </div>
    <img id="popup-image" class="popup-image" src="" alt="">
</div>
