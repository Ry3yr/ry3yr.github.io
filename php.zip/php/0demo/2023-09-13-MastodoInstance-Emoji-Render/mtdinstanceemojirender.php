<?php
    $instance = $_POST['instance'];
    $endpoint = 'https://' . $instance . '/api/v1/custom_emojis';
    $response = file_get_contents($endpoint);
    $customEmojis = json_decode($response, true);
    foreach ($customEmojis as $customEmoji) {
        $shortcode = $customEmoji['shortcode'];
        $url = $customEmoji['url'];
        $emojiTag = '<img src="' . $url . '" alt="' . $shortcode . '" width="45px">';
        echo $emojiTag;
    }
?>
<form method="POST" action="">
    <input type="text" id="instance" name="instance" required value="pb.todon.de">
    <button id="submit">Fetch Emojis</button>
</form>

<script>
    const url = new URL(window.location.href);
const queryString = url.search;
const hasInstance = queryString.includes('instance');
if (hasInstance) {
    const instanceValue = url.searchParams.get('instance');
    document.getElementById('instance').value = instanceValue;
    // Auto-submit the form only if it hasn't been submitted before or if the expiration time has passed
    const formSubmitted = localStorage.getItem('formSubmitted');
    const expirationTime = localStorage.getItem('expirationTime');
    const currentTime = new Date().getTime();
    if (!formSubmitted || (expirationTime && currentTime > expirationTime)) {
        document.getElementById('submit').click();
        localStorage.setItem('formSubmitted', true);
        const newExpirationTime = currentTime + 3000; // 3 seconds in milliseconds
        localStorage.setItem('expirationTime', newExpirationTime);
    }
    //document.getElementById('submit').disabled = true;
}
</script>