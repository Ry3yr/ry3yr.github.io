<?php
$currentURL = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$finalSlashPos = strrpos($currentURL, '/');
if ($finalSlashPos !== false) {
    $currentURL = substr($currentURL, 0, $finalSlashPos + 1);
}

$currentURL = preg_replace('#(?<!:)/{2,}#', '/', $currentURL);

$selectedOption = isset($_GET['option']) ? $_GET['option'] : '';
$videoFolder = $selectedOption . '/';

// Retrieve all video files in the folder
$videoFiles = glob($videoFolder . '*.mp4');
$videoFiles = array_merge($videoFiles, glob($videoFolder . '*.webm'));

//echo "<html><body>";
echo "<form method='GET'>";
echo "<select name='option'>";
$options = array("videos", "rnr", "kkj", "rexe");
foreach ($options as $option) {
    $selected = $selectedOption === $option ? 'selected' : '';
    echo "<option value='$option' $selected>$option</option>";
}
echo "</select>";
echo "<input type='submit' value='Submit'>";
echo "</form>";

echo "<plaintext>";
foreach ($videoFiles as $videoFile) {
    $videoName = pathinfo($videoFile, PATHINFO_FILENAME);
    $videoURL = $currentURL . $videoFolder . basename($videoFile);
    echo "<a class='link' href='$videoURL'>$videoName</a>\n";
}

//echo "</body></html>";
?>