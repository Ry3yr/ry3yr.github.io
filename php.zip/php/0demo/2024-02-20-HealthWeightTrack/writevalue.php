<a target="_blank" href="weightrender.html" style=color:blue>Render</a><br>
<script>
function getQueryParameter(user) {
  const urlSearchParams = new URLSearchParams(window.location.search);
  return urlSearchParams.get(user);
}
document.addEventListener('DOMContentLoaded', function() { //fill input field
  const apiKeyInput = document.getElementById('user');
  const queryParamValue = getQueryParameter('user');
  if (queryParamValue) {
    apiKeyInput.value = queryParamValue;
  }
});
</script>


<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user input
    $user = isset($_POST['user']) ? $_POST['user'] : '';
    $weight = isset($_POST['weight']) ? $_POST['weight'] : '';
    $dressed = isset($_POST['dressed']) ? $_POST['dressed'] : '';
    $date = isset($_POST['date']) ? $_POST['date'] : '';
    $time = isset($_POST['time']) ? $_POST['time'] : '';

    // Remove ":" from the time value
    $time = str_replace(':', '', $time);

    // Remove decimal places from the weight value
    $weight = intval($weight);

    // Create an associative array with the user data
    $userData = array(
        'user' => $user,
        'weight' => $weight,
        'dressed' => $dressed,
        'date' => $date,
        'time' => $time
    );

    // Read the existing JSON data
    $filename = $user . '_weight.json';
    $existingData = file_get_contents($filename);

    // Decode the JSON data into an associative array
    $existingArray = json_decode($existingData, true);

    // Check if the existing data is an array
    if (!is_array($existingArray)) {
        // Create a new array with the new submission
        $existingArray = array($userData);
    } else {
        // Prepend the new submission to the existing array
        array_unshift($existingArray, $userData);
    }

    // Convert the array back to JSON
    $jsonData = json_encode($existingArray);

    // Save the JSON data to the file
    file_put_contents($filename, $jsonData);

    echo 'Data saved successfully!';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Weight Form</title>
</head>
<body>
    <form method="POST" action="">
        <label for="user">User:</label>
        <input type="text" name="user" id="user" value="user" required><br><br>

        <label for="weight">Weight (kg):</label>
        <input type="text" name="weight" id="weight" required><br><br>

        <label for="dressed">Dressed:</label>
        <select name="dressed" id="dressed" required>
            <option value="dressed">Dressed</option>
            <option value="notdressed">Not Dressed</option>
        </select><br><br>

        <label for="date">Date:</label>
        <input type="text" name="date" id="date" value="<?php echo date('Y-m-d'); ?>" required><br><br>

        <label for="time">Time:</label>
        <input type="text" name="time" id="time" value="<?php echo date('H:i'); ?>" required><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
