<?php
$rss = simplexml_load_file('https://rsshub.app/pixiv/user/75406576');
foreach ($rss->channel->item as $item) {
    $title = $item->title;
    $date = date('F j, Y', strtotime($item->pubDate));
    $description = $item->description;
    $link = $item->link;
    echo "<h2><a href=\"$link\" target=\"_blank\">$title</a></h2>";
    echo "<p>$date</p>";
    echo "<p>$description</p>";
}
?>
