<a target="_blank" href="http://alceawisteria.byethost7.com/PHP/0demo/2023-08-12-API-Stuff/DA-(aoikurayami1)-APIKEY.php">APIGEN</a><br>
<a target="_blank" href="http://alceawisteria.byethost7.com/PHP/0demo/2023-08-12-API-Stuff/DAUploader-clientidver.php">DAUploader-clientidver</a><br>

<!DOCTYPE html>
<html>
  <head>
    <title>DeviantArt Image Upload</title>
  </head>
  <body>
    <form action="" method="post" enctype="multipart/form-data">
      <input type="file" name="fileInput"><br><br>
      <label for="titleInput">Title: </label>
      <input type="text" name="titleInput"><br><br>
      <label for="descriptionInput">Description: </label>
      <textarea name="descriptionInput" rows="5"></textarea><br><br>
      <label for="apiKeyInput">API Key: </label>
      <input type="text" name="apiKeyInput" style="border: none;"><br><br> <!-- Added API Key textbox -->
      <button type="submit" name="uploadImage">Upload Image</button>
    </form>

    <div id="output">
      <?php
      if (isset($_POST['uploadImage'])) {
        $file = $_FILES['fileInput'];
        $title = $_POST['titleInput'];
        $description = $_POST['descriptionInput'];
        $apiKey = $_POST['apiKeyInput'];

        // Create a FormData object
        $formData = array(
          'access_token' => $apiKey,
          'title' => $title,
          'description' => $description,
          'file' => new CURLFile($file['tmp_name'], $file['type'], $file['name'])
        );

        // Send POST request to DeviantArt Sta.sh API
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.deviantart.com/api/v1/oauth2/stash/submit');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $formData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);

        if ($response === false) {
          echo 'Error uploading image: ' . curl_error($ch);
        } else {
          echo 'Response: ' . $response;
        }

        curl_close($ch);
      }
      ?>
    </div>
  </body>
</html>
