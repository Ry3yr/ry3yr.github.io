<!---<b>curl -X POST -H "Content-Type: application/x-www-form-urlencoded" \
-d "grant_type=client_credentials&client_id=27347&client_secret=78143caadc4e67f4f26189d13fcbb13d41bc238a95611b5e7c" \
https://www.deviantart.com/oauth2/token</b><br>-->
<?php
// Pre-filled client ID
$clientId = '27347';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve values from form submission
  $clientId = $_POST['client_id'];
  $clientSecret = $_POST['client_secret'];

  // Perform the POST request
  $url = 'https://www.deviantart.com/oauth2/token';
  $data = http_build_query([
    'grant_type' => 'client_credentials',
    'client_id' => $clientId,
    'client_secret' => $clientSecret
  ]);

  $options = [
    'http' => [
      'method' => 'POST',
      'header' => 'Content-Type: application/x-www-form-urlencoded',
      'content' => $data
    ]
  ];

  $context = stream_context_create($options);
  $response = file_get_contents($url, false, $context);

  if ($response === false) {
    // Handle request error
    echo 'Error occurred during the request.';
  } else {
    $responseData = json_decode($response, true);
    // Handle the response data
    var_dump($responseData);
  }
}
?>

<form method="POST" action="">
  <label for="client_id">Client ID:</label>
  <input type="text" id="client_id" name="client_id" value="<?php echo $clientId; ?>" readonly>
  <br>

  <label for="client_secret">Client Secret:</label>
  <input type="text" id="client_secret" name="client_secret" value="">
  <br>

  <input type="submit" value="Submit">
</form>
