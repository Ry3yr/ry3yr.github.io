<?php
$homepage = file_get_contents('http://alceawisteria.byethost7.com/PHP/0demo/2023-03-25-BoxNet/yourpage.html');
echo $homepage;
?>
