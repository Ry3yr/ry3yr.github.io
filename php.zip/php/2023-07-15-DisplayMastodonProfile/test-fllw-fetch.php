<?php
// Function to make API requests
function mastodonRequest($url, $accessToken)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $accessToken]);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}
$userId = '109629985010224381';
$accessToken = 'YOUR_ACCESS_TOKEN';
$followerUrl = 'https://pb.todon.de/api/v1/accounts/' . $userId . '/followers';
$followingUrl = 'https://pb.todon.de/api/v1/accounts/' . $userId . '/following';
$followers = mastodonRequest($followerUrl, $accessToken);
$followings = mastodonRequest($followingUrl, $accessToken);
$followerIds = array_column($followers, 'id');
$followingIds = array_column($followings, 'id');
$inBothLists = array_intersect($followerIds, $followingIds);
function resolveUser($id, $accessToken)
{
    $userUrl = 'https://pb.todon.de/api/v1/accounts/' . $id;
    $user = mastodonRequest($userUrl, $accessToken);
    return $user['acct'];
}
foreach ($followers as $follower) {
    $followerId = $follower['id'];
    $followerUsername = resolveUser($followerId, $accessToken);
    if (in_array($followerId, $inBothLists)) {
        echo '<span style="color: green;">' . $followerUsername . '</span><br>';
    } else {
        echo '<span style="color: red;">' . $followerUsername . '</span><br>';
    }
}
?>

﻿<?php
    //Allow or disallow source viewing
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
