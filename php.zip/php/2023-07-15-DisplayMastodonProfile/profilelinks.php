<?php
$profileUrl = 'https://pb.todon.de/api/v1/accounts/109629985010224381';

// Make a GET request to the profile URL using cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $profileUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

// Parse the JSON response into an associative array
$data = json_decode($response, true);

// Access the fields in the JSON object
$fields = $data['fields'];

// Extract the links from the fields array
$links = [];
if (isset($fields) && is_array($fields)) {
    foreach ($fields as $field) {
        $name = $field['name'];
        $value = $field['value'];
        
        // Extract the URL from the value
        preg_match('/<a href="(.*?)"/', $value, $matches);
        $url = isset($matches[1]) ? $matches[1] : '';
        
        // Add the link to the links array
        $links[$name] = $url;
    }
}

// Display the extracted links
foreach ($links as $name => $url) {
    echo "$name: <a target='_blank' href='$url'>$url</a><br>";
}
?>