
<base href="https://" target="_blank" rel="noopener noreferrer">
<?php
$profileUrl = 'https://pb.todon.de/api/v1/accounts/109629985010224381';
$endpoint = 'https://pb.todon.de/api/v1/custom_emojis';
// Make a GET request to the profile URL using cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $profileUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
// Parse the JSON response into an associative array
$data = json_decode($response, true);
// Access the fields in the JSON object
$id = $data['id'];
$username = $data['username'];
$display_name = $data['display_name'];
$locked = $data['locked'];
$bot = $data['bot'];
$discoverable = $data['discoverable'];
$group = $data['group'];
$created_at = $data['created_at'];
$note = $data['note'];
$url = $data['url'];
$avatar = $data['avatar'];
$avatar_static = $data['avatar_static'];
$header = $data['header'];
$header_static = $data['header_static'];
$followers_count = $data['followers_count'];
$following_count = $data['following_count'];
$statuses_count = $data['statuses_count'];
$last_status_at = $data['last_status_at'];
$noindex = $data['noindex'];
$emojis = $data['emojis'];
$roles = $data['roles'];
$fields = $data['fields'];
// Make a GET request to the custom emojis endpoint
$response = file_get_contents($endpoint);
$customEmojis = json_decode($response, true);
// Replace shorthands in the note with corresponding emoji images
foreach ($customEmojis as $customEmoji) {
    $shortcode = $customEmoji['shortcode'];
    $url = $customEmoji['url'];
    $shortcodePattern = '/:' . preg_quote($shortcode, '/') . ':/';
    $emojiTag = '<img src="' . $url . '" alt="' . $shortcode . '" width="45px">';
    $note = preg_replace($shortcodePattern, $emojiTag, $note);
}

$fields = $data['fields'];
// Extract the links from the fields array
$links = [];
if (isset($fields) && is_array($fields)) {
    foreach ($fields as $field) {
        $name = $field['name'];
        $value = $field['value'];
        preg_match('/<a href="(.*?)"/', $value, $matches);
        $url = isset($matches[1]) ? $matches[1] : '';
        $links[$name] = $url;
    }
}
// Do something with the data
echo "$username@<a target=_blank href=https://urusai.social/share>urusai.social</a><br>\n";
echo "<br><hr>";
echo "$note";
echo "<hr>";
foreach ($links as $name => $url) {echo "$name: <a target='_blank' href='$url'>$url</a><br>";}
echo "Following: <b>$following_count</b>\n";
echo "Followers: <b>$followers_count</b>\n";
echo "Posts: <b>$statuses_count</b>\n";
?>
<br><br><br><br>
