
<?php
require('simple_html_dom.php');
$url = "https://www.youtube.com/user/SaphiraLynx";
$html = file_get_html($url);
$channel_id = $html->find('button[class="yt-uix-button-subscribe-branded"]', 0)->data-channel-external-id;
echo channel_id;
}
?>
