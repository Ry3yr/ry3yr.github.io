
<?php //ob_start(); ?>

<a target="_blank" href="https://www.dekudeals.com/collection/nw7vnrstb9">Link</a>&nbsp;
<a target="_blank" href="http://alceawisteria.byethost7.com/PHP/0demo/2023-04-30-parse-json/parse.php#inks/more/67087617">reload</a>
<br>


<?php
$json = file_get_contents('collection.json');
//Decode JSONV
$json_data = json_decode($json,true);
$peopleCount = 0;
?>
    <table>
        <tr>
            <th>Link</th>
            <th>Format  avail.</th>
            <th>Price</th>
            <!--<th>Note</th>-->
        </tr>
    <?php foreach($json_data['items'] as $key=>$value):
        $peopleCount++;
        ?>
        <tr>
            <td><?php
            echo "<a target=_blank href=";
            echo $value['link'];
            echo ">";
            echo $value['name'];
            echo "</a>";
            ?></td>
            <td><?php echo $value['format']; ?></td>
            <td><?php echo $value['price_paid']; ?></td>
            <td><?php //echo $value['note']; ?></td>
        </tr>
    <?php endforeach; ?>
    </table>
<?php
echo "•Total Games Count: ". $peopleCount;
?>


<?php
$jsonData = file_get_contents("collection.json");
$data = json_decode($jsonData,true);
$total = 0;
foreach ($data["items"] as $value) {
    if($value["format"]==physical){
        $total = $total+1;
    }
}
echo "•Physical Games: $total";
//file_put_contents('dekugames.html', ob_get_contents());
?>

