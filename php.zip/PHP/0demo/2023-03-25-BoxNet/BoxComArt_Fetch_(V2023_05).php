<?php
//file_put_contents("boxcomarthost.html", file_get_contents("https://app.box.com/s/j7i88s6jb4yyk4wmiti4tol8ejoikdhl")); 

$url = "https://app.box.com/s/j7i88s6jb4yyk4wmiti4tol8ejoikdhl";
$file = "arthost _ Powered by Box.html";
// Check if file exists before downloading
if (!file_exists($file)) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $html = curl_exec($ch);
    curl_close($ch);
    // Save file
    file_put_contents($file, $html);
    echo "File downloaded successfully!<br>";
} else {
    echo "File already exists!<br>";
}
?>

<?php
include('simple_html_dom.php');
$html = file_get_html('arthost _ Powered by Box.html');
foreach($html->find('a[data-resin-target="openfile"].item-link') as $link) {
    if(strpos($link->href, 'folder') === false) {
        echo $link->href . "<br>";
    }
}
?>

