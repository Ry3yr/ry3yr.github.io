
<?php
$feed_url = 'https://www.youtube.com/feeds/videos.xml?channel_id=UCmIpOnd5BVx5Si2hp0WNKZw';
$xml = simplexml_load_file($feed_url);

foreach ($xml->entry as $entry) {
    $media = $entry->children('http://search.yahoo.com/mrss/');
    $title = $entry->title;
    $link = $entry->link['href'];
    $thumbnail = $media->group->thumbnail[0]['url'];
    $video_url = $media->group->content->attributes()['url'];
    $video_type = $media->group->content->attributes()['type'];
    
    echo '<div>';
    echo '<a href="' . $link . '"><img src="' . $thumbnail . '"></a>';
    echo '<h2><a href="' . $link . '">' . $title . '</a></h2>';
    
    if ($video_type == 'application/x-shockwave-flash') {
        echo '<object type="application/x-shockwave-flash" data="' . $video_url . '">';
        echo '<param name="movie" value="' . $video_url . '">';
        echo '<param name="allowFullScreen" value="true">';
        echo '</object>';
    } else {
        echo '<video controls>';
        echo '<source src="' . $video_url . '">';
        echo '</video>';
    }
    
    echo '</div>';
}
?>
