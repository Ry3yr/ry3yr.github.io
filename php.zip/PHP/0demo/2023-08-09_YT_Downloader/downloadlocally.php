<!DOCTYPE html>
<html>
<head>
    <title>URL Downloader</title>
</head>
<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $url = $_POST["url"];
        $filename = "downloads/" . basename($url); // Specify the path where you want to save the downloaded file

        // Download the file and save it on the server
        file_put_contents($filename, file_get_contents($url));

        echo "File downloaded and saved successfully!";
    }
    ?>

    <form method="post">
        <label for="url">URL:</label>
        <input type="text" id="url" name="url" required>
        <button type="submit">Download</button>
    </form>
</body>
</html>