    <title>DeviantArt Image Upload</title>
  </head>
  <body>
    <form action="" method="post" enctype="multipart/form-data">
      <input type="file" name="fileInput"><br><br>
      <label for="titleInput">Title: </label>
      <input type="text" name="titleInput"><br><br>
      <label for="descriptionInput">Description: </label>
      <textarea name="descriptionInput" rows="5"></textarea><br><br>
      <label for="clientIdInput">Client ID: </label>
      <input type="text" name="clientIdInput" style="border: none;"><br><br> <!-- Added Client ID textbox -->
      <label for="clientSecretInput">Client Secret: </label>
      <input type="text" name="clientSecretInput" style="border: none;"><br><br> <!-- Added Client Secret textbox -->
      <button type="submit" name="uploadImage">Upload Image</button>
    </form>

    <div id="output">
      <?php
      if (isset($_POST['uploadImage'])) {
        $file = $_FILES['fileInput'];
        $title = $_POST['titleInput'];
        $description = $_POST['descriptionInput'];
        $clientId = $_POST['clientIdInput'];
        $clientSecret = $_POST['clientSecretInput'];

        // Get access token from DeviantArt OAuth2 API
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.deviantart.com/oauth2/token');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array(
          'grant_type' => 'client_credentials',
          'client_id' => $clientId,
          'client_secret' => $clientSecret
        )));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);

        if ($response === false) {
          echo 'Error getting access token: ' . curl_error($ch);
        } else {
          $responseData = json_decode($response, true);
          if (isset($responseData['access_token'])) {
            $accessToken = $responseData['access_token'];

            // Create a FormData object
            $formData = array(
              'access_token' => $accessToken,
              'title' => $title,
              'description' => $description,
              'file' => new CURLFile($file['tmp_name'], $file['type'], $file['name'])
            );

            // Send POST request to DeviantArt Sta.sh API
            curl_setopt($ch, CURLOPT_URL, 'https://www.deviantart.com/api/v1/oauth2/stash/submit');
            curl_setopt($ch, CURLOPT_POSTFIELDS, $formData);
            $response = curl_exec($ch);

            if ($response === false) {
              echo 'Error uploading image: ' . curl_error($ch);
            } else {
              echo 'Response: ' . $response;
            }
          } else {
            echo 'Error getting access token: Invalid response';
          }
        }

        curl_close($ch);
      }
      ?>
    </div>
  </body>
</html>