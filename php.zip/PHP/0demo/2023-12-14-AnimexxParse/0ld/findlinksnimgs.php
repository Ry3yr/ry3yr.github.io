<?php
// URL of the webpage with the fanarts
$url = 'https://www.animexx.de/fanart/zeichner/1248943/';

// HTML content of the webpage
$html = file_get_contents($url);

// Regular expression to find the desired links
$pattern = '/<td class="fathumb" rowspan="2"><a\s+href="([^"]+)"\s+target="([^"]+)"[^>]*>/';

// Find all matches with the regular expression
preg_match_all($pattern, $html, $matches, PREG_SET_ORDER);

// Output the found links and corresponding images
foreach ($matches as $match) {
    $link = $match[1];
    $target = $match[2];
    $validLink = $url . ltrim($link, '/');
    
    // Retrieve the HTML content of each link
    $linkHtml = file_get_contents($validLink);
    
    // Regular expression to find the image source and alt attributes
    $imgPattern = '/<img\s+src="([^"]+)"\s+id="fanart_img_gross"\s+alt="([^"]+)"[^>]*>/';
    
    // Find the image source and alt attributes within the link HTML
    preg_match($imgPattern, $linkHtml, $imgMatch);
    
    // Check if the image source and alt attributes were found
    if (isset($imgMatch[1]) && isset($imgMatch[2])) {
        $imgSrc = $imgMatch[1];
        $imgAlt = $imgMatch[2];
        
        // Output the link and the corresponding image as <img> tag
        echo '<a href="' . $validLink . '" target="' . $target . '">' . $validLink . '</a><br>';
        echo '<img src="' . $imgSrc . '" alt="' . $imgAlt . '"><br>';
    }
}
?>