<?php
// URL of the webpage with the fanarts
$url = 'https://www.animexx.de/fanart/zeichner/1248943/';

// HTML content of the webpage
$html = file_get_contents($url);

// Regular expression to find the desired links
$pattern = '/<td class="fathumb" rowspan="2"><a\s+href="([^"]+)"\s+target="([^"]+)"[^>]*>/';

// Find all matches with the regular expression
preg_match_all($pattern, $html, $matches, PREG_SET_ORDER);

// Output the found links
foreach ($matches as $match) {
    $link = $match[1];
    $target = $match[2];
    $validLink = $url . ltrim($link, '/');
    echo '<a href="' . $validLink . '" target="' . $target . '">' . $validLink . '</a><br>';
}
?>