<?php

session_start();

$ftp_server = isset($_POST['ftp_server']) ? $_POST['ftp_server'] : '';
$ftp_user = isset($_POST['ftp_user']) ? $_POST['ftp_user'] : '';
$ftp_pass = isset($_POST['ftp_pass']) ? $_POST['ftp_pass'] : '';
$use_passive_mode = isset($_POST['use_passive_mode']) && $_POST['use_passive_mode'] == 'on';

if (!empty($ftp_server) && !empty($ftp_user) && !empty($ftp_pass)) {

    // Attempt to log in
    $conn_id = ftp_connect($ftp_server);
    if ($conn_id) {
        $login_result = ftp_login($conn_id, $ftp_user, $ftp_pass);
        if ($login_result) {
            echo 'Login successful!<br>';

            // Switch between passive and active mode
            if ($use_passive_mode) {
                ftp_pasv($conn_id, true);
                echo 'Using Passive Mode<br>';
            } else {
                ftp_pasv($conn_id, false);
                echo 'Using Active Mode<br>';
            }

            // Store FTP connection in a session variable
            $_SESSION['ftp_conn_id'] = $conn_id;

            // Get the requested directory
            $current_directory = isset($_GET['dir']) ? $_GET['dir'] : '.';
            $current_directory = rtrim($current_directory, '/');

            // Change to the requested directory
            if ($current_directory !== '.') {
                $change_dir_result = ftp_chdir($conn_id, $current_directory);
                if (!$change_dir_result) {
                    echo 'Failed to change directory.';
                }
            }

            // Get the current directory
            $current_directory = ftp_pwd($conn_id);

            // Get the current directory contents
            $directory_rawlist = ftp_rawlist($conn_id, '.');
            $directory_contents = [];

            if ($directory_rawlist) {
                foreach ($directory_rawlist as $raw_item) {
                    $item_details = preg_split("/\s+/", $raw_item, 9);
                    $item_name = $item_details[8];
                    $item_type = $item_details[0][0] === 'd' ? 'directory' : 'file';

                    // Generate clickable links for directories
                    if ($item_type === 'directory') {
                        $directory_contents[] = '<a href="?dir=' . urlencode($current_directory . '/' . $item_name) . '">' . $item_name . '</a>';
                    } else {
                        $directory_contents[] = $item_name;
                    }
                }
            }

            // Display the current directory and its contents
            echo '<h3>Current Directory: ' . $current_directory . '</h3>';
            echo '<h4>Directory Contents</h4>';
            echo '<ul>';
            foreach ($directory_contents as $item) {
                echo '<li>' . $item . '</li>';
            }
            echo '</ul>';
        } else {
            echo 'Login failed. Please check your credentials.';
        }
    } else {
        echo 'Could not connect to the FTP server.';
    }
} else {
    echo 'Please fill in all the required fields.';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>FTP Form</title>
</head>
<body>
    <h1>FTP Form</h1>
    <form method="post">
        <label for="use_passive_mode">Use Passive Mode</label>
        <input type="checkbox" name="use_passive_mode" id="use_passive_mode">
        <br>
        <label for="ftp_server">FTP Server:</label>
        <input type="text" name="ftp_server" id="ftp_server" value="">
        <br>
        <label for="ftp_user">FTP Username:</label>
        <input type="text" name="ftp_user" id="ftp_user" value="">
        <br>
        <label for="ftp_pass">FTP Password:</label>
        <input type="password" name="ftp_pass" id="ftp_pass" value="">
        <br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
