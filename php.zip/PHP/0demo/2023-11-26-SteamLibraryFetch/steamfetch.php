<!DOCTYPE html>
<html>
<head>
  <title>Steam Library Viewer</title>
  <style>
    table {
      border-collapse: collapse;
    }

    table, th, td {
      border: 1px solid #ccc;
      padding: 8px;
    }
  </style>
</head>
<body>
  <table id="steamLibrary">
    <thead>
      <tr>
        <th>Game Name</th>
        <th>Playtime (minutes)</th>
        <th>Purchase Date</th>
        <th>Price Paid</th>
      </tr>
    </thead>
    <tbody>
      <?php
      // Replace 'YOUR_API_KEY' with your actual Steam API key
      $apiKey = 'F96D40C8F7FA9C51B204D4707E0A094B';
      $steamId = '76561198119673186';

      // Construct the API URL to fetch the user's Steam library data
      $libraryApiUrl = "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key={$apiKey}&steamid={$steamId}&include_appinfo=1&include_played_free_games=1";

      // Fetch the user's Steam library data
      $libraryResponse = file_get_contents($libraryApiUrl);
      $libraryData = json_decode($libraryResponse, true);

      if ($libraryData && isset($libraryData['response']['games'])) {
        $games = $libraryData['response']['games'];

        if (!empty($games)) {
          // Sort the games array alphabetically by game name
          usort($games, function($a, $b) {
            return strcmp($a['name'], $b['name']);
          });

          foreach ($games as $game) {
            $appId = $game['appid'];
            $appName = $game['name'];
            $playtimeMinutes = $game['playtime_forever'];
            $purchaseDate = isset($game['purchase_date']) ? date('Y-m-d', $game['purchase_date']) : 'Unknown';

            // Construct the API URL to fetch the purchase information for the game
            $purchaseApiUrl = "https://store.steampowered.com/api/appdetails?appids={$appId}";

            // Fetch the purchase information for the game
            $purchaseResponse = file_get_contents($purchaseApiUrl);
            $purchaseData = json_decode($purchaseResponse, true);

            if ($purchaseData && isset($purchaseData[$appId]['data']['price_overview'])) {
              $price = $purchaseData[$appId]['data']['price_overview']['final_formatted'];
            } else {
              $price = 'Unknown';
            }

            echo '<tr>';
            echo "<td>{$appName}</td>";
            echo "<td>{$playtimeMinutes}</td>";
            echo "<td>{$purchaseDate}</td>";
            echo "<td>{$price}</td>";
            echo '</tr>';
          }
        } else {
          echo '<tr><td colspan="4">No games found in the Steam library.</td></tr>';
        }
      } else {
        echo '<tr><td colspan="4">Error retrieving Steam library.</td></tr>';
      }
      ?>
    </tbody>
  </table>

  <form action="download.php" method="post">
    <input type="hidden" name="libraryData" value="<?php echo htmlspecialchars(json_encode($libraryData)); ?>">
    <button type="submit">Download as JSON</button>
  </form>
</body>
</html>