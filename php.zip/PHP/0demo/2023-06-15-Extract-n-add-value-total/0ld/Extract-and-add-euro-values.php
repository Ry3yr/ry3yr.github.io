<?php
if(isset($_POST['submit'])) {
  $input = $_POST['input'];
  $total = 0;
  preg_match_all('/(\d+)[€]/', $input, $matches);
  foreach($matches[1] as $match) {
    $total += $match;
  }
  echo "Total value: €".$total;
}
?>

<form method="post" action="">
  <textarea name="input"></textarea>
  <br>
  <button type="submit" name="submit">Calculate total</button>
</form>