<h1> FediBlock Checker</h1>

    <a target="_blank" href="?profileUrl=https%3A%2F%2Fmastodon.green%2F%40mondstern&instanceUrl=https%3A%2F%2Fpb.todon.de&apiKey=YOUR_API_KEY">xmpl</a><br><br>
    <form method="POST" action="">
        <label for="apiKey">API Key:</label>
        <input type="text" id="apiKey" name="apiKey" required><br><br>
        <label for="instanceUrl">Instance URL:</label>
        <input type="text" id="instanceUrl" name="instanceUrl" required><br><br>
        <label for="profileUrl">Profile URL:</label>
        <input type="text" id="profileUrl" name="profileUrl" required><br><br>
        <input type="submit" value="Check">
    </form>
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // API credentials
        $apiKey = $_POST['apiKey'];
        $instanceUrl = $_POST['instanceUrl'];
        $profileUrl = $_POST['profileUrl'];
        // API endpoint
        $apiEndpoint = $instanceUrl . '/api/v2/search/?q=' . urlencode($profileUrl) . '&limit=1&resolve=true';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiEndpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($httpCode >= 200 && $httpCode < 300) {
            echo "API key has access to $profileUrl.<br>";
        } else {
            echo "API key does not have access to $profileUrl. Response code: $httpCode<br>";
        }
        echo "API Endpoint: $apiEndpoint";
    }
    ?>
    <script>
        window.onload = function () {
            const urlParams = new URLSearchParams(window.location.search);
            const profileUrl = urlParams.get("profileUrl");
            const instanceUrl = urlParams.get("instanceUrl");
            const apiKey = urlParams.get("apiKey");
            if (profileUrl && instanceUrl && apiKey) {
                document.getElementById("apiKey").value = apiKey;
                document.getElementById("instanceUrl").value = instanceUrl;
                document.getElementById("profileUrl").value = profileUrl;
            }
        }
    </script>