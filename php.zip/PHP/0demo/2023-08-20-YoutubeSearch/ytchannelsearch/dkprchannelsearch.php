<!DOCTYPE html>
<html>
<head>
    <title>YouTube Channel Content Search</title>
</head>
<body>
    <h1>YouTube Channel Content Search</h1>
    <form method="POST" action="">
        <label for="channelName">Channel Name:</label>
        <input type="text" name="channelName" id="channelName"><br><br>
        <label for="channelId">Channel ID:</label>
        <input type="text" name="channelId" id="channelId" value="UCrltGih11A_Nayz6hG5XtIw"><br><br>
        <label for="searchText">Search Text:</label>
        <input type="text" name="searchText" required><br><br>
        <button type="submit">Search</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve the channel name, channel ID, and search text from the form
        $channelName = $_POST['channelName'];
        $channelId = $_POST['channelId'];
        $searchText = $_POST['searchText'];

        if (empty($searchText)) {
            echo "<p>Please enter a search text.</p>";
        } else {
            // Set your YouTube Data API key
            $apiKey = 'APIKEY';

            // Determine the channel parameter based on channel name or channel ID
            $channelParam = "";
            if (!empty($channelId)) {
                $channelParam = "channelId=" . urlencode($channelId);
            } elseif (!empty($channelName)) {
                $channelParam = "channel=" . urlencode($channelName);
            }

            // Make a request to the YouTube Data API
            $url = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=" . urlencode($searchText) . "&maxResults=10&key=" . $apiKey . "&" . $channelParam;
            $response = file_get_contents($url);
            $json = json_decode($response, true);

            if (isset($json['items']) && !empty($json['items'])) {
                echo "<h2>Search Results</h2>";

                foreach ($json['items'] as $item) {
                    if ($item['id']['kind'] !== 'youtube#video') {
                        continue; // Skip non-video results
                    }

                    $videoId = $item['id']['videoId'];
                    $videoTitle = $item['snippet']['title'];
                    $videoThumbnail = $item['snippet']['thumbnails']['default']['url'];

                    $videoLink = "https://www.youtube.com/watch?v=" . $videoId;

                    echo "<a href='$videoLink' target='_blank'>";
                    echo "<img src='$videoThumbnail' alt='$videoTitle'>";
                    echo "<p>$videoTitle</p>";
                    echo "</a>";
                }
            } else {
                echo "<p>No videos found for the specified channel and search text.</p>";
            }
        }
    }
    ?>
</body>
</html>
