<?php

$url = 'https://pb.todon.de/api/v1/accounts/109629985010224381/statuses';

$parsedUrl = parse_url($url);
$domain = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];

// Fetch data from the URL
$response = file_get_contents($url);

if ($response === false) {
    echo 'Error: Unable to fetch data.';
    exit;
}

// Extract preview card links from the response text
$previewCards = extractPreviewCardLinks($response);

// Generate HTML with <img> tags
$html = generateImageTags($previewCards, $domain);

// Display the domain and the HTML
echo 'Domain: ' . $domain . '<br>';
echo 'Preview Card Images:<br>';
echo $html;

/**
 * Extracts the preview card links from the given response text
 *
 * @param string $responseText
 * @return array
 */
function extractPreviewCardLinks($responseText)
{
    $pattern = '/\/system\/cache\/preview_cards\/images\/\d+\/\d+\/\d+\/original\/[a-f0-9]+\.(?:jpg|jpeg|png|gif)/i';
    preg_match_all($pattern, $responseText, $matches);

    return $matches[0] ?? [];
}

/**
 * Generates HTML with <img> tags using the given image URLs
 *
 * @param array $imageUrls
 * @param string $domain
 * @return string
 */
function generateImageTags($imageUrls, $domain)
{
    $html = '';

    foreach ($imageUrls as $imageUrl) {
        $html .= '<img src="' . $domain . $imageUrl . '" alt="Preview Card Image"><br>';
    }

    return $html;
}