<!DOCTYPE html>
<html>
<head>
    <title>PDF Viewer</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.2.2/pdf.js"></script>
</head>
<body>
    <label for="pdf-upload">Upload PDF:</label>
    <input type="file" id="pdf-upload" accept="application/pdf"/>

    <label for="pdf-url">PDF URL:</label>
    <input type="text" id="pdf-url" placeholder="Enter PDF URL"/>
    <button id="load-pdf">Load PDF</button>

    <button id="zoom-in" style="background:transparent; border:transparent;display: none;">Zoom In</button>
    <div id="zoom-percent" style="background:transparent; border:transparent;display: none;">60</div>
    <button id="zoom-out" style="background:transparent; border:transparent;display: none;">Zoom Out</button>
    <button id="zoom-reset" style="background:transparent; border:transparent;display: none;">Reset Zoom</button>
    <div id="pages"></div>

    <script>
        pdfjsLib.GlobalWorkerOptions.workerSrc =
            'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.2.2/pdf.worker.js';

        document.querySelector("#pdf-upload").addEventListener("change", function(e){
            document.querySelector("#pages").innerHTML = "";
            zoomReset();
            var file = e.target.files[0]
            if(file.type != "application/pdf"){
                alert(file.name + " is not a pdf file.")
                return
            }
            var fileReader = new FileReader();  
            fileReader.onload = function() {
                var typedarray = new Uint8Array(this.result);
                pdfjsLib.getDocument(typedarray).promise.then(function(pdf) {
                    // you can now use *pdf* here
                    console.log("the pdf has", pdf.numPages, "page(s).");
                    for (var i = 0; i < pdf.numPages; i++) {
                        (function(pageNum){
                        pdf.getPage(i+1).then(function(page) {
                            // you can now use *page* here
                            var viewport = page.getViewport(2.0);
                            var pageNumDiv = document.createElement("div");
                            pageNumDiv.className = "pageNumber";
                            pageNumDiv.innerHTML = "Page " + pageNum;
                            var canvas = document.createElement("canvas");
                            canvas.className = "page";
                            canvas.title = "Page " + pageNum;
                            document.querySelector("#pages").appendChild(pageNumDiv);
                            document.querySelector("#pages").appendChild(canvas);
                            canvas.height = viewport.height;
                            canvas.width = viewport.width;
                            page.render({
                                canvasContext: canvas.getContext('2d'),
                                viewport: viewport
                            }).promise.then(function(){
                                console.log('Page rendered');
                            });
                            page.getTextContent().then(function(text){
                                console.log(text);
                            });
                        });
                        })(i+1);
                    }
                });
            };
            fileReader.readAsArrayBuffer(file);
        });

        document.querySelector("#load-pdf").addEventListener("click", function(){
            document.querySelector("#pages").innerHTML = "";
            zoomReset();
            var url = document.querySelector("#pdf-url").value.trim();
            if (!url) {
                alert("Please enter a PDF URL.");
                return;
            }
            if (!url.endsWith(".pdf")) {
                alert("Please enter a valid PDF URL.");
                return;
            }
            fetch('fetch_pdf.php?url=' + encodeURIComponent(url)).then(function(response) {
                if (!response.ok) {
                    throw new Error(response.statusText);
                }
                return response.arrayBuffer();
            }).then(function(buffer) {
                pdfjsLib.getDocument(buffer).promise.then(function(pdf) {
                    // you can now use *pdf* here
                    console.log("the pdf has", pdf.numPages, "page(s).");
                    for (var i = 0; i < pdf.numPages; i++) {
                        (function(pageNum){
                        pdf.getPage(i+1).then(function(page) {
                            // you can now use *page* here
                            var viewport = page.getViewport(2.0);
                            var pageNumDiv = document.createElement("div");
                            pageNumDiv.className = "pageNumber";
                            pageNumDiv.innerHTML = "Page " + pageNum;
                            var canvas = document.createElement("canvas");
                            canvas.className = "page";
                            canvas.title = "Page " + pageNum;
                            document.querySelector("#pages").appendChild(pageNumDiv);
                            document.querySelector("#pages").appendChild(canvas);
                            canvas.height = viewport.height;
                            canvas.width = viewport.width;
                            page.render({
                                canvasContext: canvas.getContext('2d'),
                                viewport: viewport
                            }).promise.then(function(){
                                console.log('Page rendered');
                            });
                            page.getTextContent().then(function(text){
                                console.log(text);
                            });
                        });
                       })(i+1);
                    }
                });
            }).catch(function(error) {
                console.error('Error occurred while fetching the PDF: ' + error);
            });
        });

        function zoomIn() {
            var scale = parseFloat(document.querySelector("#zoom-percent").textContent);
            scale = scale + 10;
            if (scale > 200) {
                scale = 200;
            }
            document.querySelector("#zoom-percent").textContent = scale;
            updateZoomButtons();
            updateZoom(scale);
        }

        function zoomOut() {
            var scale = parseFloat(document.querySelector("#zoom-percent").textContent);
            scale = scale - 10;
            if (scale < 50) {
                scale = 50;
            }
            document.querySelector("#zoom-percent").textContent = scale;
            updateZoomButtons();
            updateZoom(scale);
        }

        function zoomReset() {
            var scale = 100;
            document.querySelector("#zoom-percent").textContent = scale;
            updateZoomButtons();
            updateZoom(scale);
        }

        function updateZoomButtons() {
            var scale = parseFloat(document.querySelector("#zoom-percent").textContent);
            var zoomInButton = document.querySelector("#zoom-in");
            var zoomOutButton = document.querySelector("#zoom-out");
            if (scale >= 200) {
                zoomInButton.style.display = "none";
            } else {
                zoomInButton.style.display = "inline-block";
            }
            if (scale <= 50) {
                zoomOutButton.style.display = "none";
            } else {
                zoomOutButton.style.display = "inline-block";
            }
        }

        function updateZoom(scale) {
            var pages = document.querySelectorAll(".page");
            for (var i = 0; i < pages.length; i++) {
                var canvas = pages[i];
                var context = canvas.getContext("2d");
                var viewport = canvas.pdfPage.getViewport({ scale: scale / 100 });
                canvas.width = viewport.width;
                canvas.height = viewport.height;
                canvas.style.width = viewport.width + "px";
                canvas.style.height = viewport.height + "px";
                canvas.pdfPage.render({ canvasContext: context, viewport: viewport });
            }
        }

        document.querySelector("#zoom-in").addEventListener("click", zoomIn);
        document.querySelector("#zoom-out").addEventListener("click", zoomOut);
        document.querySelector("#zoom-reset").addEventListener("click", zoomReset);
    </script>
</body>
</html>