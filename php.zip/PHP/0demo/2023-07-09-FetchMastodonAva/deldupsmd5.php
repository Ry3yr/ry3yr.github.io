<?php
function scanDirectories($dir)
{
    $fileList = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST,
        RecursiveIteratorIterator::CATCH_GET_CHILD // Ignore "Permission denied" errors
    );
    foreach ($iterator as $path => $fileInfo) {
        if ($fileInfo->isFile()) {
            $md5 = md5_file($path); // Calculate the MD5 hash of the file
            $fileList[$md5][] = $path; // Store the file path in an array indexed by the MD5 hash
        }
    }
    return $fileList;
}
function deleteFile($filePath)
{
    if (is_file($filePath)) {
        unlink($filePath);
        echo "Deleted: " . $filePath . "\n";
    }
}
function deleteDuplicateFiles($dir)
{
    $currentDir = getcwd(); // Get the current working directory
    chdir($dir); // Change the current working directory to the specified directory
    $fileList = scanDirectories('.'); // Scan the subdirectories from the current directory
    $filesToDelete = [];
    foreach ($fileList as $md5 => $files) {
        if (count($files) > 1) {
            $fileCount = count($files);
            for ($i = 1; $i < $fileCount; $i++) {
                $filePath = $files[$i];
                if (is_file($filePath)) {
                    $filesToDelete[] = $filePath;
                }
            }
        }
    }
    if (count($filesToDelete) > 0) {
        echo "Found duplicate files:<br>";
        foreach ($filesToDelete as $filePath) {
            echo '<a href="?delete=' . urlencode($filePath) . '">' . $filePath . '</a><br>';
        }
        if (isset($_GET['delete'])) {
            $fileToDelete = urldecode($_GET['delete']);
            deleteFile($fileToDelete);
        }
    } else {
        echo "No duplicate files found.\n";
    }
    chdir($currentDir);
}
$directory = getcwd();
deleteDuplicateFiles($directory);
?>