<?php
// Set the Mastodon user to get the avatar for
$user = "ryedai";

// Set the URL for the RSS feed
$rss_url = "https://mastodon.social/@{$user}.rss";

// Load the RSS feed using SimpleXML
$rss = simplexml_load_file($rss_url);

// Extract the image URL from the <url> element inside the <image> element of the RSS feed
$image_url = (string) $rss->channel->image->url;

// Extract the filename for the image from the URL
$filename = basename($image_url);

// Set the filename to the user's Mastodon username, the current date, and the appropriate file extension
if (strpos($filename, '.jpg') !== false) {
    $filename = $user . '_' . date('Y-m-d') . '.jpg';
} elseif (strpos($filename, '.png') !== false) {
    $filename = $user . '_' . date('Y-m-d') . '.png';
}

// Set the path to the directory to save the image
$dir = "./" . strtolower($user) . "/";

// Create the directory if it doesn't exist
if (!file_exists($dir)) {
    mkdir($dir);
}

// Download the image using cURL
$ch = curl_init($image_url);
$fp = fopen($dir . $filename, 'wb');
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_exec($ch);
curl_close($ch);
fclose($fp);