<?php
$url = 'https://yugioh.fandom.com/wiki/Yu-Gi-Oh!_Wiki';
$html = file_get_contents($url);
$start = strpos($html, 'h3><span class="mw-headline" id="TCG"><i>TCG</i></span></h3>');
$end = strpos($html, '<span class="mw-headline" id="Anime"', $start);
$length = $end - $start;
$result = substr($html, $start, $length);
$baseUrl = parse_url($url, PHP_URL_SCHEME) . '://' . parse_url($url, PHP_URL_HOST);
$fixedResult = str_replace('href="/', 'href="'.$baseUrl.'/', $result);
echo $fixedResult;
?>