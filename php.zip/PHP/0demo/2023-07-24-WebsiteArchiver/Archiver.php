<!DOCTYPE html>
<html>
<head>
  <title>Website Backup Tool</title>
</head>
<body>
  <h1>Website Backup Tool</h1>
  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="websiteUrl">Website URL:</label>
    <input type="text" name="websiteUrl" id="websiteUrl">
    <br><br>
    <input type="submit" name="submit" value="Backup Website">
  </form>
  <?php
  if(isset($_POST['websiteUrl'])) {
    $websiteUrl = $_POST['websiteUrl'];
    $backupDir = dirname(__FILE__) . '/';
    $backupFolder = $backupDir . basename(parse_url($websiteUrl, PHP_URL_HOST));
    if (!file_exists($backupFolder)) {
      mkdir($backupFolder, 0777, true);
    }
    $dom = new DOMDocument();
    $html = file_get_contents($websiteUrl);
    libxml_use_internal_errors(true);
    $dom->loadHTML($html);
    $htmlFileName = basename($websiteUrl);
    $htmlFileName = str_replace('.','-', $htmlFileName);
    $htmlFileName = str_replace('/','-', $htmlFileName);
    $htmlFileName = str_replace('?','-', $htmlFileName);
    $htmlFileName = str_replace('=','-', $htmlFileName);
    $htmlSubfolder = $backupFolder . '/' . $htmlFileName;
    if (!file_exists($htmlSubfolder)) {
      mkdir($htmlSubfolder, 0777, true);
    }
    $htmlFile = $htmlSubfolder . '/index.html';
    file_put_contents($htmlFile, $dom->saveHTML());
    $cssLinks = $dom->getElementsByTagName('link');
    foreach ($cssLinks as $cssLink) {
      if ($cssLink->getAttribute('rel') == 'stylesheet') {
        $cssUrl = $cssLink->getAttribute('href');
        $cssContent = file_get_contents($cssUrl);
        file_put_contents($htmlSubfolder . '/' . basename($cssUrl), $cssContent);
        $cssLink->setAttribute('href', basename($cssUrl));
      }
    }
    $imgTags = $dom->getElementsByTagName('img');
    foreach ($imgTags as $imgTag) {
      $imgUrl = $imgTag->getAttribute('src');
      $imgContent = file_get_contents($imgUrl);
      file_put_contents($htmlSubfolder . '/' . basename($imgUrl), $imgContent);
      $imgTag->setAttribute('src', basename($imgUrl));
    }
    $videoTags = $dom->getElementsByTagName('video');
    foreach ($videoTags as $videoTag) {
      $sources = $videoTag->getElementsByTagName('source');
      foreach ($sources as $source) {
        $videoUrl = $source->getAttribute('src');
        $videoContent = file_get_contents($videoUrl);
        file_put_contents($htmlSubfolder . '/' . basename($videoUrl), $videoContent);
        $source->setAttribute('src', basename($videoUrl));
      }
    }
    $audioTags = $dom->getElementsByTagName('audio');
    foreach ($audioTags as $audioTag) {
      $sources = $audioTag->getElementsByTagName('source');
      foreach ($sources as $source) {
        $audioUrl = $source->getAttribute('src');
        $audioContent = file_get_contents($audioUrl);
        file_put_contents($htmlSubfolder . '/' . basename($audioUrl), $audioContent);
        $source->setAttribute('src', basename($audioUrl));
      }
    }
    $fontTags = $dom->getElementsByTagName('link');
    foreach ($fontTags as $fontTag) {
      if ($fontTag->getAttribute('rel') == 'stylesheet' && strpos($fontTag->getAttribute('href'), '.woff') !== false) {
        $fontUrl = $fontTag->getAttribute('href');
        $fontContent = file_get_contents($fontUrl);
        file_put_contents($htmlSubfolder . '/' . basename($fontUrl), $fontContent);
        $fontTag->setAttribute('href', basename($fontUrl));
      }
    }
    $scriptTags = $dom->getElementsByTagName('script');
    foreach ($scriptTags as $scriptTag) {
      if ($scriptTag->getAttribute('src')) {
        $scriptUrl = $scriptTag->getAttribute('src');
        $scriptContent = file_get_contents($scriptUrl);
        file_put_contents($htmlSubfolder . '/' . basename($scriptUrl), $scriptContent);
        $scriptTag->setAttribute('src', basename($scriptUrl));
      }
    }
    file_put_contents($htmlFile, $dom->saveHTML());
    echo 'Website backup complete!';
  }
  ?>
</body>
</html>