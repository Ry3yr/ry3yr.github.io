<?php
// Settings Update Page and Handler in One File

// Function to log debug information
function logDebug($msg) {
    $logFile = __DIR__ . '/debug.log';
    file_put_contents($logFile, "[" . date('c') . "] $msg\n", FILE_APPEND);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form input data
    $masToInstance = $_POST['masToInstance'] ?? '';
    $locked = $_POST['locked'] ?? 'false';
    $bot = $_POST['bot'] ?? 'false';
    $discoverable = $_POST['discoverable'] ?? 'false'; // New Discoverable Toggle

    // Log the updated settings
    logDebug("Settings updated: masToInstance = $masToInstance, locked = $locked, bot = $bot, discoverable = $discoverable");

    // Simulate profile update without modifying static fields
    $profileObject = [
        '@context' => 'https://www.w3.org/ns/activitystreams',
        'id' => "https://alceawis.com/alceawis", // Static ID (replace with dynamic username if needed)
        'type' => 'Person',
        'inbox' => "https://alceawis.com/alceawis/inbox", // Replace with dynamic URL
        'outbox' => "https://alceawis.com/alceawis/outbox", // Replace with dynamic URL
        'followers' => "https://alceawis.com/alceawis/followers", // Replace with dynamic URL
        'publicKey' => [
            'id' => "https://alceawis.com/alceawis#main-key", // Replace with dynamic URL
            'owner' => "https://alceawis.com/alceawis", // Replace with dynamic URL
            'publicKeyPem' => @file_get_contents(__DIR__ . '/public.pem'),
        ],
        // Add new fields for toggles
        'locked' => $locked === 'true', // Convert 'true'/'false' string to boolean
        'bot' => $bot === 'true', // Convert 'true'/'false' string to boolean
        'discoverable' => $discoverable === 'true', // Convert 'true'/'false' string to boolean
    ];

    // Simulate sending the update to followers (you can federate it here)
    logDebug("Profile Update Activity Sent for masToInstance: $masToInstance");

    // For now, just log the profile update activity (in real code, you'd send this to followers)
    logDebug("Profile update: " . json_encode($profileObject, JSON_PRETTY_PRINT));

    // Show success message (optional)
    echo "<p>Settings updated successfully!</p>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings Update</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            font-size: 14px;
            display: block;
            margin-bottom: 6px;
        }

        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            font-size: 14px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Update Profile Settings</h2>
        <form action="" method="POST">
            <!-- Instance URL -->
            <label for="masToInstance">Instance URL</label>
            <input type="url" name="masToInstance" id="masToInstance" required placeholder="Enter your instance URL" value="https://mas.to">

            <!-- Locked Toggle -->
            <label for="locked">Profile Locked</label>
            <select name="locked" id="locked">
                <option value="false">No</option>
                <option value="true">Yes</option>
            </select>

            <!-- Bot Toggle -->
            <label for="bot">Bot Profile</label>
            <select name="bot" id="bot">
                <option value="false">No</option>
                <option value="true">Yes</option>
            </select>

            <!-- Discoverable Toggle -->
            <label for="discoverable">Profile Discoverable</label>
            <select name="discoverable" id="discoverable">
                <option value="false">No</option>
                <option value="true">Yes</option>
            </select>

            <!-- Submit Button -->
            <button type="submit">Update Settings</button>
        </form>
    </div>

</body>
</html>
