<?php if (!defined('HTMLY')) die('HTMLy'); ?>
<h1><?echo i18n('You_dont_have_permission_to_access_this_page');?></h1>