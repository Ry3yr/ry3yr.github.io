<!--t Fediverse Review t-->
<!--d **Mastodon (+/-)** + Great API (ratelimits to 300 postsminute), requires specific #pagination + Nice &amp; #customizable userinterface + post #edit d-->
<!--tag Mastodon,Akkoma,Pixlfed tag-->


<meta charset="utf-8">
<a target="_blank" href="https://ericmurphy.xyz/blog/mastodon/" style=color:blue>Why SocialMedia is superfluous</a>
<p style="box-sizing: border-box; margin-top: 0px; margin-bottom: 1rem; color: rgb(33, 37, 41); font-family: Georgia, sans-serif; font-size: 16px;"><span style="box-sizing: border-box; font-weight: bolder;">Mastodon (+/-)</span><br style="box-sizing: border-box;">+ Great API (ratelimits to 300 postsminute), requires specific #pagination<br style="box-sizing: border-box;">+ Nice & #customizable userinterface<br style="box-sizing: border-box;">+ post #edit function<br style="box-sizing: border-box;">+ Account deletion are immediate …<br style="box-sizing: border-box;">0 500 charalimit<br style="box-sizing: border-box;">- but posts may very well stick around in othger instances as #cache .. You can’t delete them. #ever<br style="box-sizing: border-box;">- #ActivityPub is terrible at #synchronizing posts across #servers<br style="box-sizing: border-box;">- cannot lock account post from past ( #twitter , #bluesky can!)<br style="box-sizing: border-box;">- defederation is a wonky feature at best, mutes&blocks are as in other socialmedia<br style="box-sizing: border-box;">- broken waybackarchive for 420 instances<br style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: bolder;">Verdict:</span> Do not use.<br style="box-sizing: border-box;">(Don’t use #Bluesky, #Threads, #Twitter either)<br style="box-sizing: border-box;">( #Akkoma uses the same api structure, has emoji reacts and allows editing the post state after the fact)<br style="box-sizing: border-box;">=> Use Akkom instead, but mamny demerits still apply !</p><p style="box-sizing: border-box; margin-top: 0px; margin-bottom: 1rem; color: rgb(33, 37, 41); font-family: Georgia, sans-serif; font-size: 16px;"><br style="box-sizing: border-box;"><br style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: bolder;">Writefreely</span><br style="box-sizing: border-box;">+ good interface + markdownedit<br style="box-sizing: border-box;">+ has rsscfeed and federates (with terribad #Activitypub<br style="box-sizing: border-box;">- instances die alot<br style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: bolder;">Verdict</span>:<br style="box-sizing: border-box;">Only use with many backups.<br style="box-sizing: border-box;">Blogplatforms preferred.<br style="box-sizing: border-box;">HTMLy f.e.</p><p style="box-sizing: border-box; margin-top: 0px; margin-bottom: 1rem; color: rgb(33, 37, 41); font-family: Georgia, sans-serif; font-size: 16px;"><br style="box-sizing: border-box;"><br style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: bolder;">Pixlfed</span><br style="box-sizing: border-box;">+ good interface<br style="box-sizing: border-box;">+ Instagram import …<br style="box-sizing: border-box;">- .. But no way to move content from one instance to another…<br style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: bolder;">Verdict</span>:<br style="box-sizing: border-box;">Use sparingly, or selfhost</p>

<details>
**Mastodon (+/-)**
+ Great API (ratelimits to 300 postsminute), requires specific #pagination
+ Nice & #customizable userinterface
+ post #edit function
+ Account deletion are immediate ...
0 500 charalimit
- but posts may very well stick around in othger instances as #cache .. You can't delete them. #ever
- #ActivityPub is terrible at #synchronizing posts across #servers
- cannot lock account post from past ( #twitter , #bluesky can!)
- defederation is a wonky feature at best, mutes&blocks are as in other socialmedia
- broken waybackarchive for 420  instances
**Verdict:** Do not use.
(Don't use #Bluesky, #Threads, #Twitter either)
( #Akkoma uses the same api structure, has emoji reacts and allows editing the post state after the fact)
=> Use Akkom instead, but mamny demerits still apply !

<br><br>
**Writefreely**
+ good interface + markdownedit
+ has rsscfeed and federates (with terribad #Activitypub
- instances die alot
**Verdict**:
Only use with many backups.
Blogplatforms preferred.
HTMLy f.e.

<br><br>
**Pixlfed**
+ good interface
+ Instagram import ...
- .. But no way to move content from one instance to another...
**Verdict**:
Use sparingly, or selfhost
</details>

<form action="" method="POST" id="commentForm">
  <input type="text" name="name" placeholder="Your Name"><br>
  <textarea name="comment" rows="4" cols="50"></textarea>
  <input type="hidden" name="jsonFilename" value="" id="jsonFilenameInput">
  <input type="submit" value="Submit"><br>
</form>

<script>
  window.addEventListener("DOMContentLoaded", function() {
    var urlbase; // Declare the urlbase variable

    fetch('https://ry3yr.github.io/comments.txt')
      .then(response => response.text())
      .then(data => {
        urlbase = data.trim(); // Assign the value to urlbase
      })
      .then(() => {
        var url = window.location.href;
        var jsonFilename = url.replace(/[^A-Za-z0-9]/g, "") + ".json";
        var jsonUrl = urlbase + jsonFilename;
        document.getElementById("jsonFilenameInput").value = jsonFilename;
        document.getElementById("commentForm").action = urlbase + "submit_comment.php";

        fetch(jsonUrl)
          .then(response => response.json())
          .then(data => {
            if (Array.isArray(data)) {
              data.reverse();
              data.forEach(entry => {
                var comment = entry.comment;
                var name = entry.name;
                renderComment(name, comment);
              });
            } else {
              console.log("No comments found for the current URL.");
            }
          })
          .catch(error => {
            console.log("Error fetching JSON file:", error);
          });
      });
  });

  function renderComment(name, comment) {
    var commentsElement = document.getElementById("comments");
    var commentElement = document.createElement("div");
    commentElement.innerHTML = "<strong>" + name + "</strong>: " + comment;
    commentsElement.appendChild(commentElement);
  }
</script>