<!--t Fav Anime Openings &amp; Endings t-->
<!--d Bravely You - Charlotte- Very pretty ! VividVice - JujutsuKaisen (S02)- Stunning ! title - d-->
<!--tag Anime tag-->

<a target="_blank" href="https://www.youtube.com/watch?v=RT1vyF9nFfQ" style=color:blue>Bravely You - Charlotte</a>- Very pretty !<br> 

<a target="_blank" href="https://m.youtube.com/watch?v=yXWwzgMZYOg&pp=ygUVVml2aWQgdmljZSBjcmVkaXRsZXNz" style=color:blue>VividVice - JujutsuKaisen (S02)</a>- Stunning !<br>

<a target="_blank" href="https://m.youtube.com/watch?v=4LqNYOGP3H8&pp=ygULVnJhaW5zIG9wIDI%3D" style=color:blue>Go Forward ! - VRAINS (S02)</a> - Upbeat !<br>

<a target="_blank" href="" style=color:blue>title</a> -<br>