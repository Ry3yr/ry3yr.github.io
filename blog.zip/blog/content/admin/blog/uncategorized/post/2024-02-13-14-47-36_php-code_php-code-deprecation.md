<!--t PHP Code Deprecation t-->
<!--d So. I currently target PHP8 for all projects - it is the most to date one. However, if I program something - no matter how adherent to nowadays d-->
<!--tag php code tag-->

So.
I currently target PHP8 for all projects - it is the most to date one.

However, if I program something - no matter how adherent to nowadays standsarts - what are the odds it will stay functional?

I have seen projects written in php7, no longer functional.*
Functions deprecated, Code needing to be rewritten.

So, if I write code today - can I be sure it will still run tomorrow ?
(Counterargument:
Javascript:
Despite ongoing "softdeprecation" aka "please use the the newer feature, thanks", most code is still operational today, backwardscompatibility.
Even in markuplanguage - html - frames are still around)

*Excluding the possibility of enforcing a specific version via htaccess.
That is a last resort some government institutions who cant afford to pay programmers to update code take... Even some universities. Would you believe it.

The versions itself are supported for roughly 2 years:
" Each release branch of PHP is fully supported for<a target="_blank" href="https://www.php.net/supported-versions.php" style=color:blue>two years</a> from its initial stable release
" 
<a target="_blank" href="https://stackoverflow.com/questions/77988399/chances-of-php-code-deprecation-in-future-versions-of-preprocessor" style=color:blue>Source</a>

<div id="comments"></div>
<br>
<form action="" method="POST" id="commentForm">
  <input type="text" name="name" placeholder="Your Name"><br>
  <textarea name="comment" rows="4" cols="50"></textarea>
  <input type="hidden" name="jsonFilename" value="" id="jsonFilenameInput">
  <input type="submit" value="Submit"><br>
</form>

<script>
  window.addEventListener("DOMContentLoaded", function() {
    var urlbase; // Declare the urlbase variable

    fetch('https://ry3yr.github.io/comments.txt')
      .then(response => response.text())
      .then(data => {
        urlbase = data.trim(); // Assign the value to urlbase
      })
      .then(() => {
        var url = window.location.href;
        var jsonFilename = url.replace(/[^A-Za-z0-9]/g, "") + ".json";
        var jsonUrl = urlbase + jsonFilename;
        document.getElementById("jsonFilenameInput").value = jsonFilename;
        document.getElementById("commentForm").action = urlbase + "submit_comment.php";

        fetch(jsonUrl)
          .then(response => response.json())
          .then(data => {
            if (Array.isArray(data)) {
              data.reverse();
              data.forEach(entry => {
                var comment = entry.comment;
                var name = entry.name;
                renderComment(name, comment);
              });
            } else {
              console.log("No comments found for the current URL.");
            }
          })
          .catch(error => {
            console.log("Error fetching JSON file:", error);
          });
      });
  });

  function renderComment(name, comment) {
    var commentsElement = document.getElementById("comments");
    var commentElement = document.createElement("div");
    commentElement.innerHTML = "<strong>" + name + "</strong>: " + comment;
    commentsElement.appendChild(commentElement);
  }
</script>
