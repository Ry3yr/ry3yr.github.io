<!--t Reinstalling Switchroot / Anroid on the Switch OLED t-->
<!--d Buy a premodded Switch. Make em install Android. It&#039;ll be fun. And fun it was. Until today, when I accidentally updated my switch from HOS 18 to d-->
<!--tag NintendoSwitch,Switchroot,Android,ohmygod,hwfly,Ifailed,ornot tag-->

Buy a premodded Switch.
Make em install Android.
It'll be fun.

And fun it was. Until today, when I accidentally updated my switch from HOS 18 to HOS 19, burning fuses in the process.

Burnt fuses means the emunand needs to be recreated,
and apparantly **it also means the Switchroot Android 14 is now defunct**.
Great.
So what could never happen on my V1 Switch (the android there is 4 years old)

**So what to do ? Cry ?**

.. Ofcourse not.
Retry retry retry.

Download Android 11
https://download.switchroot.org/android-11/nx-tab-beta2.75-20230705-rel.7z%
https://wiki.switchroot.org/wiki/android/11-r-setup-guide
Drats.
Not. working.

Retry that odin image from before the update ?
Well. not only did odin not backup my entire sd (hidden partition ? we'll omit that),
but I even got "fuses don't match errors"
- Who'd have thought a hekate made process - Lineage OS could require matching fuses ?
And all due to one lil folly of pressin "A" on an update prompt on StockOS..


Next thing ?
Well.
Try a donor 128 gb card (cause I didn't want to mess with the -working fine in stocksys and emunand 512 one):

1. attmempt ?+#Android 14 #Switchroot ..
https://download.lineageos.org/devices/nx_tab/builds
https://wiki.lineageos.org/devices/nx_tab/
cause the seller had that on here too.

And ?
Well. no. not working.
**Board was not initialzied properly. Hang prevented https://gist.github.com/Azkali/1d65ea4dc1bad755b1af982f13266384**

Grrreat ?!.
Updating the sdloader of the hwfly chip did nothing..
And now ?
Well. This sucks.

I cna get LineageOS to boot from hekate (splashscreen shows),
but the familiar "USB3 enabled" won't show.

more tries ?
Well cool. How about more errors ?

More reformatting.
And then, just as watching this video
https://www.youtube.com/watch?v=DFT2Hyp-rFc
makes me sad, as I did all that and just could not get the recovery to show up ...

Boom!
A different error.
"Joycon ini malformed"


As Dr.House would say "something changed, change is good !"
And right this is.
Suddenly the recovery opens !
![It's called recovery cause it'll recovery you from your errors!][1]


Next thing: fomat userpartition and system partition, and...
![install android 14 yay !][2]

Yay yay *dances.
And after all is said and done:
*Android 14 
* EmuNand
and stocksys 

run happily alongside in my OLED Switch again.
I'll never let it go again
**and to prevent updates, I'll autoboot to EMUNAND and block all nintysevers there, + dtnms**


So, Crisis (as seen [here][3]) averted !

- Cea


  [1]: https://alcea-wisteria.de/blog/content/images/20241103053808-20241103_041646.jpg
  [2]: https://alcea-wisteria.de/blog/content/images/20241103053713-20241103_041948.jpg
  [3]: http://ttps://www.reddit.com/r/Switchloader/comments/1byb1a7/hwfly_cant_boot_into_android_recovery/


<div id="comments"></div>
<br>
<form action="" method="POST" id="commentForm">
  <input type="text" name="name" placeholder="Your Name"><br>
  <textarea name="comment" rows="4" cols="50"></textarea>
  <input type="hidden" name="jsonFilename" value="" id="jsonFilenameInput">
  <input type="submit" value="Submit"><br>
</form>
<script>
  window.addEventListener("DOMContentLoaded", function() {
    var urlbase; // Declare the urlbase variable
    fetch('https://ry3yr.github.io/comments.txt')
      .then(response => response.text())
      .then(data => {
        urlbase = data.trim(); // Assign the value to urlbase
      })
      .then(() => {
        var url = window.location.href;
        var cacheBuster = Date.now(); // or you can use a version number if you prefer
        var jsonFilename = url.replace(/[^A-Za-z0-9]/g, "") + ".json";
        var jsonUrl = urlbase + jsonFilename;
        jsonUrl = jsonUrl + "?v=" + cacheBuster;

        document.getElementById("jsonFilenameInput").value = jsonFilename;
        document.getElementById("commentForm").action = urlbase + "submit_comment.php";

        fetch(jsonUrl)
          .then(response => response.json())
          .then(data => {
            if (Array.isArray(data)) {
              data.reverse();
              data.forEach(entry => {
                var comment = entry.comment;
                var name = entry.name;
                renderComment(name, comment);
              });
            } else {
              console.log("No comments found for the current URL.");
            }
          })
          .catch(error => {
            console.log("Error fetching JSON file:", error);
          });
      });
  });

  function renderComment(name, comment) {
    var commentsElement = document.getElementById("comments");
    var commentElement = document.createElement("div");
    commentElement.innerHTML = "<strong>" + name + "</strong>: " + comment;
    commentsElement.appendChild(commentElement);
  }
</script>


..
