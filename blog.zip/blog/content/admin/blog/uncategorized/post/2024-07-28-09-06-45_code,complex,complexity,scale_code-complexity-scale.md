<!--t Code Complexity Scale t-->
<!--d This was hard, maybe. d-->
<!--tag Code,Complex,complexity,scale tag-->


Instead of noting down the most complex coding problems I've <a target="_blank" href="https://mastodon.social/tag/CodeAlcea">encountered</a> <a target="_blank" href="https://yusaao.com/tag/codeao#https://pb.todon.de/tag/CodeAlcea">sofar</a>,<br>
I instead wrote another code to list them for me.<br>
Currently this list is unordered, and I may include a lil "comment" (via more program code, what else ?).<br><br>
The "complexity" number is chosen after a bit of deliberation (altho technically, if I encounter harder problems, I might have to reconsider ? especially if we scale /10).<br>
<br>
Some will appear empty, for now. That might or might not change (Altho JS/PHP/Python are my main languages)
<br>

<a target="_blank" href="https://alceawis.de/other/extra/scripts/rendercodetxt_complex.html#https://codepen.io/ryedai1/pen/zYVoLxv" style=color:blue>Direct Link</a>
<br><br>
-Alcea<br>


<object type="text/html" data="https://alceawis.de/other/extra/scripts/rendercodetxt_complex.html
" style="border:0px #ffffff none;" name="statusit" scrolling="auto" frameborder="0" marginheight="0px" marginwidth="0px" height="1000px" width="100%" allowfullscreen></object>