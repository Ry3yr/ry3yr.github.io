<!--t Smarthome, I Internet of things and data insecurity t-->
<!--d Looks like that &quot;cheap and nice smartphone addon&quot; might have a severe issue packed in. &quot;Hey #honey .. I compromised our #local d-->
<!--tag IoT,Paas tag-->

Looks like that "cheap and nice smartphone addon" might have a severe issue packed in.

"Hey #honey .. I compromised our #local #network so we could live more comfy. Hope you are chill with that 🥰"

All devices you can buy that depend on
•SmartLife
•Brilliant
•Tuya

Will most likely require auth'ing into the device with your router credencials AND will also have the inteusive app itself act as data syphon (try disabling network features, they will refuse to work without phoning home / a server connection)

Even the hardware itself is primed to this.
And attempting to dissolve the shackles
https://github.com/tuya-cloudcutter/cloudcutter-android
requires a tuya developer account, linux and flashing a FW.
Very userunfriendly.

Very concerning indeed


Sources
https://www.voanews.com/a/east-asia-pacific_voa-news-china_cybersecurity-experts-worried-chinese-firms-control-smart-devices/6209815.html 
https://www.reddit.com/r/homeautomation/comments/hh4tfc/privacy_tuyasmart_app_and_possibly_other_tuya/ 
https://pb.todon.de/@alcea/112354936990559485


<div id="comments"></div>
<br>
<form action="" method="POST" id="commentForm">
  <input type="text" name="name" placeholder="Your Name"><br>
  <textarea name="comment" rows="4" cols="50"></textarea>
  <input type="hidden" name="jsonFilename" value="" id="jsonFilenameInput">
  <input type="submit" value="Submit"><br>
</form>

<script>
  window.addEventListener("DOMContentLoaded", function() {
    var urlbase; // Declare the urlbase variable

    fetch('https://ry3yr.github.io/comments.txt')
      .then(response => response.text())
      .then(data => {
        urlbase = data.trim(); // Assign the value to urlbase
      })
      .then(() => {
        var url = window.location.href;
        var jsonFilename = url.replace(/[^A-Za-z0-9]/g, "") + ".json";
        var jsonUrl = urlbase + jsonFilename;
        document.getElementById("jsonFilenameInput").value = jsonFilename;
        document.getElementById("commentForm").action = urlbase + "submit_comment.php";

        fetch(jsonUrl)
          .then(response => response.json())
          .then(data => {
            if (Array.isArray(data)) {
              data.reverse();
              data.forEach(entry => {
                var comment = entry.comment;
                var name = entry.name;
                renderComment(name, comment);
              });
            } else {
              console.log("No comments found for the current URL.");
            }
          })
          .catch(error => {
            console.log("Error fetching JSON file:", error);
          });
      });
  });

  function renderComment(name, comment) {
    var commentsElement = document.getElementById("comments");
    var commentElement = document.createElement("div");
    commentElement.innerHTML = "<strong>" + name + "</strong>: " + comment;
    commentsElement.appendChild(commentElement);
  }
</script>

