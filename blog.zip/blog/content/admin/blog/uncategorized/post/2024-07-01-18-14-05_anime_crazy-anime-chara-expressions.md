<!--t (Crazy) Anime Chara Expressions t-->
<!--d Laughter: *Satou -Ajin *BattleProgrammerShirase d-->
<!--tag Anime tag-->

Disinterest:<br>
<a target="_blank" href="https://m.youtube.com/watch?v=HkESHJeMe_Y&pp=ygUTWXVzYWt1IGFuZ3J5IHZyYWlucw%3D%3D" style=color:blue>Yu wiiiii</a><br>

Smiling:<br><a target="_blank" href="https://m.youtube.com/watch?v=J4AsepKOqoE" style=color:blue>Yu Smiiile</a><br><br>

Epic:<br><a target="_blank" href="https://m.youtube.com/watch?v=KJHsuQqohRs" style=color:blue>Revy Prisy breaky vrns</a><br><br>



Insanity:<br>
<a target="_blank" href="https://m.youtube.com/watch?v=-9NBvsmQ2Ik&pp=ygULWXVnaSB3ZWV2aWw%3D" style=color:blue>Yugi vs Weevil DOMA</a><br>


<br>
CrazyLaughter:<br>
*<a target="_blank" href="https://m.youtube.com/watch?v=A9eV7Zs1yRU&t=49" style=color:blue>Satou -Ajin</a>
*<a target="_blank" href="https://m.youtube.com/watch?v=HxKaVZBl4U0&t=3m41s" style=color:blue>BattleProgrammerShirase</a><br>