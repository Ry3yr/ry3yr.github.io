<!--t Watched Movies &amp; Series t-->
<!--d •2024/02/03 The Tunnel to Summer the Exit Of Goodbyes Rating ★★★★★★★★☆☆ &quot;Good Movie with interesting. Maybe things are d-->
<!--tag Movies,TVShows,Anime tag-->


<hr>
•2024/02/03 <u>The Tunnel to Summer the Exit Of Goodbyes</u><br>
 Rating ★★★★★★★★☆☆<br>
•"Good Movie with interesting Gimmick.
Maybe things are good the way they are<br>
**What would you sacrifice years, decades or a century for ?** <br>• <a target="_blank" href="https://mstdn.animexx.de/@alcea/111868241783404209" style=color:blue>The Tunnel to Summer Exit of Goodbyes</a>
<hr>
<br><a target="_blank" href="ry3yr.github.io/OSTR/release/0mine/documents/favtvshows.html" style=color:gray>Old (pre 2023)</a><br>
<a target="_blank" href="https://alceawis.de/malparser.html">MAL</a>

<br>
<br>

<details><summary>Boilerplate</summary>
•20??/??/?? <u>Name</u><br>
 Rating ★★★★★★★★☆☆<br>•""<br>• <a target="_blank" href="" style=color:transparent>Name</a>
</details>
<hr>


<div id="comments"></div>
<br>
<form action="" method="POST" id="commentForm">
  <input type="text" name="name" placeholder="Your Name"><br>
  <textarea name="comment" rows="4" cols="50"></textarea>
  <input type="hidden" name="jsonFilename" value="" id="jsonFilenameInput">
  <input type="submit" value="Submit"><br>
</form>
<script>
  window.addEventListener("DOMContentLoaded", function() {
    var urlbase; // Declare the urlbase variable
    fetch('https://alcea-wisteria.de/blog/comments.txt')
      .then(response => response.text())
      .then(data => {
        urlbase = data.trim(); // Assign the value to urlbase
      })
      .then(() => {
        var url = window.location.href;
        var jsonFilename = url.replace(/[^A-Za-z0-9]/g, "") + ".json";
        var jsonUrl = urlbase + jsonFilename;
        document.getElementById("jsonFilenameInput").value = jsonFilename;
        document.getElementById("commentForm").action = urlbase + "submit_comment.php";
        fetch(jsonUrl)
          .then(response => response.json())
          .then(data => {
            if (Array.isArray(data)) {
              data.reverse();
              data.forEach(entry => {
                var comment = entry.comment;
                var name = entry.name;
                renderComment(name, comment);
              });
            } else {
              console.log("No comments found for the current URL.");
            }
          })
          .catch(error => {
            console.log("Error fetching JSON file:", error);
          });
      });
  });
  function renderComment(name, comment) {
    var commentsElement = document.getElementById("comments");
    var commentElement = document.createElement("div");
    commentElement.innerHTML = "<strong>" + name + "</strong>: " + comment;
    commentsElement.appendChild(commentElement);
  }
</script>
