<!--t Fav Developers t-->
<!--d Games Big: Capcom (MMBN, MMSF) Small h.a.n.d (KH 358/2, ) ILCA (Pokémon BD/SP) d-->
<!--tag Developers tag-->



<hr>
<b>Games</b><br><br>
Big:<br>
Capcom (MMBN, MMSF)<br><br>

Small<br>
h.a.n.d (KH 358/2, )<br>
ILCA (Pokémon BD/SP)<br>


<div id="comments"></div>
<br>
<form action="" method="POST" id="commentForm">
  <input type="text" name="name" placeholder="Your Name"><br>
  <textarea name="comment" rows="4" cols="50"></textarea>
  <input type="hidden" name="jsonFilename" value="" id="jsonFilenameInput">
  <input type="submit" value="Submit"><br>
</form>
<script>
  window.addEventListener("DOMContentLoaded", function() {
    var urlbase; // Declare the urlbase variable
    fetch('https://ry3yr.github.io/comments.txt')
      .then(response => response.text())
      .then(data => {
        urlbase = data.trim(); // Assign the value to urlbase
      })
      .then(() => {
        var url = window.location.href;
        var cacheBuster = Date.now(); // or you can use a version number if you prefer
        var jsonFilename = url.replace(/[^A-Za-z0-9]/g, "") + ".json";
        var jsonUrl = urlbase + jsonFilename;
        jsonUrl = jsonUrl + "?v=" + cacheBuster;

        document.getElementById("jsonFilenameInput").value = jsonFilename;
        document.getElementById("commentForm").action = urlbase + "submit_comment.php";

        fetch(jsonUrl)
          .then(response => response.json())
          .then(data => {
            if (Array.isArray(data)) {
              data.reverse();
              data.forEach(entry => {
                var comment = entry.comment;
                var name = entry.name;
                renderComment(name, comment);
              });
            } else {
              console.log("No comments found for the current URL.");
            }
          })
          .catch(error => {
            console.log("Error fetching JSON file:", error);
          });
      });
  });

  function renderComment(name, comment) {
    var commentsElement = document.getElementById("comments");
    var commentElement = document.createElement("div");
    commentElement.innerHTML = "<strong>" + name + "</strong>: " + comment;
    commentsElement.appendChild(commentElement);
  }
</script>
