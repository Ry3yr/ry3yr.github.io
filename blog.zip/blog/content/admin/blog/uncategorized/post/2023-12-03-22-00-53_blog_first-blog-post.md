<base target="_blank"> 

<!--t First Blog post t-->
<!-- Finally a proper **blog** . Guess I might use this once in a while to <a href="https://pb.todon.de/@alcea" target="_blank">mastodon</a>. ~Alcea -->
<!--tag blog tag-->

Finally a proper **blog** 😸.

Guess I might use this once in a while to <a href="https://pb.todon.de/@alcea" target="_blank">mastodon</a>.

~Alcea
