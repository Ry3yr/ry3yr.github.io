<!--t First Blog post t-->
<!--d Finally a proper blog 😸. Guess I might use this once in a while to mastodon. ~Alcea $(document).ready(function(){ var baseUrl = d-->
<!--tag blog tag-->

<base target="_blank"> 
<!-- Finally a proper **blog** . Guess I might use this once in a while to <a href="https://pb.todon.de/@alcea" target="_blank">mastodon</a>. ~Alcea -->
Finally a proper **blog** 😸.

Guess I might use this once in a while to <a href="https://ry3yr.github.io/mtd" target="_blank">mastodon</a>.

~Alcea

<hr>
<a target="_blank" href="https://urusai.social/tags/IdeasAlcea" style=color:blue>Ideas for future Blogposts</a>...

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    var baseUrl = "https://alcea-wisteria.de/disqus.html";
    $("#dsqcomm").load(baseUrl + "");
});
</script>
<div class="formClass">
    <div id="dsqcomm">
    </div>
</div>
