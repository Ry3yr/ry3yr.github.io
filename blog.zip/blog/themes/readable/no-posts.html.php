<?php if (!defined('HTMLY')) die('HTMLy'); ?>
<h1><?php echo i18n('No_posts_found');?>!</h1>