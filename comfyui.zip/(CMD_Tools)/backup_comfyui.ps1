# Set paths
$source = "C:\Users\Cea\AppData\Local\Programs\ComfyUI"
$destination = "$env:USERPROFILE\Desktop\ComfyUI.zip"

# Folders to exclude
$excludeFolders = @(
    "models\text_encoders",
    "models\diffusion_models",
    "models\checkpoints",
    "models\GGUF",
    "models\RMBG",
    "models\loras",
    "models\vae\",
    "models\unet",
    "models\detection",
    "models\clip_vision",
    "ComfyUI\models\text_encoders",
    "ComfyUI\models\diffusion_models",
    "ComfyUI\models\checkpoints",
    "ComfyUI\models\GGUF",
    "ComfyUI\models\RMBG",
    "ComfyUI\models\loras",
    "ComfyUI\models\vae\",
    "ComfyUI\models\unet",
    "ComfyUI\models\detection",
    "ComfyUI\models\clip_vision"
)

# Delete existing zip if present
if (Test-Path $destination) { Remove-Item $destination -Force }

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  BACKUP COMFYUI (Live Size Progress)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Scanning files..." -ForegroundColor Yellow

# 1. SCAN FIRST
$allFiles = Get-ChildItem -Path $source -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
    $relative = $_.FullName.Substring($source.Length + 1)
    $exclude = $false
    foreach ($folder in $excludeFolders) {
        if ($relative.StartsWith($folder)) {
            $exclude = $true
            break
        }
    }
    -not $exclude
}

$totalFiles = $allFiles.Count
if ($totalFiles -eq 0) {
    Write-Host "No files found to backup!" -ForegroundColor Red
    exit
}

$totalSize = ($allFiles | Measure-Object -Property Length -Sum).Sum
$totalSizeMB = [math]::Round($totalSize / 1MB, 2)
$totalSizeGB = [math]::Round($totalSize / 1GB, 2)

# 2. SHOW USER DATA
Write-Host ""
Write-Host "Folders EXCLUDED:" -ForegroundColor DarkYellow
foreach ($folder in $excludeFolders) {
    Write-Host "  - $folder" -ForegroundColor DarkYellow
}
Write-Host ""
Write-Host "Files to backup: $totalFiles" -ForegroundColor Green
Write-Host "Size to backup: $totalSizeMB MB ($totalSizeGB GB)" -ForegroundColor Yellow
Write-Host ""

# 3. USER CONFIRMATION
$confirmation = Read-Host "Proceed? (y/n)"

if ($confirmation -ne 'y') {
    Write-Host "Cancelled." -ForegroundColor Red
    exit
}

Write-Host ""
Write-Host "Creating ZIP archive using .NET ZipFile..." -ForegroundColor Yellow
Write-Host ""

# 4. CREATE ZIP USING .NET
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$barLength = 50
$filesProcessed = 0
$lastPercent = -1

# Create zip file using FileStream and ZipArchive
$stream = [System.IO.File]::Create($destination)
$zip = New-Object System.IO.Compression.ZipArchive($stream, [System.IO.Compression.ZipArchiveMode]::Create)

try {
    foreach ($file in $allFiles) {
        # Get relative path for the entry
        $relativePath = $file.FullName.Substring($source.Length + 1)
        
        # Create entry and copy file content
        $entry = $zip.CreateEntry($relativePath)
        $entryStream = $entry.Open()
        $fileStream = [System.IO.File]::OpenRead($file.FullName)
        
        try {
            $fileStream.CopyTo($entryStream)
        }
        finally {
            $entryStream.Close()
            $fileStream.Close()
        }
        
        $filesProcessed++
        
        # Update progress bar every 50 files or 1% change
        $percent = [math]::Floor(($filesProcessed / $totalFiles) * 100)
        if ($percent -gt 99) { $percent = 99 }
        if ($percent -ne $lastPercent) {
            $filled = [math]::Floor(($percent / 100) * $barLength)
            $empty = $barLength - $filled
            $bar = "[" + ("#" * $filled) + (" " * $empty) + "]"
            
            # Check current zip file size
            if (Test-Path $destination) {
                $currentSize = (Get-Item $destination).Length
                $currentSizeMB = [math]::Round($currentSize / 1MB, 2)
                Write-Host "`r  $bar $percent% ($filesProcessed/$totalFiles files) - $currentSizeMB MB written" -NoNewline -ForegroundColor Cyan
            } else {
                Write-Host "`r  $bar $percent% ($filesProcessed/$totalFiles files)" -NoNewline -ForegroundColor Cyan
            }
            $lastPercent = $percent
        }
    }
}
finally {
    $zip.Dispose()
    $stream.Dispose()
}

Write-Host ""

# 5. FINAL OUTPUT
if (Test-Path $destination) {
    $finalSize = (Get-Item $destination).Length
    $finalSizeMB = [math]::Round($finalSize / 1MB, 2)
    $finalSizeGB = [math]::Round($finalSize / 1GB, 2)
    $compressionRatio = [math]::Round((1 - ($finalSize / $totalSize)) * 100, 1)
    
    $fullBar = "[" + ("#" * $barLength) + "]"
    Write-Host "`r  $fullBar 100% ($totalFiles/$totalFiles files)" -ForegroundColor Cyan
    Write-Host ""

    Write-Host "========================================" -ForegroundColor Green
    Write-Host "  BACKUP COMPLETE!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Saved to: $destination" -ForegroundColor White
    Write-Host "Final archive size: $finalSizeMB MB ($finalSizeGB GB)" -ForegroundColor Yellow
    Write-Host "Compression ratio: $compressionRatio% saved" -ForegroundColor Green
} else {
    Write-Host "Error: ZIP file could not be verified." -ForegroundColor Red
}