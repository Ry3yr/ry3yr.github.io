# Set paths
$source = "C:\Users\Cea\AppData\Local\Programs\ComfyUI"
$destination = "$env:USERPROFILE\Desktop\ComfyUI.zip"

# Folders to exclude
$excludeFolders = @(
    "models\text_encoders",
    "models\diffusion_models",
    "models\checkpoints",
    "ComfyUI\models\text_encoders",
    "ComfyUI\models\diffusion_models",
    "ComfyUI\models\checkpoints"
)

# Delete existing zip if present
if (Test-Path $destination) { Remove-Item $destination -Force }

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  BACKUP COMFYUI (Live Size Progress)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Scanning files..." -ForegroundColor Yellow

# 1. SCAN FIRST
$allFiles = Get-ChildItem -Path $source -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
    $relative = $_.FullName.Substring($source.Length + 1)
    $exclude = $false
    foreach ($folder in $excludeFolders) {
        if ($relative.StartsWith($folder)) {
            $exclude = $true
            break
        }
    }
    -not $exclude
}

$totalFiles = $allFiles.Count
if ($totalFiles -eq 0) {
    Write-Host "No files found to backup!" -ForegroundColor Red
    exit
}

$totalSize = ($allFiles | Measure-Object -Property Length -Sum).Sum
$totalSizeMB = [math]::Round($totalSize / 1MB, 2)
$totalSizeGB = [math]::Round($totalSize / 1GB, 2)

# 2. SHOW USER DATA
Write-Host ""
Write-Host "Folders EXCLUDED:" -ForegroundColor DarkYellow
foreach ($folder in $excludeFolders) {
    Write-Host "  - $folder" -ForegroundColor DarkYellow
}
Write-Host ""
Write-Host "Files to backup: $totalFiles" -ForegroundColor Green
Write-Host "Size to backup: $totalSizeMB MB ($totalSizeGB GB)" -ForegroundColor Yellow
Write-Host ""

# 3. USER CONFIRMATION
$confirmation = Read-Host "Proceed? (y/n)"

if ($confirmation -ne 'y') {
    Write-Host "Cancelled." -ForegroundColor Red
    exit
}

Write-Host ""
Write-Host "Streaming data directly into archive..." -ForegroundColor Yellow
Write-Host ""

# Tar-Argumente vorbereiten
$tarArgs = @("-a", "-c", "-f", $destination)
foreach ($folder in $excludeFolders) {
    $normalizedFolder = $folder.Replace("\", "/")
    $tarArgs += "--exclude=$normalizedFolder"
}
$tarArgs += "*"

# In Quellordner wechseln für relative Pfade
Push-Location $source

# 4. COMPRESS DIRECTLY & MONITOR DISK WRITE LIVE
# Wir starten tar nativ als Hintergrundprozess, damit wir die ZIP-Größe parallel abfragen können
$proc = Start-Process -FilePath "tar.exe" -ArgumentList $tarArgs -PassThru -NoNewWindow

$barLength = 50

while (-not $proc.HasExited) {
    if (Test-Path $destination) {
        $currentSize = (Get-Item $destination).Length
        
        # Da die ZIP komprimiert wird, wird sie das unkomprimierte Limit ($totalSize) nie ganz erreichen.
        # Wir berechnen den temporären Prozentwert und deckeln ihn bei 99%, bis tar fertig ist.
        $percent = [math]::Floor(($currentSize / $totalSize) * 100)
        if ($percent -gt 99) { $percent = 99 }
        if ($percent -lt 0) { $percent = 0 }
        
        $currentSizeMB = [math]::Round($currentSize / 1MB, 2)
        
        $filled = [math]::Floor(($percent / 100) * $barLength)
        $empty = $barLength - $filled
        $bar = "[" + ("#" * $filled) + (" " * $empty) + "]"
        
        Write-Host "`r  $bar $percent% ($currentSizeMB MB written / uncompressed target: $totalSizeMB MB)" -NoNewline -ForegroundColor Cyan
    }
    # Kurze Atempause für die Schleife (4 Mal pro Sekunde aktualisieren)
    Start-Sleep -Milliseconds 250
}

Pop-Location
Write-Host ""

# 5. FINAL OUTPUT (Setzt den Balken nach Abschluss fix auf 100%)
if (Test-Path $destination) {
    $finalSize = (Get-Item $destination).Length
    $finalSizeMB = [math]::Round($finalSize / 1MB, 2)
    $finalSizeGB = [math]::Round($finalSize / 1GB, 2)
    
    $fullBar = "[" + ("#" * $barLength) + "]"
    Write-Host "`r  $fullBar 100% ($finalSizeMB MB successfully compressed!)" -ForegroundColor Cyan
    Write-Host ""

    Write-Host "========================================" -ForegroundColor Green
    Write-Host "  BACKUP COMPLETE!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Saved strictly direct to: $destination" -ForegroundColor White
    Write-Host "Final archive size: $finalSizeMB MB ($finalSizeGB GB)" -ForegroundColor Yellow
} else {
    Write-Host "Error: ZIP file could not be verified." -ForegroundColor Red
}