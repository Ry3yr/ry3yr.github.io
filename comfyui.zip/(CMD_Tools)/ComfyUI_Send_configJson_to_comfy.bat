

@echo off
setlocal enabledelayedexpansion

set COMFY_URL=http://127.0.0.1:8000
set "COMFY_LOG=C:\Users\Cea\AppData\Roaming\ComfyUI\logs\comfyui.log"

if "%~1"=="" (
    echo [ERROR] Drag and drop a JSON file onto this batch file.
    pause
    exit /b 1
)

if not exist "%~1" (
    echo [ERROR] File not found: %~1
    pause
    exit /b 1
)

echo.
echo Sending: %~nx1
echo.

set "INPUT_FILE=%~1"
set "PAYLOAD_PATH=%TEMP%\payload.json"
set "RESPONSE_PATH=%TEMP%\response.json"
set "HISTORY_PATH=%TEMP%\history.json"

:: Wrap raw text directly
powershell -Command "$content = Get-Content $env:INPUT_FILE -Raw; $body = '{\"prompt\":' + $content + '}'; [System.IO.File]::WriteAllText($env:PAYLOAD_PATH, $body)"

:: Get the initial line count of the log file so we only look at *new* entries
set INITIAL_LINE_COUNT=0
if exist "%COMFY_LOG%" (
    for /f %%c in ('powershell -Command "(Get-Content '%COMFY_LOG%').Count"') do set INITIAL_LINE_COUNT=%%c
)

:: Submit using curl
curl -s -X POST "%COMFY_URL%/prompt" -H "Content-Type: application/json" -d "@%PAYLOAD_PATH%" > "%RESPONSE_PATH%"

:: Check for success
findstr /C:"prompt_id" "%RESPONSE_PATH%" > nul
if errorlevel 1 (
    echo.
    echo [FAILED] ComfyUI rejected the script. Response was:
    type "%RESPONSE_PATH%"
    del "%PAYLOAD_PATH%" "%RESPONSE_PATH%" 2>nul
    pause
    exit /b 1
)

:: Extract prompt_id
for /f "delims=" %%i in ('powershell -Command "(Get-Content $env:RESPONSE_PATH -Raw | ConvertFrom-Json).prompt_id"') do set PROMPT_ID=%%i

echo [SUCCESS] Prompt ID: %PROMPT_ID%
echo Streaming internal logs...

:loop
timeout /t 1 /nobreak > nul

:: Stream any newly added lines from the log file in real-time
if exist "%COMFY_LOG%" (
    powershell -Command "$lines = Get-Content '%COMFY_LOG%'; if ($lines.Count -gt %INITIAL_LINE_COUNT%) { $lines[%INITIAL_LINE_COUNT%..($lines.Count-1)] | ForEach-Object { Write-Host $_ -ForegroundColor Cyan } };"
    :: Update line count marker to the current end of the file
    for /f %%c in ('powershell -Command "(Get-Content '%COMFY_LOG%').Count"') do set INITIAL_LINE_COUNT=%%c
)

:: Check if the prompt is officially finished via API history
curl -s "%COMFY_URL%/history/%PROMPT_ID%" > "%HISTORY_PATH%"
findstr /C:"%PROMPT_ID%" "%HISTORY_PATH%" > nul
if not errorlevel 1 (
    echo [COMPLETE] ComfyUI finished execution!
    del "%PAYLOAD_PATH%" "%RESPONSE_PATH%" "%HISTORY_PATH%" 2>nul
    pause
    exit /b 0
)

goto loop