@echo off
setlocal enabledelayedexpansion

set COMFY_URL=http://127.0.0.1:8000
set "COMFY_LOG=C:\Users\Cea\AppData\Roaming\ComfyUI\logs\comfyui.log"

:: Check for empty argument using a safer GOTO method instead of IF brackets
if "%~1"=="" goto :missing_arg
if not exist "%~1" goto :missing_file

echo.
echo Sending: %~nx1
echo.

set "INPUT_FILE=%~1"
set "PAYLOAD_PATH=%TEMP%\payload.json"
set "RESPONSE_PATH=%TEMP%\response.json"
set "HISTORY_PATH=%TEMP%\history.json"

:: Wrap raw text directly using environment variables so PowerShell handles the path safely
powershell -Command "$content = Get-Content -Path $env:INPUT_FILE -Raw; $body = '{\"prompt\":' + $content + '}'; [System.IO.File]::WriteAllText($env:PAYLOAD_PATH, $body)"

if not exist "%PAYLOAD_PATH%" goto :payload_failed

:: Get the initial line count of the log file
set INITIAL_LINE_COUNT=0
if exist "%COMFY_LOG%" (
    for /f "usebackq delims=" %%c in (`powershell -Command "(Get-Content $env:COMFY_LOG -ErrorAction SilentlyContinue).Count" 2^>nul`) do set INITIAL_LINE_COUNT=%%c
)

:: Submit using curl
curl -s -X POST "%COMFY_URL%/prompt" -H "Content-Type: application/json" -d "@%PAYLOAD_PATH%" > "%RESPONSE_PATH%"

:: Check for success safely
findstr /C:"prompt_id" "%RESPONSE_PATH%" > nul
if errorlevel 1 goto :server_rejected

:: Extract prompt_id
for /f "usebackq delims=" %%i in (`powershell -Command "(Get-Content $env:RESPONSE_PATH -Raw | ConvertFrom-Json).prompt_id"`) do set PROMPT_ID=%%i

echo [SUCCESS] Prompt ID: %PROMPT_ID%
echo Streaming internal logs...

:loop
timeout /t 1 /nobreak > nul

if exist "%COMFY_LOG%" (
    powershell -Command "$lines = Get-Content $env:COMFY_LOG -ErrorAction SilentlyContinue; $currentCount = $lines.Count; if ($currentCount -gt $env:INITIAL_LINE_COUNT) { $lines[[int]$env:INITIAL_LINE_COUNT..($currentCount-1)] | ForEach-Object { Write-Host $_ -ForegroundColor Cyan } }"
    for /f "usebackq delims=" %%c in (`powershell -Command "(Get-Content $env:COMFY_LOG -ErrorAction SilentlyContinue).Count" 2^>nul`) do set INITIAL_LINE_COUNT=%%c
)

:: Check if finished via API history
curl -s "%COMFY_URL%/history/%PROMPT_ID%" > "%HISTORY_PATH%"
findstr /C:"%PROMPT_ID%" "%HISTORY_PATH%" > nul
if not errorlevel 1 (
    echo [COMPLETE] ComfyUI finished execution!
    del "%PAYLOAD_PATH%" "%RESPONSE_PATH%" "%HISTORY_PATH%" 2>nul
    pause
    exit /b 0
)

goto loop

:: --- Error Handling Blocks (No parentheses grouping to prevent crashes) ---

:missing_arg
echo [ERROR] Drag and drop a JSON file onto this batch file.
pause
exit /b 1

:missing_file
echo [ERROR] File not found. The path or folder name contains unsupported characters.
pause
exit /b 1

:payload_failed
echo [ERROR] Failed to create payload.json
pause
exit /b 1

:server_rejected
echo.
echo [FAILED] ComfyUI rejected the script. Response was:
type "%RESPONSE_PATH%"
del "%PAYLOAD_PATH%" "%RESPONSE_PATH%" 2>nul
pause
exit /b 1