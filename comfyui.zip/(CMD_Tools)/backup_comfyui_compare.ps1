# Target path to verify against
$source = "C:\Users\Cea\AppData\Local\Programs\ComfyUI"

# Extended exclude list (Identical to backup logic)
$excludeFolders = @(
    "models\text_encoders",
    "models\diffusion_models",
    "models\checkpoints",
    "ComfyUI\models\text_encoders",
    "ComfyUI\models\diffusion_models",
    "ComfyUI\models\checkpoints"
)

# Namen der Skripte, die ignoriert werden dürfen (Exakter Match)
$scriptNamesToIgnore = @("backup_comfyui.ps1")

# Get path from arguments (for Drag and Drop)
$zipPath = $args[0]

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  COMFYUI ZIP COMPARE TOOL (Strict Filter)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if (-not $zipPath) {
    $zipPath = Read-Host "--> Drag & Drop your ZIP file here and press ENTER"
}

$zipPath = $zipPath.Trim(@('"', "'"))

if (-not (Test-Path $zipPath)) {
    Write-Host "Error: File not found! ($zipPath)" -ForegroundColor Red
    Write-Host ""
    Read-Host "Press ENTER to exit..."
    exit
}

Write-Host ""
Write-Host "Reading ZIP archive structure..." -ForegroundColor Yellow

$zipFiles = @{}
$zipCount = 0

# 1. Read ZIP + Filter out .git and SPECIFIC scripts inline
$tarOutput = & tar.exe -tf $zipPath 2>&1
foreach ($line in $tarOutput) {
    $cleanLine = $line.ToString().Trim()
    if ($cleanLine -and -not $cleanLine.EndsWith("/")) {
        $relative = $cleanLine.Replace('/', '\')
        
        # Check if it's one of our utility scripts
        $fileName = Split-Path $relative -Leaf
        if ($scriptNamesToIgnore -contains $fileName) {
            continue
        }
        
        # Git-Filter (Anfang oder mittendrin, aber keine pauschale .ps1 Blockade)
        if ($relative -like ".git\*" -or $relative -like "*\.git\*" -or $relative -eq "models") {
            continue
        }
        
        $zipFiles[$relative] = $true
        $zipCount++
    }
}

Write-Host "Scanning local target folder..." -ForegroundColor Yellow

$localFiles = @{}
$localCount = 0

# 2. Read local folder + Filter out .git and SPECIFIC scripts inline
Get-ChildItem -Path $source -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
    $relative = $_.FullName.Substring($source.Length + 1)
    
    # Check if it's one of our utility scripts
    $fileName = $_.Name
    if ($scriptNamesToIgnore -contains $fileName) {
        return
    }
    
    # Git-Filter
    if ($relative -like ".git\*" -or $relative -like "*\.git\*") {
        return
    }
    
    $exclude = $false
    foreach ($folder in $excludeFolders) {
        if ($relative.StartsWith($folder)) {
            $exclude = $true
            break
        }
    }
    if (-not $exclude) {
        $localFiles[$relative] = $true
        $localCount++
    }
}

Write-Host "Comparing datasets..." -ForegroundColor Yellow
Write-Host ""

$missingInZip = @()
$missingInLocal = @()
$matchingCount = 0

foreach ($key in $localFiles.Keys) {
    if ($zipFiles.ContainsKey($key)) {
        $matchingCount++
    } else {
        $missingInZip += $key
    }
}

foreach ($key in $zipFiles.Keys) {
    if (-not $localFiles.ContainsKey($key)) {
        $missingInLocal += $key
    }
}

# 3. OUTPUT RESULTS
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  COMPARISON RESULTS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Files inside ZIP (Filtered):  $zipCount" -ForegroundColor White
Write-Host "Files on Drive   (Filtered):  $localCount" -ForegroundColor White
Write-Host "Matching files:               $matchingCount" -ForegroundColor Green
Write-Host ""

if ($missingInZip.Count -eq 0 -and $missingInLocal.Count -eq 0) {
    Write-Host "[OK] PERFECT MATCH! The core ComfyUI backup is 100% in sync." -ForegroundColor Green
} else {
    if ($missingInZip.Count -gt 0) {
        Write-Host "[CHANGED/NEW] Missing in ZIP ($($missingInZip.Count) files):" -ForegroundColor Yellow
        $missingInZip | Select-Object -First 15 | ForEach-Object { Write-Host "   + $_" -ForegroundColor DarkYellow }
        if ($missingInZip.Count -gt 15) { Write-Host "   ... and $($missingInZip.Count - 15) more." -ForegroundColor DarkYellow }
        Write-Host ""
    }
    
    if ($missingInLocal.Count -gt 0) {
        Write-Host "[DELETED] Missing locally ($($missingInLocal.Count) files):" -ForegroundColor Red
        $missingInLocal | Select-Object -First 15 | ForEach-Object { Write-Host "   - $_" -ForegroundColor DarkRed }
        if ($missingInLocal.Count -gt 15) { Write-Host "   ... and $($missingInLocal.Count - 15) more." -ForegroundColor DarkRed }
        Write-Host ""
    }
    
    Write-Host "--> Status: OUT OF SYNC" -ForegroundColor Red
}

Write-Host ""
Read-Host "Press ENTER to close..."