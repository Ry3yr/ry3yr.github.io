# Target path to verify against
$source = "C:\Users\Cea\AppData\Local\Programs\ComfyUI"

# Extended exclude list (Identical to backup logic)
$excludeFolders = @(
    "models\text_encoders",
    "models\diffusion_models",
    "models\checkpoints",
    "models\GGUF",
    "models\RMBG",
    "models\loras",
    "models\vae",
    "models\unet",
    "models\detection",
    "models\clip_vision",
    "ComfyUI\models\text_encoders",
    "ComfyUI\models\diffusion_models",
    "ComfyUI\models\checkpoints",
    "ComfyUI\models\GGUF",
    "ComfyUI\models\RMBG",
    "ComfyUI\models\loras",
    "ComfyUI\models\vae",
    "ComfyUI\models\unet",
    "ComfyUI\models\detection",
    "ComfyUI\models\clip_vision"
)

# Names of scripts to ignore (Exact Match)
$scriptNamesToIgnore = @("backup_comfyui.ps1", "backup_comfyui_compare.ps1")

# Get path from arguments (for Drag and Drop)
$zipPath = $args[0]

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  COMFYUI ZIP COMPARE TOOL (Unicode)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if (-not $zipPath) {
    $zipPath = Read-Host "--> Drag & Drop your ZIP file here and press ENTER"
}

$zipPath = $zipPath.Trim(@('"', "'"))

if (-not (Test-Path $zipPath)) {
    Write-Host "Error: File not found! ($zipPath)" -ForegroundColor Red
    Write-Host ""
    Read-Host "Press ENTER to exit..."
    exit
}

Write-Host ""
Write-Host "Reading ZIP archive structure..." -ForegroundColor Yellow

$zipFiles = @{}
$zipCount = 0

# 1. READ ZIP USING .NET ZipArchive (Proper Unicode/UTF-8 support)
Add-Type -AssemblyName System.IO.Compression.FileSystem

try {
    $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    
    foreach ($entry in $zip.Entries) {
        # Skip directories (entries ending with /)
        if ($entry.FullName -match "/$") {
            continue
        }
        
        $relative = $entry.FullName.Replace('/', '\')
        
        # Strip leading .\ if present
        if ($relative.StartsWith(".\")) {
            $relative = $relative.Substring(2)
        }
        
        # Check if it's one of our utility scripts
        $fileName = Split-Path $relative -Leaf
        if ($scriptNamesToIgnore -contains $fileName) {
            continue
        }
        
        # Git-Filter
        if ($relative -like ".git\*" -or $relative -like "*\.git\*") {
            continue
        }
        
        $zipFiles[$relative] = $true
        $zipCount++
    }
    
    $zip.Dispose()
}
catch {
    Write-Host "Error reading ZIP file: $_" -ForegroundColor Red
    Read-Host "Press ENTER to exit..."
    exit
}

Write-Host "Scanning local target folder..." -ForegroundColor Yellow

$localFiles = @{}
$localCount = 0

# 2. Read local folder using Get-ChildItem
Get-ChildItem -Path $source -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
    $fullPath = $_.FullName
    $relative = $fullPath.Substring($source.Length + 1)
    
    # Check if it's one of our utility scripts
    $fileName = Split-Path $relative -Leaf
    if ($scriptNamesToIgnore -contains $fileName) {
        return
    }
    
    # Git-Filter
    if ($relative -like ".git\*" -or $relative -like "*\.git\*") {
        return
    }
    
    # Prefix filtering matching the backup rule logic
    $exclude = $false
    foreach ($folder in $excludeFolders) {
        if ($relative.StartsWith($folder + "\", [System.StringComparison]::OrdinalIgnoreCase) -or
            $relative.Equals($folder, [System.StringComparison]::OrdinalIgnoreCase)) {
            $exclude = $true
            break
        }
    }
    if (-not $exclude) {
        $localFiles[$relative] = $true
        $localCount++
    }
}

Write-Host "Comparing datasets..." -ForegroundColor Yellow
Write-Host ""

$missingInZip = @()
$missingInLocal = @()
$matchingCount = 0

foreach ($key in $localFiles.Keys) {
    if ($zipFiles.ContainsKey($key)) {
        $matchingCount++
    } else {
        $missingInZip += $key
    }
}

foreach ($key in $zipFiles.Keys) {
    if (-not $localFiles.ContainsKey($key)) {
        $missingInLocal += $key
    }
}

# 3. OUTPUT RESULTS
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  COMPARISON RESULTS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Files inside ZIP (Filtered):  $zipCount" -ForegroundColor White
Write-Host "Files on Drive   (Filtered):  $localCount" -ForegroundColor White
Write-Host "Matching files:               $matchingCount" -ForegroundColor Green
Write-Host ""

if ($missingInZip.Count -eq 0 -and $missingInLocal.Count -eq 0) {
    Write-Host "[OK] PERFECT MATCH! The core ComfyUI backup is 100% in sync." -ForegroundColor Green
} else {
    if ($missingInZip.Count -gt 0) {
        Write-Host "[CHANGED/NEW] Missing in ZIP ($($missingInZip.Count) files):" -ForegroundColor Yellow
        $missingInZip | Sort-Object | Select-Object -First 15 | ForEach-Object { Write-Host "   + $_" -ForegroundColor DarkYellow }
        if ($missingInZip.Count -gt 15) { Write-Host "   ... and $($missingInZip.Count - 15) more" -ForegroundColor DarkYellow }
    }

    if ($missingInLocal.Count -gt 0) {
        Write-Host ""
        Write-Host "[OBSOLETE] In ZIP but missing locally ($($missingInLocal.Count) files):" -ForegroundColor Magenta
        $missingInLocal | Sort-Object | Select-Object -First 15 | ForEach-Object { Write-Host "   - $_" -ForegroundColor DarkMagenta }
        if ($missingInLocal.Count -gt 15) { Write-Host "   ... and $($missingInLocal.Count - 15) more" -ForegroundColor DarkMagenta }
    }
}

Write-Host ""
Read-Host "Press ENTER to exit..."