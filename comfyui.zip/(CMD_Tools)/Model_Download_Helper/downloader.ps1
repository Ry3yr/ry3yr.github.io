# Model Download Helper fuer ComfyUI (Mit HuggingFace XET Unterstützung)

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "   Model Downloader fuer ComfyUI" -ForegroundColor White
Write-Host "========================================`n" -ForegroundColor Cyan

# Globale Variablen für Benutzereinstellungen
$global:UseXET = $null
$global:DownloadMethod = $null

# Funktion: Ist es ein HuggingFace Link?
function Is-HuggingFaceLink {
    param([string]$url)
    return $url -match "huggingface\.co"
}

# Funktion: HuggingFace zu XET Link konvertieren
function Convert-ToXETLink {
    param([string]$url)
    $cleanUrl = $url -replace '\?.+$', ''
    
    if ($cleanUrl -match "huggingface\.co/(.+?)/resolve/(main|branch)/(.+)$") {
        $repo = $Matches[1]
        $branch = $Matches[2]
        $filePath = $Matches[3]
        $xetUrl = "https://xetsvc.com/$repo/$branch/$filePath"
        return $xetUrl
    }
    return $url
}

# Funktion: HuggingFace Link verarbeiten (mit gespeicherter Einstellung)
function Process-HuggingFaceLink {
    param([string]$url, [string]$fileName)
    
    if (-not (Is-HuggingFaceLink -url $url)) {
        return $url
    }
    
    Write-Host "[!] HuggingFace Link erkannt: $fileName" -ForegroundColor Cyan
    
    # Wenn XET Preference noch nicht gesetzt ist, frage einmalig ab
    if ($global:UseXET -eq $null) {
        $askXET = Read-Host "XET fuer schnelleren Download verwenden? (j/n) (Empfohlen fuer große Dateien)"
        $global:UseXET = ($askXET -eq "j")
    }
    
    if ($global:UseXET) {
        $xetLink = Convert-ToXETLink -url $url
        Write-Host "[+] Verwende XET Link" -ForegroundColor Green
        return $xetLink
    } else {
        Write-Host "[+] Verwende normalen HuggingFace Link" -ForegroundColor Yellow
        return $url
    }
}

# Funktion: Datei herunterladen (mit gespeicherter Methode)
function Download-File {
    param([string]$url, [string]$path)
    
    # Wenn Download-Methode noch nicht gesetzt ist, frage einmalig ab
    if ($global:DownloadMethod -eq $null) {
        Write-Host "`n[?] Download-Methode waehlen:" -ForegroundColor Yellow
        Write-Host "   [1] PowerShell (einfach, kein Fortschrittsbalken)" -ForegroundColor Gray
        Write-Host "   [2] curl (Fortschrittsbalken, empfohlen)" -ForegroundColor Green
        Write-Host "   [3] aria2 (Multi-Connection, sehr schnell)" -ForegroundColor Cyan
        $methodChoice = Read-Host "Deine Wahl (1,2,3)"
        
        switch ($methodChoice) {
            "1" { $global:DownloadMethod = "powershell" }
            "2" { $global:DownloadMethod = "curl" }
            "3" { $global:DownloadMethod = "aria2" }
            default { $global:DownloadMethod = "curl" }
        }
        Write-Host "[+] Verwende Methode: $($global:DownloadMethod)" -ForegroundColor Green
    }
    
    Write-Host "`n[>] Starte Download..." -ForegroundColor Cyan
    Write-Host "    Quelle: $url" -ForegroundColor Gray
    Write-Host "    Ziel:   $path" -ForegroundColor Gray
    Write-Host ""
    
    try {
        switch ($global:DownloadMethod) {
            "powershell" {
                $webClient = New-Object System.Net.WebClient
                $webClient.DownloadFile($url, $path)
            }
            "curl" {
                curl.exe -L -o "$path" "$url" --progress-bar
            }
            "aria2" {
                $aria2check = Get-Command aria2c -ErrorAction SilentlyContinue
                if (-not $aria2check) {
                    Write-Host "[!] aria2 nicht gefunden. Fallback zu curl..." -ForegroundColor Yellow
                    curl.exe -L -o "$path" "$url" --progress-bar
                } else {
                    aria2c -x 16 -s 16 -o "$path" "$url" --console-log-level=error
                }
            }
            default {
                curl.exe -L -o "$path" "$url" --progress-bar
            }
        }
        
        $size = (Get-Item $path).Length / 1GB
        Write-Host "`n[+] Download abgeschlossen! ($([math]::Round($size,2)) GB)" -ForegroundColor Green
        Write-Host "[+] Gespeichert unter: $path" -ForegroundColor White
        return $true
        
    } catch {
        Write-Host "`n[X] FEHLER: $_" -ForegroundColor Red
        return $false
    }
}

# Funktion: Einzelnen Link verarbeiten
function Process-SingleLink {
    Write-Host "`n[?] Download-Link eingeben:" -ForegroundColor Yellow
    Write-Host "    (Rechtsklick im Browser -> Link kopieren)" -ForegroundColor Gray
    $originalLink = Read-Host

    if (-not $originalLink) {
        Write-Host "[X] Kein Link eingegeben." -ForegroundColor Red
        return $false
    }

    # Query-Parameter entfernen
    $cleanLink = $originalLink
    $hasQueryString = $originalLink -match '\?.+$'

    if ($hasQueryString) {
        Write-Host "`n[!] Query-Parameter erkannt: $($Matches[0])" -ForegroundColor Yellow
        $cleanLink = $originalLink -replace '\?.+$', ''
        Write-Host "[?] Bereinigter Link: $cleanLink" -ForegroundColor Green
        
        $removeQuery = Read-Host "`nMoechtest du die Query-Parameter entfernen? (j/n)"
        if ($removeQuery -eq "j") {
            Write-Host "[+] Verwende bereinigten Link" -ForegroundColor Green
        } else {
            $cleanLink = $originalLink
            Write-Host "[!] Verwende Original-Link mit Query-Parametern" -ForegroundColor Yellow
        }
    }

    # Modellnamen extrahieren
    $fileName = ($cleanLink -split '/' | Select-Object -Last 1)
    $fileName = $fileName -split '\?' | Select-Object -First 1
    Write-Host "`n[+] Modellname: $fileName" -ForegroundColor Green

    # HuggingFace Link verarbeiten
    $downloadUrl = Process-HuggingFaceLink -url $cleanLink -fileName $fileName

    # Speicherort auswaehlen
    Write-Host "`n[?] Speicherort waehlen:" -ForegroundColor Yellow
    Write-Host "   [1] ComfyUI/models/ (Unterordner selbst waehlen)" -ForegroundColor Green
    Write-Host "   [2] Desktop (Download-Ordner)" -ForegroundColor Gray
    Write-Host "   [3] Pfad manuell eingeben" -ForegroundColor Gray
    $choice = Read-Host "Deine Wahl (1,2,3)"

    $targetDir = $null
    switch ($choice) {
        "1" {
            Write-Host "`n[?] ComfyUI Pfad eingeben (Enter fuer Standard):" -ForegroundColor Yellow
            Write-Host "    Standard: C:\Users\Cea\AppData\Local\Programs\ComfyUI\models\" -ForegroundColor Gray
            $comfyPath = Read-Host
            if (-not $comfyPath) {
                $comfyPath = "C:\Users\Cea\AppData\Local\Programs\ComfyUI\models\"
            }
            
            Write-Host "`n[?] Unterordner (z.B. diffusion_models, loras, vae, text_encoders):" -ForegroundColor Yellow
            $subFolder = Read-Host
            $targetDir = Join-Path $comfyPath $subFolder
        }
        "2" {
            $targetDir = [Environment]::GetFolderPath("Desktop")
        }
        "3" {
            Write-Host "[?] Vollstaendigen Zielpfad eingeben:" -ForegroundColor Yellow
            $targetDir = Read-Host
        }
        default {
            Write-Host "[X] Ungueltige Auswahl." -ForegroundColor Red
            return $false
        }
    }

    if (-not (Test-Path $targetDir)) {
        Write-Host "[!] Erstelle Ordner: $targetDir" -ForegroundColor Yellow
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }

    $savePath = Join-Path $targetDir $fileName

    # Existierende Datei pruefen
    if (Test-Path $savePath) {
        Write-Host "`n[!] Datei existiert bereits:" -ForegroundColor Yellow
        Write-Host "    $savePath" -ForegroundColor Gray
        $overwrite = Read-Host "Ueberschreiben? (j/n)"
        if ($overwrite -ne "j") {
            Write-Host "[X] Abgebrochen." -ForegroundColor Red
            return $false
        }
    }

    return (Download-File -url $downloadUrl -path $savePath)
}

# Funktion: Textdatei mit Drag & Drop verarbeiten
function Process-TextFile {
    param([string]$filePath)
    
    Write-Host "`n[+] Lese Datei: $filePath" -ForegroundColor Green
    
    if (-not (Test-Path $filePath)) {
        Write-Host "[X] Datei nicht gefunden!" -ForegroundColor Red
        return $false
    }
    
    $lines = Get-Content $filePath -Encoding UTF8
    $successCount = 0
    $totalCount = 0
    
    # Sammle alle Einträge zuerst
    $entries = @()
    foreach ($line in $lines) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        if ($line.TrimStart().StartsWith("#")) { continue }
        
        $parts = $line -split '\s+', 2
        if ($parts.Count -ne 2) {
            Write-Host "[X] Ungueltiges Format: $line" -ForegroundColor Red
            continue
        }
        
        $entries += @{
            Url = $parts[0].Trim() -replace '^"|"$', ''
            TargetDir = $parts[1].Trim() -replace '^"|"$', ''
        }
        $totalCount++
    }
    
    if ($totalCount -eq 0) {
        Write-Host "[X] Keine gueltigen Eintraege gefunden." -ForegroundColor Red
        return $false
    }
    
    # Einmalig nach XET Preference fragen (vor der ersten Datei)
    Write-Host "`n[?] Einstellungen fuer alle $totalCount Downloads:" -ForegroundColor Yellow
    $askXET = Read-Host "XET fuer schnelleren Download verwenden? (j/n) (Empfohlen fuer große Dateien)"
    $global:UseXET = ($askXET -eq "j")
    
    # Einmalig nach Download-Methode fragen
    Write-Host "`n[?] Download-Methode waehlen:" -ForegroundColor Yellow
    Write-Host "   [1] PowerShell (einfach, kein Fortschrittsbalken)" -ForegroundColor Gray
    Write-Host "   [2] curl (Fortschrittsbalken, empfohlen)" -ForegroundColor Green
    Write-Host "   [3] aria2 (Multi-Connection, sehr schnell)" -ForegroundColor Cyan
    $methodChoice = Read-Host "Deine Wahl (1,2,3)"
    
    switch ($methodChoice) {
        "1" { $global:DownloadMethod = "powershell" }
        "2" { $global:DownloadMethod = "curl" }
        "3" { $global:DownloadMethod = "aria2" }
        default { $global:DownloadMethod = "curl" }
    }
    Write-Host "[+] Verwende Methode: $($global:DownloadMethod)" -ForegroundColor Green
    
    # Jetzt alle Downloads durchfuehren
    $index = 0
    foreach ($entry in $entries) {
        $index++
        Write-Host "`n--- Datei $index von $totalCount ---" -ForegroundColor Cyan
        
        $url = $entry.Url
        $targetDir = $entry.TargetDir
        
        # Extrahiere Dateinamen aus URL
        $cleanUrl = $url -replace '\?.+$', ''
        $fileName = ($cleanUrl -split '/' | Select-Object -Last 1)
        
        Write-Host "[+] Modell: $fileName" -ForegroundColor Green
        
        # HuggingFace Link verarbeiten (mit gespeicherter Einstellung)
        $downloadUrl = $url
        if (Is-HuggingFaceLink -url $url) {
            Write-Host "[!] HuggingFace Link erkannt" -ForegroundColor Cyan
            if ($global:UseXET) {
                $downloadUrl = Convert-ToXETLink -url $url
                Write-Host "[+] Verwende XET Link" -ForegroundColor Green
            } else {
                Write-Host "[+] Verwende normalen HuggingFace Link" -ForegroundColor Yellow
            }
        }
        
        # Erstelle Zielverzeichnis falls nicht vorhanden
        if (-not (Test-Path $targetDir)) {
            Write-Host "[!] Erstelle Ordner: $targetDir" -ForegroundColor Yellow
            New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
        }
        
        $savePath = Join-Path $targetDir $fileName
        
        # Pruefe ob Datei bereits existiert
        if (Test-Path $savePath) {
            Write-Host "[!] Datei existiert bereits: $fileName" -ForegroundColor Yellow
            $overwrite = Read-Host "Ueberschreiben? (j/n/q=alle überspringen)"
            if ($overwrite -eq "q") {
                Write-Host "[!] Überspringe restliche Dateien" -ForegroundColor Yellow
                break
            }
            if ($overwrite -ne "j") {
                Write-Host "[-] Überspringe $fileName" -ForegroundColor Gray
                continue
            }
        }
        
        if (Download-File -url $downloadUrl -path $savePath) {
            $successCount++
        }
    }
    
    Write-Host "`n[+] Fertig! $successCount von $totalCount Dateien erfolgreich heruntergeladen." -ForegroundColor Green
    return ($successCount -eq $totalCount)
}

# Hauptmenue: Modus auswaehlen
Write-Host "[?] Modus auswaehlen:" -ForegroundColor Yellow
Write-Host "   [1] Einzelnen Link herunterladen" -ForegroundColor Green
Write-Host "   [2] Textdatei mit mehreren Links (Drag & Drop)" -ForegroundColor Cyan
$mode = Read-Host "Deine Wahl (1,2)"

$success = $false

if ($mode -eq "1") {
    $success = Process-SingleLink
} elseif ($mode -eq "2") {
    Write-Host "`n[?] Textdatei hier ablegen (Drag & Drop) oder Pfad eingeben:" -ForegroundColor Yellow
    $filePath = Read-Host
    $filePath = $filePath.Trim('"')
    $success = Process-TextFile -filePath $filePath
} else {
    Write-Host "[X] Ungueltige Auswahl." -ForegroundColor Red
}

if (-not $success) {
    Write-Host "`n[X] Einige oder alle Downloads fehlgeschlagen." -ForegroundColor Red
}

Write-Host "`nDruecke eine beliebige Taste zum Beenden..."
pause