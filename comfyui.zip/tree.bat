Pause
echo "Enter to start"

@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
type break > folder_dir.txt 2>nul

(set LF=^

)

:: 1. List files in the root directory (Gets a newline and #)
for /f "delims=" %%i in ('dir /b /a-d') do (
    if "%%i" NEQ "tree.bat" if "%%i" NEQ "folder_dir.txt" (
        echo ├─ %%i!LF!# >> folder_dir.txt
    )
)

:: 2. Deep scan all folders and subfolders
for /f "delims=" %%d in ('dir /b /ad') do (
    :: Root folders never get a #
    echo ├─ %%d/ >> folder_dir.txt
    
    :: Loop through all contents recursively
    for /f "delims=" %%f in ('dir "%%d" /b /s 2^>nul') do (
        set "full_path=%%f"
        set "relative_path=!full_path:%~dp0=!"
        
        if exist "%%f\" (
            :: Subfolders never get a #
            echo │  └─ !relative_path!/ >> folder_dir.txt
        ) else (
            :: Files always get a newline and #
            echo │  └─ !relative_path!!LF!# >> folder_dir.txt
        )
    )
)