#!/bin/bash

# Change to the script's directory
cd "$(dirname "$0")"

# Output file
output="folder_dir.txt"

# Clear the output file
> "$output"

# Function to print indented lines
print_line() {
    local indent="$1"
    local text="$2"
    local add_hash="$3"
    
    if [ "$add_hash" = true ]; then
        echo "${indent}${text}" >> "$output"
        echo "#" >> "$output"
    else
        echo "${indent}${text}" >> "$output"
    fi
}

# 1. List files in the root directory
while IFS= read -r file; do
    if [ "$file" != "tree.sh" ] && [ "$file" != "folder_dir.txt" ] && [ -f "$file" ]; then
        echo "├─ $file" >> "$output"
        echo "#" >> "$output"
    fi
done < <(ls -p 2>/dev/null | grep -v /)

# 2. Deep scan all folders and subfolders
find . -maxdepth 1 -type d ! -name "." ! -name ".." | while read -r dir; do
    dirname=$(basename "$dir")
    
    # Root folders never get a #
    echo "├─ $dirname/" >> "$output"
    
    # Loop through all contents recursively (excluding the root dir itself)
    find "$dir" -mindepth 1 | while read -r item; do
        # Get relative path
        relative_path="${item#./}"
        
        if [ -d "$item" ]; then
            # Subfolders never get a #
            echo "│  └─ $relative_path/" >> "$output"
        else
            # Files always get a newline and #
            echo "│  └─ $relative_path" >> "$output"
            echo "#" >> "$output"
        fi
    done
done

cat "$output"