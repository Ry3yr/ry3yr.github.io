<?php
// ======================================================================
// Keyword filtering (default + ?exclude=word1,word2 support)
// ======================================================================

function get_exclude_keywords() {
    // Always-on default filters
    $keywords = ['rumor', 'rumour', 'leak'];

    // Allow additional keywords via ?exclude=keyword,nextkeyword
    if (isset($_GET['exclude']) && $_GET['exclude'] !== '') {
        $custom = explode(',', $_GET['exclude']);
        foreach ($custom as $kw) {
            $kw = trim($kw);
            if ($kw !== '') {
                $keywords[] = $kw;
            }
        }
    }

    // Normalize: lowercase + de-duplicate
    $keywords = array_values(array_unique(array_map('strtolower', $keywords)));
    return $keywords;
}

function filter_excluded_articles($articles, $keywords) {
    if (empty($keywords)) return $articles;
    return array_values(array_filter($articles, function ($a) use ($keywords) {
        $haystack = strtolower(($a['title'] ?? '') . ' ' . ($a['excerpt'] ?? ''));
        foreach ($keywords as $kw) {
            if ($kw !== '' && strpos($haystack, $kw) !== false) {
                return false; // matched an excluded keyword -> drop it
            }
        }
        return true;
    }));
}

// ======================================================================
// START: AJAX Handlers
// ======================================================================

// Handler for the new "Fetch New Posts" button
if (isset($_GET['action']) && $_GET['action'] === 'fetch_new') {
    header('Content-Type: application/json');
    $latest_timestamp = $_GET['latest_timestamp'] ?? '1970-01-01 00:00:00';
    $base_url = 'https://nintendonews.com/news';
    $blocked_domains = ['nintendolife.de','nintendolife.com'];
    $exclude_keywords = get_exclude_keywords();
    $social_data = fetch_fake_social_data();

    $all_new_posts = [];
    $page = 1;
    $keep_fetching = true;

    while ($keep_fetching && $page <= 5) {
        $url = $base_url . '?page=' . $page;
        $html = fetch_url_content($url);
        if (!$html) { $keep_fetching = false; continue; }
        $articles_on_page = parse_articles_regex($html, $base_url, [], $social_data);
        if (empty($articles_on_page)) { $keep_fetching = false; continue; }

        foreach ($articles_on_page as $article) {
            if ($article['date'] > $latest_timestamp) {
                $all_new_posts[] = $article;
            } else {
                $keep_fetching = false;
                break;
            }
        }
        $page++;
    }

    // Apply keyword filtering (rumor/rumour/leak + any ?exclude= keywords)
    $all_new_posts = filter_excluded_articles($all_new_posts, $exclude_keywords);

    sort_articles_by_date($all_new_posts); // Sort all new posts first

    $domain_counts = [];
    $unblocked_new_articles = [];
    $blocked_posts_details = []; // MODIFIED: New array for blocked post details

    foreach ($all_new_posts as $article) {
        $host = $article['badge'];
        $domain_counts[$host] = ($domain_counts[$host] ?? 0) + 1;

        $is_blocked = false;
        foreach ($blocked_domains as $blocked_domain) {
            if (stripos($article['link'], $blocked_domain) !== false) {
                $is_blocked = true;
                break;
            }
        }
        if (!$is_blocked) {
            $unblocked_new_articles[] = $article;
        } else {
            // MODIFIED: Capture details for blocked posts
            $blocked_posts_details[] = [
                'title' => $article['title'],
                'date' => $article['date'],
                'badge' => $article['badge']
            ];
        }
    }

    arsort($domain_counts);

    echo json_encode([
        'total_count' => count($all_new_posts),
        'domain_counts' => $domain_counts,
        'new_articles' => $unblocked_new_articles,
        'blocked_articles' => $blocked_posts_details, // MODIFIED: Add to response
        'social_data' => $social_data // ADDED: Pass social data to JavaScript
    ]);
    exit;
}

// Handler for manual caching
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'cache') {
    header('Content-Type: application/json');
    $json_input = file_get_contents('php://input');
    $articles_from_page = json_decode($json_input, true);
    if (!is_array($articles_from_page)) { http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid data received.']); exit; }
    function update_json_cache($new_articles_from_page) {
        $json_file = 'pastentries.json';
        $past_entries = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) ?: [] : [];
        $existing_links = array_flip(array_column($past_entries, 'link'));
        $articles_to_add = [];
        foreach ($new_articles_from_page as $article) { if (!isset($existing_links[$article['link']])) { $articles_to_add[] = $article; } }
        $newly_added_count = count($articles_to_add);
        if ($newly_added_count > 0) {
            $all_articles = array_merge($articles_to_add, $past_entries);
            if (count($all_articles) > 500) { $all_articles = array_slice($all_articles, 0, 500); }
            file_put_contents($json_file, json_encode($all_articles, JSON_PRETTY_PRINT));
        }
        return $newly_added_count;
    }
    echo json_encode(['status' => 'success', 'added' => update_json_cache($articles_from_page)]);
    exit;
}
// ======================================================================
// END: AJAX Handlers
// ======================================================================

function fetch_url_content($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
    $html = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($http_code === 200) ? $html : false;
}

function normalize_image_url($url, $base_url) {
    $url = trim($url);
    if ($url === '' || strpos($url, '...') !== false) { return 'https://via.placeholder.com/150x80?text=No+Image'; }
    if (preg_match('#^https?://#i', $url)) return $url;
    $parsed = parse_url($base_url);
    $host = $parsed['scheme'].'://'.$parsed['host'];
    if (isset($parsed['port'])) $host .= ':'.$parsed['port'];
    if ($url[0] !== '/') $url = '/'.$url;
    return $host.$url;
}

function fetch_fake_social_data() {
    $json_url = 'https://alceawis.de/other/extra/scripts/fakesocialmedia/0ld/data_akkoma.json?nocache=' . time();
    $json_data = fetch_url_content($json_url);
    if (!$json_data) return [];
    $data = json_decode($json_data, true);
    $preview_links = [];
    foreach ($data as $item) { if (isset($item['preview']) && !empty($item['preview'])) { $preview_links[] = ['preview' => $item['preview'], 'url' => $item['url']]; } }
    return $preview_links;
}

function parse_articles_regex($html, $base_url, $blocked_domains, $social_data) {
    $articles = [];
    $pattern = '#<div\s+class=["\']item[^"\']*["\'][^>]*>.*?<img[^>]*src=["\']([^"\']+)["\'][^>]*>.*?<h2[^>]*class=["\']heading[^"\']*["\'][^>]*>\s*<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>.*?(<p[^>]*class=["\']summary[^"\']*["\']>(.*?)</p>)?.*?data-timestamp=["\']([^"\']+)["\']#si';
    if (preg_match_all($pattern, $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $link = trim($m[2]);
            $blocked = false;
            foreach ($blocked_domains as $d) { if (stripos($link, $d) !== false) { $blocked = true; break; } }
            if ($blocked) continue;
            $host = parse_url($link, PHP_URL_HOST);
            $badge = strtoupper(preg_replace('/^www\./','',$host));
            $articles[] = ['image' => normalize_image_url($m[1], $base_url), 'link' => $link, 'title' => trim(htmlspecialchars_decode($m[3])), 'excerpt' => isset($m[5]) ? trim(htmlspecialchars_decode($m[5])) : '', 'badge' => $badge, 'date' => isset($m[6]) ? $m[6] : ''];
        }
    }
    return $articles;
}

function load_past_entries() {
    $json_file = 'pastentries.json';
    if (!file_exists($json_file)) { return []; }
    $json_data = file_get_contents($json_file);
    $past_entries = json_decode($json_data, true);
    return is_array($past_entries) ? $past_entries : [];
}

function get_missing_articles($current_articles, $all_saved_articles) {
    $missing = [];
    $current_urls_set = array_flip(array_column($current_articles, 'link'));
    foreach ($all_saved_articles as $saved_article) { if (!isset($current_urls_set[$saved_article['link']])) { $missing[] = $saved_article; } }
    return $missing;
}

function sort_articles_by_date(&$articles) {
    usort($articles, function($a, $b) {
        if (empty($a['date']) && empty($b['date'])) return 0;
        if (empty($a['date'])) return 1;
        if (empty($b['date'])) return -1;
        return strcmp($b['date'], $a['date']);
    });
}

// --- Main Page Logic ---
$base_url = 'https://nintendonews.com/news';
$blocked_domains = ['nintendolife.de','nintendolife.com'];
$exclude_keywords = get_exclude_keywords();
$social_data = fetch_fake_social_data();
$page_param = isset($_GET['page']) ? max(1,intval($_GET['page'])) : 1;
$autopage = isset($_GET['autopage']);
$url = $base_url . '?page=' . $page_param;
$html = fetch_url_content($url);
$current_articles = $html ? parse_articles_regex($html, $base_url, $blocked_domains, $social_data) : [];
$past_entries = load_past_entries();
$missing_articles = get_missing_articles($current_articles, $past_entries);
$all_articles = array_merge($current_articles, $missing_articles);
sort_articles_by_date($all_articles);

// Apply keyword filtering (rumor/rumour/leak + any ?exclude= keywords)
$all_articles = filter_excluded_articles($all_articles, $exclude_keywords);

$current_page = $page_param;

if ($autopage && isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    echo json_encode(['articles' => $all_articles, 'current' => $current_page, 'social_data' => $social_data]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Nintendo News</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; position: relative; }
        .article { position: relative; border: 1px solid #ccc; margin-bottom: 10px; padding: 15px; border-radius: 8px; display: flex; gap: 15px; }
        .article img { max-width: 150px; border-radius: 4px; }
        .badge { position: absolute; bottom: 5px; right: 10px; font-size: 11px; color: #666; background: #f2f2f2; padding: 2px 6px; border-radius: 3px; }
        .date { position: absolute; top: 5px; left: 10px; font-size: 11px; color: #333; background: #fff; padding: 2px 6px; border-radius: 3px; border: 1px solid #ccc; }
        #page-indicator { position: fixed; bottom: 10px; right: 10px; font-size: 12px; color: #444; background: #eee; padding: 2px 6px; border-radius: 4px; z-index: 1000; }
        .social-iframe { width: 100%; height: 300px; border: 1px solid #ddd; margin-top: 10px; border-radius: 4px; }
        .missing-article { background-color: #f0f0f0; opacity: 0.8; }
        #date-overlay { position: fixed; top: 20px; right: 20px; background: rgba(230, 0, 18, 0.9); color: white; padding: 10px 15px; border-radius: 8px; font-size: 16px; font-weight: bold; z-index: 1000; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); }
        #scroll-progress { position: fixed; top: 0; left: 0; width: 100%; height: 4px; background: #e0e0e0; z-index: 1001; }
        #progress-bar { height: 100%; background: #e60012; width: 0%; transition: width 0.2s ease; }
        .controls { position: fixed; top: 20px; left: 20px; z-index: 1000; display: flex; gap: 10px; flex-wrap: wrap; max-width: 90vw; }
        .controls button { background: #e60012; color: white; border: none; padding: 10px 15px; border-radius: 8px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); }
        #toggle-social.active { background: #4CAF50; }
        #cache-posts-btn { background-color: #007bff; }
        #fetch-new-btn { background-color: #ff9800; }
        .hidden { display: none !important; }
        #cache-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.7); color: white; display: flex; justify-content: center; align-items: center; z-index: 2000; text-align: center; }
        #cache-message { padding: 25px 40px; background: rgba(40, 40, 40, 0.9); border-radius: 10px; font-size: 1.2em; font-weight: bold; }
        #loader { text-align: center; padding: 20px; font-style: italic; color: #888; }
        #fetch-status-message { background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; padding: 15px; margin: 10px 0; font-family: monospace; line-height: 1.6; }
        #filter-bar { background: #eef; border: 1px solid #ccd; border-radius: 8px; padding: 10px 15px; margin: 10px 0; font-size: 13px; }
        #filter-bar input { padding: 6px 8px; border-radius: 4px; border: 1px solid #ccc; width: 260px; }
        #filter-bar button { padding: 6px 10px; border-radius: 4px; border: none; background: #333; color: #fff; cursor: pointer; }
    </style>
</head>
<body>
    <div id="scroll-progress"><div id="progress-bar"></div></div>
    <div id="date-overlay">Latest News</div>
    <div class="controls">
        <button id="toggle-social">Show Only Social Posts</button>
        <button id="cache-posts-btn">Cache Posts</button>
        <button id="fetch-new-btn">Fetch New Posts</button>
    </div>

    <h1>Latest Nintendo News</h1>

<details><summary>.</summary>
    <div id="filter-bar">
        <b>Excluded keywords:</b> <?= htmlspecialchars(implode(', ', $exclude_keywords)) ?><br>
        Add more (comma separated), then reload:
        <input type="text" id="extra-exclude-input" placeholder="e.g. switch2,pokemon">
        <button id="apply-exclude-btn">Apply</button>
    </div>
</details>
    <div id="fetch-status-message" class="hidden"></div>

    <ul id="article-list" style="list-style:none;padding:0;">
        <?php foreach($all_articles as $a): 
            $is_missing = in_array($a['link'], array_column($missing_articles, 'link'));
            $class = $is_missing ? 'article missing-article' : 'article';
        ?>
        <li class="<?= $class ?>" data-url="<?= htmlspecialchars($a['link']) ?>" data-date="<?= htmlspecialchars($a['date']) ?>">
            <div class="date"><?=htmlspecialchars($a['date'])?></div>
            <div><img src="<?=htmlspecialchars($a['image'])?>" alt="<?=htmlspecialchars($a['title'])?>"></div>
            <div>
                <h3><a href="<?=htmlspecialchars($a['link'])?>" target="_blank"><?=htmlspecialchars($a['title'])?></a></h3>
                <p><?=htmlspecialchars($a['excerpt'])?></p>
            </div>
            <span class="badge"><?=htmlspecialchars($a['badge'])?></span>
        </li>
        <?php endforeach; ?>
    </ul>
    
    <div id="loader">Loading more articles...</div>
    <div id="page-indicator">Page <?=$current_page?></div>
    <div id="cache-overlay" class="hidden"><div id="cache-message"></div></div>

    <script>
        let currentPage = <?=$current_page?>;
        let loading = false;
        let showOnlySocial = false;
        const list = document.getElementById('article-list');
        const indicator = document.getElementById('page-indicator');
        const dateOverlay = document.getElementById('date-overlay');
        const progressBar = document.getElementById('progress-bar');
        const toggleButton = document.getElementById('toggle-social');
        const cacheButton = document.getElementById('cache-posts-btn');
        const cacheOverlay = document.getElementById('cache-overlay');
        const cacheMessage = document.getElementById('cache-message');
        const loader = document.getElementById('loader');
        const fetchNewBtn = document.getElementById('fetch-new-btn');
        const fetchStatusMsg = document.getElementById('fetch-status-message');
        const extraExcludeInput = document.getElementById('extra-exclude-input');
        const applyExcludeBtn = document.getElementById('apply-exclude-btn');
        let socialData = <?= json_encode($social_data) ?>;

        // Current exclude keywords (default + any from ?exclude=), used so
        // AJAX calls (fetch new / autopage) keep applying the same filter.
        const excludeKeywords = <?= json_encode($exclude_keywords) ?>;
        const excludeParam = encodeURIComponent(excludeKeywords.join(','));

        // Helper to append the current exclude param onto a query string
        function withExclude(qs) {
            return qs + (excludeParam ? '&exclude=' + excludeParam : '');
        }

        applyExcludeBtn.addEventListener('click', () => {
            const extra = extraExcludeInput.value.trim();
            const combined = extra ? excludeKeywords.concat(extra.split(',').map(s => s.trim()).filter(Boolean)) : excludeKeywords;
            const url = new URL(window.location.href);
            url.searchParams.set('exclude', combined.join(','));
            window.location.href = url.toString();
        });

        const displayedUrls = new Set(Array.from(document.querySelectorAll('#article-list li[data-url]')).map(li => li.getAttribute('data-url')));

        // Function to match URLs by removing all slashes
        function matchSocialUrl(articleUrl) {
            const cleanArticle = articleUrl.replace(/[\/\\]/g, '');
            
            for (const socialItem of socialData) {
                if (!socialItem.preview) continue;
                
                const cleanPreview = socialItem.preview.replace(/[\/\\]/g, '');
                
                // Exact match without slashes
                if (cleanArticle === cleanPreview) {
                    return socialItem.url;
                }
                
                // Also check if article starts with preview
                if (cleanArticle.startsWith(cleanPreview)) {
                    return socialItem.url;
                }
            }
            return false;
        }

        // Process existing articles for social matches
function processSocialMatches() {
    document.querySelectorAll('#article-list li').forEach(li => {
        const articleUrl = li.getAttribute('data-url');
        const socialUrl = matchSocialUrl(articleUrl);
        
        if (socialUrl) {
            li.setAttribute('data-has-social', 'true');
            
            // Only add the iframe if one doesn't already exist
            if (!li.querySelector('.social-iframe')) { 
                const socialHtml = `
                    <div style="width:100%;margin-top:10px;">
                        <div style="font-size:8px;color:#888;margin-bottom:4px;word-wrap:break-word;">${socialUrl}</div>
                        <iframe src="replyhandlerfull.html?url=${encodeURIComponent(socialUrl)}" class="social-iframe"></iframe>
                    </div>
                `;
                li.insertAdjacentHTML('beforeend', socialHtml);
            }
        } else {
            li.setAttribute('data-has-social', 'false');
        }
    });
}

        // Initial processing
        processSocialMatches();

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => { if (entry.isIntersecting) { const date = entry.target.getAttribute('data-date'); if (date) dateOverlay.textContent = formatDate(date); } });
        }, { root: null, rootMargin: '0px', threshold: 0.5 });
        document.querySelectorAll('.article').forEach(article => observer.observe(article));

        function formatDate(dateString) {
            if (!dateString) return 'Latest News';
            const date = new Date(dateString.replace(' ', 'T'));
            return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
        }

        window.addEventListener('scroll', () => {
            const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
            progressBar.style.width = scrollPercent + '%';
        });

        toggleButton.addEventListener('click', () => {
            showOnlySocial = !showOnlySocial;
            toggleButton.classList.toggle('active', showOnlySocial);
            toggleButton.textContent = showOnlySocial ? 'Show All Posts' : 'Show Only Social Posts';
            document.querySelectorAll('#article-list li').forEach(li => {
                li.classList.toggle('hidden', showOnlySocial && li.getAttribute('data-has-social') === 'false');
            });

            // MODIFICATION: Update loader text based on mode
            if (showOnlySocial) {
                loader.textContent = 'Autoload is disabled in "Social Posts Only" mode.';
            } else {
                loader.textContent = 'Loading more articles...';
            }
        });

        cacheButton.addEventListener('click', async () => {
            cacheOverlay.classList.remove('hidden');
            cacheMessage.textContent = 'Scanning all posts...';
            const articlesOnPage = Array.from(document.querySelectorAll('#article-list li.article')).map(li => {
                const socialIframe = li.querySelector('.social-iframe');
                return { link: li.dataset.url, date: li.dataset.date, image: li.querySelector('img').src, title: li.querySelector('h3 a').textContent.trim(), excerpt: li.querySelector('p').textContent.trim(), badge: li.querySelector('.badge').textContent.trim(), social_url: socialIframe ? new URL(socialIframe.src).searchParams.get('url') : null };
            });
            cacheMessage.textContent = `Found ${articlesOnPage.length} posts. Saving new ones...`;
            try {
                const response = await fetch('?action=cache', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(articlesOnPage) });
                const result = await response.json();
                cacheMessage.textContent = `Success! ${result.added} new posts added to cache.`;
            } catch (error) { cacheMessage.textContent = `Error: ${error.message}`; }
            setTimeout(() => cacheOverlay.classList.add('hidden'), 4000);
        });
        
        fetchNewBtn.addEventListener('click', async () => {
            // Check if in social-only mode
            if (showOnlySocial) {
                fetchStatusMsg.innerHTML = 'Fetching new posts is disabled in "Social Posts Only" mode.';
                fetchStatusMsg.classList.remove('hidden');
                setTimeout(() => { fetchStatusMsg.classList.add('hidden'); }, 4000);
                return; // Exit the function
            }

            const firstArticle = list.querySelector('li.article');
            const latestTimestamp = firstArticle ? firstArticle.dataset.date : '1970-01-01 00:00:00';

            fetchStatusMsg.innerHTML = 'Checking for new posts...';
            fetchStatusMsg.classList.remove('hidden');
            fetchNewBtn.disabled = true;

            try {
                const response = await fetch(withExclude(`?action=fetch_new&latest_timestamp=${encodeURIComponent(latestTimestamp)}`));
                const data = await response.json();

                if (data.social_data) {
                    socialData = data.social_data;
                }

                let message = `<b>New posts found: ${data.total_count}</b>`;
                if (data.total_count > 0) {
                    for (const domain in data.domain_counts) {
                        message += `<br>- ${domain}: ${data.domain_counts[domain]} posts`;
                    }
                }

                if (data.blocked_articles && data.blocked_articles.length > 0) {
                    message += `<hr style="margin:10px 0; border:0; border-top:1px solid #ddd;"><b>Blocked Posts:</b>`;
                    data.blocked_articles.forEach(blockedPost => {
                        message += `<br><small style="color:#555;">[${blockedPost.date}] [${blockedPost.badge}] ${blockedPost.title}</small>`;
                    });
                }
                fetchStatusMsg.innerHTML = message;

                if (data.new_articles && data.new_articles.length > 0) {
                    data.new_articles.forEach(a => {
                        if (displayedUrls.has(a.link)) return;
                        displayedUrls.add(a.link);
                        const li = createArticleElement(a);
                        list.prepend(li);
                        observer.observe(li);
                    });
                    processSocialMatches();
                }
            } catch (error) {
                console.error('Failed to fetch new posts:', error);
                fetchStatusMsg.textContent = 'An error occurred while fetching new posts.';
            } finally {
                fetchNewBtn.disabled = false;
            }
        });

        function createArticleElement(a) {
            const li = document.createElement('li');
            li.className = 'article';
            li.dataset.url = a.link;
            li.dataset.date = a.date;
            li.innerHTML = `<div class="date">${a.date}</div><div><img src="${a.image}" alt="${a.title}"></div><div><h3><a href="${a.link}" target="_blank">${a.title}</a></h3><p>${a.excerpt}</p></div><span class="badge">${a.badge}</span>`;
            return li;
        }

        async function loadMoreArticles() {
            // MODIFICATION: Check if loading or in social-only mode
            if (loading || showOnlySocial) return;

            loading = true;
            loader.textContent = 'Loading...';
            const nextPage = currentPage + 1;
            try {
                const resp = await fetch(withExclude(`?autopage=1&page=${nextPage}&ajax=1`));
                const data = await resp.json();
                if (!data.articles || data.articles.length === 0) { loader.textContent = 'No more articles to load.'; loadMoreObserver.unobserve(loader); return; }
                
                if (data.social_data) {
                    socialData = data.social_data;
                }
                
                const newArticles = data.articles.filter(article => !displayedUrls.has(article.link));
                if (newArticles.length === 0) {
                    console.log(`Page ${nextPage} had no new content, trying page ${nextPage + 1}...`);
                    currentPage = nextPage;
                    loading = false;
                    loadMoreArticles();
                    return;
                }
                newArticles.forEach(a => {
                    displayedUrls.add(a.link);
                    const li = createArticleElement(a);
                    list.appendChild(li);
                    observer.observe(li);
                });
                currentPage = nextPage;
                indicator.textContent = `Page ${currentPage}`;
                
                processSocialMatches();
            } catch (error) {
                console.error("Failed to load more articles:", error);
                loader.textContent = 'Error loading articles.';
            } finally {
                loading = false;
            }
        }
        const loadMoreObserver = new IntersectionObserver(entries => { if (entries[0].isIntersecting) { loadMoreArticles(); } }, { threshold: 0.1 });
        loadMoreObserver.observe(loader);
    </script>
</body>
</html>
