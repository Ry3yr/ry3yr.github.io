<details>
  <div id="content"></div>
  <script>
    const baseUrl = "https://alceawis.de"; // Base URL
    fetch("https://alceawis.de/code.html")
      .then(response => response.text())
      .then(data => {
        const start = data.indexOf("CMDS") + 4;
        const end = data.indexOf("CodeDistribution") - 0;
        const content = data.substring(start, end);
        // Create a temporary element to parse the content as HTML
        const tempElement = document.createElement("div");
        tempElement.innerHTML = content;
        // Find and convert relative URLs to absolute URLs
        const relativeUrls = tempElement.querySelectorAll("a[href], img[src]");
        relativeUrls.forEach(url => {
          const originalUrl = url.getAttribute("href") || url.getAttribute("src");
          const absoluteUrl = new URL(originalUrl, baseUrl).href;
          url.setAttribute("href", absoluteUrl);
          url.setAttribute("src", absoluteUrl);
        });
        // Append the modified content to the target element
        document.getElementById("content").appendChild(tempElement);
      });
  </script>
</details><br>


<?php
if (!isset($_GET['user']) || $_GET['user'] !== 'admin') {
    $disableButton = true;
} else {
    $disableButton = false;
}
?>
<script>
    window.addEventListener('DOMContentLoaded', function() {
        var submitButtons = document.querySelectorAll('input[type="submit"]');
        if (<?php echo $disableButton ? 'true' : 'false'; ?>) {
            submitButtons.forEach(function(button) {
                button.disabled = true;
            });
        }
    });
</script>



<?php
$currentDir = __DIR__; // Get the current directory
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedFile = $_POST['selectedFile'];
    $content = $_POST['content'];
    $filename = basename($selectedFile);

    if (!empty($selectedFile) && !empty($content)) {
        file_put_contents($filename, $content); // Save the modified content back to the file
        echo "File saved successfully!";
    }
}
$files = array_diff(scandir($currentDir), array('.', '..')); // Get the list of files excluding "." and ".."
echo "<form method='POST'>";
echo "<select name='selectedFile'>";
foreach ($files as $file) {
    if (pathinfo($file, PATHINFO_EXTENSION) === 'txt') {
        echo "<option value='$file'>$file</option>";
    }
}
echo "</select>";
echo "<input type='submit' value='Load File'>";
echo "</form>";
if (isset($_POST['selectedFile'])) {
    $selectedFile = $_POST['selectedFile'];
    $filename = basename($selectedFile);
    if (file_exists($filename)) {
        $content = file_get_contents($filename);
        $escapedContent = htmlspecialchars($content);
        echo "<br>";
        echo "<form method='POST'>";
        echo "<textarea name='content' rows='120' cols='120'>$escapedContent</textarea><br>";
        echo "<input type='hidden' name='selectedFile' value='$selectedFile'>";
        echo "<input type='submit' value='Save'>";
        echo "</form>";
    }
}
?>
