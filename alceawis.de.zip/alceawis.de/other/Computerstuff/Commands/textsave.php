<a href=/code.html>code</a><br>
<?php
if (!isset($_GET['user']) || $_GET['user'] !== 'admin') {
    $disableButton = true;
} else {
    $disableButton = false;
}
?>
<script>
    window.addEventListener('DOMContentLoaded', function() {
        var submitButtons = document.querySelectorAll('input[type="submit"]');
        if (<?php echo $disableButton ? 'true' : 'false'; ?>) {
            submitButtons.forEach(function(button) {
                button.disabled = true;
            });
        }
    });
</script>



<?php
$currentDir = __DIR__; // Get the current directory
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedFile = $_POST['selectedFile'];
    $content = $_POST['content'];
    $filename = basename($selectedFile);

    if (!empty($selectedFile) && !empty($content)) {
        file_put_contents($filename, $content); // Save the modified content back to the file
        echo "File saved successfully!";
    }
}
$files = array_diff(scandir($currentDir), array('.', '..')); // Get the list of files excluding "." and ".."
echo "<form method='POST'>";
echo "<select name='selectedFile'>";
foreach ($files as $file) {
    if (pathinfo($file, PATHINFO_EXTENSION) === 'txt') {
        echo "<option value='$file'>$file</option>";
    }
}
echo "</select>";
echo "<input type='submit' value='Load File'>";
echo "</form>";
if (isset($_POST['selectedFile'])) {
    $selectedFile = $_POST['selectedFile'];
    $filename = basename($selectedFile);
    if (file_exists($filename)) {
        $content = file_get_contents($filename);
        $escapedContent = htmlspecialchars($content);
        echo "<br>";
        echo "<form method='POST'>";
        echo "<textarea name='content' rows='120' cols='120'>$escapedContent</textarea><br>";
        echo "<input type='hidden' name='selectedFile' value='$selectedFile'>";
        echo "<input type='submit' value='Save'>";
        echo "</form>";
    }
}
?>
