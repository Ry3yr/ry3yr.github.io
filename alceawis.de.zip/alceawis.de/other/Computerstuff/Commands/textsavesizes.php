<?php
// Check if the URL contains the 'admin' query parameter
if (isset($_GET['admin'])) {
    // Get the list of all .txt files in the current directory
    $files = glob('*.txt');
    
    // Initialize an array to hold file sizes
    $fileSizes = array();
    
    // Iterate over each file and get its size
    foreach ($files as $file) {
        // Get the file size in bytes
        $size = filesize($file);
        // Add the file name and its size to the array
        $fileSizes[$file] = $size;
    }
    
    // Convert the array to JSON format
    $json = json_encode($fileSizes, JSON_PRETTY_PRINT);
    
    // Save the JSON to a file named sizes.json
    file_put_contents('sizes.json', $json);
    
    // Optionally, output a message indicating success
    echo "File sizes have been written to sizes.json";
} else {
    // Optionally, output a message if the query string is not present
    echo "Access denied.";
}
?>
