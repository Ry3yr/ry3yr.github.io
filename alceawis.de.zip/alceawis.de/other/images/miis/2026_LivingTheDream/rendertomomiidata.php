<?php
header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

// Validate: digits only, to avoid path injection
if (!$id || !ctype_digit((string)$id)) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing or invalid id']);
    exit;
}

$url = "https://api.tomodachishare.com/api/mii/{$id}/info";

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_USERAGENT      => 'Mozilla/5.0 (proxy)',
]);
$body = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

http_response_code($code ?: 502);
echo $body ?: json_encode(['error' => 'Upstream request failed']);