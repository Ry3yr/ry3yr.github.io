<?php
declare(strict_types=1);

header('Content-Type: text/plain; charset=utf-8');
set_time_limit(0);

// only run when explicitly asked
if (($_GET['run'] ?? '') !== 'yes') {
    http_response_code(403);
    echo "Forbidden.";
    //echo "Forbidden. Add ?run=yes to execute.\n";
    exit;
}

// --- config ---
$DOC_ROOT   = rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/');
$MIIS_HTML  = $DOC_ROOT . '/miis.html';
$OUT_DIR    = __DIR__ . '/miiinfo';
$API_BASE   = 'https://api.tomodachishare.com/api/mii/';
$TIMEOUT    = 10;
$THROTTLE   = 150000;        // 150ms between API calls
$MAX_AGE    = 24 * 60 * 60;  // 24 hours
// ---------------

if (!is_file($MIIS_HTML)) {
    http_response_code(500);
    echo "ERROR: $MIIS_HTML not found\n";
    exit;
}

if (!is_dir($OUT_DIR) && !mkdir($OUT_DIR, 0775, true)) {
    http_response_code(500);
    echo "ERROR: cannot create $OUT_DIR\n";
    exit;
}

$html = file_get_contents($MIIS_HTML);
if ($html === false) {
    http_response_code(500);
    echo "ERROR: cannot read $MIIS_HTML\n";
    exit;
}

preg_match_all('#/mii/(\d+)/image#', $html, $m);
$ids = array_values(array_unique(array_map('intval', $m[1])));

if (!$ids) {
    echo "No ids found in $MIIS_HTML\n";
    exit;
}

echo "Cache dir: $OUT_DIR\n";
echo "Found " . count($ids) . " ids\n\n";

$ok = 0; $skip = 0; $fail = 0;

foreach ($ids as $id) {
    $path = $OUT_DIR . '/' . $id . '.json';

    if (is_file($path)) {
        $age = time() - filemtime($path);
        if ($age < $MAX_AGE) {
            echo "SKIP  $id  (age " . round($age / 60) . " min)\n";
            $skip++;
            continue;
        }
    }

    $url = $API_BASE . $id . '/info';

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => $TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; MiiCache/1.0)',
        CURLOPT_HTTPHEADER     => ['Accept: application/json'],
    ]);
    $body = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($body === false || $code !== 200) {
        echo "FAIL  $id  (HTTP $code" . ($err ? ", $err" : "") . ")\n";
        $fail++;
        usleep($THROTTLE);
        continue;
    }

    $decoded = json_decode($body, true);
    if (!is_array($decoded)) {
        echo "FAIL  $id  (not JSON)\n";
        $fail++;
        usleep($THROTTLE);
        continue;
    }

    $tmp = $path . '.tmp';
    if (file_put_contents($tmp, $body, LOCK_EX) === false || !rename($tmp, $path)) {
        echo "FAIL  $id  (write error)\n";
        @unlink($tmp);
        $fail++;
        usleep($THROTTLE);
        continue;
    }

    echo "OK    $id  (" . strlen($body) . " bytes)\n";
    $ok++;
    usleep($THROTTLE);
}

echo "\nDone. ok=$ok skip=$skip fail=$fail\n";