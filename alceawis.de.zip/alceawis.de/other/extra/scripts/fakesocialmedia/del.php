<?php
ini_set('display_errors', 0);
?>



<?php
$user = $_GET['user'] ?? '';
$jsonFilePath = "data_" . $user . ".json";
if (!file_exists($jsonFilePath)) {
    die('JSON file not found.');
}
$jsonData = file_get_contents($jsonFilePath);
$data = json_decode($jsonData, true);
if (isset($_POST['deleteEntryId'])) {
    $deleteEntryId = $_POST['deleteEntryId'];
    foreach ($data as $key => $entry) {
        if ($entry['id'] == $deleteEntryId) {
            unset($data[$key]);
            break;
        }
    }
    $jsonData = json_encode(array_values($data), JSON_PRETTY_PRINT);
    file_put_contents($jsonFilePath, $jsonData);
}
echo '<ul>';
foreach ($data as $entry) {
    echo '<li>';
    foreach ($entry as $key => $value) {
        if (!is_numeric($key) && $key !== 'plaintext') {
            echo $key . ': ' . $value . '<br>';
        }
    }
    echo '<form method="post" style="display: inline-block;">';
    echo '<input type="hidden" name="deleteEntryId" value="' . $entry['id'] . '">';
    echo '<input type="submit" value="Delete">';
    echo '</form>';

    // Display the text next to the delete button
        echo '<span>';
        print_r($entry);
        echo '</span>';

    echo '</li>';
}
echo '</ul>';
?>
