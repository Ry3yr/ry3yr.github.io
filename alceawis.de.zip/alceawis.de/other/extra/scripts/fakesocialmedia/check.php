<?php
// Set the JSON file name
$json_file = "data_alcea.json";

// Load the JSON data
$json_data = file_get_contents($json_file);

// Decode the JSON data
$data = json_decode($json_data, true);

// Check for errors in the JSON decoding process
if (json_last_error() !== JSON_ERROR_NONE) {
    echo "Error decoding JSON: " . json_last_error_msg() . "\n";
    exit;
}

// Check for errors in the data
$errors = [];
$depth = 0;
$path = [];
$traverse_data = function($data) use (&$errors, &$depth, &$path, &$traverse_data) {
    global $json_file;
    if (is_array($data)) {
        $depth++;
        foreach ($data as $key => $value) {
            $path[] = $key;
            $traverse_data($value);
            array_pop($path);
        }
        $depth--;
    } else {
        $json_path = $json_file . "#" . implode(".", $path);
        if (is_null($data)) {
            $errors[] = "Null value found at path: $json_path";
        } elseif (!is_string($data) && !is_numeric($data) && !is_bool($data)) {
            $errors[] = "Invalid data type at path: $json_path";
        }
    }
};
$traverse_data($data);

// Display the errors, if any
if (empty($errors)) {
    echo "No errors found in the JSON file.\n";
} else {
    echo "Errors found in the JSON file:\n";
    foreach ($errors as $error) {
        echo "- " . $error . "\n";
    }
}
?>