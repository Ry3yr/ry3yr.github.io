
<button id="writeBtn" style="background-color: white; border: 1px solid black; padding: 1px 20px; font-size: 16px; cursor: pointer;">💾WRITE</button>
<button id="readBtn" style="background-color: white; border: 1px solid black; padding: 1px 20px; font-size: 16px; cursor: pointer;">📥READ</button>


<!--<a href="#" id="loadDataLink">Load</a>
<input type="number" id="entryNumber" min="1" value="1" style="width: 40px; margin-left: 5px;">|
<a href="#" id="submitEditLink">Submit Edit</a>
 <a target="_blank" href="https://woof.tech/search?q=%40alcea%40alceawis.com&type=accounts" style=color:lightpink>check</a>
<a href="/githubrepo.html?namefilter=acws,akko,infosec" target="_blank">RepoLinks 🔗</a>-->
<textarea id="originalTextbox" style="display:none;"></textarea>
<script>
function loadEntryByReversedNumber(entryNum) {
    fetch('/other/extra/scripts/fakesocialmedia/data_alcea.json', { cache: 'no-cache' })
      .then(response => response.json())
      .then(data => {
        const reversedIndex = data.length - entryNum;

        if (reversedIndex < 0 || reversedIndex >= data.length) {
          alert('Entry number exceeds data length');
          return;
        }

        const entry = data[reversedIndex];
        const innerKey = Object.keys(entry)[0];
        const value = entry[innerKey].value;

        document.getElementById('textbox').value = value;
        document.getElementById('originalTextbox').value = value;
      })
      .catch(error => {
        console.error('Error loading data:', error);
      });
  }

  // Handle Load click
  document.getElementById('loadDataLink').addEventListener('click', function(e) {
    e.preventDefault();
    const userEntry = parseInt(document.getElementById('entryNumber').value, 10);

    if (userEntry < 1) {
      alert('Please enter a number 1 or greater');
      return;
    }

    loadEntryByReversedNumber(userEntry);
  });

  // Handle Submit Edit
  document.getElementById('submitEditLink').addEventListener('click', function(e) {
    e.preventDefault();
    const newText = document.getElementById('textbox').value;
    const originalText = document.getElementById('originalTextbox').value;
    const params = new URLSearchParams({
      new: newText,
      original: originalText
    });
    window.location.href = 'edit.php?' + params.toString();
  });

  // Prefill entryNumber with the last entry number on page load (reversed numbering)
  window.addEventListener('DOMContentLoaded', function() {
    fetch('/other/extra/scripts/fakesocialmedia/data_alcea.json', { cache: 'no-cache' })
      .then(response => response.json())
      .then(data => {
        document.getElementById('entryNumber').value = data.length;
      })
      .catch(error => {
        console.error('Error preloading entry number:', error);
      });
  });
</script>








<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["specificButton"])) {
    $value = $_POST["textbox"];
    $user = $_GET["user"];
    $date = date("Ymd");
    $newData = array($date => array("value" => $value));
    $hashtags = array();
    preg_match_all('/#(\w+)/', $value, $matches);
    if (!empty($matches[1])) {
        $hashtags = $matches[1];
    }
    if (!empty($hashtags)) {
        $newData[$date]["hashtags"] = implode(", ", $hashtags);
    }

    $fullFilename = "data_" . $user . ".json";
    $partFilename = "data_part_" . $user . ".json";

    // Save all data to data_$user.json
    if (file_exists($fullFilename)) {
        $existingData = json_decode(file_get_contents($fullFilename), true);
    } else {
        $existingData = array();
    }
    array_unshift($existingData, $newData);
    file_put_contents($fullFilename, json_encode($existingData, JSON_PRETTY_PRINT));

    // Overwrite data_part_$user.json with the latest 60 entries
    $partialData = array($newData);
    if (file_exists($fullFilename)) {
        $fullData = json_decode(file_get_contents($fullFilename), true);
        $partialData = array_slice($fullData, 0, 60);
    }
    file_put_contents($partFilename, json_encode($partialData, JSON_PRETTY_PRINT));
}
?>
<form method="post" action="<?php echo $_SERVER["PHP_SELF"] . "?user=" . $_GET["user"]; ?>">
    <textarea id="textbox" name="textbox" rows="4" cols="50"></textarea>
    <input type="submit" name="specificButton" value="Submit" disabled>
</form>


<br>
<details><summary>Preview</summary>
<iframe id="postpreview" width="600" height="400" frameborder="0" style="border:none;"></iframe>
<script>
  document.getElementById('postpreview').src = '/other/extra/scripts/fakesocialmedia/postpreview.html?' + Date.now();
</script>
</details>
<br>

<button type="button" id="checkButton">Check</button>
<script src="/other/extra/scripts/fakesocialmedia/check.js"></script>
<script>
  document.getElementById("checkButton").addEventListener("click", function () {
    if (typeof check === "function") {
      check();
    }
  });
</script>

<!--Dupfinder-Button-->
<div class="dupfind"></div>
<script>
document.getElementById("checkButton").addEventListener("click",(function(){const t=this,e=document.querySelector(".dupfind");if(e.textContent="",t.textContent="Loading...",document.getElementById("checkJsScript"))t.textContent="Check","function"==typeof window.checkDuplicates?window.checkDuplicates({inputId:"textbox",outputSelector:".dupfind",button:t}):e.textContent="checkDuplicates() function not found";else{const c=document.createElement("script");c.id="checkJsScript",c.src="/other/extra/scripts/fakesocialmedia/check.js",c.onload=()=>{t.textContent="Check","function"==typeof window.checkDuplicates?window.checkDuplicates({inputId:"textbox",outputSelector:".dupfind",button:t}):e.textContent="check.js loaded, but checkDuplicates() not found"},c.onerror=()=>{t.textContent="Check",e.textContent="Failed to load check.js"},document.body.appendChild(c)}}));
</script>


<!----Text-Clip--handler--->
    <script> document.getElementById('writeBtn').addEventListener('click', function () {
            const text = document.getElementById('textbox').value;
            fetch('clip.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'send=' + encodeURIComponent(text)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Write failed');
                }
                console.log('Text saved successfully');
            })
            .catch(error => console.error(error));
        }); document.getElementById('readBtn').addEventListener('click', function () {
            fetch('clip.txt', { cache: 'no-cache' })
                .then(response => response.text())
                .then(data => {
                    document.getElementById('textbox').value = data;
                });
        });
    </script>
