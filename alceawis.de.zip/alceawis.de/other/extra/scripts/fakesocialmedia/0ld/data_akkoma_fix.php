<?php

// ===============================
// SET TO true TO APPLY FIX AUTOMATICALLY
// ===============================
$CONFIRM_APPLY = isset($_POST['apply_fix']) && $_POST['apply_fix'] === 'yes';

$inputFile = __DIR__ . '/data_akkoma.json';

if (!is_file($inputFile)) {
    exit("ERROR: File not found:<br>$inputFile<br>");
}

$json = file_get_contents($inputFile);
if ($json === false) {
    exit("ERROR: Failed to read file<br>");
}

// Remove BOM if present
$json = preg_replace('/^\xEF\xBB\xBF/', '', $json);

// Pattern: invalid UTF-16 surrogate (unpaired)
$pattern = '/\\\\uD[89AB][0-9A-F]{2}(?!\\\\uD[CDEF][0-9A-F]{2})/i';

echo "<br>==================== JSON CHECK ====================<br><br>";

// Check if JSON contains invalid surrogate
if (!preg_match($pattern, $json, $m, PREG_OFFSET_CAPTURE)) {
    echo "✅ JSON is valid. No UTF-16 issues found.<br><br>";
    exit;
}

// Extract match info
$match  = $m[0][0];
$offset = $m[0][1];

// Compute line number
$before = substr($json, 0, $offset);
$line   = substr_count($before, "\n") + 1;

// Extract context (120 chars around the broken sequence)
$contextRaw = substr($json, max(0, $offset - 60), 120);

// Decode JSON fragment so \n becomes real line breaks
$contextDecoded = json_decode('"' . str_replace('"', '\"', $contextRaw) . '"');
if ($contextDecoded === null) {
    $contextDecoded = $contextRaw; // fallback
}

// Replace newlines with <br> for HTML display
$contextHtml = str_replace("\n", "<br>", $contextDecoded);

// ❌ Error report
echo <<<EOT
❌ INVALID JSON FOUND<br><br>

Problem:<br>
  Unpaired UTF-16 surrogate escape detected.<br><br>

Broken sequence:<br>
  <span style="color:red;">$match</span><br><br>

Location:<br>
  Line: $line<br>
  Offset: $offset (byte position)<br><br>

Context (snippet around error):<br>
----------------------------------------------------<br>
$contextHtml<br>
----------------------------------------------------<br><br>

Why this is broken:<br>
  • UTF-16 surrogate escapes must come in pairs.<br>
  • $match is only HALF of a character.<br>
  • JSON parsers must reject this.<br><br>

Planned fix:<br>
  • Remove ONLY this invalid escape
  <form method="post" style="display:inline;">
      <input type="hidden" name="apply_fix" value="yes">
      <button type="submit">Apply Fix</button>
  </form><br>
  • Leave all other content untouched<br>
  • Reformat JSON cleanly<br><br>
EOT;

// If user pressed the button, $CONFIRM_APPLY will be true
if ($CONFIRM_APPLY) {
    // Apply fix
    $fixed = preg_replace($pattern, '', $json, 1);

    // Validate JSON after fix
    $data = json_decode($fixed, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        exit("ERROR AFTER FIX: " . json_last_error_msg() . "<br>");
    }

    // Reformat JSON
    $fixed = json_encode(
        $data,
        JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );

    // Save back to file
    file_put_contents($inputFile, $fixed);

    // ✅ Success report
    echo <<<EOT
✅ FIX APPLIED<br><br>
Removed invalid escape at line $line.<br>
JSON file has been reformatted and is now valid.<br><br>
EOT;
} else {
    echo <<<EOT
FIX NOT APPLIED ⚠️<br>
Click the button above to apply the fix.<br><br>
EOT;
}
?>
