<?php
// Check if the 'send' parameter is set via POST
if (isset($_POST['send'])) {
    $content = $_POST['send'];
}
// Check if the 'clip' query string is set via GET
elseif (isset($_GET['clip'])) {
    $content = $_GET['clip'];
} 
else {
    // No data received
    exit("No content provided.");
}

// Save the content to the clip.txt file
file_put_contents('clip.txt', $content);

// Optionally, you can send a success message
echo "Content saved to 'clip.txt'.";
exit;
?>
<?php
if (isset($_POST['send'])) {
    $content = $_POST['send'];
    file_put_contents('clip.txt', $content);
}
exit;
?>
