<?php
if (isset($_POST['send'])) {
    $content = $_POST['send'];
    file_put_contents('clip.txt', $content);
}
exit;
?>
