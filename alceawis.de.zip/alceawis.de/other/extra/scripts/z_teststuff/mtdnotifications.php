<?php
// Get the query parameters from the URL
$apiKey = $_GET['apikey'];
$userId = $_GET['userid'];
$instanceUrl = $_GET['instanceurl'];

// Create a new cURL resource
$ch = curl_init();

// Define the API endpoint URL
$apiUrl = $instanceUrl . '/api/v1/notifications';

// Set up the request
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer ' . $apiKey));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute the request
$response = curl_exec($ch);

// Check for errors
if ($response === false) {
    echo 'Request failed. Error: ' . curl_error($ch);
    curl_close($ch);
    exit;
}

// Get the HTTP status code
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Close the cURL resource
curl_close($ch);

// Process the response
if ($httpCode === 200) {
    $notifications = json_decode($response, true);

    // Display the notifications
    echo '<div id="notifications">';
    foreach ($notifications as $notification) {
        $notificationElement = createNotificationElement($notification);
        echo $notificationElement;
    }
    echo '</div>';
} else {
    echo '<div id="error">Request failed. Status: ' . $httpCode . '</div>';
    exit;
}

// Helper function to create a notification element
function createNotificationElement($notification)
{
    $notificationElement = '<div class="notification" style="border: 1px solid #ccc;padding: 10px;margin-bottom: 10px;';
    
    if ($notification['type'] === 'mention') {
        $notificationElement .= 'background-color: lightblue;">';
    } else if ($notification['type'] === 'favourite') {
        $notificationElement .= 'background-color: pink;">';
    } else {
        $notificationElement .= '">';
    }

    $accountElement = '<div class="account">' . ($notification['account']['display_name'] ?? $notification['account']['username']) . '</div>';
    $statusElement = '<div class="status">' . $notification['status']['content'] . '</div>';

    $dateElement = '<div class="date"><a href="' . $notification['status']['url'] . '" target="_blank">' . date('Y-m-d H:i:s', strtotime($notification['created_at'])) . '</a></div>';

    $notificationElement .= $accountElement . $statusElement . $dateElement . '</div>';

    return $notificationElement;
}
?>