<a target="_blank" href="plot.html" style=color:blue>Plot</a><br><br>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the input values
    $textEntry = $_POST['text_entry'];
    $rating = $_POST['rating'];
    $year = $_POST['year'];
    $month = $_POST['month'];
    $day = $_POST['day'];
    $sortIn = isset($_POST['sort_in']) && $_POST['sort_in'] === 'on';
    $date = sprintf("%04d-%02d-%02d", $year, $month, $day);
    $data = $date . ' (' . $rating . ') ' . $textEntry . "\n";
    if ($sortIn) {
        $data = "\n" . $data;
    }
    $contents = file_get_contents('events.txt');
    if ($sortIn) {
        $lines = explode("\n", $contents);
        $entries = [];
        foreach ($lines as $line) {
            if (!empty($line)) {
                $entry = [
                    'date' => substr($line, 0, 10),
                    'content' => $line
                ];
                $entries[] = $entry;
            }
        }
        $newEntry = [
            'date' => $date,
            'content' => $data
        ];
        $entries[] = $newEntry;

        // Sort the entries based on the date
        usort($entries, function ($a, $b) {
            $dateA = DateTime::createFromFormat('Y-m-d', $a['date']);
            $dateB = DateTime::createFromFormat('Y-m-d', $b['date']);
            return $dateA <=> $dateB;
        });
        $contents = '';
        foreach ($entries as $entry) {
            $contents .= $entry['content'];
        }
    } else {
        $contents = $data . $contents;
    }
    file_put_contents('events.txt', $contents);
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
} else {
    $today = getdate();
    $defaultYear = $today['year'];
    $defaultMonth = $today['mon'];
    $defaultDay = $today['mday'];
}
?>
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="year">Year:</label>
        <input type="number" id="year" name="year" value="<?php echo $defaultYear; ?>" required><br><br>
        <label for="month">Month:</label>
        <input type="number" id="month" name="month" value="<?php echo $defaultMonth; ?>" required><br><br>
        <label for="day">Day:</label>
        <input type="number" id="day" name="day" value="<?php echo $defaultDay; ?>" required><br><br>
        <label for="text_entry">Text Entry:</label>
        <input type="text" id="text_entry" name="text_entry" required><br><br>
        <label for="rating">Rating:</label>
        <select id="rating" name="rating">
            <option value="-----">-----</option>
            <option value="----">----</option>
            <option value="---">---</option>
            <option value="--">--</option>
            <option value="-">-</option>
            <option value="0">0</option>
            <option value="+">+</option>
            <option value="++">++</option>
            <option value="+++">+++</option>
            <option value="++++">++++</option>
            <option value="+++++">+++++</option>
        </select><br><br>
        <label for="sort_in">Sort In:</label>
        <input type="checkbox" id="sort_in" name="sort_in"><br><br>
        <input type="submit" value="Submit">
    </form>
