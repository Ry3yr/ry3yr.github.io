<?php
$text = $_POST['text'];
$x = $_POST['x'];
$y = $_POST['y'];
$data = array();

// Check if the file has been modified in the last 15 sec
$file_modified_time = filemtime('text_data.json');
$current_time = time();
$five_minutes_ago = $current_time - (5 * 3);

if ($file_modified_time > $five_minutes_ago) {
    echo "The text data file has been modified in the last 5 minutes. Exiting script.";
    exit;
}

if (file_exists('text_data.json')) {
    $data = json_decode(file_get_contents('text_data.json'), true);
}
$data[] = array(
    'text' => $text,
    'x' => $x,
    'y' => $y
);
file_put_contents('text_data.json', json_encode($data, JSON_PRETTY_PRINT));
echo "Text saved successfully!";
?>