console.log(WURFL);

$('.is-mobile .wurfl-data').html( 'That\'s ' + WURFL.is_mobile + ', yo' );
$('.form-factor .wurfl-data').html( WURFL.form_factor + ', yo' );
$('.device-name .wurfl-data').html( WURFL.complete_device_name + ', yo' );