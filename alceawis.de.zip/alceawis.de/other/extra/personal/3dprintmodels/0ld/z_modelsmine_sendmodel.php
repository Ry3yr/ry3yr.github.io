<?php
// Get values from query string or set default values
$name = $_GET['name'] ?? '';
$url = $_GET['url'] ?? '';
$downloadLink = $_GET['downloadlink'] ?? $url; // Defaults to URL if empty
$imgLink = $_GET['imglink'] ?? 'https://commons.wikimedia.org/wiki/File:3D_printer.svg';           // Defaults to "-"
$time2Print = $_GET['time2print'] ?? '-';     // Defaults to "-"
$maxDimension = $_GET['maxdimension'] ?? '-'; // Defaults to "-"
$support = $_GET['support'] ?? 'no';         // Defaults to "no"
$date = $_GET['date'] ?? date('Y-m-d H:i:s'); // Use current date if not provided

// Ensure empty string values default as well
$downloadLink = empty($downloadLink) ? $url : $downloadLink;
$imgLink = empty($imgLink) ? '-' : $imgLink;
$time2Print = empty($time2Print) ? '-' : $time2Print;
$maxDimension = empty($maxDimension) ? '-' : $maxDimension;
$support = empty($support) ? 'no' : $support;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $url = $_POST['url'] ?? '';
    $downloadLink = $_POST['downloadlink'] ?? $url;
    $imgLink = $_POST['imglink'] ?? 'https://commons.wikimedia.org/wiki/File:3D_printer.svg';
    $time2Print = $_POST['time2print'] ?? '-';
    $maxDimension = $_POST['maxdimension'] ?? '-';
    $support = $_POST['support'] ?? 'no';

    // Validate required fields
    if (empty($name) || empty($url)) {
        echo "Name and URL are required.";
        exit;
    }

    // Create the data array
    $newData = [
        'name' => $name,
        'url' => $url,
        'downloadlink' => $downloadLink,
        'imglink' => $imgLink,
        'time2print' => $time2Print,
        'maxdimension' => $maxDimension,
        'support' => $support,
        'date' => $date,
    ];

    // Path to the JSON file
    $filePath = 'z_modelmine.json';

    // Read the existing data
    $data = [];
    if (file_exists($filePath)) {
        $jsonContent = file_get_contents($filePath);
        $data = json_decode($jsonContent, true) ?? [];
    }

    // Prepend the new data
    array_unshift($data, $newData);

    // Save back to the JSON file
    file_put_contents($filePath, json_encode($data, JSON_PRETTY_PRINT));

    echo "Data saved successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Model</title>
</head>
<body>
    <h1>Add Model</h1>
    <form method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($name) ?>" required><br><br>

        <label for="url">URL:</label>
        <input type="url" id="url" name="url" value="<?= htmlspecialchars($url) ?>" required><br><br>

        <label for="downloadlink">Download Link:</label>
        <input type="url" id="downloadlink" name="downloadlink" value="<?= htmlspecialchars($downloadLink) ?>"><br><br>

        <label for="imglink">Image Link:</label>
        <input type="url" id="imglink" name="imglink" value="<?= htmlspecialchars($imgLink) ?>"><br><br>

        <label for="time2print">Time to Print:</label>
        <input type="text" id="time2print" name="time2print" value="<?= htmlspecialchars($time2Print) ?>"><br><br>

        <label for="maxdimension">Max Dimension:</label>
        <input type="text" id="maxdimension" name="maxdimension" value="<?= htmlspecialchars($maxDimension) ?>"><br><br>

        <label for="support">Support:</label>
        <input type="text" id="support" name="support" value="<?= htmlspecialchars($support) ?>"><br><br>

        <input type="hidden" name="date" value="<?= htmlspecialchars($date) ?>">

        <button type="submit">Save</button>
    </form>
</body>
</html>
