<?php
if (isset($_GET['url'])) {
    $inputUrl = filter_var($_GET['url'], FILTER_SANITIZE_URL);

    // Validate the URL
    if (filter_var($inputUrl, FILTER_VALIDATE_URL)) {
        // Fetch the HTML content
        $htmlContent = file_get_contents($inputUrl);

        if ($htmlContent !== false) {
            // Load HTML into DOMDocument
            libxml_use_internal_errors(true);
            $dom = new DOMDocument();
            $dom->loadHTML($htmlContent);
            libxml_clear_errors();

            // Extract the title
            $title = '';
            $titleTags = $dom->getElementsByTagName('title');
            if ($titleTags->length > 0) {
                $title = $titleTags->item(0)->nodeValue;
            }

            // Extract images and find the largest one
            $largestImage = '';
            $largestImageSize = 0;
            $images = $dom->getElementsByTagName('img');

            foreach ($images as $img) {
                $src = $img->getAttribute('src');
                if (!empty($src)) {
                    $absoluteUrl = filter_var($src, FILTER_VALIDATE_URL) ? $src : rtrim($inputUrl, '/') . '/' . ltrim($src, '/');
                    $imageSize = getimagesize($absoluteUrl);

                    if ($imageSize && ($imageSize[0] * $imageSize[1] > $largestImageSize)) {
                        $largestImageSize = $imageSize[0] * $imageSize[1];
                        $largestImage = $absoluteUrl;
                    }
                }
            }

            // Encode data for relaying
            $relayTitle = urlencode($title);
            $relayUrl = urlencode($inputUrl);
            $relayImgLink = urlencode($largestImage);

            // Display the results
            echo "<h1>Page Details</h1>";
            echo "<p><strong>Page Title:</strong> " . htmlspecialchars($title) . "</p>";
            echo "<p><strong>Page URL:</strong> " . htmlspecialchars($inputUrl) . "</p>";
            if ($largestImage) {
                echo "<p><strong>Largest Image:</strong></p>";
                echo "<img src='" . htmlspecialchars($largestImage) . "' alt='Largest Image' style='max-width:100%; height:auto;'><br>";
                echo "<a href='" . htmlspecialchars($largestImage) . "' target='_blank'>" . htmlspecialchars($largestImage) . "</a>";
            } else {
                echo "<p><strong>Largest Image:</strong> Not found</p>";
            }

            // Add a button to relay the data
            echo "<form method='get' action='https://alcea-wisteria.de/PHP//0demo/2025-01-12-3DModels/sendmodel.php' style='margin-top:20px;'>";
            echo "<input type='hidden' name='name' value='" . htmlspecialchars($title) . "'>";
            echo "<input type='hidden' name='url' value='" . htmlspecialchars($inputUrl) . "'>";
            echo "<input type='hidden' name='imglink' value='" . htmlspecialchars($largestImage) . "'>";
            echo "<button type='submit'>Send Data</button>";
            echo "</form>";
        } else {
            echo "<p>Error: Could not fetch the HTML content of the URL.</p>";
        }
    } else {
        echo "<p>Error: Invalid URL provided.</p>";
    }
} else {
    echo "<p>Error: No URL provided. Use the format ?url=yourwebsite.com</p>";
}
?>
