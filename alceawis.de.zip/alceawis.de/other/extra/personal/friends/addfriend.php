<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the values from the text boxes
    $text1 = isset($_POST['text1']) ? $_POST['text1'] : '';
    $text2 = isset($_POST['text2']) ? $_POST['text2'] : '';
    $text3 = isset($_POST['text3']) ? $_POST['text3'] : '';
    $text4 = isset($_POST['text4']) ? $_POST['text4'] : '';
    $html = '<a target="_blank" href="' . $text1 . '"><img src="' . $text2 . '" style="width:45px;"></img></a><span class="smart-hover" title="' . $text3 . '">  <u>' . $text4 . '</u></span><style>.smart-hover:hover::after{content:attr(title);}</style><br>';
    $friendHtmlFile = 'friends.html';
    file_put_contents($friendHtmlFile, $html, FILE_APPEND);
    // Output a success message
    echo "HTML code has been appended to your friend's HTML file!";
}
?>
<html>
<head>
    <title>Friends from the future</title>
</head>
<body>
    <form method="POST" action="">
        <input type="text" name="text1" placeholder="url"><br>
        <input type="text" name="text2" placeholder="pfp img url"><br>
        <input type="text" name="text3" placeholder="description"><br>
        <input type="text" name="text4" placeholder="name"><br>
        <input type="submit" value="Submit">
    </form>
</body>

<a href="/favs.html" style=color:red>Lookin good today !</a><br><br>

<iframe src="/other/extra/personal/friends/friends.html" style="border:0px #ffffff none;" name="statusit" scrolling="no" frameborder="0" marginheight="0px" marginwidth="0px" height=100% width="500" allowfullscreen></iframe>
