<a target="_blank" href="?source" style=color:pink>Source Code</a><hr>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the values from the text boxes
    $text0 = isset($_POST['text0']) ? $_POST['text0'] : '';
    $text1 = isset($_POST['text1']) ? $_POST['text1'] : '';
    $text2 = isset($_POST['text2']) ? $_POST['text2'] : '';
    $text3 = isset($_POST['text3']) ? $_POST['text3'] : '';
    $text4 = isset($_POST['text4']) ? $_POST['text4'] : '';
    // Check if any of the text fields contain '<' or '>'
    if (strpos($text0, '<') !== false || strpos($text0, '>') !== false ||
        strpos($text1, '<') !== false || strpos($text1, '>') !== false ||
        strpos($text2, '<') !== false || strpos($text2, '>') !== false ||
        strpos($text3, '<') !== false || strpos($text3, '>') !== false ||
        strpos($text4, '<') !== false || strpos($text4, '>') !== false) {
        echo "Invalid input in one or more text fields. Please remove '<' or '>' characters.";
    } else {
        $html = $text0 . ' - <a target="_blank" href="' . $text1 . '"><img src="' . $text2 . '" style="width:45px;"></a><span class="smart-hover" title="' . $text3 . '"><u>' . $text4 . '</u></span><style>.smart-hover:hover::after{content:attr(title);}</style><br>' . PHP_EOL;
        $friendHtmlFile = 'friends.html';
        $existingContent = file_get_contents($friendHtmlFile);
        $newContent = $html . $existingContent;
        file_put_contents($friendHtmlFile, $newContent);
        echo "HTML code has been prepended with $text4's entry!";
    }
}
$currentDate = date("Y-m-d");
?>

<html>
<head>
    <title>Friends from the future</title>
</head>
<body>
    <form method="POST" action="">
        <input type="text" name="text0" placeholder="date" value="<?php echo $currentDate; ?>"><br>
        <input type="text" name="text1" placeholder="url"><br>
        <input type="text" name="text2" placeholder="pfp img url"><br>
        <input type="text" name="text3" placeholder="description"><br>
        <input type="text" name="text4" placeholder="name"><br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
<a href="/favs.html" style=color:red>Lookin good today !</a><br><br>
<!--<iframe src="/other/extra/personal/friends/friends.html" style="border:0px #ffffff none;" name="statusit" scrolling="no" frameborder="0" marginheight="0px" marginwidth="0px" height=100% width="800" allowfullscreen></iframe>-->
<iframe src="<?php echo '/other/extra/personal/friends/friends.html?v=' . uniqid(); ?>" style="border:0px #ffffff none;" name="statusit" scrolling="no" frameborder="0" marginheight="0px" marginwidth="0px" height=100% width="800" allowfullscreen></iframe>

<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>

