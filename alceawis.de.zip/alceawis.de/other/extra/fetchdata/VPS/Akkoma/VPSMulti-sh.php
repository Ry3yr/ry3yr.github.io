<button type="button" onclick="fillScriptPath('/root/reboot_akkoma.sh')">Load Akkoma Script</button>
<button type="button" onclick="fillScriptPath('/root/reboot_nginx.sh')">Load Nginx Script</button>
<script>
function fillScriptPath(path) {
  document.getElementById('remoteScriptPath').value = path;
}
</script>



<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$remoteServer = "root@194.164.200.5";
$defaultRemoteScriptPath = "/root/letsencryptchron.sh";

$scriptDir = dirname(__FILE__);
$uploadedKey = $scriptDir . "/uploaded_key";
$formSubmitted = false;

$remoteScriptPath = isset($_POST['remoteScriptPath']) ? $_POST['remoteScriptPath'] : $defaultRemoteScriptPath;

// Create safe log filename from remote script path
$logFileBase = str_replace('/', '_', $remoteScriptPath);
if (substr($logFileBase, -3) === '.sh') {
    $logFileBase = substr($logFileBase, 0, -3); // Remove .sh extension
}
$logFile = "/tmp/" . $logFileBase . ".log";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['ppkFile'])) {
    if ($_FILES['ppkFile']['error'] === UPLOAD_ERR_OK) {
        if (move_uploaded_file($_FILES['ppkFile']['tmp_name'], $uploadedKey)) {
            echo "File uploaded!<br>";
            $formSubmitted = true;
        } else {
            echo "Failed to move the uploaded file.<br>";
            exit(1);
        }
    } else {
        echo "Upload error code: " . $_FILES['ppkFile']['error'] . "<br>";
        exit(1);
    }
}

if ($formSubmitted && file_exists($uploadedKey)) {
    chmod($uploadedKey, 0600);

    // Escape the remote script path safely for bash on remote (no extra quotes)
    $escapedRemoteScriptPath = escapeshellcmd($remoteScriptPath);

    // Compose SSH command
    $sshCommand = "ssh -i " . escapeshellarg($uploadedKey) .
                  " -o StrictHostKeyChecking=no " . escapeshellarg($remoteServer) .
                  " 'bash " . $escapedRemoteScriptPath . " > $logFile 2>&1'";

    exec($sshCommand, $output, $returnVar);

    echo $returnVar === 0 ? "Remote script executed successfully.<br>" : "Remote script failed to execute.<br>";

    // Get the log output from remote
    $logContents = shell_exec("ssh -i " . escapeshellarg($uploadedKey) .
                             " -o StrictHostKeyChecking=no " . escapeshellarg($remoteServer) .
                             " 'cat $logFile'");

    echo $logContents ? "<pre>" . htmlspecialchars($logContents) . "</pre>" : "No log output.<br>";

    // Cleanup
    if (file_exists($uploadedKey)) {
        unlink($uploadedKey);
        echo "File deleted!<br>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Upload Key and Run</title>
</head>
<body>
<h2>Upload OpenSSH Private Key</h2>
<form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" enctype="multipart/form-data">
    <label for="ppkFile">Choose your private key:</label>
    <input type="file" name="ppkFile" id="ppkFile" required><br><br>

    <label for="remoteScriptPath">Remote script path:</label>
    <input type="text" name="remoteScriptPath" id="remoteScriptPath" value="<?php echo htmlspecialchars($remoteScriptPath); ?>" style="width: 400px;" required><br><br>

    <button type="submit">Upload & Run</button>
</form>
</body>
</html>
