<?php
session_set_cookie_params(['secure' => true,'httponly' => true,'samesite' => 'Strict']);
session_start();
$session_lifetime = 3 * 60; // Session timeout
$correct_username = "admin";
$correct_password_hash = '$2y$10$S9naYnE6MqP14zVRfIsig.A98jBGzEImaGLgKVuiSGKpI7yr7XeGG'; // password: 4869
//echo password_hash("pass", PASSWORD_DEFAULT); //generate
if (isset($_GET['logout'])) {
session_unset();
session_destroy();
header("Location: " . $_SERVER['PHP_SELF']);
exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['heartbeat'])) {
$_SESSION['last_activity'] = time();
exit;
}
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
if ($username === $correct_username && password_verify($password, $correct_password_hash)) {
session_regenerate_id(true);
$_SESSION['logged_in'] = true;
$_SESSION['last_activity'] = time();
header("Location: " . $_SERVER['PHP_SELF']);
exit;
} else {
$error = "Invalid username or password.";
}
}
?>
<?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
<form method="post">
<label>Username: <input name="username" required></label><br>
<label>Password: <input type="password" name="password" required></label><br>
<button type="submit">Login</button>
</form>
<?php
exit;
}
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $session_lifetime) {
session_unset();
session_destroy();
header("Location: " . $_SERVER['PHP_SELF']);
exit;
}
$_SESSION['last_activity'] = time(); // Refresh session activity
$remaining_time = ($_SESSION['last_activity'] + $session_lifetime) - time();
?>
Welcome, you are logged in! <span id="countdown"></span><hr>
<a href="?logout=1">Logout</a>
<script>
let remaining = <?php echo $remaining_time; ?>;
function updateCountdown() {
if (remaining <= 0) {
clearInterval(timer);
alert("Session expired due to inactivity.");
location.reload();
return;
}
const minutes = Math.floor(remaining / 60);
const seconds = remaining % 60;
document.getElementById('countdown').textContent =
minutes + "m " + (seconds < 10 ? "0" : "") + seconds + "s";
remaining--;
}
updateCountdown();
const timer = setInterval(updateCountdown, 1000);
setInterval(() => {
fetch("", {
method: "POST",
headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
body: "heartbeat=1"
});
}, 30000);
</script>









<button type="button" onclick="fillScriptPath('/root/letsencryptcheck.sh')">Check LetsEncryptStatus</button>
<hr>
<button type="button" onclick="fillScriptPath('/root/reboot_akkoma.sh')">Load Akkoma Script</button>
<button type="button" onclick="fillScriptPath('/root/reboot_nginx.sh')">Load Nginx Script</button>
<button type="button" onclick="fillScriptPath('/root/find.sh')">Find File</button>
<script>
function fillScriptPath(path) {
  document.getElementById('remoteScriptPath').value = path;
}
</script>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$remoteServer = "root@194.164.200.5";
$defaultRemoteScriptPath = "/root/letsencryptchron.sh";

$scriptDir = dirname(__FILE__);
$uploadedKey = $scriptDir . "/uploaded_key";
$formSubmitted = false;

$remoteScriptPath = isset($_POST['remoteScriptPath']) ? $_POST['remoteScriptPath'] : $defaultRemoteScriptPath;

// Create safe log filename from remote script path
$logFileBase = str_replace('/', '_', $remoteScriptPath);
if (substr($logFileBase, -3) === '.sh') {
    $logFileBase = substr($logFileBase, 0, -3); // Remove .sh extension
}
$logFile = "/tmp/" . $logFileBase . ".log";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['ppkFile'])) {
    if ($_FILES['ppkFile']['error'] === UPLOAD_ERR_OK) {
        if (move_uploaded_file($_FILES['ppkFile']['tmp_name'], $uploadedKey)) {
            echo "File uploaded!<br>";
            $formSubmitted = true;
        } else {
            echo "Failed to move the uploaded file.<br>";
            exit(1);
        }
    } else {
        echo "Upload error code: " . $_FILES['ppkFile']['error'] . "<br>";
        exit(1);
    }
}

if ($formSubmitted && file_exists($uploadedKey)) {
    chmod($uploadedKey, 0600);

    // Escape the remote script path safely for bash on remote (no extra quotes)
    $escapedRemoteScriptPath = escapeshellcmd($remoteScriptPath);

    // Compose SSH command
    $sshCommand = "ssh -i " . escapeshellarg($uploadedKey) .
                  " -o StrictHostKeyChecking=no " . escapeshellarg($remoteServer) .
                  " 'bash " . $escapedRemoteScriptPath . " > $logFile 2>&1'";

    exec($sshCommand, $output, $returnVar);

    echo $returnVar === 0 ? "Remote script executed successfully.<br>" : "Remote script failed to execute.<br>";

    // Get the log output from remote
    $logContents = shell_exec("ssh -i " . escapeshellarg($uploadedKey) .
                             " -o StrictHostKeyChecking=no " . escapeshellarg($remoteServer) .
                             " 'cat $logFile'");

    echo $logContents ? "<pre>" . htmlspecialchars($logContents) . "</pre>" : "No log output.<br>";

    // Cleanup
    if (file_exists($uploadedKey)) {
        unlink($uploadedKey);
        echo "File deleted!<br>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Upload Key and Run</title>
</head>
<body>
<h2>Upload OpenSSH Private Key</h2>
<form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" enctype="multipart/form-data">
    <label for="ppkFile">Choose your private key:</label>
    <input type="file" name="ppkFile" id="ppkFile" required><br><br>

    <label for="remoteScriptPath">Remote script path:</label>
    <input type="text" name="remoteScriptPath" id="remoteScriptPath" value="<?php echo htmlspecialchars($remoteScriptPath); ?>" style="width: 400px;" required><br><br>

    <button type="submit">Upload & Run</button>
</form>
</body>
</html>
