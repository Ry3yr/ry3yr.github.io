<?php
function getPixivUserArt($userId, $random) {
    $apiUrl = "https://www.pixiv.net/ajax/user/{$userId}/profile/all?useid={$userId}";
    $options = array(
        'http' => array(
            'method' => 'GET',
            'header' => 'Referer: https://www.pixiv.net/'
        ),
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false
        )
    );
    $context = stream_context_create($options);
    $response = file_get_contents($apiUrl, false, $context);
    $data = json_decode($response, true);
    if (isset($data['body']['illusts'])) {
        $artworks = $data['body']['illusts'];
        $numLinks = 0; // Variable to keep track of the number of links
        $pixivLinks = [];
        if ($random) {
            // Get a random artwork
            $randomArtId = array_rand($artworks);
            $randomArt = $artworks[$randomArtId];
            $artLink = "https://www.pixiv.net/artworks/{$randomArtId}";
            $pixivLinks[] = $artLink;
            echo "<a target=_blank href=\"{$artLink}\"> </a><br>\n";
            $numLinks++; // Increment the link counter
            if ($numLinks >= 4) {
                return $pixivLinks; // Return the links to be processed
            }
        } else {
            foreach ($artworks as $artId => $art) {
                $artLink = "https://www.pixiv.net/artworks/{$artId}";
                $pixivLinks[] = $artLink;
                echo "<a target=_blank href=\"{$artLink}\"> </a> <a target=_blank href=\"https://alcea-wisteria.de/PHP/0demo/2024-03-14-PixivTools/2023-03-14-pixiv-single-img-fetch/pixv-single-img-fetch.php?pixivurl={$artLink}\" id=dld> </a><div class=\"counts\"></div>\n";
                $numLinks++; // Increment the link counter
                if ($numLinks >= 4) {
                    return $pixivLinks; // Return the links to be processed
                }
            }
        }
    } else {
        echo "No artworks found for the given user.";
    }
    return []; // Return an empty array if no links were found
}

function getPageTitle($html) {
    $titleStart = stripos($html, '<title>');
    $titleEnd = stripos($html, '</title>');
    if ($titleStart !== false && $titleEnd !== false) {
        $titleLength = $titleEnd - $titleStart - 7;
        return substr($html, $titleStart + 7, $titleLength);
    }
    return '';
}

function processPixivLinks($pixivLinks) {
    echo "<br>";
    foreach ($pixivLinks as $index => $link) {
        $html = file_get_contents($link);
        $title = getPageTitle($html);
        $bookmarkStart = strpos($html, '"bookmarkCount":');
        if ($bookmarkStart !== false) {
            $bookmarkEnd = strpos($html, ',', $bookmarkStart);
            if ($bookmarkEnd !== false) {
                $bookmarkCount = substr($html, $bookmarkStart + 16, $bookmarkEnd - $bookmarkStart - 16);
            }
        }
        $likeStart = strpos($html, '"likeCount":');
        if ($likeStart !== false) {
            $likeEnd = strpos($html, ',', $likeStart);
            if ($likeEnd !== false) {
                $likeCount = substr($html, $likeStart + 12, $likeEnd - $likeStart - 12);
            }
        }
        $commentStart = strpos($html, '"commentCount":');
        if ($commentStart !== false) {
            $commentEnd = strpos($html, ',', $commentStart);
            if ($commentEnd !== false) {
                $commentCount = substr($html, $commentStart + 15, $commentEnd - $commentStart - 15);
            }
        }
        $counts = "Bookmark Count: {$bookmarkCount}, Like Count: {$likeCount}, Comment Count: {$commentCount}";
        echo "<div><a target='_blank' href='{$link}'>{$title}</a> <a target='_blank' href='https://alcea-wisteria.de/PHP/0demo/2024-03-14-PixivTools/2023-03-14-pixiv-single-img-fetch/pixv-single-img-fetch.php?pixivurl={$link}' id='dld'>»</a><div class='counts'>{$counts}</div></div>\n";
    }
    echo "<script>document.getElementById('linkCount').innerHTML = 'Number of artworks: " . count($pixivLinks) . "';</script>";
}

$userId = isset($_GET['userId']) ? $_GET['userId'] : '75406576';
$random = isset($_GET['random']);
$pixivLinks = getPixivUserArt($userId, $random);
processPixivLinks($pixivLinks);