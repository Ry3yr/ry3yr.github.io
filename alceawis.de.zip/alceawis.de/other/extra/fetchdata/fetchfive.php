<script>
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('a[href^="https://pixiv.perennialte.ch"]').forEach(link => {
    link.href = link.href.replace("https://pixiv.perennialte.ch", "https://pixiv.net");
  });
});
</script>


<?php
echo '<a href="?userId=115969453" style="color:blue">Cea</a> ';
echo '<a target="_blank" href="?userId=75406576" style="color:blue">Alcea</a>';
echo ' <a target="_blank" href="https://pixivfe-docs.pages.dev/instance-list/#clearnet" style=color:gray>PixivFE instances</a><hr>';
function getPixivUserArt($userId, $random, $maxLinks = 4) {
    // Adjust API URL if userId query param exists
    $queryUserId = $_GET['userId'] ?? null;
    if ($queryUserId) {
        $apiUrl = "https://www.pixiv.net/ajax/user/{$queryUserId}/profile/all?useid={$queryUserId}";
    } else {
        $apiUrl = "https://www.pixiv.net/ajax/user/{$userId}/profile/all?useid={$userId}";
    }

    $options = [
        'http' => [
            'method' => 'GET',
            'header' => 'Referer: https://www.pixiv.net/'
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false
        ]
    ];
    $context = stream_context_create($options);
    $response = @file_get_contents($apiUrl, false, $context);
    if (!$response) {
        echo "Failed to fetch user data.";
        return [];
    }

    $data = json_decode($response, true);
    if (isset($data['body']['illusts'])) {
        $artworks = $data['body']['illusts'];
        $pixivLinks = [];

        if ($random) {
            $randomArtId = array_rand($artworks);
            $pixivLinks[] = "https://www.pixiv.net/en/artworks/{$randomArtId}";
        } else {
            foreach (array_keys($artworks) as $artId) {
                $pixivLinks[] = "https://www.pixiv.net/en/artworks/{$artId}";
                if (count($pixivLinks) >= $maxLinks) break;
            }
        }
        return $pixivLinks;
    }

    echo "No artworks found for the given user.";
    return [];
}
$userId = $_GET['userId'] ?? '75406576';
$random = isset($_GET['random']);
$maxLinks = isset($_GET['max']) ? (int)$_GET['max'] : 4;
$pixivLinks = getPixivUserArt($userId, $random, $maxLinks);
foreach ($pixivLinks as $link) {
    $encodedUrl = urlencode($link);
    $singlefetchUrl = "https://alcea-wisteria.de/PHP//0demo/2024-03-14-PixivTools/2024-03-15-PixivFindLikesBookmarks/2025-05-25-PixivFE-approach/singlefetch.php?url=$encodedUrl";
    $context = stream_context_create([
        'http' => ['timeout' => 10]
    ]);
    $output = @file_get_contents($singlefetchUrl, false, $context);
    if ($output === false) {
        echo "<div>Failed to load: <a target='_blank' href='" . htmlspecialchars($link) . "'>" . htmlspecialchars($link) . "</a></div><br>";
    } else {
        echo $output . "<br>";
    }
}
?>
