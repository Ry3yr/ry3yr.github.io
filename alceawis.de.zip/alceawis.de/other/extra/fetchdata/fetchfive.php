<a href="?userId=115969453" style=color:blue>Cea</a> <a target="_blank" href="?userId=75406576" style=color:blue>Alcea</a><hr>

<?php
function getPixivUserArt($userId, $random, $maxLinks = 4) {
    $apiUrl = "https://www.pixiv.net/ajax/user/{$userId}/profile/all?useid={$userId}";
    $options = [
        'http' => [
            'method' => 'GET',
            'header' => 'Referer: https://www.pixiv.net/'
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false
        ]
    ];
    $context = stream_context_create($options);
    $response = @file_get_contents($apiUrl, false, $context);
    if (!$response) {
        echo "Failed to fetch user data.";
        return [];
    }

    $data = json_decode($response, true);
    if (isset($data['body']['illusts'])) {
        $artworks = $data['body']['illusts'];
        $pixivLinks = [];

        if ($random) {
            $randomArtId = array_rand($artworks);
            $pixivLinks[] = "https://www.pixiv.net/artworks/{$randomArtId}";
        } else {
            foreach (array_keys($artworks) as $artId) {
                $pixivLinks[] = "https://www.pixiv.net/artworks/{$artId}";
                if (count($pixivLinks) >= $maxLinks) break;
            }
        }
        return $pixivLinks;
    }

    echo "No artworks found for the given user.";
    return [];
}

function getPageTitle($html) {
    if (preg_match('/<title>(.*?)<\/title>/is', $html, $matches)) {
        return trim($matches[1]);
    }
    return '';
}

function processPixivLinks($pixivLinks) {
    echo "<br>";
    foreach ($pixivLinks as $link) {
        $html = @file_get_contents($link);
        if (!$html) {
            echo "<div><a target='_blank' href='{$link}'>Failed to load</a></div>";
            continue;
        }

        $title = getPageTitle($html);
        $bookmarkCount = $likeCount = $commentCount = 'N/A';

        if (preg_match('/"bookmarkCount":(\d+)/', $html, $bm)) {
            $bookmarkCount = $bm[1];
        }
        if (preg_match('/"likeCount":(\d+)/', $html, $lk)) {
            $likeCount = $lk[1];
        }
        if (preg_match('/"commentCount":(\d+)/', $html, $cm)) {
            $commentCount = $cm[1];
        }

        $counts = "Bookmarks: {$bookmarkCount}, Likes: {$likeCount}, Comments: {$commentCount}";
        echo "<div>
                <a target='_blank' href='{$link}'>{$title}</a> 
                <a target='_blank' href='https://alcea-wisteria.de/PHP/0demo/2024-03-14-PixivTools/2023-03-14-pixiv-single-img-fetch/pixv-single-img-fetch.php?pixivurl={$link}' id='dld'>[>>]</a>
                <div class='counts'>{$counts}</div>
              </div>\n";
    }
    echo "<script>document.getElementById('linkCount').innerHTML = 'Number of artworks: " . count($pixivLinks) . "';</script>";
}

// Input handling
$userId = $_GET['userId'] ?? '75406576';
$random = isset($_GET['random']);
$maxLinks = isset($_GET['max']) ? (int)$_GET['max'] : 4;

$pixivLinks = getPixivUserArt($userId, $random, $maxLinks);
processPixivLinks($pixivLinks);
?>
