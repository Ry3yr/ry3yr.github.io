<?php
$url = 'https://poipiku.com/11331041/';
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3');
$htmlContent = curl_exec($ch);
curl_close($ch);
if (!$htmlContent) {
    die('Error fetching the page content.');
}
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($htmlContent);
libxml_clear_errors();
$xpath = new DOMXPath($dom);
foreach ($xpath->query('//h2') as $h2) {
    $h2->parentNode->removeChild($h2);
}
$sectionNode = $xpath->query('//section[@id="IllustThumbList"]')->item(0);
if ($sectionNode === NULL) {
    die('The specified section was not found in the page.');
}
$baseUrl = 'https://poipiku.com';
$imageCount = 0;
$maxImages = 4;
$nodesToRemove = [];
foreach ($sectionNode->getElementsByTagName('a') as $a) {
    if ($imageCount >= $maxImages) {
        $nodesToRemove[] = $a;
        continue;
    }

    $href = $a->getAttribute('href');
    if (strpos($href, 'http') === false) {
        $a->setAttribute('href', $baseUrl . $href);
    }
    $a->setAttribute('target', '_blank');
    $style = $a->getAttribute('style');
    if (preg_match("/url\('\/\/(.*?)'\)/", $style, $matches)) {
        $relativeImageUrl = $matches[1];
        $absoluteImageUrl = 'https://' . $relativeImageUrl;
        $brTag = $dom->createElement('br');
        $imgTag = $dom->createElement('img');
        $imgTag->setAttribute('src', $absoluteImageUrl);
        $imgTag->setAttribute('alt', 'Thumbnail');
        $hrTag = $dom->createElement('hr');
        $fragment = $dom->createDocumentFragment();
        $fragment->appendChild($brTag);
        $fragment->appendChild($imgTag);
        $fragment->appendChild($hrTag);
        $a->parentNode->insertBefore($fragment, $a);
        $imageCount++;
    }
}
foreach ($nodesToRemove as $node) {
    $node->parentNode->removeChild($node);
}
$extractedHtml = $dom->saveHTML($sectionNode);
if ($imageCount > 0) {
    echo $extractedHtml;
}
?>
