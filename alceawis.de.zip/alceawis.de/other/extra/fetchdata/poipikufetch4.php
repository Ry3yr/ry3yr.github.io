<?php
function getTitle($url) {
    $html = @file_get_contents($url);
    if ($html === false) return 'No Title (Failed to load)';

    libxml_use_internal_errors(true);
    $doc = new DOMDocument();
    $doc->loadHTML($html);
    libxml_clear_errors();

    $titles = $doc->getElementsByTagName('title');
    if ($titles->length === 0) return 'No Title';

    $fullTitle = $titles->item(0)->textContent;

    // Remove the suffix after " - alcea's Poipiku..."
    $cleanTitle = preg_replace('/\s*-\s*alcea.*$/', '', $fullTitle);
    return trim($cleanTitle);
}

$url = 'https://poipiku.com/11331041';
$html = file_get_contents($url);

libxml_use_internal_errors(true);
$doc = new DOMDocument();
$doc->loadHTML($html);
libxml_clear_errors();

$xpath = new DOMXPath($doc);
$links = $xpath->query('//a[@href]');
$foundUrls = [];

foreach ($links as $link) {
    $href = $link->getAttribute('href');
    if (preg_match('#^/11331041/\d+\.html$#', $href)) {
        $fullUrl = 'https://poipiku.com' . $href;
        if (!in_array($fullUrl, $foundUrls)) {
            $foundUrls[] = $fullUrl;
            if (count($foundUrls) >= 3) break; // limit to 3 links
        }
    }
}

// Output HTML with iframe for each link
foreach ($foundUrls as $pageUrl) {
    // Get the title of the page
    $title = htmlspecialchars(getTitle($pageUrl), ENT_QUOTES, 'UTF-8');

    // Display iframe with PoipikuGetImage.php and link
    echo "<iframe src=\"PoipikuGetImage.php?url=" . urlencode($pageUrl) . "\" width=\"400\" height=\"400\" frameborder=\"0\"></iframe><br>\n";
    echo "<a href=\"$pageUrl\" target=\"_blank\">$title</a><br>\n";
}
?>
