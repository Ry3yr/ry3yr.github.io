<?php
$url = 'https://poipiku.com/11331041/';
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
);
$htmlContent = curl_exec($ch);
curl_close($ch);

if (!$htmlContent) {
    die('Error fetching the page content.');
}

$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($htmlContent);
libxml_clear_errors();
$xpath = new DOMXPath($dom);

// Remove all <h2> elements
foreach ($xpath->query('//h2') as $h2) {
    $h2->parentNode->removeChild($h2);
}

$sectionNode = $xpath->query('//section[@id="IllustThumbList"]')->item(0);
if ($sectionNode === NULL) {
    die('The specified section was not found in the page.');
}

$baseUrl = 'https://poipiku.com';
$imageCount = 0;
$maxImages = 4;
$nodesToRemove = [];

foreach ($sectionNode->getElementsByTagName('a') as $a) {
    if ($imageCount >= $maxImages) {
        $nodesToRemove[] = $a;
        continue;
    }

    $href = $a->getAttribute('href');
    if (strpos($href, 'http') === false) {
        $href = $baseUrl . $href;
    }
    $a->setAttribute('href', $href);
    $a->setAttribute('target', '_blank');
    $style = $a->getAttribute('style');

    if (preg_match("/url\('\/\/(.*?)'\)/", $style, $matches)) {
        $relativeImageUrl = $matches[1];
        $absoluteImageUrl = 'https://' . $relativeImageUrl;
        
        //$highResImageUrl = str_replace("_360.jpg", "_640.jpg", $absoluteImageUrl);
        $highResImageUrl = str_replace("_360.jpg", "", $absoluteImageUrl);

        // Create <br> before the image
        $brBefore = $dom->createElement('br');

        // Create <img> element with original resolution
        $imgTag = $dom->createElement('img');
        $imgTag->setAttribute('src', $absoluteImageUrl);
        $imgTag->setAttribute('alt', 'Thumbnail');

        // Clear anchor contents and append image inside it
        while ($a->firstChild) {
            $a->removeChild($a->firstChild);
        }
        $a->appendChild($brBefore);
        $a->appendChild($imgTag);

        // Add direct link to high-resolution image below the thumbnail
        $brAfter = $dom->createElement('br');
        $imageLink = $dom->createElement('a', '» View Full Image');
        $imageLink->setAttribute('href', $highResImageUrl);
        $imageLink->setAttribute('target', '_blank');
        $imageLink->setAttribute('style', 'display:block; margin-top:5px; font-size:14px; text-decoration:none; color:blue;');

        // Add <hr> after the "View Full Image" link
        $hrTag = $dom->createElement('hr');

        $a->parentNode->appendChild($brAfter);
        $a->parentNode->appendChild($imageLink);
        $a->parentNode->appendChild($hrTag);

        $imageCount++;
    }
}

foreach ($nodesToRemove as $node) {
    $node->parentNode->removeChild($node);
}

$extractedHtml = $dom->saveHTML($sectionNode);
if ($imageCount > 0) {
    echo $extractedHtml;
}
?>
