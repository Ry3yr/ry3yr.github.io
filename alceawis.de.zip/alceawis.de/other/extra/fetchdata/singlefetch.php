<?php

// Default URL base
$defaultBaseUrl = "https://pixiv.perennialte.ch/artworks/";

// Get ?url= parameter if exists
$inputUrl = $_GET['url'] ?? null;
$artworkId = null;

// Extract artwork ID (number at end) from given URL or fallback
if ($inputUrl) {
    // Match last number in URL path
    if (preg_match('#/(\d+)(?:[/?]|$)#', $inputUrl, $matches)) {
        $artworkId = $matches[1];
    }
}

if ($artworkId) {
    $url = $defaultBaseUrl . $artworkId;
} else {
    // fallback default
    $url = $defaultBaseUrl . "127908186";
}

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/114.0.0.0 Safari/537.36',
    CURLOPT_HEADER => false,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_COOKIEJAR => '/tmp/cookies.txt',
    CURLOPT_COOKIEFILE => '/tmp/cookies.txt',
    CURLOPT_HTTPHEADER => [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.9',
        'Connection: keep-alive',
        'Referer: https://pixiv.perennialte.ch/',
    ],
]);

$html = curl_exec($ch);
$err = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

if ($html === false || $err) {
    die("cURL error: $err");
}
if ($code !== 200) {
    die("Unexpected HTTP status code: $code");
}

$doc = new DOMDocument();
libxml_use_internal_errors(true);
$doc->loadHTML($html);
libxml_clear_errors();

$xpath = new DOMXPath($doc);

function getNextElementSibling($node) {
    do {
        $node = $node->nextSibling;
    } while ($node && $node->nodeType !== XML_ELEMENT_NODE);
    return $node;
}

// Extract page title
$title = $doc->getElementsByTagName('title')->item(0);
$titleText = $title ? trim($title->textContent) : 'No Title';

$imageUrl = null;
$img = $xpath->query('//div[contains(@class,"artwork-container")]//img')->item(0);
if (!$img) {
    $img = $xpath->query('//img')->item(0);
}
if ($img) {
    $imageUrl = $img->getAttribute('src');
}

$favoriteCount = null;
$favoriteSpan = $xpath->query('//span[contains(@class,"material-symbols-rounded-20") and normalize-space(text())="favorite"]')->item(0);
if ($favoriteSpan) {
    $nextSpan = getNextElementSibling($favoriteSpan);
    if ($nextSpan && strpos($nextSpan->getAttribute('class'), 'inline') !== false) {
        $favoriteCount = trim($nextSpan->textContent);
    }
}

$likeCount = null;
$likeSpan = $xpath->query('//span[contains(@class,"material-symbols-rounded-20") and normalize-space(text())="thumb_up"]')->item(0);
if ($likeSpan) {
    $nextSpan = getNextElementSibling($likeSpan);
    if ($nextSpan && strpos($nextSpan->getAttribute('class'), 'inline') !== false) {
        $likeCount = trim($nextSpan->textContent);
    }
}

echo '<a href="' . htmlspecialchars($url) . '" target="_blank">' . htmlspecialchars($titleText) . '</a> ';
if ($imageUrl) {
    echo '<a href="' . htmlspecialchars($imageUrl) . '" target="_blank"><img src="' . htmlspecialchars($imageUrl) . '" alt="img" style="height:20px;vertical-align:middle;"></a> ';
}
echo 'favs ' . htmlspecialchars($favoriteCount ?? 'N/A') . ' bookmarks ' . htmlspecialchars($likeCount ?? 'N/A');
