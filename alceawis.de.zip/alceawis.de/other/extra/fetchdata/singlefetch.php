<?php
// Default URL base
$defaultBaseUrl = "https://www.pixiv.net/artworks/";

// Get ?url= parameter if exists
$inputUrl = $_GET['url'] ?? null;
$artworkId = null;

// Extract artwork ID (number at end) from given URL or fallback
if ($inputUrl) {
    if (preg_match('#/(\d+)(?:[/?]|$)#', $inputUrl, $matches)) {
        $artworkId = $matches[1];
    }
}

// Fallback to default artwork if no ID found
$artworkId = $artworkId ?? "127908186";

/**
 * Fetch Pixiv Artwork Data via API
 */
function fetchPixivData($illust_id) {
    $apiUrl = "https://www.pixiv.net/ajax/illust/{$illust_id}";
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $apiUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
            'Referer: https://www.pixiv.net/',
            // Uncomment if accessing private/NSFW works (replace XXX with your PHPSESSID):
            // 'Cookie: PHPSESSID=XXX;',
        ],
        CURLOPT_ENCODING       => 'gzip',
        CURLOPT_SSL_VERIFYPEER => false, // Disable if SSL issues occur
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        return ['error' => true, 'message' => "HTTP {$httpCode} - API request failed"];
    }
    
    return json_decode($response, true);
}

// Fetch artwork data
$artworkData = fetchPixivData($artworkId);

// Handle errors
if (isset($artworkData['error']) && $artworkData['error']) {
    die("Error: " . ($artworkData['message'] ?? 'Failed to fetch artwork'));
}

// Extract data
$title = $artworkData['body']['title'] ?? 'No Title';
$imageUrl = $artworkData['body']['urls']['original'] ?? $artworkData['body']['urls']['regular'] ?? null;
$views = $artworkData['body']['viewCount'] ?? 0;
$bookmarks = $artworkData['body']['bookmarkCount'] ?? 0;
$likes = $artworkData['body']['likeCount'] ?? 0;
$comments = $artworkData['body']['commentCount'] ?? 0;
$artworkUrl = $defaultBaseUrl . $artworkId;
echo '<br><a href="' . htmlspecialchars($artworkUrl) . '" target="_blank">' 
     . htmlspecialchars($title) . '</a> ';

if ($imageUrl) {
    $proxyImageUrl = "https://i.pixiv.re/" . basename($imageUrl);
    echo '<a href="' . htmlspecialchars($imageUrl) . '" target="_blank">'
         . '<img src="' . htmlspecialchars($proxyImageUrl) . '" alt="preview" style="height:20px;"></a> ';
}

echo sprintf(
    'Views: %s | Bookmarks: %s | Likes: %s | Comments: %s',
    htmlspecialchars($views),
    htmlspecialchars($bookmarks),
    htmlspecialchars($likes),
    htmlspecialchars($comments)
);
?>
