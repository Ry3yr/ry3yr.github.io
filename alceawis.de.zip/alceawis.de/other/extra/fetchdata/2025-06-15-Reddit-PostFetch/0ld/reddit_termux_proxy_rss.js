/**
 * Tiny local proxy — run this in Termux on your phone.
 *
 * Purpose: your phone's own network requests to reddit.com's public RSS/JSON
 * endpoints already work fine (confirmed by opening those URLs directly in
 * the browser). The only remaining problem is that your page's JavaScript
 * can't read the response directly due to CORS, a browser-side restriction.
 *
 * This script runs locally on the SAME device, fetches the real Reddit URL
 * itself (same network path that already works), and hands the result back
 * to your page with permissive CORS headers so fetch() can read it.
 *
 * No login, no cookies, no automation — just a same-device relay for public
 * data your phone can already reach.
 *
 * Run with: node proxy.js
 * Then point your page's fetch calls at: http://localhost:8080/proxy?url=...
 */

const http = require('http');

const PORT = 8090; // 8080 is taken by KSWeb on this device
const ALLOWED_HOST = 'www.reddit.com';

const server = http.createServer(async (req, res) => {
  // CORS headers for every response, including preflight
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const reqUrl = new URL(req.url, `http://localhost:${PORT}`);

  if (reqUrl.pathname !== '/proxy') {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found. Use /proxy?url=...');
    return;
  }

  const target = reqUrl.searchParams.get('url');
  if (!target) {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end('Missing ?url= parameter');
    return;
  }

  let targetUrl;
  try {
    targetUrl = new URL(target);
  } catch {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end('Invalid URL');
    return;
  }

  // Only allow reddit.com public endpoints — nothing else
  if (targetUrl.hostname !== ALLOWED_HOST || targetUrl.protocol !== 'https:') {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end('Only https://www.reddit.com URLs are allowed.');
    return;
  }
  if (!/\.rss$|\.json$/.test(targetUrl.pathname)) {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end('Only .rss or .json endpoints are allowed.');
    return;
  }

  try {
    const upstream = await fetch(targetUrl.toString(), {
      headers: {
        // A real, descriptive UA, same as a normal mobile browser visit —
        // required by Reddit's own API guidelines, not a spoofing trick.
        'User-Agent': 'Mozilla/5.0 (Linux; Android 13) MyPersonalRedditReader/1.0',
        Accept: '*/*',
      },
    });

    const contentType = upstream.headers.get('content-type') || 'text/plain';
    const body = await upstream.text();

    res.writeHead(upstream.status, { 'Content-Type': contentType });
    res.end(body);
  } catch (err) {
    res.writeHead(502, { 'Content-Type': 'text/plain' });
    res.end(`Proxy fetch failed: ${err.message}`);
  }
});

server.listen(PORT, () => {
  console.log(`Local proxy running at http://localhost:${PORT}`);
  console.log(`Test it: http://localhost:${PORT}/proxy?url=https://www.reddit.com/r/webdev/.rss`);
});