<script>
function getQueryParam(name) {
    const params = new URLSearchParams(window.location.search);
    return params.get(name) || '';
}

window.addEventListener('DOMContentLoaded', () => {
    const uploadUrlInput = document.querySelector('input[name="upload_url"]');
    const urlParam = getQueryParam('url');
    if (uploadUrlInput && urlParam) {
        uploadUrlInput.value = urlParam;
    }
});
</script>
<script>
function getQueryParam(name) {
    const params = new URLSearchParams(window.location.search);
    return params.get(name) || '';
}
function saveCredentialsToLocalStorage(username, password) {
    if (username) localStorage.setItem('username', username);
    if (password) localStorage.setItem('password', password);
}
function loadCredentialsFromLocalStorage() {
    return {
        username: localStorage.getItem('username') || '',
        password: localStorage.getItem('password') || ''
    };
}
window.addEventListener('DOMContentLoaded', () => {
    const usernameInput = document.querySelector('input[name="username"]');
    const passwordInput = document.querySelector('input[name="password"]');
    let username = getQueryParam('username');
    let password = getQueryParam('password');
    if (!username || !password) {
        const stored = loadCredentialsFromLocalStorage();
        if (!username) username = stored.username;
        if (!password) password = stored.password;
    }
    if (usernameInput && username) usernameInput.value = username;
    if (passwordInput && password) passwordInput.value = password;
    const form = usernameInput.closest('form');
    if (form) {
        form.addEventListener('submit', () => {
            saveCredentialsToLocalStorage(usernameInput.value, passwordInput.value);
        });
    }
});
</script>

<?php
ini_set('memory_limit', '256M'); // Or '512M' or '-1' (no limit)
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    // Error Reporting for debugging
    //echo "<div class='debug'><strong>PHP Error:</strong> [$errno] $errstr in $errfile on line $errline</div>";
    return true;
});
// further Error reporting
//set_exception_handler(function($e) {echo "<div class='debug'><strong>Uncaught Exception:</strong> " . $e->getMessage() . "</div>";});


function getQuery($key, $default = '') {return isset($_REQUEST[$key]) ? $_REQUEST[$key] : $default;}
$username = getQuery('username');
$password = getQuery('password');
$server   = getQuery('server');
$path     = getQuery('path', '/');
$protocol = getQuery('protocol', 'ftp');
$uploadType = getQuery('upload_type', 'url'); // 'file' or 'url'

$isDir = substr($path, -1) === '/';
$files = [];
$debug = [];
$uploadSuccess = null;

function ftpUpload($server, $username, $password, $remoteDir, $localFile, $remoteFile, &$debug) {
    $conn = @ftp_connect($server);
    if (!$conn) {
        $debug[] = "FTP connect failed.";
        return false;
    }
    if (!@ftp_login($conn, $username, $password)) {
        $debug[] = "FTP login failed.";
        ftp_close($conn);
        return false;
    }
    ftp_pasv($conn, true);
    if (!@ftp_chdir($conn, $remoteDir)) {
        $debug[] = "FTP failed to change directory to $remoteDir";
        ftp_close($conn);
        return false;
    }
    $list = ftp_nlist($conn, ".");
    if ($list !== false && in_array($remoteFile, $list)) {
        $debug[] = "File $remoteFile already exists in $remoteDir.";
        ftp_close($conn);
        return false;
    }
    $uploadResult = ftp_put($conn, $remoteFile, $localFile, FTP_BINARY);
    ftp_close($conn);
    if (!$uploadResult) {
        $debug[] = "FTP upload failed for $remoteFile.";
        return false;
    }
    $debug[] = "FTP upload successful for $remoteFile.";
    return true;
}

function sftpUpload($server, $username, $password, $remoteDir, $localFile, $remoteFile, &$debug) {
    $url = "sftp://$username:$password@$server/" . trim($remoteDir, '/') . '/' . $remoteFile;
    $debug[] = "SFTP upload URL: $url";

    // Check existence by curl LIST (simplified)
    $chCheck = curl_init();
    curl_setopt($chCheck, CURLOPT_URL, "sftp://$username:$password@$server/" . trim($remoteDir, '/') . "/");
    curl_setopt($chCheck, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chCheck, CURLOPT_PROTOCOLS, CURLPROTO_SFTP);
    curl_setopt($chCheck, CURLOPT_CUSTOMREQUEST, 'LIST');
    $listOutput = curl_exec($chCheck);
    curl_close($chCheck);

    if ($listOutput !== false && strpos($listOutput, $remoteFile) !== false) {
        $debug[] = "File $remoteFile already exists in $remoteDir.";
        return false;
    }

    $fp = fopen($localFile, 'rb');
    if (!$fp) {
        $debug[] = "Failed to open local file for reading.";
        return false;
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_UPLOAD, true);
    curl_setopt($ch, CURLOPT_INFILE, $fp);
    curl_setopt($ch, CURLOPT_INFILESIZE, filesize($localFile));
    curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_SFTP);
    $result = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    fclose($fp);

    if (!$result) {
        $debug[] = "SFTP upload failed: $error";
        return false;
    }
    $debug[] = "SFTP upload successful for $remoteFile.";
    return true;
}

function webdavUpload($server, $username, $password, $remoteDir, $localFile, $remoteFile, &$debug) {
    $url = rtrim("https://$server/" . trim($remoteDir, '/'), '/') . '/' . $remoteFile;
    $debug[] = "WebDAV upload URL: $url";

    if (!file_exists($localFile)) {
        $debug[] = "Local file does not exist for upload.";
        return false;
    }

    // HEAD to check existence
    $optsCheck = [
        "http" => [
            "method" => "HEAD",
            "header" => "Authorization: Basic " . base64_encode("$username:$password")
        ]
    ];
    $contextCheck = stream_context_create($optsCheck);
    $headers = @get_headers($url, 1, $contextCheck);
    if ($headers !== false && strpos($headers[0], '200') !== false) {
        $debug[] = "File $remoteFile already exists in $remoteDir.";
        return false;
    }

    $data = file_get_contents($localFile);
    $opts = [
        "http" => [
            "method" => "PUT",
            "header" => "Authorization: Basic " . base64_encode("$username:$password") . "\r\nContent-Length: " . strlen($data),
            "content" => $data
        ]
    ];
    $context = stream_context_create($opts);
    $result = @file_get_contents($url, false, $context);
    if ($result === false) {
        $debug[] = "WebDAV upload failed.";
        return false;
    }
    $debug[] = "WebDAV upload successful for $remoteFile.";
    return true;
}

// Handle upload on POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $username && $password && $server && $protocol && $isDir) {
    $remoteDir = $path;
    if ($uploadType === 'file' && isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] === UPLOAD_ERR_OK) {
        $localTmpFile = $_FILES['upload_file']['tmp_name'];
        $remoteFile = basename($_FILES['upload_file']['name']);
        if ($protocol === 'ftp') {
            $uploadSuccess = ftpUpload($server, $username, $password, $remoteDir, $localTmpFile, $remoteFile, $debug);
        } elseif ($protocol === 'sftp') {
            $uploadSuccess = sftpUpload($server, $username, $password, $remoteDir, $localTmpFile, $remoteFile, $debug);
        } elseif ($protocol === 'webdav') {
            $uploadSuccess = webdavUpload($server, $username, $password, $remoteDir, $localTmpFile, $remoteFile, $debug);
        }
    } elseif ($uploadType === 'url' && !empty($_POST['upload_url'])) {
        $urlToUpload = trim($_POST['upload_url']);
        $tmpFile = tempnam(sys_get_temp_dir(), 'upload_');
        $downloaded = @file_put_contents($tmpFile, @file_get_contents($urlToUpload));
        if (!$downloaded) {
            $debug[] = "Failed to download file from URL: $urlToUpload";
            $uploadSuccess = false;
        } else {
            $remoteFile = basename(parse_url($urlToUpload, PHP_URL_PATH));
            if ($protocol === 'ftp') {
                $uploadSuccess = ftpUpload($server, $username, $password, $remoteDir, $tmpFile, $remoteFile, $debug);
            } elseif ($protocol === 'sftp') {
                $uploadSuccess = sftpUpload($server, $username, $password, $remoteDir, $tmpFile, $remoteFile, $debug);
            } elseif ($protocol === 'webdav') {
                $uploadSuccess = webdavUpload($server, $username, $password, $remoteDir, $tmpFile, $remoteFile, $debug);
            }
            unlink($tmpFile);
        }
    }
    if ($uploadSuccess === true) {
        $debug[] = "Upload succeeded.";
    } elseif ($uploadSuccess === false) {
        $debug[] = "Upload failed or file exists.";
    }
}

// Build URL helper
function buildUrl($protocol, $server, $path) {
    $scheme = ($protocol === 'webdav') ? 'https' : $protocol;
    return "$scheme://$server$path";
}

// Directory listing with clickable links
function listDirectory($protocol, $server, $username, $password, $path, &$debug) {
    $isDir = substr($path, -1) === '/';
    if (!$isDir) {
        echo "Path must end with '/' to be a directory.<br>";
        return [];
    }
    $files = [];

    if ($protocol === 'ftp') {
        $conn = @ftp_connect($server);
        if ($conn && @ftp_login($conn, $username, $password)) {
            ftp_pasv($conn, true);
            if (@ftp_chdir($conn, $path)) {
                $rawList = ftp_rawlist($conn, ".");
                foreach ($rawList as $line) {
                    // Parse line: typical unix ls -l format
                    $parts = preg_split("/\s+/", $line, 9);
                    if (count($parts) === 9) {
                        $name = $parts[8];
                        $type = $parts[0][0] === 'd' ? 'dir' : 'file';
                        $files[] = ['name' => $name, 'type' => $type];
                    }
                }
            } else {
                echo "Failed to change directory $path on FTP server.<br>";
            }
            ftp_close($conn);
        } else {
            echo "FTP connection/login failed.<br>";
        }
    } elseif ($protocol === 'sftp') {
        $conn = @ssh2_connect($server);
        if ($conn && @ssh2_auth_password($conn, $username, $password)) {
            $sftp = ssh2_sftp($conn);
            $dirHandle = @opendir("ssh2.sftp://$sftp$path");
            if ($dirHandle) {
                while (($file = readdir($dirHandle)) !== false) {
                    if ($file === '.' || $file === '..') continue;
                    $fullPath = "ssh2.sftp://$sftp$path$file";
                    $type = is_dir($fullPath) ? 'dir' : 'file';
                    $files[] = ['name' => $file, 'type' => $type];
                }
                closedir($dirHandle);
            } else {
                echo "Failed to open directory $path over SFTP.<br>";
            }
        } else {
            echo "SFTP connection/authentication failed.<br>";
        }
    } elseif ($protocol === 'webdav') {
        $url = buildUrl($protocol, $server, $path);
        $opts = [
            "http" => [
                "method" => "PROPFIND",
                "header" => "Authorization: Basic " . base64_encode("$username:$password") . "\r\nDepth: 1",
                "content" => ""
            ]
        ];
        $context = stream_context_create($opts);
        $result = @file_get_contents($url, false, $context);
        if ($result !== false) {
            preg_match_all('/<d:href>(.*?)<\/d:href>/i', $result, $matches);
            foreach ($matches[1] as $href) {
                $name = basename(parse_url($href, PHP_URL_PATH));
                if ($name && $name !== basename($path)) {
                    // Detect trailing slash means directory
                    $type = (substr($href, -1) === '/') ? 'dir' : 'file';
                    $files[] = ['name' => $name, 'type' => $type];
                }
            }
        } else {
            echo "WebDAV PROPFIND failed.<br>";
        }
    }

    return $files;
}

echo '<form method="post" enctype="multipart/form-data" style="margin-bottom:20px;">
    Upload type:<br>
    <label><input type="radio" name="upload_type" value="file" '.($uploadType === 'file' ? 'checked' : '').' onclick="toggleUploadType()"> File</label><br>
    <label><input type="radio" name="upload_type" value="url" '.($uploadType === 'url' ? 'checked' : '').' onclick="toggleUploadType()"> URL</label><br><br>
    
    Username: <input type="text" name="username" value="'.htmlspecialchars($username).'"><br>
    Password: <input type="password" name="password" value="'.htmlspecialchars($password).'"><br>
    Server: <input type="text" name="server" value="'.htmlspecialchars($server).'"><br>
    Path: <input type="text" name="path" value="'.htmlspecialchars($path).'"><br>
    
    Protocol:<br>
    <label><input type="radio" name="protocol" value="ftp" '.($protocol == 'ftp' ? 'checked' : '').'> FTP</label>
    <label><input type="radio" name="protocol" value="sftp" '.($protocol == 'sftp' ? 'checked' : '').'> SFTP</label>
    <label><input type="radio" name="protocol" value="webdav" '.($protocol == 'webdav' ? 'checked' : '').'> WebDAV</label>
    <br><br>
    
    <div id="fileUploadDiv" style="display: '.($uploadType === 'file' ? 'block' : 'none').';">
        Select file to upload:<br>
        <input type="file" name="upload_file"><br>
    </div>
    
    <div id="urlUploadDiv" style="display: '.($uploadType === 'url' ? 'block' : 'none').';">
        Enter URL to upload:<br>
        <input type="url" name="upload_url" style="width:300px;" value="'.htmlspecialchars(getQuery('upload_url')).'"><br>
    </div>
    
    <input type="submit" value="Connect / Upload">
</form>

<script>
function toggleUploadType() {
    const fileDiv = document.getElementById("fileUploadDiv");
    const urlDiv = document.getElementById("urlUploadDiv");
    const fileRadio = document.querySelector(\'input[name="upload_type"][value="file"]\');
    
    if(fileRadio.checked) {
        fileDiv.style.display = "block";
        urlDiv.style.display = "none";
    } else {
        fileDiv.style.display = "none";
        urlDiv.style.display = "block";
    }
}
</script>
';

// Show debug info
if ($debug) {
    echo "<pre style='background:#eee;padding:10px;max-height:150px;overflow:auto;'>";
    foreach ($debug as $d) {
        echo htmlspecialchars($d) . "\n";
    }
    echo "</pre>";
}

// Show directory listing with clickable links
if ($username && $password && $server && $isDir) {
    $files = listDirectory($protocol, $server, $username, $password, $path, $debug);

    if ($path !== '/') {
        // Parent directory link
        $parent = rtrim($path, '/');
        $parent = substr($parent, 0, strrpos($parent, '/') + 1);
        echo '<a href="?username='.urlencode($username).'&password='.urlencode($password).'&server='.urlencode($server).'&protocol='.urlencode($protocol).'&path='.urlencode($parent).'&upload_type='.htmlspecialchars($uploadType).'">.. (Parent directory)</a><br>';
    }

    echo "<ul>";
    foreach ($files as $file) {
        $name = $file['name'];
        $type = $file['type'];
        $urlPath = $path . $name . ($type === 'dir' ? '/' : '');
        echo '<li>';
        if ($type === 'dir') {
            echo "📁 <a href='?username=".urlencode($username)."&password=".urlencode($password)."&server=".urlencode($server)."&protocol=".urlencode($protocol)."&path=".urlencode($urlPath)."&upload_type=".htmlspecialchars($uploadType)."'>" . htmlspecialchars($name) . "</a>";
        } else {
            $linkUrl = buildUrl($protocol, $server, $urlPath);
            echo "📄 <a href='$linkUrl' target='_blank'>" . htmlspecialchars($name) . "</a>";
        }
        echo "</li>";
    }
    echo "</ul>";
}
?>
