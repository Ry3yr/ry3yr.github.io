<?php
// === Hardcoded values ===
//$apikey = 'XrmDUgMBxbyAG5nSpHqBHOzpBhbha-kkBNUzKLwdKlc'; //blob.cat key
$apikey = 'nAJ2E-4CDUN4uA9HQuhyU1cNFdcxl-5mXBrbgmhzsFA'; //read-only_alceawis
$instanceurl = 'https://alceawis.com';
$apiUrl = $instanceurl . '/api/v1/notifications';
$outputFile = 'notifynew.txt';

// === Set up cURL ===
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer $apikey",
    "Accept: application/json"
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// === Check for success ===
if ($httpCode !== 200) {
    file_put_contents($outputFile, "Error: HTTP $httpCode\n");
    die("API call failed with HTTP $httpCode\n");
}

// === Parse JSON ===
$notifications = json_decode($response, true);

if (!$notifications || !isset($notifications[0])) {
    file_put_contents($outputFile, "No notifications found.\n");
    die("No notifications returned.\n");
}

// === Get newest notification ===
$n = $notifications[0];
$type = ucfirst($n['type']);
$account = $n['account']['display_name'] ?: $n['account']['username'];
$content = isset($n['status']['content']) ? strip_tags($n['status']['content']) : '[No content]';
$created = date('Y-m-d H:i:s', strtotime($n['created_at']));

// === Save formatted text ===
$output = "Type: $type\nFrom: $account\nTime: $created\nContent: $content\n";
file_put_contents($outputFile, $output);

echo "Notification saved to $outputFile\n";
