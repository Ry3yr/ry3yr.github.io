<a target="_blank" href="https://alcea-wisteria.de/PHP//0demo/2023-07-09-FetchMastodonAva/0list.php#https://retrospring.net/Alcea">OldAvas</a><br><hr><br>

<?php
echo '<p>Current path: ' . getcwd() . '</p>';

$users = [
    'alcea@infosec.exchange'  => ['instance' => 'https://infosec.exchange', 'rss' => null],
    'alcea@alceawis.com'       => ['instance' => 'https://alceawis.com', 'rss' => null],
    'aoikurayami@mk.absturztau.be' => ['instance' => 'https://mk.absturztau.be', 'rss' => 'https://mk.absturztau.be/@aoikurayami.rss'],
    'alcea@mstdn.animexx.de'  => ['instance' => 'https://mstdn.animexx.de', 'rss' => 'https://mstdn.animexx.de/@alcea.rss'],
    'alcea@mas.to'             => ['instance' => 'https://mas.to', 'rss' => null]
];

$saveDir   = '/home/alceawis/alceawis.de/other/images/fediavas';
$publicUrl = 'https://alceawis.de/other/images/fediavas';

$gifFileName = '';
$gifPath     = '';
$gifUrl      = '';
$avatarUrl   = '';
$resizeWidth = null;
$gifBlob     = null;
$md5Match    = false;
$filesIdenticalMessage = '';

if (isset($_GET['resize'])) {
    $resizeParam = $_GET['resize'];
    
    if (preg_match('/(\d+)px/', $resizeParam, $matches)) {
        $resizeWidth = (int) $matches[1];
        echo "<p>Resize width from URL: $resizeWidth px</p>";
    } else {
        echo "<p>Invalid resize format. Use '250px' format.</p>";
    }
}

if (isset($_POST['select_user'])) {
    $selectedAcct = $_POST['select_user'];
    $instance = $users[$selectedAcct]['instance'];
    $rssUrl = $users[$selectedAcct]['rss'];
    $domain = explode('@', $selectedAcct)[1];
    $gifFileName = $domain . '.gif';
    $gifPath = $saveDir . '/' . $gifFileName;
    $gifUrl = $publicUrl . '/' . $gifFileName;

    if ($rssUrl) {
        $rssData = file_get_contents($rssUrl);
        if ($rssData === false) {
            $errorMsg = 'RSS fetch failed for ' . $rssUrl;
        } else {
            libxml_use_internal_errors(true);
            $rss = simplexml_load_string($rssData);
            if ($rss === false) {
                $errorMsg = 'Failed to parse RSS feed';
                foreach(libxml_get_errors() as $error) {
                    $errorMsg .= "\n" . $error->message;
                }
            } else {
                $avatarUrl = (string) $rss->channel->image->url;
            }
        }
    } else {
        $lookupUrl = $instance . '/api/v1/accounts/lookup?acct=' . urlencode($selectedAcct);
        $ch = curl_init($lookupUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERAGENT => 'AvatarFetcher'
        ]);
        $data = json_decode(curl_exec($ch), true);
        curl_close($ch);

        if (empty($data['avatar'])) {
            $errorMsg = 'Avatar not found';
        } else {
            $avatarUrl = $data['avatar'];
        }
    }

    if ($avatarUrl && !isset($errorMsg)) {
        $imgData = file_get_contents($avatarUrl);
        $img = new Imagick();
        $img->readImageBlob($imgData);
        
        if ($resizeWidth) {
            $originalWidth = $img->getImageWidth();
            $originalHeight = $img->getImageHeight();
            
            $resizeHeight = ($resizeWidth / $originalWidth) * $originalHeight;
            
            echo "<p>Resizing from {$originalWidth}x{$originalHeight} to {$resizeWidth}x{$resizeHeight}</p>";
            
            $img->resizeImage($resizeWidth, $resizeHeight, Imagick::FILTER_LANCZOS, 1);
        }
        
        $img->setImageFormat('gif');
        $gifBlob = $img->getImageBlob();
        $img->destroy();
        
        // Check if file exists and compare with new file
        $exists = file_exists($gifPath);
        if ($exists) {
            $existingHash = md5_file($gifPath);
            $newHash = md5($gifBlob);
            $md5Match = ($existingHash === $newHash);
            
            if ($md5Match) {
                $filesIdenticalMessage = "✓ The new avatar is identical to the existing file. No need to save.";
            }
        }
    }
}

// Handle saving the file
$exists = file_exists($gifPath);
$saved = false;
$sizeDiff = 0;

if (isset($_POST['save']) && $gifBlob) {
    if ($exists && empty($_POST['overwrite'])) {
        echo "<p style='color:orange;'>File exists. Check overwrite to replace.</p>";
    } else {
        if (file_put_contents($gifPath, $gifBlob) !== false) {
            $saved = true;
            $exists = true;
            echo "<p style='color:green;'>File saved successfully to: $gifPath</p>";
        } else {
            echo "<p style='color:red;'>Failed to save file. Check directory permissions.</p>";
            echo "<p>Save directory: $saveDir</p>";
            
            if (!is_dir($saveDir)) {
                echo "<p>Directory does not exist.</p>";
            } elseif (!is_writable($saveDir)) {
                echo "<p>Directory is not writable.</p>";
                echo "<p>Permissions: " . substr(sprintf('%o', fileperms($saveDir)), -4) . "</p>";
            }
        }
    }
}

// Calculate size difference if file exists and we have new blob
if ($exists && $gifBlob) {
    $oldSize = filesize($gifPath);
    $newSize = strlen($gifBlob);
    $sizeDiff = $newSize - $oldSize;
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Avatar Saver</title>
<style>
    .old-avatar {
        filter: grayscale(100%);
        width: 100px;
        height: 100px;
    }
    .avatars-container {
        display: flex;
        gap: 10px;
        align-items: center;
        margin: 20px 0;
    }
    .info {
        background-color: #f0f0f0;
        padding: 10px;
        margin: 10px 0;
        border-radius: 5px;
    }
    .identical-message {
        background-color: #d4edda;
        color: #155724;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #c3e6cb;
        margin: 10px 0;
    }
</style>
</head>
<body>

<h2>Select a User</h2>
<form method="post">
    <select name="select_user" required>
        <option value="">-- Select User --</option>
        <?php foreach ($users as $acct => $data): ?>
            <option value="<?= $acct ?>" <?= isset($selectedAcct) && $selectedAcct == $acct ? 'selected' : '' ?>><?= $acct ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit">Fetch Avatar</button>
</form>

<div class="info">
    <p>To resize, add <code>?resize=250px</code> to the URL (adjust number as needed).</p>
</div>

<?php if (isset($selectedAcct)): ?>
    <h2>Generated Avatar GIF for <?= htmlspecialchars($selectedAcct) ?></h2>

    <?php if (isset($errorMsg)): ?>
        <p style="color:red;"><?= htmlspecialchars($errorMsg) ?></p>
        <h3>Enter an image URL manually</h3>
        <form method="post">
            <input type="hidden" name="select_user" value="<?= htmlspecialchars($selectedAcct) ?>">
            <input type="text" name="avatar_url" required placeholder="Enter image URL" />
            <button type="submit" name="use_manual_url">Use Manual URL</button>
        </form>
    <?php endif; ?>

    <?php if ($gifBlob): ?>
        <?php if ($filesIdenticalMessage): ?>
            <div class="identical-message">
                <?= $filesIdenticalMessage ?>
            </div>
        <?php endif; ?>
        
        <div class="avatars-container">
            <div>
                <h4>New Avatar</h4>
                <img src="data:image/gif;base64,<?= base64_encode($gifBlob) ?>" alt="New Avatar" width="100" height="100">
            </div>
            
            <?php if ($exists && file_exists($gifPath)): ?>
                <div>
                    <h4>Old Avatar</h4>
                    <img src="<?= $gifUrl . '?t=' . time() ?>" alt="Old Avatar" class="old-avatar" width="100" height="100">
                </div>
            <?php endif; ?>
        </div>
        
        <div class="info">
            <p>File will be saved as: <strong><?= $gifFileName ?></strong></p>
            <p>Save path: <?= $gifPath ?></p>
            <p>Public URL: <a href="<?= $gifUrl ?>" target="_blank"><?= $gifUrl ?></a></p>
        </div>

        <?php if (!$md5Match): ?>
            <?php if ($exists && !$md5Match): ?>
                <p style="color:orange;">File exists but has different content.</p>
                <form method="post">
                    <input type="hidden" name="select_user" value="<?= htmlspecialchars($selectedAcct) ?>">
                    <label>
                        <input type="checkbox" name="overwrite" value="1" checked> Overwrite existing file
                    </label><br><br>
                    <button type="submit" name="save">Save Avatar</button>
                </form>
            <?php else: ?>
                <form method="post">
                    <input type="hidden" name="select_user" value="<?= htmlspecialchars($selectedAcct) ?>">
                    <button type="submit" name="save">Save Avatar</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>

        <?php if ($saved): ?>
            <p style="color:green;">
                ✓ Saved successfully: 
                <a href="<?= $gifUrl ?>" target="_blank"><?= $gifUrl ?></a>
            </p>
        <?php endif; ?>

        <?php if ($exists && !$md5Match && isset($sizeDiff)): ?>
            <p>File size difference: <?= $sizeDiff ?> bytes 
            (<?= $sizeDiff > 0 ? 'larger' : 'smaller' ?>)</p>
        <?php endif; ?>

    <?php endif; ?>

<?php endif; ?>

</body>
</html>
