<?php

// Initialize variables
$response = '';
$errorMessage = '';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
    $url = $_POST['url'];

    // Validate the URL (basic validation)
    if (filter_var($url, FILTER_VALIDATE_URL)) {
        // Initialize cURL session
        $ch = curl_init();

        // Set the cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        // Add ActivityPub headers
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/activity+json',  // Specify the ActivityPub format
            'User-Agent: MastodonBot/1.0 (https://mastodon.social)',  // Simulating a bot user-agent
            'Content-Type: application/json'  // Specify that we expect JSON in the response
        ]);

        // Execute the request and store the response
        $response = curl_exec($ch);

        // Check for cURL errors
        if (curl_errno($ch)) {
            $errorMessage = 'cURL Error: ' . curl_error($ch);
        }

        // Close the cURL session
        curl_close($ch);

        // Decode the JSON response
        if (!$errorMessage && $response) {
            $data = json_decode($response, true);
            if ($data) {
                $response = json_encode($data, JSON_PRETTY_PRINT);
            } else {
                $errorMessage = 'Invalid JSON response from server.';
            }
        }
    } else {
        $errorMessage = 'Please enter a valid URL.';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fetch Mastodon Post ActivityPub Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            max-width: 900px;
            margin: auto;
        }
        textarea {
            width: 100%;
            height: 300px;
            margin-bottom: 10px;
            font-family: monospace;
            font-size: 14px;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            font-size: 14px;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
        }
        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h1>Fetch Mastodon Post ActivityPub Data</h1>

    <!-- Form to enter the Mastodon post URL -->
    <form method="POST" action="">
        <label for="url">Mastodon Post URL:</label>
        <input type="text" id="url" name="url" placeholder="Enter Mastodon Post URL" required value="<?= isset($_POST['url']) ? htmlspecialchars($_POST['url']) : '' ?>">
        <button type="submit">Fetch Data</button>
    </form>

    <!-- Display error message if any -->
    <?php if ($errorMessage): ?>
        <p class="error"><?= $errorMessage ?></p>
    <?php endif; ?>

    <!-- Display the JSON response -->
    <?php if ($response): ?>
        <h2>ActivityPub JSON-LD Response:</h2>
        <textarea readonly><?= $response ?></textarea>
    <?php endif; ?>

</body>
</html>
