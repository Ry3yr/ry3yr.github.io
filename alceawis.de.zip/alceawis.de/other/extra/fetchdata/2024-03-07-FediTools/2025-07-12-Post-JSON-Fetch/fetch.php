<?php

// Initialize variables
$response = '';
$errorMessage = '';
$noteContentPlainText = '';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
    $url = $_POST['url'];

    // Validate the URL
    if (filter_var($url, FILTER_VALIDATE_URL)) {
        // Initialize cURL session
        $ch = curl_init();

        // Set the cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5); // Prevent infinite loops

        // Add ActivityPub headers
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/activity+json',
            'User-Agent: MastodonBot/1.0 (https://mastodon.social)',
            'Content-Type: application/json'
        ]);

        // Execute the request
        $response = curl_exec($ch);

        // Check for cURL errors
        if (curl_errno($ch)) {
            $errorMessage = 'cURL Error: ' . curl_error($ch);
        }

        // Close the cURL session
        curl_close($ch);

        // Decode the JSON response
        if (!$errorMessage && $response) {
            $data = json_decode($response, true);
            if (is_array($data)) {
                $response = json_encode($data, JSON_PRETTY_PRINT);

                // Extract note content (plain text version)
                if (isset($data['content'])) {
                    $noteContentPlainText = strip_tags($data['content']);
                } else {
                    $noteContentPlainText = '[No "content" field found in ActivityPub data]';
                }
            } else {
                $errorMessage = 'Invalid JSON response from server.';
            }
        }
    } else {
        $errorMessage = 'Please enter a valid URL.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post ActivityPub Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            max-width: 900px;
            margin: auto;
        }
        textarea {
            width: 100%;
            height: 300px;
            margin-bottom: 10px;
            font-family: monospace;
            font-size: 14px;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            font-size: 14px;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
        }
        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h1>Fetch Fedi Post ActivityPub Data</h1>

    <form method="POST" action="">
        <label for="url">Mastodon Post URL:</label>
        <input type="text" id="url" name="url" placeholder="Enter Mastodon Post URL" required value="<?= isset($_POST['url']) ? htmlspecialchars($_POST['url']) : '' ?>">
        <button type="submit">Fetch Data</button>
    </form>

    <?php if ($errorMessage): ?>
        <p class="error"><?= htmlspecialchars($errorMessage) ?></p>
    <?php endif; ?>

    <?php if ($response && !$errorMessage): ?>
        <h2>ActivityPub JSON-LD Response:</h2>
        <textarea readonly><?= htmlspecialchars($response) ?></textarea>
    <?php endif; ?>

    <?php if ($noteContentPlainText): ?>
        <h2>Note Content (Plain Text):</h2>
        <textarea readonly><?= htmlspecialchars($noteContentPlainText) ?></textarea>
    <?php endif; ?>

</body>
</html>
