<?php

// Set memory limit and max execution time
ini_set('memory_limit', '1024M');  // Set memory limit to 1024MB
set_time_limit(500);  // Set script timeout to 500 seconds

// Initialize an array to store the failed URLs
$failedUrls = [];

// Get the URL parameter from the query string
$fileUrl = isset($_GET['url']) ? $_GET['url'] : '';

// If no URL is provided, display an error
if (empty($fileUrl)) {
    echo "<p style='color: red;'>Error: No URL provided in the query string. Please provide a URL with ?url=YOUR_URL</p>";
    exit;
}

// Function to check the availability of URLs
function checkUrlAvailability($url) {
    global $failedUrls; // Use the global array to store failed URLs

    // Get headers for the URL (with a timeout to avoid hanging the script)
    $headers = @get_headers($url, 1);

    // Check if the URL headers could be fetched
    if ($headers === false) {
        echo "<p style='color: red;'>Failed: $url (Could not get headers)</p>";
        // Add to failed URLs
        $failedUrls[] = $url;
    } else {
        // Get the status code from the first header
        $status = $headers[0];

        // Check if the status is not 200 OK
        if (strpos($status, '200 OK') === false) {
            echo "<p style='color: red;'>Failed: $url (Status: $status)</p>";
            // Add to failed URLs
            $failedUrls[] = $url;
        } else {
            echo "<p style='color: green;'>Success: $url (Status: $status)</p>";
        }
    }
}

// Fetch the content of the file containing URLs
$content = @file_get_contents($fileUrl);

// If the content can't be fetched, stop the script and show an error
if ($content === false) {
    echo "<p style='color: red;'>Failed to fetch the file at $fileUrl</p>";
    exit;
}

// Regex pattern to match all URLs
preg_match_all('/https?\:\/\/[^\s]+/', $content, $matches);

// Loop through each URL and check its availability
foreach ($matches[0] as $url) {
    // Process each URL and give feedback immediately after each URL is checked
    checkUrlAvailability($url);
    // Flush the output buffer to make sure it displays immediately in real time
    ob_flush();
    flush();
}

// Check if there are failed URLs and display the "Download Failures" button
if (count($failedUrls) > 0) {
    // Create a downloadable text file with the failed URLs
    $filename = 'failed_urls.txt';
    $fileContent = implode("\n", $failedUrls);
    file_put_contents($filename, $fileContent);

    // Display a button to download the failed URLs
    echo "<br><a href='$filename' download><button>Download Failed URLs</button></a>";
} else {
    echo "<p style='color: green;'>All URLs were successful!</p>";
}

?>
