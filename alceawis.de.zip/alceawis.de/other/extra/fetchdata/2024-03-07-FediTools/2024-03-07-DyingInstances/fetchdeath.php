<?php
$url = 'https://wiki.archiveteam.org/index.php/Mastodon';
$html = file_get_contents($url);
$startPos = strpos($html, '<h2><span class="mw-headline" id="Dead_and_dying_instances"');
$endPos = strpos($html, '</ul>', $startPos);
$sectionHtml = substr($html, $startPos, $endPos + strlen('</ul>') - $startPos);
echo $sectionHtml;
?>

  <unique>
  <button onclick="savePageAsHTML()">Save Page as HTML</button>
  <script>
    function savePageAsHTML() {
      var placeholder = document.querySelector('unique');
      placeholder.parentNode.removeChild(placeholder);
      var html = document.documentElement.outerHTML;
      var filename = 'dyingfedi.html';
      var element = document.createElement('a');
      element.setAttribute('href', 'data:text/html;charset=utf-8,' + encodeURIComponent(html));
      element.setAttribute('download', filename);
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      document.body.appendChild(placeholder);
    }
  </script>
  </unique>