



<?php
// Pleroma/Akkoma admin: login + user manager (approve / deactivate / reactivate)
// session_start() must run before any output.
session_start();

const VERIFY_SSL      = true; // set to false only if your host has no CA bundle (cURL error 60)
const USER_AGENT      = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36';
const OAUTH_SCOPE     = 'read write follow push admin:read admin:write';
const PROTECTED_USERS = ['admin', 'alcea']; // can never be changed, enforced on the server too

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function http_request(string $url, array $opts = []): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, $opts + [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERAGENT      => USER_AGENT,
        CURLOPT_SSL_VERIFYPEER => VERIFY_SSL,
        CURLOPT_SSL_VERIFYHOST => VERIFY_SSL ? 2 : 0,
        CURLOPT_TIMEOUT        => 30,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    return ['code' => $code, 'body' => is_string($body) ? $body : '', 'error' => $err];
}

function oauth_login(string $base, string $user, string $pass): array {
    $r = http_request($base . '/oauth/token', [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'grant_type'    => 'password',
            'username'      => $user,
            'password'      => $pass,
            'scope'         => OAUTH_SCOPE,
            // default AdminFE client credentials
            'client_id'     => 'ECfTrzsW11bkG7simInOJf614Ee2sBhOlvE-69KDMzs',
            'client_secret' => 'r5EbNudkfePUwvRmc7DbafP0yOXpUC4lvipSrU8QOpo',
        ]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded', 'Accept: application/json'],
    ]);
    $d = json_decode($r['body'], true);
    if ($r['code'] === 200 && !empty($d['access_token'])) {
        return ['ok' => true, 'token' => $d['access_token']];
    }
    $msg = is_array($d) ? ($d['error_description'] ?? $d['error'] ?? 'Login failed') : 'Login failed';
    $msg .= ' (HTTP ' . $r['code'] . ')';
    if ($r['error']) $msg .= ' cURL: ' . $r['error'];
    return ['ok' => false, 'message' => $msg];
}

// Always talk to the instance over https, whatever scheme was typed in.
function instance_base(): string {
    $host = preg_replace('#^https?://#', '', rtrim($_SESSION['base_url'] ?? '', '/'));
    return 'https://' . $host;
}

$hasAuth = !empty($_SESSION['bearer_token']) && !empty($_SESSION['base_url']);

// ---------- AJAX: user actions (plain urlencoded POST, NO multipart) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    header('Content-Type: application/json; charset=utf-8');

    if (!$hasAuth) {
        echo json_encode(['success' => false, 'error' => 'Not authenticated']);
        exit;
    }

    $action   = $_POST['action'] ?? '';
    $nickname = trim($_POST['nickname'] ?? '');

    if (!in_array($action, ['approve', 'deactivate', 'activate'], true)) {
        echo json_encode(['success' => false, 'error' => 'Unknown action']);
        exit;
    }
    if ($nickname === '' || !preg_match('/^[A-Za-z0-9_.-]+$/', $nickname)) {
        echo json_encode(['success' => false, 'error' => 'Invalid nickname']);
        exit;
    }
    if (in_array(strtolower($nickname), PROTECTED_USERS, true)) {
        echo json_encode(['success' => false, 'error' => 'Protected user cannot be modified']);
        exit;
    }

    $r = http_request(instance_base() . '/api/v1/pleroma/admin/users/' . $action, [
        CURLOPT_CUSTOMREQUEST => 'PATCH',
        CURLOPT_POSTFIELDS    => json_encode(['nicknames' => [$nickname]]),
        CURLOPT_HTTPHEADER    => [
            'Authorization: Bearer ' . $_SESSION['bearer_token'],
            'Content-Type: application/json',
            'Accept: application/json',
        ],
    ]);

    if ($r['code'] >= 200 && $r['code'] < 300) {
        echo json_encode(['success' => true]);
    } else {
        if ($r['code'] === 401) { $_SESSION = []; }
        $detail = trim(preg_replace('/\s+/', ' ', substr($r['body'], 0, 200)));
        echo json_encode(['success' => false, 'error' => 'HTTP ' . $r['code']
            . ($r['error'] ? ' ' . $r['error'] : '') . ($detail ? ': ' . $detail : '')]);
    }
    exit;
}

// ---------- login form ----------
$loginMsg = null; // ['ok'=>bool,'text'=>string]
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
    $serverUrl = trim($_POST['server_url'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $password  = $_POST['password'] ?? '';

    if ($serverUrl === '' || $username === '' || $password === '') {
        $loginMsg = ['ok' => false, 'text' => 'Please fill all fields.'];
    } elseif (!filter_var($serverUrl, FILTER_VALIDATE_URL)) {
        $loginMsg = ['ok' => false, 'text' => 'Invalid URL.'];
    } else {
        $res = oauth_login(rtrim($serverUrl, '/'), $username, $password);
        if ($res['ok']) {
            $_SESSION['base_url']     = rtrim($serverUrl, '/');
            $_SESSION['bearer_token'] = $res['token'];
            $loginMsg = ['ok' => true, 'text' => 'Logged in.'];
        } else {
            $loginMsg = ['ok' => false, 'text' => $res['message']];
        }
    }
    $hasAuth = !empty($_SESSION['bearer_token']) && !empty($_SESSION['base_url']);
}

// POST target without query string, so secrets never ride along in the form request
$action = strtok($_SERVER['REQUEST_URI'], '?');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pleroma/Akkoma Admin – Login + User Manager</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; background: #fff; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .tabs { display: flex; background: #8e44ad; border-radius: 10px 10px 0 0; }
        .tab { flex: 1; padding: 16px; text-align: center; color: white; font-weight: bold; cursor: pointer; }
        .tab.active { background: #9b59b6; }
        .panel { padding: 30px; display: none; }
        .panel.active { display: block; }
        h1 { color: #333; border-bottom: 2px solid #8e44ad; padding-bottom: 10px; }
        .warning { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        input[type="text"], input[type="password"], input[type="url"] {
            width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; box-sizing: border-box;
        }
        button { background: #8e44ad; color: white; padding: 12px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; width: 100%; }
        button:hover { background: #9b59b6; }
        .result { margin-top: 30px; padding: 20px; border-radius: 5px; }
        .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
        .user-list { margin-top: 20px; }
        .user-item { border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px; background: #fafafa; }
        .user-item a { color: #8e44ad; text-decoration: none; font-weight: bold; }
        .user-item a:hover { text-decoration: underline; }
        .status-active { color: green; font-weight: bold; }
        .status-pending { color: orange; font-weight: bold; }
        .status-inactive { color: red; font-weight: bold; }
        .action-buttons { margin-top: 10px; display: flex; gap: 8px; flex-wrap: wrap; }
        .action-btn { flex: 1; min-width: 80px; padding: 5px 12px; border: none; border-radius: 3px; cursor: pointer; font-size: 12px; text-align: center; width: auto; }
        .btn-approve { background: #28a745; color: white; }
        .btn-deactivate { background: #ffc107; color: #333; }
        .btn-activate { background: #17a2b8; color: white; }
        .btn-disabled { background: #6c757d; color: white; cursor: not-allowed; opacity: 0.6; flex: 1; min-width: 80px; padding: 5px 12px; border: none; border-radius: 3px; font-size: 12px; text-align: center; width: auto; }
        .user-link { display: inline-block; margin-left: 10px; font-size: 12px; background: #8e44ad; color: white !important; padding: 2px 8px; border-radius: 3px; text-decoration: none; }
        .user-link:hover { background: #9b59b6; }
        .loading { opacity: 0.5; pointer-events: none; }
        .toast { position: fixed; bottom: 20px; right: 20px; padding: 12px 20px; border-radius: 5px; color: white; z-index: 1000; max-width: 80vw; }
        .toast-success { background: #28a745; }
        .toast-error { background: #dc3545; }
        .debug { background: #e2e3e5; padding: 12px; border-radius: 5px; margin: 10px 0; white-space: pre-wrap; word-wrap: break-word; font-size: 11px; overflow: auto; max-height: 400px; font-family: monospace; }
    </style>
</head>
<body data-loggedin="<?= $hasAuth ? '1' : '0' ?>">
<div class="container">
    <div class="tabs">
        <div class="tab <?= !$hasAuth ? 'active' : '' ?>" data-tab="login">1. Admin Login</div>
        <div class="tab <?= $hasAuth ? 'active' : '' ?>" data-tab="users">2. User Management <a target="_blank" href="https://fba.ryona.agency/?domain=alceawis.com">DeFed</a>  <a target="_blank" href="https://alceawis.com/pleroma/admin/#/users/index">AdminLogin</a></div>
    </div>

    <!-- Login Panel -->
    <div id="login" class="panel <?= !$hasAuth ? 'active' : '' ?>">
        <h1>🔐 Admin Login (OAuth)</h1>
        <div class="warning">
            <strong>⚠️ Administrators only!</strong><br>
            Prefill via URL fragment: <code>#instance=https%3A%2F%2Fexample.com&amp;user=you%40example.com&amp;password=secret</code>
            (a literal <code>+</code> in the password must be written <code>%2B</code>).
        </div>

        <form method="POST" action="<?= h($action) ?>" id="loginForm">
            <label>Server URL:</label>
            <input type="url" name="server_url" id="server_url" placeholder="https://your-instance.com" required
                   value="<?= h($_POST['server_url'] ?? $_SESSION['base_url'] ?? '') ?>">

            <label>Admin Username/Email:</label>
            <input type="text" name="username" id="username" placeholder="admin@domain.com" required autocomplete="username"
                   value="<?= h($_POST['username'] ?? '') ?>">

            <label>Admin Password:</label>
            <input type="password" name="password" id="password" required autocomplete="current-password">

            <button type="submit" name="admin_login">Login as Admin</button>
        </form>

        <?php if ($loginMsg): ?>
            <div class="result <?= $loginMsg['ok'] ? 'success' : 'error' ?>">
                <?= $loginMsg['ok'] ? '✅' : '❌' ?> <?= h($loginMsg['text']) ?>
                <?php if ($loginMsg['ok']): ?><br>Open the "User Management" tab.<?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- User Management Panel -->
    <div id="users" class="panel <?= $hasAuth ? 'active' : '' ?>">
        <h1>👥 User Management</h1>

        <?php if ($hasAuth):
            $base     = instance_base();
            $instance = preg_replace('#^https://#', '', $base);
            $token    = $_SESSION['bearer_token'];
            $auth     = ['Authorization: Bearer ' . $token, 'Accept: application/json'];
        ?>
            <div class="warning"><strong>Connected to: <?= h($_SESSION['base_url']) ?></strong></div>

            <?php
            $apiUrl = $base . '/api/v1/pleroma/admin/users?filters=local&page_size=20&page=1';
            $r      = http_request($apiUrl, [CURLOPT_HTTPHEADER => $auth]);

            if ($r['code'] === 200) {
                $data  = json_decode($r['body'], true);
                $users = $data['users'] ?? $data;

                if (is_array($users) && count($users) > 0) {
                    echo '<div class="user-list">';
                    echo '<h2>Latest local users on ' . h($instance) . '</h2>';

                    $count = 0;
                    foreach ($users as $entry) {
                        if ($count >= 20) break;

                        $u        = $entry['user'] ?? $entry;
                        $username = $u['nickname'] ?? $u['username'] ?? $u['acct'] ?? null;
                        if (!$username) continue;
                        if (strpos($username, '@') !== false) $username = explode('@', $username)[0];

                        $isProtected = in_array(strtolower($username), PROTECTED_USERS, true);

                        $acct  = http_request($base . '/api/v1/accounts/lookup?acct=' . urlencode($username), [
                            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token],
                            CURLOPT_TIMEOUT    => 10,
                        ]);
                        $posts = 0;
                        if ($acct['body'] !== '') {
                            $ad    = json_decode($acct['body'], true);
                            $posts = $ad['statuses_count'] ?? 0;
                        }

                        $registrationDate = $u['created_at'] ?? $u['inserted_at'] ?? null;
                        $isActive    = isset($u['is_active'])    ? (bool)$u['is_active']    : true;
                        $isConfirmed = isset($u['is_confirmed']) ? (bool)$u['is_confirmed'] : true;
                        $isApproved  = isset($u['is_approved'])  ? (bool)$u['is_approved']  : true;

                        if (!$isActive) {
                            $statusMessage = '❌ Deactivated';
                            $statusClass   = 'status-inactive';
                            $buttons = [['action' => 'activate', 'text' => '🔓 Reactivate', 'class' => 'btn-activate']];
                        } elseif (!$isConfirmed) {
                            $statusMessage = '⏳ Unconfirmed Email';
                            $statusClass   = 'status-pending';
                            $buttons = [['action' => 'deactivate', 'text' => '🔒 Deactivate', 'class' => 'btn-deactivate']];
                        } elseif (!$isApproved) {
                            $statusMessage = '⏳ Pending Approval';
                            $statusClass   = 'status-pending';
                            $buttons = [
                                ['action' => 'approve',    'text' => '✓ Approve',      'class' => 'btn-approve'],
                                ['action' => 'deactivate', 'text' => '🔒 Deactivate', 'class' => 'btn-deactivate'],
                            ];
                        } else {
                            $statusMessage = '✅ Active';
                            $statusClass   = 'status-active';
                            $buttons = [['action' => 'deactivate', 'text' => '🔒 Deactivate', 'class' => 'btn-deactivate']];
                        }

                        $formattedDate = $registrationDate ? date('Y-m-d H:i:s', strtotime($registrationDate)) : 'Unknown';
                        $profileUrl    = $base . '/@' . rawurlencode($username);

                        echo '<div class="user-item" data-nickname="' . h($username) . '">';
                        echo '<a href="' . h($profileUrl) . '" target="_blank" rel="noopener">@' . h($username) . '</a>';
                        echo '<a href="userpanel.php?user=' . h(urlencode($username)) . '" class="user-link" target="_blank">⚙️ Panel</a><br>';
                        echo 'Posts: ' . (int)$posts . '<br>';
                        echo 'Status: <span class="' . $statusClass . '">' . $statusMessage . '</span><br>';
                        echo 'Registered: ' . h($formattedDate) . '<br>';

                        echo '<div class="action-buttons">';
                        foreach ($buttons as $btn) {
                            if ($isProtected) {
                                echo '<button class="btn-disabled" disabled title="Protected user cannot be modified">' . $btn['text'] . '</button>';
                            } else {
                                echo '<button class="action-btn ' . $btn['class'] . '" data-action="' . $btn['action']
                                   . '" data-nickname="' . h($username) . '">' . $btn['text'] . '</button>';
                            }
                        }
                        echo '</div></div>';

                        $count++;
                    }
                    echo '</div>';
                } else {
                    echo '<div class="result error">No users found or unexpected response format.</div>';
                    echo '<div class="debug">Response: ' . h(substr($r['body'], 0, 1000)) . '</div>';
                }
            } else {
                echo '<div class="result error">';
                echo '<strong>Failed to fetch users (HTTP ' . (int)$r['code'] . ')</strong><br>';
                echo 'URL: ' . h($apiUrl) . '<br>';
                if ($r['error']) echo 'cURL Error: ' . h($r['error']) . '<br>';
                echo '</div>';
                echo '<div class="debug"><strong>Response Body:</strong><br>' . h(substr($r['body'], 0, 1000)) . '</div>';
            }
            ?>
        <?php else: ?>
            <div class="result error">
                <strong>No active admin session.</strong><br>
                Please log in first on the Login tab.
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    function showToast(msg, type) {
        var toast = document.createElement('div');
        toast.className = 'toast toast-' + type;
        toast.textContent = msg;
        document.body.appendChild(toast);
        setTimeout(function () { toast.remove(); }, 4000);
    }

    async function handleUserAction(nickname, action) {
        var msg = '';
        if (action === 'approve')    msg = 'Approve user @' + nickname + '?';
        if (action === 'deactivate') msg = 'Deactivate user @' + nickname + '?';
        if (action === 'activate')   msg = 'Reactivate user @' + nickname + '?';
        if (!confirm(msg)) return;

        var item = Array.from(document.querySelectorAll('.user-item')).find(function (el) {
            return el.dataset.nickname === nickname;
        });
        if (item) item.classList.add('loading');

        try {
            // Plain urlencoded POST. Multipart (FormData) is blocked by the host since PHP2Shell.
            var body = new URLSearchParams({ ajax: '1', action: action, nickname: nickname });
            var resp = await fetch(window.location.pathname, { method: 'POST', body: body });
            var text = await resp.text();

            var result;
            try {
                result = JSON.parse(text);
            } catch (e) {
                // not JSON: a firewall or error page answered instead of this script
                showToast('❌ HTTP ' + resp.status + ': ' + text.replace(/\s+/g, ' ').slice(0, 120), 'error');
                if (item) item.classList.remove('loading');
                return;
            }

            if (result.success) {
                showToast('✅ ' + action + 'd @' + nickname, 'success');
                setTimeout(function () { location.reload(); }, 1000);
            } else {
                showToast('❌ Failed: ' + (result.error || 'Unknown'), 'error');
                if (item) item.classList.remove('loading');
            }
        } catch (e) {
            showToast('❌ Error: ' + e.message, 'error');
            if (item) item.classList.remove('loading');
        }
    }

    document.querySelectorAll('.tab').forEach(function (tab) {
        tab.addEventListener('click', function () {
            document.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('active'); });
            document.querySelectorAll('.panel').forEach(function (p) { p.classList.remove('active'); });
            tab.classList.add('active');
            document.getElementById(tab.dataset.tab).classList.add('active');
        });
    });

    // ---- prefill from #fragment (preferred) or ?query, then scrub the URL and auto-login ----
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.action-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                handleUserAction(btn.dataset.nickname, btn.dataset.action);
            });
        });

        var fromHash  = new URLSearchParams(location.hash.replace(/^#/, ''));
        var fromQuery = new URLSearchParams(location.search);
        var get = function (k) { var v = fromHash.get(k); return v !== null ? v : fromQuery.get(k); }; // already decoded

        var instance = get('instance'), user = get('user'), password = get('password');
        if (!instance && !user && !password) return;

        var form = document.getElementById('loginForm');
        if (!form) return;
        if (instance) form.querySelector('[name="server_url"]').value = instance;
        if (user)     form.querySelector('[name="username"]').value   = user;
        if (password) form.querySelector('[name="password"]').value   = password;

        history.replaceState(null, '', location.pathname); // remove secrets from address bar / history

        if (instance && user && password && document.body.dataset.loggedin !== '1') {
            form.querySelector('[name="admin_login"]').click();
        }
    });
</script>
</body>
</html>