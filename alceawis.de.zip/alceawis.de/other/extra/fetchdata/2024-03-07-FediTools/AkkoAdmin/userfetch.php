<?php
session_start();

class PleromaAdminAuth {
    private $baseUrl;
    private $userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';
    private $cookieFile;

    public function __construct($baseUrl) {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->cookieFile = sys_get_temp_dir() . '/pleroma_admin_cookies_' . session_id() . '.txt';
    }

    public function login($username, $password) {
        $adminPage = $this->baseUrl . '/pleroma/admin/';
        $ch = curl_init($adminPage);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => $this->userAgent,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_COOKIEJAR => $this->cookieFile,
            CURLOPT_COOKIEFILE => $this->cookieFile,
            CURLOPT_TIMEOUT => 30
        ]);
        curl_exec($ch);
        curl_close($ch);

        $oauthUrl = $this->baseUrl . '/oauth/token';
        $postData = [
            'grant_type' => 'password',
            'username' => $username,
            'password' => $password,
            'client_id' => 'ECfTrzsW11bkG7simInOJf614Ee2sBhOlvE-69KDMzs',
            'client_secret' => 'r5EbNudkfePUwvRmc7DbafP0yOXpUC4lvipSrU8QOpo',
        ];

        $ch = curl_init($oauthUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($postData),
            CURLOPT_USERAGENT => $this->userAgent,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_COOKIEJAR => $this->cookieFile,
            CURLOPT_COOKIEFILE => $this->cookieFile,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/x-www-form-urlencoded',
                'Accept: application/json'
            ],
            CURLOPT_TIMEOUT => 30
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);

        if ($httpCode === 200 && isset($data['access_token'])) {
            $_SESSION['bearer_token'] = $data['access_token'];
            return ['success' => true, 'message' => 'Admin OAuth login successful', 'token' => $data['access_token']];
        }

        return ['success' => false, 'message' => 'Login failed', 'http_code' => $httpCode, 'response' => $response];
    }

    public function cleanup() {
        if (file_exists($this->cookieFile)) {
            unlink($this->cookieFile);
        }
    }
}

// Handle AJAX requests for user actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['bearer_token']) || !isset($_SESSION['base_url'])) {
        echo json_encode(['success' => false, 'error' => 'Not authenticated']);
        exit;
    }
    
    $action = $_POST['action'] ?? '';
    $nickname = $_POST['nickname'] ?? '';
    $instance = preg_replace('#^https?://#', '', rtrim($_SESSION['base_url'], '/'));
    $token = $_SESSION['bearer_token'];
    
    $apiBase = "https://$instance/api/v1/pleroma/admin/users";
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'Accept: application/json'
        ]
    ]);
    
    switch ($action) {
        case 'approve':
            curl_setopt($ch, CURLOPT_URL, $apiBase . '/approve');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['nicknames' => [$nickname]]));
            break;
        case 'deactivate':
            curl_setopt($ch, CURLOPT_URL, $apiBase . '/deactivate');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['nicknames' => [$nickname]]));
            break;
        case 'activate':
            curl_setopt($ch, CURLOPT_URL, $apiBase . '/activate');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['nicknames' => [$nickname]]));
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown action']);
            exit;
    }
    
    $responseBody = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode >= 200 && $httpCode < 300) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => "HTTP $httpCode"]);
    }
    exit;
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
    $serverUrl = trim($_POST['server_url']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    if ($serverUrl && $username && $password) {
        $auth = new PleromaAdminAuth($serverUrl);
        $result = $auth->login($username, $password);
        
        if ($result['success']) {
            $_SESSION['base_url'] = $serverUrl;
            $_SESSION['bearer_token'] = $result['token'];
            $loginSuccess = true;
            $bearerToken = $result['token'];
        } else {
            $error = $result['message'];
            if (isset($result['http_code'])) $error .= " (HTTP " . $result['http_code'] . ")";
        }
    } else {
        $error = 'Please fill all fields';
    }
}

$hasAuth = isset($_SESSION['bearer_token']) && isset($_SESSION['base_url']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pleroma/Akkoma Admin – Login + User Manager</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; background: #fff; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .tabs { display: flex; background: #8e44ad; border-radius: 10px 10px 0 0; }
        .tab { flex: 1; padding: 16px; text-align: center; color: white; font-weight: bold; cursor: pointer; }
        .tab.active { background: #9b59b6; }
        .panel { padding: 30px; display: none; }
        .panel.active { display: block; }
        h1 { color: #333; border-bottom: 2px solid #8e44ad; padding-bottom: 10px; }
        .warning { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        input[type="text"], input[type="password"], input[type="url"] {
            width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; box-sizing: border-box;
        }
        button { background: #8e44ad; color: white; padding: 12px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; width: 100%; }
        button:hover { background: #9b59b6; }
        .result { margin-top: 30px; padding: 20px; border-radius: 5px; }
        .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
        .token-box { background: #f3e8ff; padding: 12px; border-radius: 5px; margin: 10px 0; word-break: break-all; font-family: monospace; font-size: 12px; }
        .user-list { margin-top: 20px; }
        .user-item { border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px; background: #fafafa; }
        .user-item a { color: #8e44ad; text-decoration: none; font-weight: bold; }
        .user-item a:hover { text-decoration: underline; }
        .status-active { color: green; font-weight: bold; }
        .status-pending { color: orange; font-weight: bold; }
        .status-inactive { color: red; font-weight: bold; }
        .action-buttons { margin-top: 10px; display: flex; gap: 8px; flex-wrap: wrap; }
        .action-btn { flex: 1; min-width: 80px; padding: 5px 12px; border: none; border-radius: 3px; cursor: pointer; font-size: 12px; text-align: center; }
        .btn-approve { background: #28a745; color: white; }
        .btn-deactivate { background: #ffc107; color: #333; }
        .btn-activate { background: #17a2b8; color: white; }
        .btn-disabled { background: #6c757d; color: white; cursor: not-allowed; opacity: 0.6; flex: 1; min-width: 80px; padding: 5px 12px; border: none; border-radius: 3px; font-size: 12px; text-align: center; }
        .user-link { display: inline-block; margin-left: 10px; font-size: 12px; background: #8e44ad; color: white; padding: 2px 8px; border-radius: 3px; text-decoration: none; }
        .user-link:hover { background: #9b59b6; }
        .loading { opacity: 0.5; pointer-events: none; }
        .toast { position: fixed; bottom: 20px; right: 20px; padding: 12px 20px; border-radius: 5px; color: white; z-index: 1000; }
        .toast-success { background: #28a745; }
        .toast-error { background: #dc3545; }
        .debug { background: #e2e3e5; padding: 12px; border-radius: 5px; margin: 10px 0; white-space: pre-wrap; word-wrap: break-word; font-size: 11px; overflow: auto; max-height: 400px; font-family: monospace; }
    </style>
</head>
<body>
<div class="container">
    <div class="tabs">
        <div class="tab <?php echo !$hasAuth ? 'active' : ''; ?>" data-tab="login">1. Admin Login</div>
        <div class="tab <?php echo $hasAuth ? 'active' : ''; ?>" data-tab="users">2. User Management</div>
    </div>

    <!-- Login Panel -->
    <div id="login" class="panel <?php echo !$hasAuth ? 'active' : ''; ?>">
        <h1>🔐 Admin Login (OAuth)</h1>
        <div class="warning">
            <strong>⚠️ Administrators only!</strong><br>
            Uses the same OAuth password flow as the official admin panel.
        </div>

        <form method="POST" id="loginForm">
            <label>Server URL:</label>
            <input type="url" name="server_url" id="server_url" placeholder="https://your-instance.com" required
                   value="<?php echo htmlspecialchars($_POST['server_url'] ?? $_SESSION['base_url'] ?? ''); ?>">

            <label>Admin Username/Email:</label>
            <input type="text" name="username" id="username" placeholder="admin@domain.com" required
                   value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">

            <label>Admin Password:</label>
            <input type="password" name="password" id="password" required>

            <button type="submit" name="admin_login">Login as Admin</button>
        </form>

        <?php if (isset($loginSuccess) && $loginSuccess): ?>
            <div class="result success">
                <h3>✅ Login Successful!</h3>
                <p>You are now authenticated.</p>
                <div class="token-box">
                    <strong>Bearer Token:</strong><br>
                    <?php echo htmlspecialchars($_SESSION['bearer_token']); ?>
                </div>
                <p>Click the "User Management" tab to view users.</p>
            </div>
        <?php elseif (isset($error)): ?>
            <div class="result error">
                <h3>❌ Login Failed</h3>
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>
    </div>

    <!-- User Management Panel -->
    <div id="users" class="panel <?php echo $hasAuth ? 'active' : ''; ?>">
        <h1>👥 User Management</h1>
        
        <?php if ($hasAuth): 
            $instance = preg_replace('#^https?://#', '', rtrim($_SESSION['base_url'], '/'));
            $token = $_SESSION['bearer_token'];
        ?>
            <div class="warning">
                <strong>Connected to: <?php echo htmlspecialchars($_SESSION['base_url']); ?></strong><br>
                Token: <?php echo substr(htmlspecialchars($token), 0, 50); ?>...
            </div>
            
            <?php
            $apiUrl = "https://$instance/api/v1/pleroma/admin/users?filters=local&page_size=20&page=1";
            
            $ch = curl_init($apiUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $token,
                    'Accept: application/json'
                ],
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HEADER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $headers = substr($response, 0, $headerSize);
            $body = substr($response, $headerSize);
            $curlError = curl_error($ch);
            curl_close($ch);
            
            if ($httpCode === 200) {
                $data = json_decode($body, true);
                $users = $data['users'] ?? $data;
                
                if (is_array($users) && count($users) > 0) {
                    echo '<div class="user-list">';
                    echo "<h2>Latest local users on $instance</h2>";
                    
                    $count = 0;
                    foreach ($users as $entry) {
                        if ($count >= 20) break;
                        
                        $u = $entry['user'] ?? $entry;
                        $username = $u['nickname'] ?? $u['username'] ?? $u['acct'] ?? null;
                        
                        if (!$username) continue;
                        if (strpos($username, '@') !== false) {
                            $username = explode('@', $username)[0];
                        }
                        
                        // Check if user is protected (admin or alcea)
                        $isProtected = ($username === 'admin' || $username === 'alcea');
                        
                        $acctUrl = "https://$instance/api/v1/accounts/lookup?acct=" . urlencode($username);
                        $acctCh = curl_init($acctUrl);
                        curl_setopt_array($acctCh, [
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token],
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_SSL_VERIFYHOST => false,
                            CURLOPT_TIMEOUT => 10
                        ]);
                        $acctResponse = curl_exec($acctCh);
                        curl_close($acctCh);
                        
                        $posts = 0;
                        if ($acctResponse) {
                            $acctData = json_decode($acctResponse, true);
                            $posts = $acctData['statuses_count'] ?? 0;
                        }
                        
                        $registrationDate = $u['created_at'] ?? $u['inserted_at'] ?? null;
                        $isActive = isset($u['is_active']) ? (bool)$u['is_active'] : true;
                        $isConfirmed = isset($u['is_confirmed']) ? (bool)$u['is_confirmed'] : true;
                        $isApproved = isset($u['is_approved']) ? (bool)$u['is_approved'] : true;
                        
                        if (!$isActive) {
                            $statusMessage = "❌ Deactivated";
                            $statusClass = "status-inactive";
                            $buttons = [
                                ['action' => 'activate', 'text' => '🔓 Reactivate', 'class' => 'btn-activate']
                            ];
                        } elseif (!$isConfirmed) {
                            $statusMessage = "⏳ Unconfirmed Email";
                            $statusClass = "status-pending";
                            $buttons = [
                                ['action' => 'deactivate', 'text' => '🔒 Deactivate', 'class' => 'btn-deactivate']
                            ];
                        } elseif (!$isApproved) {
                            $statusMessage = "⏳ Pending Approval";
                            $statusClass = "status-pending";
                            $buttons = [
                                ['action' => 'approve', 'text' => '✓ Approve', 'class' => 'btn-approve'],
                                ['action' => 'deactivate', 'text' => '🔒 Deactivate', 'class' => 'btn-deactivate']
                            ];
                        } else {
                            $statusMessage = "✅ Active";
                            $statusClass = "status-active";
                            $buttons = [
                                ['action' => 'deactivate', 'text' => '🔒 Deactivate', 'class' => 'btn-deactivate']
                            ];
                        }
                        
                        $formattedDate = $registrationDate ? date('Y-m-d H:i:s', strtotime($registrationDate)) : 'Unknown';
                        $profileUrl = "https://$instance/@$username";
                        
                        echo "<div class='user-item' data-nickname='" . htmlspecialchars($username) . "'>";
                        echo "<a href='$profileUrl' target='_blank'>@$username</a>";
                        echo "<a href='userpanel.php?user=" . urlencode($username) . "' class='user-link' target='_blank'>⚙️ Panel</a><br>";
                        echo "Posts: $posts<br>";
                        echo "Status: <span class='$statusClass'>$statusMessage</span><br>";
                        echo "Registered: $formattedDate<br>";
                        
                        echo "<div class='action-buttons'>";
                        foreach ($buttons as $btn) {
                            if ($isProtected) {
                                echo "<button class='btn-disabled' disabled title='Protected user cannot be modified'>{$btn['text']}</button>";
                            } else {
                                echo "<button class='action-btn {$btn['class']}' data-action='{$btn['action']}' data-nickname='" . htmlspecialchars($username) . "'>{$btn['text']}</button>";
                            }
                        }
                        echo "</div>";
                        echo "</div>";
                        
                        $count++;
                    }
                    echo "</div>";
                } else {
                    echo '<div class="result error">No users found or unexpected response format.</div>';
                    echo '<div class="debug">Response: ' . htmlspecialchars(substr($body, 0, 1000)) . '</div>';
                }
            } else {
                echo '<div class="result error">';
                echo "<strong>Failed to fetch users (HTTP $httpCode)</strong><br>";
                echo "URL: " . htmlspecialchars($apiUrl) . "<br>";
                if ($curlError) echo "cURL Error: " . htmlspecialchars($curlError) . "<br>";
                echo '</div>';
                echo '<div class="debug">';
                echo "<strong>Response Headers:</strong><br>" . htmlspecialchars($headers) . "<br><br>";
                echo "<strong>Response Body:</strong><br>" . htmlspecialchars(substr($body, 0, 1000));
                echo '</div>';
            }
            ?>
        <?php else: ?>
            <div class="result error">
                <strong>No active admin session.</strong><br>
                Please log in first on the Login tab.
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    function showToast(msg, type) {
        var toast = document.createElement('div');
        toast.className = 'toast toast-' + type;
        toast.textContent = msg;
        document.body.appendChild(toast);
        setTimeout(function() { toast.remove(); }, 3000);
    }

    async function handleUserAction(nickname, action) {
        var msg = '';
        if (action === 'approve') msg = 'Approve user @' + nickname + '?';
        if (action === 'deactivate') msg = 'Deactivate user @' + nickname + '?';
        if (action === 'activate') msg = 'Reactivate user @' + nickname + '?';
        if (!confirm(msg)) return;
        
        var item = document.querySelector('.user-item[data-nickname="' + nickname + '"]');
        if (item) item.classList.add('loading');
        
        try {
            var fd = new FormData();
            fd.append('action', action);
            fd.append('nickname', nickname);
            var resp = await fetch(window.location.href, {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: fd
            });
            var result = await resp.json();
            if (result.success) {
                showToast('✅ ' + action + 'd @' + nickname, 'success');
                setTimeout(function() { location.reload(); }, 1000);
            } else {
                showToast('❌ Failed: ' + (result.error || 'Unknown'), 'error');
                if (item) item.classList.remove('loading');
            }
        } catch(e) {
            showToast('❌ Error: ' + e.message, 'error');
            if (item) item.classList.remove('loading');
        }
    }

    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
            tab.classList.add('active');
            document.getElementById(tab.dataset.tab).classList.add('active');
        });
    });

    function getQueryParam(param) {
        return new URLSearchParams(window.location.search).get(param);
    }

    function prefillFromQueryParams() {
        var instance = getQueryParam('instance');
        var user = getQueryParam('user');
        var password = getQueryParam('password');
        
        if (instance) {
            var serverUrlInput = document.querySelector('input[name="server_url"]');
            if (serverUrlInput) serverUrlInput.value = decodeURIComponent(instance);
        }
        
        if (user) {
            var userInput = document.querySelector('input[name="username"]');
            if (userInput) userInput.value = decodeURIComponent(user);
        }
        
        if (password) {
            var passInput = document.querySelector('input[name="password"]');
            if (passInput) passInput.value = decodeURIComponent(password);
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        prefillFromQueryParams();
        document.querySelectorAll('.action-btn:not(.btn-disabled)').forEach(function(btn) {
            var action = btn.dataset.action;
            var nickname = btn.dataset.nickname;
            btn.addEventListener('click', function() { handleUserAction(nickname, action); });
        });
    });
</script>
</body>
</html>