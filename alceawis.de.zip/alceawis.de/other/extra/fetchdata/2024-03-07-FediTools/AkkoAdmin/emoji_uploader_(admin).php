<?php
// Pleroma/Akkoma admin login + emoji uploader
// IMPORTANT: session_start() must run before ANY output (the old version printed a <script> first).
session_start();

const VERIFY_SSL  = true; // set to false only if your host has no CA bundle (cURL error 60)
const USER_AGENT  = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36';
const OAUTH_SCOPE = 'read write follow push admin:read admin:write';
const MAX_BYTES   = 1048576; // 1 MB
const MAX_DIM     = 256;     // px

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function http_request(string $url, array $opts = []): array {
    $headers = '';
    $ch = curl_init($url);
    curl_setopt_array($ch, $opts + [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERAGENT      => USER_AGENT,
        CURLOPT_SSL_VERIFYPEER => VERIFY_SSL,
        CURLOPT_SSL_VERIFYHOST => VERIFY_SSL ? 2 : 0,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_HEADERFUNCTION => function ($c, $line) use (&$headers) {
            $headers .= $line;
            return strlen($line);
        },
    ]);
    $body = curl_exec($ch);
    $info = curl_getinfo($ch);
    $err  = curl_error($ch);
    curl_close($ch);
    return [
        'code'    => (int)$info['http_code'],
        'time'    => round($info['total_time'], 3),
        'headers' => $headers,
        'body'    => is_string($body) ? $body : '',
        'error'   => $err,
    ];
}

function oauth_login(string $base, string $user, string $pass): array {
    $r = http_request($base . '/oauth/token', [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'grant_type'    => 'password',
            'username'      => $user,
            'password'      => $pass,
            'scope'         => OAUTH_SCOPE,
            // default AdminFE client credentials
            'client_id'     => 'ECfTrzsW11bkG7simInOJf614Ee2sBhOlvE-69KDMzs',
            'client_secret' => 'r5EbNudkfePUwvRmc7DbafP0yOXpUC4lvipSrU8QOpo',
        ]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded', 'Accept: application/json'],
    ]);
    $d = json_decode($r['body'], true);
    if ($r['code'] === 200 && !empty($d['access_token'])) {
        return ['ok' => true, 'token' => $d['access_token'], 'scope' => $d['scope'] ?? ''];
    }
    $msg = is_array($d) ? ($d['error_description'] ?? $d['error'] ?? 'Login failed') : 'Login failed';
    return ['ok' => false, 'message' => $msg, 'code' => $r['code'], 'curl_error' => $r['error']];
}

// Ask the instance which emoji packs exist and which shortcodes they already contain.
function fetch_packs(string $base, string $token): array {
    $r = http_request($base . '/api/v1/pleroma/emoji/packs?page_size=100', [
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Accept: application/json'],
    ]);
    $d = json_decode($r['body'], true);
    if ($r['code'] === 200 && is_array($d) && isset($d['packs']) && is_array($d['packs'])) {
        $out = [];
        foreach ($d['packs'] as $name => $p) {
            $out[(string)$name] = array_map('strval', array_keys($p['files'] ?? []));
        }
        return ['ok' => true, 'packs' => $out];
    }
    return ['ok' => false, 'error' => 'HTTP ' . $r['code'] . ($r['error'] ? ' ' . $r['error'] : '')];
}

function validate_upload(?array $f, bool $viaBase64 = false): string {
    if (!$f)                                  return 'No file received.';
    if ($f['error'] !== UPLOAD_ERR_OK)        return 'Upload error code: ' . $f['error'];
    if (!$viaBase64 && !is_uploaded_file($f['tmp_name'])) return 'Not a valid uploaded file.';
    if ($f['size'] > MAX_BYTES)               return 'File too large (max 1 MB).';
    if (!preg_match('/^[a-zA-Z0-9_]+$/', pathinfo($f['name'], PATHINFO_FILENAME))) {
        return 'Shortcode (filename without extension) may only contain letters, numbers and underscores.';
    }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['png', 'gif', 'webp', 'jpg', 'jpeg'], true)) return 'Only PNG, GIF, WebP, JPG/JPEG allowed.';
    $info = getimagesize($f['tmp_name']);
    if (!$info) return 'File is not a readable image (corrupted or not an image).';
    if ($info[0] > MAX_DIM || $info[1] > MAX_DIM) {
        return 'Image dimensions ' . $info[0] . 'x' . $info[1] . ' px too large (max 256x256 px).';
    }
    $expected = ['png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg'];
    if (($info['mime'] ?? '') !== $expected[$ext]) {
        return 'Extension .' . $ext . ' does not match the real content (' . ($info['mime'] ?? 'unknown') . ').';
    }
    return '';
}

function upload_emoji(string $base, string $token, string $pack, array $f): array {
    $mime = $f['type'];
    if (!$mime || $mime === 'application/octet-stream') {
        $fi   = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($fi, $f['tmp_name']);
        finfo_close($fi);
    }
    $shortcode = pathinfo($f['name'], PATHINFO_FILENAME);
    $r = http_request($base . '/api/v1/pleroma/emoji/packs/files?name=' . urlencode($pack), [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => ['file' => new CURLFile($f['tmp_name'], $mime, $f['name'])],
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Accept: application/json'],
    ]);
    $json = json_decode($r['body'], true);
    $ok   = $r['code'] >= 200 && $r['code'] < 300;

    $hint = '';
    if (!$ok) {
        if ($r['code'] === 0)                               $hint = 'The request never reached the instance (see cURL error).';
        elseif ($r['code'] === 401)                         $hint = 'Token invalid or expired. Log in again.';
        elseif ($r['code'] === 403 && !is_array($json))     $hint = 'Non-JSON 403: a firewall/WAF in front of the instance blocked the request.';
        elseif ($r['code'] === 403)                         $hint = 'Pleroma refused the request (admin:write missing?). Log out and log in again.';
    }

    return [
        'ok'        => $ok,
        'code'      => $r['code'],
        'time'      => $r['time'],
        'shortcode' => $shortcode,
        'pack'      => $pack,
        'file'      => (is_array($json) && isset($json[$shortcode])) ? $json[$shortcode] : null,
        'body'      => $ok ? '' : substr($r['body'], 0, 1500),
        'headers'   => $r['headers'],
        'error'     => $r['error'],
        'hint'      => $hint,
    ];
}

// ---------- gallery view (?gallery=1[&last=N]) ----------
// PHP pulls every emoji image itself and embeds it as base64, so the browser never has to reach the instance's image URLs.

// Parallel HTTP requests (GET or HEAD) without any auth header (image URLs are public, never leak the token to them).
function multi_fetch(array $reqs, bool $headOnly, int $parallel = 8): array {
    $res  = [];
    $keys = array_keys($reqs);
    $n    = count($keys);
    $i    = 0;
    $map  = [];
    $mh   = curl_multi_init();

    $add = function () use (&$i, &$map, $keys, $reqs, $headOnly, $mh) {
        $key = $keys[$i++];
        $ch  = curl_init($reqs[$key]);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERAGENT      => USER_AGENT,
            CURLOPT_SSL_VERIFYPEER => VERIFY_SSL,
            CURLOPT_SSL_VERIFYHOST => VERIFY_SSL ? 2 : 0,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_NOBODY         => $headOnly,
            CURLOPT_HEADER         => true,
        ]);
        curl_multi_add_handle($mh, $ch);
        $map[spl_object_id($ch)] = $key;
    };

    while ($i < $n && count($map) < $parallel) $add();

    while ($map) {
        curl_multi_exec($mh, $running);
        while ($info = curl_multi_info_read($mh)) {
            $ch  = $info['handle'];
            $id  = spl_object_id($ch);
            $raw = (string)curl_multi_getcontent($ch);
            $hs  = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $res[$map[$id]] = [
                'code'    => (int)curl_getinfo($ch, CURLINFO_HTTP_CODE),
                'headers' => substr($raw, 0, $hs),
                'body'    => (string)substr($raw, $hs),
                'error'   => $info['result'] !== CURLE_OK ? curl_error($ch) : '',
            ];
            unset($map[$id]);
            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
            if ($i < $n) $add();
        }
        if ($map && curl_multi_select($mh, 1.0) === -1) usleep(1000);
    }
    curl_multi_close($mh);
    return $res;
}

function gallery_emoji_url(string $base, string $pack, string $sc, string $file, array $byPack, array $any): string {
    $u = $byPack[$pack][$sc] ?? $any[$sc] ?? ($base . '/emoji/' . rawurlencode($pack) . '/' . rawurlencode($file));
    return $u !== '' && $u[0] === '/' ? $base . $u : $u; // relative -> absolute
}

function gallery_flush() {
    if (function_exists('ob_get_level') && ob_get_level() > 0) @ob_flush();
    flush();
}

function gallery_figure(array $e, ?array $r, bool $showPack): string {
    $sc     = $e['sc'];
    $meta   = [];
    $broken = false;

    if ($r === null || $r['code'] !== 200 || $r['body'] === '') {
        $broken = true;
        $why = $r === null ? 'no response' : ($r['error'] ?: 'HTTP ' . $r['code']);
        $img = '<div class="failbox">⚠️ PHP could not fetch it: ' . h($why) . '</div>';
    } else {
        $body = $r['body'];
        $info = @getimagesizefromstring($body);
        if (!$info) {
            $broken = true;
            $img = '<div class="failbox">⚠️ not a readable image</div>';
        } else {
            $mime   = $info['mime'];
            $meta[] = $info[0] . '×' . $info[1];
            $meta[] = round(strlen($body) / 1024, 1) . ' KB';
            if ($mime === 'image/gif') {
                $frames = preg_match_all('/\x21\xF9\x04.{4}\x00[\x2C\x21]/s', $body);
                $meta[] = 'GIF' . ($frames > 1 ? ', ' . $frames . ' frames' : '');
            } else {
                $meta[] = strtoupper(substr($mime, 6));
            }
            $img = '<img src="data:' . h($mime) . ';base64,' . base64_encode($body) . '" alt=":' . h($sc) . ':">';
        }
    }
    if (!empty($e['mtime'])) $meta[] = gmdate('Y-m-d H:i', $e['mtime']) . ' UTC';

    return '<figure class="emo' . ($broken ? ' broken' : '') . '" data-sc="' . h(strtolower($sc)) . '" data-code=":' . h($sc)
         . ':" title="' . h($e['url']) . '">' . $img
         . '<figcaption>:' . h($sc) . ':'
         . ($showPack ? '<span class="pk">' . h($e['pack']) . '</span>' : '')
         . '<span class="dim">' . h(implode(' · ', $meta)) . '</span></figcaption></figure>';
}

function gallery_stream(array $entries, array $counts, bool $flat) {
    $cur = null;
    foreach (array_chunk($entries, 12, true) as $chunk) {
        $reqs = [];
        foreach ($chunk as $i => $e) $reqs[$i] = $e['url'];
        $got = multi_fetch($reqs, false, 8);
        foreach ($chunk as $i => $e) {
            if (!$flat && $e['pack'] !== $cur) {
                $cur = $e['pack'];
                echo '<h2 class="packh">' . h($cur) . ' <small>(' . (int)($counts[$cur] ?? 0) . ')</small></h2>';
            }
            echo gallery_figure($e, $got[$i] ?? null, $flat);
        }
        unset($got);
        gallery_flush();
    }
}

function render_gallery(bool $loggedIn, string $backUrl): void {
    @set_time_limit(300);
    @ini_set('memory_limit', '512M');
    while (ob_get_level() > 0) @ob_end_clean();
    header('Cache-Control: no-store');
    header('X-Accel-Buffering: no');

    $packs     = [];   // packName => [shortcode => filename]
    $error     = '';
    $base      = '';
    $urlByPack = [];
    $urlAny    = [];
    $entries   = [];
    $counts    = [];
    $dateNote  = '';
    $last      = (isset($_GET['last']) && ctype_digit((string)$_GET['last'])) ? max(1, min(500, (int)$_GET['last'])) : 0;

    if ($loggedIn) {
        $base = rtrim($_SESSION['base_url'], '/');
        $auth = ['Authorization: Bearer ' . $_SESSION['bearer_token'], 'Accept: application/json'];

        $page = 1;
        do {
            $r = http_request($base . '/api/v1/pleroma/emoji/packs?page_size=50&page=' . $page, [CURLOPT_HTTPHEADER => $auth]);
            $d = json_decode($r['body'], true);
            if ($r['code'] !== 200 || !is_array($d) || !isset($d['packs']) || !is_array($d['packs'])) {
                $error = 'Could not load the pack list (HTTP ' . $r['code'] . ($r['error'] ? ', ' . $r['error'] : '') . ').';
                if ($r['code'] === 401) $error .= ' Your token expired, log in again.';
                break;
            }
            $expected = (int)($d['count'] ?? count($d['packs']));
            foreach ($d['packs'] as $name => $p) {
                $packs[(string)$name] = is_array($p['files'] ?? null) ? $p['files'] : [];
            }
            $page++;
        } while (count($packs) < $expected && $page <= 20 && !empty($d['packs']));

        // the instance's own emoji URLs (public API) so image links are exact
        $c  = http_request($base . '/api/v1/custom_emojis', [CURLOPT_HTTPHEADER => ['Accept: application/json']]);
        $cd = json_decode($c['body'], true);
        if ($c['code'] === 200 && is_array($cd)) {
            foreach ($cd as $e) {
                if (!isset($e['shortcode'], $e['url'])) continue;
                $urlByPack[(string)($e['category'] ?? '')][(string)$e['shortcode']] = $e['url'];
                $urlAny[(string)$e['shortcode']] = $e['url'];
            }
        }

        // flat list: pack by pack, A-Z inside a pack; 'order' remembers the server's own order
        $off = 0;
        foreach ($packs as $pack => $files) {
            $pos = [];
            $k = 0;
            foreach ($files as $sc => $_) $pos[(string)$sc] = $k++;
            $names = array_map('strval', array_keys($files));
            usort($names, 'strcasecmp');
            foreach ($names as $sc) {
                $entries[] = [
                    'pack'  => (string)$pack,
                    'sc'    => $sc,
                    'url'   => gallery_emoji_url($base, (string)$pack, $sc, (string)($files[$sc] ?? ''), $urlByPack, $urlAny),
                    'mtime' => null,
                    'order' => $off + $pos[$sc],
                ];
            }
            $counts[(string)$pack] = count($files);
            $off += count($files);
        }
        $totalAll = count($entries);

        // &last=N: rank by the image file's Last-Modified header (= upload time), keep the newest N
        if (!$error && $last > 0 && $entries) {
            $urls = [];
            foreach ($entries as $i => $e) $urls[$i] = $e['url'];
            $heads = multi_fetch($urls, true, 16);
            $have  = 0;
            foreach ($entries as $i => $e) {
                $m = null;
                $hh = $heads[$i] ?? null;
                if ($hh && $hh['code'] === 200 && preg_match_all('/^last-modified:\s*(.+?)\s*$/im', $hh['headers'], $mm)) {
                    $t = strtotime(end($mm[1]));
                    if ($t) { $m = $t; $have++; }
                }
                $entries[$i]['mtime'] = $m;
            }
            if ($have > 0) {
                usort($entries, function ($a, $b) {
                    $c = ($b['mtime'] ?? 0) <=> ($a['mtime'] ?? 0);
                    return $c !== 0 ? $c : ($b['order'] <=> $a['order']);
                });
            } else {
                usort($entries, function ($a, $b) { return $b['order'] <=> $a['order']; });
                $dateNote = 'The instance sends no Last-Modified header for emoji files, so "newest" falls back to the last entries of the server\'s own list. That order is not guaranteed to be chronological.';
            }
            $entries = array_slice($entries, 0, $last);
        }
    }
    $showing = count($entries);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emoji gallery</title>
    <style>
        :root { --size: 96px; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; color: #333; }
        .wrap { max-width: 1400px; margin: 0 auto; }
        .bar { position: sticky; top: 0; z-index: 10; background: #8e44ad; color: #fff; padding: 12px 16px; border-radius: 10px;
               display: flex; flex-wrap: wrap; gap: 10px; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,.15); }
        .bar a { color: #fff; font-weight: bold; }
        .bar input[type=search] { padding: 8px 10px; border: none; border-radius: 5px; font-size: 15px; min-width: 180px; }
        .bar button { background: #9b59b6; color: #fff; border: 1px solid #fff5; border-radius: 5px; padding: 6px 10px; cursor: pointer; }
        .bar button.on { background: #fff; color: #8e44ad; font-weight: bold; }
        .spacer { flex: 1; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(calc(var(--size) + 24px), 1fr)); gap: 10px; margin-top: 16px; }
        .packh { grid-column: 1 / -1; border-bottom: 2px solid #8e44ad; padding-bottom: 6px; margin: 24px 0 0; }
        figure.emo { margin: 0; background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 8px; text-align: center; cursor: pointer; }
        figure.emo:hover { border-color: #8e44ad; }
        figure.emo img { width: var(--size); height: var(--size); object-fit: contain;
            background: repeating-conic-gradient(#ececec 0% 25%, #fff 0% 50%) 50% / 12px 12px; }
        figure.emo figcaption { font-size: 11px; word-break: break-all; margin-top: 4px; }
        figure.emo .dim { display: block; color: #777; font-size: 10px; }
        figure.emo .pk  { display: block; color: #8e44ad; font-size: 10px; }
        figure.emo.broken { border-color: #dc3545; background: #f8d7da; }
        figure.emo.broken .dim { color: #721c24; font-weight: bold; }
        .failbox { width: var(--size); height: var(--size); margin: 0 auto; display: flex; align-items: center; justify-content: center;
                   font-size: 11px; color: #721c24; text-align: center; }
        figure.emo.hl { outline: 3px solid #28a745; box-shadow: 0 0 12px #28a74588; }
        .msg { background: #fff; border-radius: 8px; padding: 20px; margin-top: 20px; }
        .msg.error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .msg.note { background: #fff3cd; border: 1px solid #ffeaa7; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: #28a745; color: #fff; padding: 10px 16px; border-radius: 5px; }
    </style>
</head>
<body>
<div class="wrap">
<?php if (!$loggedIn): ?>
    <div class="msg error"><strong>No active admin session.</strong><br>Log in first in the <a href="<?= h($backUrl) ?>">uploader</a>, then open the gallery link again.</div>
<?php elseif ($error): ?>
    <div class="msg error"><?= h($error) ?></div>
<?php else: ?>
    <div class="bar">
        <strong>🖼️
            <?php if ($last > 0): ?>
                newest <?= h($showing) ?> of <?= h($totalAll) ?> emoji
            <?php else: ?>
                <?= h(count($packs)) ?> pack(s), <span id="shown"><?= h($showing) ?></span> emoji
            <?php endif; ?>
        </strong>
        <input type="search" id="q" placeholder="Filter by shortcode…" autofocus>
        <span>Size:</span>
        <button data-size="48">S</button>
        <button data-size="96" class="on">M</button>
        <button data-size="160">L</button>
        <button data-size="256">XL</button>
        <span class="spacer"></span>
        <?php if ($last > 0): ?><a href="?gallery=1">Show all</a><?php endif; ?>
        <a href="">↻ Reload</a>
    </div>
    <?php if ($dateNote): ?><div class="msg note"><?= h($dateNote) ?></div><?php endif; ?>
    <?php if ($last === 0 && $showing > 40): ?>
        <div class="msg note">Loading <?= h($showing) ?> images through PHP can take a while. Add <code>&amp;last=5</code> to the URL to load only the newest ones.</div>
    <?php endif; ?>

    <div class="grid" id="grid">
    <?php gallery_flush(); gallery_stream($entries, $counts, $last > 0); ?>
    </div>
<?php endif; ?>
</div>

<script>
(function () {
    const root  = document.documentElement;
    const items = Array.from(document.querySelectorAll('figure.emo'));
    const heads = Array.from(document.querySelectorAll('.packh'));

    // PHP already fetched every image; flag the ones the browser cannot decode
    items.forEach(fig => {
        const img = fig.querySelector('img');
        if (!img) return;
        const bad = () => {
            fig.classList.add('broken');
            fig.querySelector('.dim').textContent = '⚠️ browser cannot decode this image';
        };
        img.addEventListener('error', bad);
        if (img.complete && !img.naturalWidth) bad();
    });

    document.querySelectorAll('.bar button[data-size]').forEach(b => b.addEventListener('click', () => {
        root.style.setProperty('--size', b.dataset.size + 'px');
        document.querySelectorAll('.bar button[data-size]').forEach(x => x.classList.toggle('on', x === b));
    }));

    const q = document.getElementById('q');
    const shown = document.getElementById('shown');
    if (q) q.addEventListener('input', () => {
        const term = q.value.trim().toLowerCase();
        let n = 0;
        items.forEach(f => {
            const hit = !term || f.dataset.sc.includes(term);
            f.style.display = hit ? '' : 'none';
            if (hit) n++;
        });
        heads.forEach(hd => {
            let el = hd.nextElementSibling, any = false;
            while (el && !el.classList.contains('packh')) {
                if (el.classList.contains('emo') && el.style.display !== 'none') any = true;
                el = el.nextElementSibling;
            }
            hd.style.display = any ? '' : 'none';
        });
        if (shown) shown.textContent = n;
    });

    items.forEach(f => f.addEventListener('click', async () => {
        try { await navigator.clipboard.writeText(f.dataset.code); toast('Copied ' + f.dataset.code); }
        catch (e) { toast(f.dataset.code); }
    }));
    function toast(t) {
        const d = document.createElement('div');
        d.className = 'toast'; d.textContent = t;
        document.body.appendChild(d);
        setTimeout(() => d.remove(), 1800);
    }

    // ?gallery=1#shortcode highlights and scrolls to that emoji
    const target = decodeURIComponent(location.hash.replace(/^#/, '')).toLowerCase();
    if (target) {
        const f = items.find(x => x.dataset.sc === target);
        if (f) { f.classList.add('hl'); f.scrollIntoView({ block: 'center' }); }
    }
})();
</script>
</body>
</html>
<?php
}

// ---------- handle requests BEFORE any output ----------
$loggedIn     = !empty($_SESSION['bearer_token']) && !empty($_SESSION['base_url']);
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['gallery'])) {
    render_gallery($loggedIn, strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}
$activeTab    = $loggedIn ? 'upload' : 'login';
$loginMsg     = null;   // ['ok'=>bool,'text'=>string]
$uploadResult = null;
$uploadError  = '';
$debugInfo    = '';

$packs      = null; // [packName => [shortcodes...]] as reported by the instance
$packsError = '';

function refresh_packs() {
    global $loggedIn, $packs, $packsError;
    $packs = null;
    $packsError = '';
    if (!$loggedIn) return;
    $res = fetch_packs($_SESSION['base_url'], $_SESSION['bearer_token']);
    if ($res['ok']) $packs = $res['packs'];
    else            $packsError = $res['error'];
}
refresh_packs();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['logout'])) {
        $_SESSION = [];
        $loggedIn  = false;
        $packs     = null;
        $activeTab = 'login';
        $loginMsg  = ['ok' => true, 'text' => 'Logged out.'];

    } elseif (isset($_POST['admin_login'])) {
        $activeTab = 'login';
        $serverUrl = trim($_POST['server_url'] ?? '');
        $username  = trim($_POST['username'] ?? '');
        $password  = $_POST['password'] ?? '';

        if ($serverUrl === '' || $username === '' || $password === '') {
            $loginMsg = ['ok' => false, 'text' => 'Please fill all fields.'];
        } elseif (!filter_var($serverUrl, FILTER_VALIDATE_URL)) {
            $loginMsg = ['ok' => false, 'text' => 'Invalid URL.'];
        } else {
            $res = oauth_login(rtrim($serverUrl, '/'), $username, $password);
            if ($res['ok']) {
                $_SESSION['base_url']     = rtrim($serverUrl, '/');
                $_SESSION['bearer_token'] = $res['token'];
                $loggedIn  = true;
                refresh_packs();
                $activeTab = 'upload';
                $loginMsg  = ['ok' => true, 'text' => 'Logged in. Granted scope: ' . $res['scope']];
            } else {
                $txt = $res['message'] . ' (HTTP ' . $res['code'] . ')';
                if ($res['curl_error']) $txt .= ' cURL: ' . $res['curl_error'];
                $loginMsg = ['ok' => false, 'text' => $txt];
            }
        }

    } elseif (isset($_POST['do_upload'])) {
        $activeTab = 'upload';
        $pack = trim($_POST['packName'] ?? '');
        $file = null;
        $viaB64 = false;

        if (!empty($_POST['emoji_b64'])) {
            // Image arrived as base64 text in a normal urlencoded POST (no multipart involved)
            $raw = base64_decode($_POST['emoji_b64'], true);
            if ($raw !== false && $raw !== '') {
                $tmpFromB64 = tempnam(sys_get_temp_dir(), 'emo');
                file_put_contents($tmpFromB64, $raw);
                register_shutdown_function(function () use ($tmpFromB64) { @unlink($tmpFromB64); });
                $file = [
                    'name'     => basename((string)($_POST['emoji_name'] ?? '')),
                    'type'     => '',
                    'tmp_name' => $tmpFromB64,
                    'size'     => strlen($raw),
                    'error'    => UPLOAD_ERR_OK,
                ];
                $viaB64 = true;
            }
        } elseif (!empty($_FILES['emojiFile'])) {
            $file = $_FILES['emojiFile']; // multipart fallback
        }

        $debugInfo = 'Transport: ' . ($viaB64 ? 'base64 in urlencoded POST' : 'multipart') . "\n" . print_r($file, true) . "\n";

        if (!$loggedIn) {
            $uploadError = 'No active admin session. Please log in first.';
        } elseif ($pack === '') {
            $uploadError = 'Pack name is required.';
        } elseif ($packs !== null && !isset($packs[$pack])) {
            $uploadError = 'Pack "' . $pack . '" does not exist on the instance.';
        } elseif (($uploadError = validate_upload($file, $viaB64)) === '') {
            $sc = pathinfo($file['name'], PATHINFO_FILENAME);
            $taken = $packs !== null && in_array(strtolower($sc), array_map('strtolower', $packs[$pack]), true);
            if ($taken) {
                $uploadError = 'Shortcode :' . $sc . ': already exists in pack ' . $pack . '. Rename the file.';
            } else {
                $uploadResult = upload_emoji($_SESSION['base_url'], $_SESSION['bearer_token'], $pack, $file);
                $debugInfo   .= "\nResponse headers from instance:\n" . $uploadResult['headers'];
                if ($uploadResult['code'] === 401) { $_SESSION = []; $loggedIn = false; $packs = null; }
                elseif ($uploadResult['ok'])       { refresh_packs(); }
            }
        }
    }
}

// POST target without query string, so passwords/URLs never ride along in the form request
$action = strtok($_SERVER['REQUEST_URI'], '?');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pleroma/Akkoma Admin – Login + Emoji Upload</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #fff; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); overflow: hidden; }
        .tabs { display: flex; background: #8e44ad; }
        .tab { flex: 1; padding: 16px; text-align: center; color: white; font-weight: bold; cursor: pointer; }
        .tab.active { background: #9b59b6; }
        .panel { padding: 30px; display: none; }
        .panel.active { display: block; }
        h1 { color: #333; border-bottom: 2px solid #8e44ad; padding-bottom: 10px; }
        .warning { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        input[type="text"], input[type="password"], input[type="url"], input[type="file"] {
            width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; box-sizing: border-box;
        }
        button { background: #8e44ad; color: white; padding: 12px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; width: 100%; }
        button:hover { background: #9b59b6; }
        button:disabled { background: #bbb; cursor: not-allowed; }
        button.secondary { background: #777; margin-top: 20px; }
        .result { margin-top: 30px; padding: 20px; border-radius: 5px; }
        .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
        .debug { background: #e2e3e5; padding: 12px; border-radius: 5px; margin: 10px 0; white-space: pre-wrap; word-wrap: break-word; font-size: 12px; }
        .preview { max-height: 64px; vertical-align: middle; margin-left: 8px; }
        pre { white-space: pre-wrap; word-wrap: break-word; }
        .checks { margin-top: 12px; padding: 12px; border: 1px solid #ddd; border-radius: 5px; background: #fafafa; }
        .checks .thumb { display: block; max-width: 128px; max-height: 128px; margin-bottom: 10px; border: 1px solid #ccc;
            background: repeating-conic-gradient(#e8e8e8 0% 25%, #fff 0% 50%) 50% / 12px 12px; }
        .check-row { padding: 4px 0; font-size: 14px; }
        .check-row.ok { color: #155724; }
        .check-row.fail { color: #721c24; font-weight: bold; }
    </style>
</head>
<body data-loggedin="<?= $loggedIn ? '1' : '0' ?>">
<?php if ($loggedIn): ?>
<div style="max-width:900px;margin:0 auto 12px;text-align:right;">
    <a href="<?= h($action) ?>?gallery=1" target="_blank" rel="noopener" style="color:#8e44ad;font-weight:bold;text-decoration:none;">🖼️ View all emojis (new tab) ↗</a>
</div>
<?php endif; ?>
<div class="container">
    <div class="tabs">
        <div class="tab <?= $activeTab === 'login' ? 'active' : '' ?>" data-tab="login">1. Admin Login</div>
        <div class="tab <?= $activeTab === 'upload' ? 'active' : '' ?>" data-tab="upload">2. Emoji Uploader</div>
    </div>

    <div id="login" class="panel <?= $activeTab === 'login' ? 'active' : '' ?>">
        <h1>🔐 Admin Login (OAuth)</h1>
        <div class="warning">
            <strong>⚠️ Administrators only!</strong><br>
            Prefill via URL fragment: <code>#instance=https%3A%2F%2Fexample.com&amp;user=you%40example.com&amp;password=secret</code>
            (a literal <code>+</code> in the password must be written <code>%2B</code>).
        </div>

        <form method="POST" action="<?= h($action) ?>" id="loginForm">
            <label>Server URL:</label>
            <input type="url" name="server_url" placeholder="https://your-instance.com" required
                   value="<?= h($_POST['server_url'] ?? '') ?>">

            <label>Admin Username/Email:</label>
            <input type="text" name="username" placeholder="admin@domain.com" required autocomplete="username"
                   value="<?= h($_POST['username'] ?? '') ?>">

            <label>Admin Password:</label>
            <input type="password" name="password" required autocomplete="current-password">

            <button type="submit" name="admin_login">Login as Admin</button>
        </form>

        <?php if ($loginMsg): ?>
            <div class="result <?= $loginMsg['ok'] ? 'success' : 'error' ?>">
                <?= $loginMsg['ok'] ? '✅' : '❌' ?> <?= h($loginMsg['text']) ?>
                <?php if ($loginMsg['ok'] && $loggedIn): ?><br>Switch to the Emoji Uploader tab.<?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <div id="upload" class="panel <?= $activeTab === 'upload' ? 'active' : '' ?>">
        <h1>🎨 Emoji Uploader</h1>
        <div class="warning">
            Requires successful admin login.<br>
            <strong>Pack must already exist</strong> (create it first in Admin → Settings → Emoji if needed).
        </div>

        <?php if ($loggedIn): ?>
            <form method="POST" action="<?= h($action) ?>" id="uploadForm">
                <label>Pack:</label>
                <?php if ($packs !== null && $packs): ?>
                    <select name="packName" required style="width:100%;padding:10px;margin:8px 0;font-size:16px;border:1px solid #ddd;border-radius:5px;">
                        <?php foreach ($packs as $pn => $codes): ?>
                            <option value="<?= h($pn) ?>" <?= ($_POST['packName'] ?? '') === (string)$pn ? 'selected' : '' ?>>
                                <?= h($pn) ?> (<?= count($codes) ?> emoji)
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php else: ?>
                    <input type="text" name="packName" placeholder="Pack name" value="<?= h($_POST['packName'] ?? '') ?>" required>
                    <div class="warning">
                        <?= $packs === null
                            ? 'Could not load the pack list from the instance (' . h($packsError) . '). Type the pack name by hand.'
                            : 'The instance reports no emoji packs. Create one in Admin → Settings → Emoji first.' ?>
                    </div>
                <?php endif; ?>

                <label>Emoji Image (max 1 MB, 256×256 px):</label>
                <input type="file" id="emojiFile" accept="image/png,image/gif,image/webp,image/jpeg" required>
                <input type="hidden" name="emoji_b64" id="emoji_b64">
                <input type="hidden" name="emoji_name" id="emoji_name">
                <input type="hidden" name="do_upload" value="1">

                <button type="submit" id="uploadBtn">Upload Emoji</button>
            </form>

            <form method="POST" action="<?= h($action) ?>">
                <button type="submit" name="logout" class="secondary">Log out</button>
            </form>
        <?php else: ?>
            <div class="result error">
                <strong>No active admin session.</strong><br>
                Please log in first on the Login tab.
            </div>
        <?php endif; ?>

        <?php if ($uploadError): ?>
            <div class="result error">❌ <?= h($uploadError) ?></div>
        <?php endif; ?>

        <?php if ($uploadResult): $u = $uploadResult; ?>
            <div class="result <?= $u['ok'] ? 'success' : 'error' ?>">
                <?php if ($u['ok']): ?>
                    <h3>✅ Emoji uploaded</h3>
                    <p>Shortcode: <strong>:<?= h($u['shortcode']) ?>:</strong>
                       in pack <strong><?= h($u['pack']) ?></strong>
                       <?php if ($u['file']): ?>
                           <img class="preview" alt="" onerror="this.style.display='none'"
                                src="<?= h($_SESSION['base_url'] . '/emoji/' . rawurlencode($u['pack']) . '/' . rawurlencode($u['file'])) ?>">
                       <?php endif; ?>
                    </p>
                    <p>You may need to reload emojis in the admin panel before it shows up everywhere.</p>
                <?php else: ?>
                    <h3>❌ Upload failed</h3>
                    <p>HTTP <?= (int)$u['code'] ?> after <?= h($u['time']) ?>s</p>
                    <?php if ($u['error']): ?><p>cURL error: <?= h($u['error']) ?></p><?php endif; ?>
                    <?php if ($u['hint']): ?><p><strong><?= h($u['hint']) ?></strong></p><?php endif; ?>
                    <?php if ($u['body']): ?><pre><?= h($u['body']) ?></pre><?php endif; ?>
                <?php endif; ?>
                <details>
                    <summary>Debug info</summary>
                    <div class="debug"><?= h($debugInfo) ?></div>
                </details>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// ---- tabs ----
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(tab.dataset.tab).classList.add('active');
    });
});

// ---- prefill from #fragment (preferred) or ?query, then scrub the URL and auto-login ----
document.addEventListener('DOMContentLoaded', () => {
    const fromHash  = new URLSearchParams(location.hash.replace(/^#/, ''));
    const fromQuery = new URLSearchParams(location.search);
    const get = k => fromHash.get(k) ?? fromQuery.get(k);   // URLSearchParams already decodes

    const instance = get('instance'), user = get('user'), password = get('password');
    if (!instance && !user && !password) return;

    const form = document.getElementById('loginForm');
    if (!form) return;
    if (instance) form.querySelector('[name="server_url"]').value = instance;
    if (user)     form.querySelector('[name="username"]').value   = user;
    if (password) form.querySelector('[name="password"]').value   = password;

    // remove secrets from address bar / history entry
    history.replaceState(null, '', location.pathname);

    const alreadyLoggedIn = document.body.dataset.loggedin === '1';
    if (instance && user && password && !alreadyLoggedIn) {
        form.querySelector('[name="admin_login"]').click();
    }
});

// ---- image check: renders? size? dimensions? shortcode free in the chosen pack? ----
const PACKS = <?= json_encode($packs ?: new stdClass(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?>;

document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('emojiFile');
    if (!fileInput) return;
    const form      = fileInput.closest('form');
    const submitBtn = document.getElementById('uploadBtn');
    const packSel   = form.querySelector('[name="packName"]');
    const box       = document.createElement('div');
    fileInput.parentNode.appendChild(box);

    let runId = 0, lastUrl = null;
    submitBtn.disabled = true; // enabled only when every check passes

    fileInput.addEventListener('change', run);
    if (packSel) packSel.addEventListener('change', run);
    if (fileInput.files.length) run();

    // Send the image as base64 text in a normal (urlencoded) POST instead of multipart/form-data,
    // because the host answers multipart POSTs with an instant 403.
    form.addEventListener('submit', (e) => {
        const f = fileInput.files[0];
        if (!f) return;
        e.preventDefault();
        submitBtn.disabled = true;
        const fr = new FileReader();
        fr.onload = () => {
            document.getElementById('emoji_b64').value  = String(fr.result).split(',')[1] || '';
            document.getElementById('emoji_name').value = f.name;
            form.submit(); // programmatic submit does not fire this handler again
        };
        fr.onerror = () => { submitBtn.disabled = false; alert('Could not read the file.'); };
        fr.readAsDataURL(f);
    });

    function run() {
        const id = ++runId;
        const f = fileInput.files[0];
        if (lastUrl) { URL.revokeObjectURL(lastUrl); lastUrl = null; }
        box.innerHTML = '';
        box.className = '';
        if (!f) { submitBtn.disabled = true; return; }

        const url = URL.createObjectURL(f);
        const img = new Image();
        img.onload  = () => finish(id, f, url, img.naturalWidth, img.naturalHeight, true);
        img.onerror = () => finish(id, f, url, 0, 0, false);
        img.src = url;
    }

    function finish(id, f, url, w, h, renders) {
        if (id !== runId) { URL.revokeObjectURL(url); return; }
        lastUrl = url;

        const name = f.name.replace(/\.[^.]+$/, '');
        const ext  = (f.name.split('.').pop() || '').toLowerCase();
        const rows = [];
        const add = (ok, text) => rows.push({ ok, text });

        add(renders, renders ? 'Image renders in the browser' : 'Image does NOT render (corrupted or not an image)');
        add(['png', 'gif', 'webp', 'jpg', 'jpeg'].includes(ext),
            `File type .${ext} ` + (['png', 'gif', 'webp', 'jpg', 'jpeg'].includes(ext) ? '' : '(only PNG, GIF, WebP, JPG/JPEG)'));
        add(f.size <= 1048576, `Size ${(f.size / 1024).toFixed(1)} KB (max 1024 KB)`);
        if (renders) add(w <= 256 && h <= 256, `Dimensions ${w}×${h} px (max 256×256)`);
        add(/^[a-zA-Z0-9_]+$/.test(name),
            `Shortcode :${name}: ` + (/^[a-zA-Z0-9_]+$/.test(name) ? 'is valid' : '- only letters, numbers and underscores'));

        if (packSel && PACKS[packSel.value]) {
            const taken = PACKS[packSel.value].some(s => String(s).toLowerCase() === name.toLowerCase());
            add(!taken, taken ? `:${name}: already exists in pack ${packSel.value} - rename the file`
                              : `:${name}: is free in pack ${packSel.value}`);
        }

        box.className = 'checks';
        if (renders) {
            const t = document.createElement('img');
            t.className = 'thumb';
            t.src = url;
            t.alt = 'preview';
            box.appendChild(t);
        }
        rows.forEach(r => {
            const d = document.createElement('div');
            d.className = 'check-row ' + (r.ok ? 'ok' : 'fail');
            d.textContent = (r.ok ? '✅ ' : '❌ ') + r.text;
            box.appendChild(d);
        });

        const allOk = rows.every(r => r.ok);
        if (!allOk && (f.size > 1048576 || w > 256 || h > 256)) {
            const a = document.createElement('a');
            a.href = 'resize.html';
            a.target = '_blank';
            a.textContent = 'Open resize tool';
            box.appendChild(a);
        }
        submitBtn.disabled = !allOk;
    }
});
</script>
</body>
</html>