<?php
session_start();

// Check if user is logged in and has a session
if (!isset($_SESSION['bearer_token']) || !isset($_SESSION['base_url'])) {
    header('Location: index.php');
    exit;
}

$username = $_GET['user'] ?? '';
if (empty($username)) {
    die('No user specified');
}

// Check if user is protected
$isProtected = ($username === 'admin' || $username === 'alcea');

$instance = preg_replace('#^https?://#', '', rtrim($_SESSION['base_url'], '/'));
$token = $_SESSION['bearer_token'];

// Fetch user details using same method as index.php
$apiUrl = "https://$instance/api/v1/pleroma/admin/users?filters=local&page_size=50&page=1";
$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Accept: application/json'],
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_TIMEOUT => 30
]);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
$users = $data['users'] ?? [];
$userData = null;

foreach ($users as $entry) {
    $u = $entry['user'] ?? $entry;
    $nickname = $u['nickname'] ?? $u['username'] ?? $u['acct'] ?? null;
    if ($nickname === $username || (strpos($nickname, '@') !== false && explode('@', $nickname)[0] === $username)) {
        $userData = $u;
        break;
    }
}

if (!$userData) {
    die('User not found');
}

// Fetch user roles
$rolesUrl = "https://$instance/api/v1/pleroma/admin/users/$username/permission_group";
$ch = curl_init($rolesUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Accept: application/json'],
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_TIMEOUT => 30
]);
$rolesResponse = curl_exec($ch);
curl_close($ch);
$roles = json_decode($rolesResponse, true);
$isAdmin = $roles['is_admin'] ?? false;
$isModerator = $roles['is_moderator'] ?? false;

// Fetch user's last 3 posts (same as index.php)
$acctUrl = "https://$instance/api/v1/accounts/lookup?acct=" . urlencode($username);
$ch = curl_init($acctUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token],
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_TIMEOUT => 10
]);
$acctResponse = curl_exec($ch);
curl_close($ch);

$posts = 0;
$userId = null;
if ($acctResponse) {
    $acctData = json_decode($acctResponse, true);
    $posts = $acctData['statuses_count'] ?? 0;
    $userId = $acctData['id'] ?? null;
}

// Fetch actual posts
$userPosts = [];
if ($userId) {
    $statusesUrl = "https://$instance/api/v1/accounts/$userId/statuses?limit=3&exclude_reblogs=true";
    $ch = curl_init($statusesUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT => 30
    ]);
    $postsResponse = curl_exec($ch);
    curl_close($ch);
    $userPosts = json_decode($postsResponse, true);
}

// Determine user status - USING SAME LOGIC AS INDEX.PHP
$isActive = isset($userData['is_active']) ? (bool)$userData['is_active'] : true;
$isConfirmed = isset($userData['is_confirmed']) ? (bool)$userData['is_confirmed'] : true;
$isApproved = isset($userData['is_approved']) ? (bool)$userData['is_approved'] : true;

if (!$isActive) {
    $statusMessage = "❌ Deactivated";
    $statusClass = "status-inactive";
    $buttonAction = "activate";
    $buttonText = "🔓 Reactivate";
    $buttonClass = "btn-activate";
} elseif (!$isConfirmed) {
    $statusMessage = "⏳ Unconfirmed Email";
    $statusClass = "status-pending";
    $buttonAction = null;
} elseif (!$isApproved) {
    $statusMessage = "⏳ Pending Approval";
    $statusClass = "status-pending";
    $buttonAction = "approve";
    $buttonText = "✓ Approve";
    $buttonClass = "btn-approve";
} else {
    $statusMessage = "✅ Active";
    $statusClass = "status-active";
    $buttonAction = "deactivate";
    $buttonText = "🔒 Deactivate";
    $buttonClass = "btn-deactivate";
}

$registrationDate = $userData['created_at'] ?? $userData['inserted_at'] ?? null;
$formattedDate = $registrationDate ? date('Y-m-d H:i:s', strtotime($registrationDate)) : 'Unknown';
$email = $userData['email'] ?? 'Not available';
$displayName = $userData['display_name'] ?? $username;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Panel - @<?php echo htmlspecialchars($username); ?></title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #fff; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 30px; }
        h1 { color: #333; border-bottom: 2px solid #8e44ad; padding-bottom: 10px; }
        h2 { color: #8e44ad; margin-top: 20px; }
        h3 { color: #666; margin: 15px 0 10px 0; font-size: 16px; }
        .info-box { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .info-row { padding: 8px 0; border-bottom: 1px solid #eee; }
        .info-label { font-weight: bold; display: inline-block; width: 120px; }
        .info-value { display: inline-block; }
        .status-active { color: green; font-weight: bold; }
        .status-pending { color: orange; font-weight: bold; }
        .status-inactive { color: red; font-weight: bold; }
        .role-badge { display: inline-block; padding: 3px 8px; border-radius: 3px; font-size: 11px; margin-right: 5px; }
        .role-admin { background: #dc3545; color: white; }
        .role-moderator { background: #17a2b8; color: white; }
        .role-none { background: #6c757d; color: white; }
        .post { border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px; background: #fafafa; }
        .post-content { margin-bottom: 10px; line-height: 1.4; }
        .post-date { font-size: 12px; color: #666; }
        .action-buttons { margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap; }
        .role-buttons { display: flex; gap: 10px; margin-top: 10px; flex-wrap: wrap; }
        .btn { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; display: inline-block; text-align: center; }
        .btn-approve { background: #28a745; color: white; }
        .btn-deactivate { background: #ffc107; color: #333; }
        .btn-activate { background: #17a2b8; color: white; }
        .btn-back { background: #8e44ad; color: white; }
        .btn-admin { background: #dc3545; color: white; }
        .btn-moderator { background: #17a2b8; color: white; }
        .btn-remove { background: #6c757d; color: white; }
        .btn-disabled { background: #6c757d; color: white; cursor: not-allowed; opacity: 0.6; }
        .btn-reset { background: #dc3545; color: white; padding: 5px 12px; font-size: 12px; margin-left: 10px; }
        .btn-small { padding: 5px 12px; font-size: 12px; }
        .btn:hover { opacity: 0.8; }
        .btn-disabled:hover { opacity: 0.6; }
        .toast { position: fixed; bottom: 20px; right: 20px; padding: 12px 20px; border-radius: 5px; color: white; z-index: 1000; }
        .toast-success { background: #28a745; }
        .toast-error { background: #dc3545; }
        .loading { opacity: 0.5; pointer-events: none; }
        hr { margin: 20px 0; }
        .warning-box { background: #fff3cd; border: 1px solid #ffeaa7; padding: 10px; border-radius: 5px; margin: 10px 0; font-size: 13px; }
    </style>
</head>
<body>
<div class="container">
    <h1>👤 User Panel: @<?php echo htmlspecialchars($username); ?></h1>
    <?php if ($displayName && $displayName !== $username): ?>
        <p style="color: #666; margin-top: -10px;"><?php echo htmlspecialchars($displayName); ?></p>
    <?php endif; ?>
    
    <?php if ($isProtected): ?>
        <div class="warning-box">
            ⚠️ This is a protected user (admin). Role management and actions are disabled.
        </div>
    <?php endif; ?>
    
    <div class="info-box">
        <div class="info-row">
            <span class="info-label">Status:</span>
            <span class="info-value <?php echo $statusClass; ?>"><?php echo $statusMessage; ?></span>
        </div>
        <div class="info-row">
            <span class="info-label">Posts:</span>
            <span class="info-value"><?php echo $posts; ?></span>
        </div>
        <div class="info-row">
            <span class="info-label">Registered:</span>
            <span class="info-value"><?php echo htmlspecialchars($formattedDate); ?></span>
        </div>
        <div class="info-row">
            <span class="info-label">Email:</span>
            <span class="info-value"><?php echo htmlspecialchars($email); ?></span>
        </div>
        <div class="info-row">
            <span class="info-label">Password:</span>
            <span class="info-value">
                •••••••• 
                <button class="btn-reset" onclick="handlePasswordReset()" <?php echo $isProtected ? 'disabled' : ''; ?>>Force Reset</button>
                <span style="font-size: 11px; color: #666; margin-left: 10px;">(cannot view, can only reset)</span>
            </span>
        </div>
    </div>

    <!-- Role Management Section -->
    <h2>👑 Role Management</h2>
    <div class="info-box">
        <div class="info-row">
            <span class="info-label">Current Roles:</span>
            <span class="info-value">
                <?php if ($isAdmin): ?>
                    <span class="role-badge role-admin">Admin</span>
                <?php endif; ?>
                <?php if ($isModerator): ?>
                    <span class="role-badge role-moderator">Moderator</span>
                <?php endif; ?>
                <?php if (!$isAdmin && !$isModerator): ?>
                    <span class="role-badge role-none">User</span>
                <?php endif; ?>
            </span>
        </div>
        
        <?php if (!$isProtected): ?>
            <div class="role-buttons">
                <?php if ($isAdmin): ?>
                    <button class="btn btn-remove btn-small" data-role-action="remove_admin" data-nickname="<?php echo htmlspecialchars($username); ?>">Remove Admin</button>
                <?php else: ?>
                    <button class="btn btn-admin btn-small" data-role-action="add_admin" data-nickname="<?php echo htmlspecialchars($username); ?>">Make Admin</button>
                <?php endif; ?>
                
                <?php if ($isModerator): ?>
                    <button class="btn btn-remove btn-small" data-role-action="remove_moderator" data-nickname="<?php echo htmlspecialchars($username); ?>">Remove Moderator</button>
                <?php else: ?>
                    <button class="btn btn-moderator btn-small" data-role-action="add_moderator" data-nickname="<?php echo htmlspecialchars($username); ?>">Make Moderator</button>
                <?php endif; ?>
            </div>
            <p style="font-size: 12px; color: #666; margin-top: 10px;">Note: Admins can do everything. Moderators can manage users but not change server settings.</p>
        <?php else: ?>
            <p style="font-size: 12px; color: #666;">Role management disabled for protected users.</p>
        <?php endif; ?>
    </div>

    <!-- User Action Buttons -->
    <div class="action-buttons">
        <?php if ($isProtected): ?>
            <button class="btn btn-disabled" disabled><?php echo $buttonText; ?> (Protected)</button>
        <?php else: ?>
            <?php if ($buttonAction): ?>
                <button class="btn <?php echo $buttonClass; ?>" data-action="<?php echo $buttonAction; ?>" data-nickname="<?php echo htmlspecialchars($username); ?>"><?php echo $buttonText; ?></button>
            <?php endif; ?>
        <?php endif; ?>
        <a href="index.php" class="btn btn-back">← Back to User List</a>
    </div>

    <hr>

    <h2>📝 Recent Posts (Last 3)</h2>
    <?php if (empty($userPosts)): ?>
        <p>No posts found.</p>
    <?php else: ?>
        <?php foreach ($userPosts as $post): ?>
            <div class="post">
                <div class="post-content"><?php echo htmlspecialchars(strip_tags($post['content'] ?? '')); ?></div>
                <div class="post-date"><?php echo date('Y-m-d H:i:s', strtotime($post['created_at'] ?? 'now')); ?></div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <hr>

    <h2>⚠️ Disciplinary Actions</h2>
    <div class="info-box">
        <p>• <strong>Deactivate</strong> - User cannot log in, but data is preserved</p>
        <p>• <strong>Reactivate</strong> - Restores login access</p>
        <p>• <strong>Approve</strong> - Approves pending user registration</p>
        <p>• <strong>Force Password Reset</strong> - User must create new password on next login</p>
    </div>
</div>

<script>
    function showToast(msg, type) {
        var toast = document.createElement('div');
        toast.className = 'toast toast-' + type;
        toast.textContent = msg;
        document.body.appendChild(toast);
        setTimeout(function() { toast.remove(); }, 3000);
    }

    async function handleRoleAction(nickname, action) {
        var msg = '';
        if (action === 'add_admin') msg = 'Make @' + nickname + ' an Admin? They will have full server access.';
        if (action === 'remove_admin') msg = 'Remove Admin role from @' + nickname + '?';
        if (action === 'add_moderator') msg = 'Make @' + nickname + ' a Moderator?';
        if (action === 'remove_moderator') msg = 'Remove Moderator role from @' + nickname + '?';
        if (!confirm(msg)) return;
        
        var btns = document.querySelectorAll('.btn');
        btns.forEach(function(btn) { if(btn.classList) btn.classList.add('loading'); });
        
        try {
            var fd = new FormData();
            fd.append('role_action', action);
            fd.append('nickname', nickname);
            var resp = await fetch('index.php', {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: fd
            });
            var result = await resp.json();
            if (result.success) {
                showToast('✅ Role updated for @' + nickname, 'success');
                setTimeout(function() { location.reload(); }, 1000);
            } else {
                showToast('❌ Failed: ' + (result.error || 'Unknown'), 'error');
            }
        } catch(e) {
            showToast('❌ Error: ' + e.message, 'error');
        }
        btns.forEach(function(btn) { if(btn.classList) btn.classList.remove('loading'); });
    }

    async function handlePasswordReset() {
        var nickname = '<?php echo htmlspecialchars($username); ?>';
        if (!confirm('Force password reset for @' + nickname + '? User will need to create a new password on next login.')) return;
        
        var btns = document.querySelectorAll('.btn');
        btns.forEach(function(btn) { if(btn.classList) btn.classList.add('loading'); });
        
        try {
            var fd = new FormData();
            fd.append('action', 'force_password_reset');
            fd.append('nickname', nickname);
            var resp = await fetch('index.php', {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: fd
            });
            var result = await resp.json();
            if (result.success) {
                showToast('✅ Password reset forced for @' + nickname, 'success');
            } else {
                showToast('❌ Failed: ' + (result.error || 'Endpoint may not be available'), 'error');
            }
        } catch(e) {
            showToast('❌ Error: ' + e.message, 'error');
        }
        btns.forEach(function(btn) { if(btn.classList) btn.classList.remove('loading'); });
    }

    async function handleUserAction(nickname, action) {
        var msg = '';
        if (action === 'approve') msg = 'Approve user @' + nickname + '?';
        if (action === 'deactivate') msg = 'Deactivate user @' + nickname + '?';
        if (action === 'activate') msg = 'Reactivate user @' + nickname + '?';
        if (!confirm(msg)) return;
        
        var btns = document.querySelectorAll('.btn');
        btns.forEach(function(btn) { if(btn.classList) btn.classList.add('loading'); });
        
        try {
            var fd = new FormData();
            fd.append('action', action);
            fd.append('nickname', nickname);
            var resp = await fetch('index.php', {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: fd
            });
            var result = await resp.json();
            if (result.success) {
                showToast('✅ ' + action + 'd @' + nickname, 'success');
                setTimeout(function() { location.reload(); }, 1000);
            } else {
                showToast('❌ Failed: ' + (result.error || 'Unknown'), 'error');
                btns.forEach(function(btn) { if(btn.classList) btn.classList.remove('loading'); });
            }
        } catch(e) {
            showToast('❌ Error: ' + e.message, 'error');
            btns.forEach(function(btn) { if(btn.classList) btn.classList.remove('loading'); });
        }
    }

    // Attach role action listeners
    document.querySelectorAll('[data-role-action]').forEach(function(btn) {
        var action = btn.dataset.roleAction;
        var nickname = btn.dataset.nickname;
        btn.addEventListener('click', function() { handleRoleAction(nickname, action); });
    });

    // Attach user action listeners
    document.querySelectorAll('[data-action]').forEach(function(btn) {
        var action = btn.dataset.action;
        var nickname = btn.dataset.nickname;
        btn.addEventListener('click', function() { handleUserAction(nickname, action); });
    });
</script>
</body>
</html>