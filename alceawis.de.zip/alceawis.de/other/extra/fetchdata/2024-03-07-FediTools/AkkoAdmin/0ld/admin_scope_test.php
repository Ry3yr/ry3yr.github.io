<?php
// scope_test.php — diagnostic only. Do NOT leave this on a public server.
// It prints the token and admin data. Delete it after testing.

header('Content-Type: text/plain; charset=utf-8');

$instance = $_GET['instance'] ?? '';
$user     = $_GET['user']     ?? '';
$password = $_GET['password'] ?? '';

if (!$instance || !$user || !$password) {
    echo "Usage: ?instance=https%3A%2F%2Fexample.com&user=you%40example.com&password=secret\n";
    exit;
}

$base = rtrim($instance, '/');
$ua   = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';

function req($url, $opts = []) {
    global $ua;
    $ch = curl_init($url);
    $defaults = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT      => $ua,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HEADER         => true, // we want headers too
    ];
    curl_setopt_array($ch, $defaults + $opts);
    $raw  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $err  = curl_error($ch);
    curl_close($ch);
    return [
        'code'    => $code,
        'headers' => substr($raw, 0, $hsize),
        'body'    => substr($raw, $hsize),
        'error'   => $err,
    ];
}

echo "=== STEP 1: OAuth password grant ===\n";
$post = http_build_query([
    'grant_type'    => 'password',
    'username'      => $user,
    'password'      => $password,
    'client_id'     => 'ECfTrzsW11bkG7simInOJf614Ee2sBhOlvE-69KDMzs',
    'client_secret' => 'r5EbNudkfePUwvRmc7DbafP0yOXpUC4lvipSrU8QOpo',
]);

$r = req($base . '/oauth/token', [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $post,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/x-www-form-urlencoded',
        'Accept: application/json',
    ],
]);

echo "HTTP: {$r['code']}\n";
echo "Body: {$r['body']}\n\n";

$tok = json_decode($r['body'], true);
if (!isset($tok['access_token'])) {
    echo "No access_token — stopping.\n";
    exit;
}

$token = $tok['access_token'];
$scope = $tok['scope'] ?? '(server did not return a scope field)';

echo "=== STEP 2: Granted scope ===\n";
echo "token : {$token}\n";
echo "scope : {$scope}\n";
echo "has admin:write ? " . (strpos($scope, 'admin:write') !== false ? "YES" : "NO") . "\n\n";

// Helper: call an endpoint with the bearer token
function api($url, $token, $method = 'GET', $body = null) {
    $opts = [
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $token,
            'Accept: application/json',
        ],
        CURLOPT_CUSTOMREQUEST => $method,
    ];
    if ($body !== null) {
        $opts[CURLOPT_POSTFIELDS] = $body;
        $opts[CURLOPT_HTTPHEADER][] = 'Content-Type: application/x-www-form-urlencoded';
    }
    return req($url, $opts);
}

echo "=== STEP 3: Probe endpoints ===\n";

// 3a. Who am I (basic auth check)
$r = api($base . '/api/v1/accounts/verify_credentials', $token);
echo "\n[verify_credentials] HTTP {$r['code']}\n";
echo substr($r['body'], 0, 500) . "\n";

// 3b. Admin endpoint — MUST be 200 if token has admin:read
$r = api($base . '/api/v1/pleroma/admin/users?page=1', $token);
echo "\n[admin/users] HTTP {$r['code']}  <-- if 403, token lacks admin:read\n";
echo substr($r['body'], 0, 500) . "\n";

// 3c. Emoji pack list (requires admin:read)
$r = api($base . '/api/v1/pleroma/emoji/packs', $token);
echo "\n[emoji/packs] HTTP {$r['code']}\n";
echo substr($r['body'], 0, 1000) . "\n";

// 3d. The exact upload endpoint, but with a GET to see the response shape
//     (a GET on the files endpoint usually gives 405/400/403; 403 here = admin:write missing)
$r = api($base . '/api/v1/pleroma/emoji/packs/files?name=CeaMoji', $token);
echo "\n[emoji/packs/files GET] HTTP {$r['code']}  <-- if 403, admin:write is missing or pack not accessible\n";
echo substr($r['body'], 0, 500) . "\n";

echo "\n=== DONE ===\n";