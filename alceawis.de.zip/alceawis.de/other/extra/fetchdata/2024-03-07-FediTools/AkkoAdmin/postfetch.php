<a target="_blank" href="/other/extra/fetchdata/2024-03-07-FediTools/AkkoAdmin/postfetch.php?user=alcea&instance=alceawis.com&limit=15&images=1">@alcea@alceawis.com</a>
<a target="_blank" href="/other/extra/fetchdata/2024-03-07-FediTools/AkkoAdmin/postfetch.php?user=alcea&instance=miraiverse.xyz&limit=15&images=1">@alcea@miraiverse.xyz</a>
<a target="_blank" href="/other/extra/fetchdata/2024-03-07-FediTools/AkkoAdmin/postfetch.php?user=alcea&instance=infosec.exchange&limit=15&images=1">@alcea@infosec.exchange</a>
<a target="_blank" href="/other/extra/fetchdata/2024-03-07-FediTools/AkkoAdmin/postfetch.php?user=aoikurayami&instance=mk.absturztau.be&limit=15&images=1">@aoikurayami@mk.absturztau.be</a>

<?php
/* ---------------- USER INPUT ---------------- */
$acctName  = $_GET['user'] ?? "alcea";
$accountId = $_GET['userid'] ?? null;
$order     = $_GET['order'] ?? 'desc';
$instance  = $_GET['instance'] ?? null;
$limit     = isset($_GET['limit']) ? (int)$_GET['limit'] : 0;
$loadImages = isset($_GET['images']);

/* ---------------- PARSE @user@instance ---------------- */
$acctName = trim($acctName);

if (strpos($acctName, '@') !== false) {
    $parts = explode('@', ltrim($acctName, '@'));
    if (count($parts) === 2) {
        $acctName = $parts[0];
        if (!$instance) $instance = $parts[1];
    }
}

if (!$instance) $instance = "alceawis.com";
$instance = preg_replace('/[^a-zA-Z0-9\.\-]/', '', $instance);
$base = "https://" . $instance;

/* ---------------- HELPERS ---------------- */
function curlGet($url, $timeout = 10) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => 'MastodonArchiveBot/1.0'
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($httpCode === 200) ? $response : null;
}

function fetchJSON($url, $timeout = 10) {
    $data = curlGet($url, $timeout);
    return $data ? json_decode($data, true) : null;
}

function fetchImageAsBase64($url) {
    $data = curlGet($url, 15);
    if (!$data) return null;
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    
    if (strpos($mime, 'image/') !== 0) return null;
    return "data:$mime;base64," . base64_encode($data);
}

function resolveAccountId($base, $user, $instance) {
    $url = $base . "/api/v1/accounts/lookup?acct=" . urlencode($user . "@" . $instance);
    $data = fetchJSON($url);
    return $data['id'] ?? null;
}

// Fetch ONLY emoji URLs (not base64 yet)
function fetchEmojiUrls($base) {
    $data = fetchJSON($base . "/api/v1/custom_emojis");
    if (!$data) return [];
    
    $emojis = [];
    foreach ($data as $emoji) {
        $emojis[$emoji['shortcode']] = $emoji['url'];
    }
    return $emojis;
}

// Find which emojis are used in posts
function findUsedEmojis($posts, $emojiUrls) {
    $used = [];
    foreach ($posts as $post) {
        foreach ($emojiUrls as $shortcode => $url) {
            if (strpos($post['content_raw'], ":$shortcode:") !== false) {
                $used[$shortcode] = $url;
            }
        }
    }
    return $used;
}

/* ---------------- RESOLVE ACCOUNT ---------------- */
if (!$accountId && $acctName) {
    $accountId = resolveAccountId($base, $acctName, $instance);
}
if (!$accountId) {
    die("❌ Could not resolve account ID for @" . htmlspecialchars($acctName) . "@" . htmlspecialchars($instance));
}

/* ---------------- FETCH POSTS FIRST ---------------- */
$max_id = null;
$posts = [];
$apiLimit = min(40, $limit > 0 ? $limit : 40);

while (true) {
    if ($limit > 0 && count($posts) >= $limit) break;
    
    $url = "$base/api/v1/accounts/$accountId/statuses";
    if ($max_id) $url .= "?max_id=$max_id&limit=$apiLimit";
    elseif ($apiLimit) $url .= "?limit=$apiLimit";
    
    $data = fetchJSON($url);
    if (!$data || count($data) === 0) break;
    
    foreach ($data as $post) {
        if ($limit > 0 && count($posts) >= $limit) break 2;
        
        $raw = $post['reblog']['content'] ?? $post['content'] ?? '';
        
        $posts[] = [
            'date' => $post['created_at'] ?? '',
            'content_raw' => $raw,
            'url' => $post['url'] ?? '',
            'media_attachments' => $post['media_attachments'] ?? $post['reblog']['media_attachments'] ?? []
        ];
    }
    
    $max_id = $data[count($data)-1]['id'] ?? null;
    if (count($data) < $apiLimit) break;
}

if ($limit > 0 && count($posts) > $limit) $posts = array_slice($posts, 0, $limit);
if ($order === 'asc') $posts = array_reverse($posts);

/* ---------------- FETCH ONLY NEEDED EMOJIS ---------------- */
$emojiBase64 = [];
if ($loadImages && !empty($posts)) {
    // Get all emoji URLs
    $allEmojis = fetchEmojiUrls($base);
    // Find which ones are actually used in these posts
    $usedEmojis = findUsedEmojis($posts, $allEmojis);
    // Convert ONLY used emojis to base64
    foreach ($usedEmojis as $shortcode => $url) {
        $base64 = fetchImageAsBase64($url);
        if ($base64) {
            $emojiBase64[$shortcode] = $base64;
        }
    }
}

// Replace emojis in content
function replaceEmojis($content, $emojis) {
    if (empty($emojis)) return $content;
    foreach ($emojis as $shortcode => $base64) {
        $content = str_replace(
            ":$shortcode:",
            "<img src='$base64' class='emoji' alt=':$shortcode:' style='height:1.2em;width:1.2em;vertical-align:middle;display:inline-block;'>",
            $content
        );
    }
    return $content;
}

// Process posts with emojis
foreach ($posts as &$p) {
    $content = html_entity_decode($p['content_raw']);
    if ($loadImages && !empty($emojiBase64)) {
        $content = replaceEmojis($content, $emojiBase64);
    } else {
        $content = nl2br(htmlspecialchars(strip_tags($content)));
    }
    $p['content'] = $content;
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($acctName) ?> Archive</title>
<style>
body { background: #0f0f0f; color: #eaeaea; font-family: system-ui, Arial; max-width: 750px; margin: auto; padding: 20px; }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; flex-wrap: wrap; gap: 10px; }
form { margin-bottom: 20px; display: flex; gap: 8px; flex-wrap: wrap; }
input, select { background: #1a1a1a; color: #fff; border: 1px solid #333; padding: 8px; border-radius: 8px; }
button, a.button { background: #1f1f1f; color: #fff; border: 1px solid #333; padding: 8px 12px; border-radius: 8px; cursor: pointer; text-decoration: none; display: inline-block; }
button:hover, a.button:hover { background: #2a2a2a; }
.post { border: 1px solid #2a2a2a; background: #161616; border-radius: 14px; padding: 14px; margin-bottom: 14px; }
.date { font-size: 12px; color: #888; margin-bottom: 8px; }
.content { white-space: pre-wrap; line-height: 1.45; }
.content img.emoji { height: 1.2em; width: 1.2em; vertical-align: middle; display: inline-block; }
a.link { color: #4da3ff; font-size: 12px; text-decoration: none; }
.stats { font-size: 12px; color: #888; margin-bottom: 15px; padding: 8px; background: #1a1a1a; border-radius: 8px; }
.image-gallery { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
.image-item { max-width: 200px; background: #1a1a1a; border-radius: 8px; overflow: hidden; cursor: pointer; }
.image-item img { width: 100%; height: auto; display: block; }
.lightbox { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); z-index: 1000; cursor: pointer; align-items: center; justify-content: center; }
.lightbox.active { display: flex; }
.lightbox img { max-width: 90%; max-height: 90%; object-fit: contain; }
.lightbox-close { position: absolute; top: 20px; right: 40px; color: #fff; font-size: 40px; cursor: pointer; font-family: Arial; }
</style>
</head>
<body>

<div class="header">
    <h2><?= $loadImages ? '🖼️' : '📜' ?> @<?= htmlspecialchars($acctName) ?>@<?= htmlspecialchars($instance) ?></h2>
    <div>
        <?php $toggleOrder = ($order === 'desc') ? 'asc' : 'desc'; ?>
        <a class="button" href="?user=<?= urlencode($acctName) ?>&instance=<?= urlencode($instance) ?>&userid=<?= urlencode($accountId) ?>&order=<?= $toggleOrder ?><?= $limit > 0 ? '&limit=' . $limit : '' ?><?= $loadImages ? '&images=1' : '' ?>">🔁 Invert order</a>
        <?php if (!$loadImages): ?>
        <a class="button" href="?user=<?= urlencode($acctName) ?>&instance=<?= urlencode($instance) ?>&userid=<?= urlencode($accountId) ?>&order=<?= $order ?><?= $limit > 0 ? '&limit=' . $limit : '' ?>&images=1">🖼️ Load Images & Emojis</a>
        <?php else: ?>
        <a class="button" href="?user=<?= urlencode($acctName) ?>&instance=<?= urlencode($instance) ?>&userid=<?= urlencode($accountId) ?>&order=<?= $order ?><?= $limit > 0 ? '&limit=' . $limit : '' ?>">📝 Text Only</a>
        <?php endif; ?>
    </div>
</div>

<form method="get">
    <input type="text" name="user" placeholder="@user@instance or user" value="<?= htmlspecialchars($acctName) ?>">
    <input type="text" name="instance" placeholder="instance" value="<?= htmlspecialchars($instance) ?>">
    <input type="text" name="userid" placeholder="user id" value="<?= htmlspecialchars($accountId) ?>">
    <input type="number" name="limit" placeholder="max posts (0=all)" value="<?= htmlspecialchars($limit) ?>" min="0" max="1000" style="width: 120px;">
    <input type="hidden" name="order" value="<?= htmlspecialchars($order) ?>">
    <?php if ($loadImages): ?><input type="hidden" name="images" value="1"><?php endif; ?>
    <button type="submit">Load</button>
</form>

<?php if (!empty($posts)): ?>
<div class="stats">📊 Showing <?= count($posts) ?> posts <?php if ($limit > 0 && count($posts) >= $limit): ?>(limited to <?= $limit ?>)<?php endif; ?> <?php if ($loadImages): ?>- 🖼️ Loaded <?= count($emojiBase64) ?> emojis (only used ones)<?php endif; ?></div>
<?php endif; ?>

<?php foreach ($posts as $p): ?>
<div class="post">
    <div class="date"><?= htmlspecialchars($p['date']) ?></div>
    <div class="content"><?= $p['content'] ?></div>
    
    <?php if ($loadImages && !empty($p['media_attachments'])): ?>
    <div class="image-gallery">
        <?php foreach ($p['media_attachments'] as $attachment):
            if ($attachment['type'] === 'image'):
                $base64 = fetchImageAsBase64($attachment['url']);
                if ($base64):
        ?>
        <div class="image-item" onclick="openLightbox(this)">
            <img src="<?= $base64 ?>" alt="<?= htmlspecialchars($attachment['description'] ?? '') ?>" loading="lazy">
        </div>
        <?php 
                endif;
            endif;
        endforeach; ?>
    </div>
    <?php endif; ?>
    
    <?php if (!empty($p['url'])): ?>
    <div style="margin-top: 10px;"><a class="link" href="<?= htmlspecialchars($p['url']) ?>" target="_blank">open post ↗</a></div>
    <?php endif; ?>
</div>
<?php endforeach; ?>

<?php if (empty($posts)): ?>
<div class="stats">ℹ️ No posts found for this account.</div>
<?php endif; ?>

<div id="lightbox" class="lightbox" onclick="closeLightbox()">
    <div class="lightbox-close">&times;</div>
    <img id="lightbox-img" src="">
</div>

<script>
function openLightbox(element) {
    const img = element.querySelector('img');
    if (img) {
        document.getElementById('lightbox-img').src = img.src;
        document.getElementById('lightbox').classList.add('active');
    }
}
function closeLightbox() {
    document.getElementById('lightbox').classList.remove('active');
}
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeLightbox(); });
</script>
</body>
</html>
