<?php
/**
 * Perl Module Installer via cPanel API - With Custom Path Support
 * Usage: ?apitoken=YOUR_TOKEN
 */

/* ====== CONFIGURE ME ====== */
$CPANEL_HOST = 'https://cp179.sp-server.net:2083';
$CPANEL_USER = isset($_GET['user']) ? trim($_GET['user']) : 'alceawis';
$API_TOKEN   = isset($_GET['apitoken']) ? trim($_GET['apitoken']) : 'token';
$VERIFY_SSL  = false;
/* =========================== */

// ============================================
// CUSTOM PERL MODULE PATHS
// ============================================
$customPaths = [
    '/home/alceawis/perl/usr/share/perl5',
    '/home/alceawis/perl/usr/lib64/perl5',
    '/home/alceawis/perl/usr/site_lib',
    '/home/alceawis/perl/usr/lib/x86_64-linux',
];

// ============================================
// Common Perl Modules
// ============================================
$commonModules = [
    'LWP::UserAgent' => 'HTTP client for web scraping',
    'LWP::Protocol::https' => 'HTTPS support for LWP (FIXED!)',
    'HTTP::Cookies' => 'Cookie handling for HTTP requests',
    'HTML::TreeBuilder' => 'HTML parser and DOM manipulation',
    'HTML::Parser' => 'Fast HTML parsing',
    'HTML::TokeParser' => 'Token-based HTML parsing',
    'Web::Scraper' => 'Web scraping framework',
    'JSON::XS' => 'Fast JSON encoder/decoder',
    'JSON' => 'JSON encoder/decoder',
    'Data::Dumper' => 'Data structure visualization',
    'Data::Dump' => 'Pretty printing of data structures',
    'Storable' => 'Persistent data structures',
    'DBI' => 'Database interface',
    'DBD::mysql' => 'MySQL driver for DBI',
    'DBD::Pg' => 'PostgreSQL driver for DBI',
    'DBD::SQLite' => 'SQLite driver for DBI',
    'File::Path' => 'File path manipulation',
    'File::Copy' => 'File copying',
    'Archive::Zip' => 'ZIP archive handling',
    'Net::FTP' => 'FTP client',
    'Net::SSH' => 'SSH client',
    'Net::SMTP' => 'SMTP email',
    'XML::Simple' => 'Simple XML parsing',
    'XML::Parser' => 'XML parsing',
    'Digest::SHA' => 'SHA hashing',
    'Digest::MD5' => 'MD5 hashing',
    'Crypt::SSLeay' => 'SSL/TLS support',
    'Email::MIME' => 'MIME email handling',
    'Email::Sender' => 'Email sending',
    'MIME::Lite' => 'Lightweight MIME email',
    'Getopt::Long' => 'Command line option parsing',
    'Time::Piece' => 'Time manipulation',
    'Encode' => 'Character encoding',
    'MIME::Base64' => 'Base64 encoding',
    'REST::Client' => 'REST API client',
    'SOAP::Lite' => 'SOAP client',
    'Test::More' => 'Testing framework',
    'GD' => 'Graphics drawing',
    'Image::Magick' => 'Image manipulation',
];

// ============================================
// Helper Functions with Custom Path Support
// ============================================

function buildPerlCommand($code) {
    global $customPaths;
    $incPath = '';
    foreach ($customPaths as $path) {
        if (is_dir($path)) {
            $incPath .= ' -I' . escapeshellarg($path);
        }
    }
    return "perl $incPath -e " . escapeshellarg($code) . " 2>&1";
}

function checkModule($module) {
    global $customPaths;
    
    // Method 1: Check with custom paths
    $testCode = "use $module; print 'OK'";
    $cmd = buildPerlCommand($testCode);
    exec($cmd, $output, $returnCode);
    
    if ($returnCode === 0 && isset($output[0]) && trim($output[0]) === 'OK') {
        return true;
    }
    
    // Method 2: Try with eval (handles modules that don't export)
    $testCode = "eval { require $module; }; print 'OK' if !\$@";
    $cmd = buildPerlCommand($testCode);
    exec($cmd, $output, $returnCode);
    
    if ($returnCode === 0 && isset($output[0]) && trim($output[0]) === 'OK') {
        return true;
    }
    
    // Method 3: Check if the .pm file exists in custom paths
    $modulePath = str_replace('::', '/', $module) . '.pm';
    foreach ($customPaths as $path) {
        if (is_dir($path)) {
            $fullPath = $path . '/' . $modulePath;
            if (file_exists($fullPath)) {
                return true;
            }
            // Also check in site_lib
            $sitePath = $path . '/site_lib/' . $modulePath;
            if (file_exists($sitePath)) {
                return true;
            }
        }
    }
    
    return false;
}

function getModuleVersion($module) {
    $cmd = buildPerlCommand("use $module; print \$$module::VERSION");
    exec($cmd, $output, $returnCode);
    return $returnCode === 0 ? trim($output[0]) : 'unknown';
}

function getModulePath($module) {
    $cmd = buildPerlCommand("use $module; print \$INC{\"$module.pm\"}");
    exec($cmd, $output, $returnCode);
    if ($returnCode === 0 && !empty($output[0])) {
        return trim($output[0]);
    }
    
    // Check file system
    $modulePath = str_replace('::', '/', $module) . '.pm';
    global $customPaths;
    foreach ($customPaths as $path) {
        if (is_dir($path)) {
            $fullPath = $path . '/' . $modulePath;
            if (file_exists($fullPath)) {
                return $fullPath;
            }
        }
    }
    return 'not found';
}

function isCustomPath($path) {
    global $customPaths;
    foreach ($customPaths as $customPath) {
        if (strpos($path, $customPath) !== false) {
            return true;
        }
    }
    return false;
}

function getPerlCodeSnippet($module = null) {
    global $customPaths;
    $pathsStr = implode("';\n    use lib '", $customPaths);
    $moduleUse = $module ? "use $module;" : '';
    return <<<PERL
# ==============================================
# ADD THIS TO YOUR PERL SCRIPTS
# ==============================================
use lib '$pathsStr';

# Now use the module
$moduleUse

# Example usage with LWP::Protocol::https:
use LWP::UserAgent;
use LWP::Protocol::https;
use JSON::XS;

my \$ua = LWP::UserAgent->new();
my \$response = \$ua->get('https://api.example.com');
PERL;
}

/**
 * Install Perl module with multiple methods
 */
function installModule($module) {
    $results = [];
    $outputs = [];
    
    // Method 1: cPanel Perl
    $cpanelPerl = '/usr/local/cpanel/3rdparty/bin/perl';
    if (file_exists($cpanelPerl)) {
        $cmd = "$cpanelPerl -MCPAN -e 'install \"$module\"' 2>&1";
        exec($cmd, $output, $returnCode);
        $outputs[] = "cPanel Perl: " . implode("\n", $output);
        if ($returnCode === 0 && checkModule($module)) {
            $results['success'] = true;
            $results['method'] = 'cpanel_perl';
            $results['output'] = implode("\n", $output);
            return $results;
        }
    }
    
    // Method 2: System Perl with CPAN
    $systemPerl = '/usr/bin/perl';
    if (file_exists($systemPerl)) {
        $cmd = "$systemPerl -MCPAN -e 'install \"$module\"' 2>&1";
        exec($cmd, $output, $returnCode);
        $outputs[] = "System Perl: " . implode("\n", $output);
        if ($returnCode === 0 && checkModule($module)) {
            $results['success'] = true;
            $results['method'] = 'system_perl';
            $results['output'] = implode("\n", $output);
            return $results;
        }
    }
    
    // Method 3: Regular cpan
    $cmd = "cpan -i $module 2>&1";
    exec($cmd, $output, $returnCode);
    $outputs[] = "cpan: " . implode("\n", $output);
    if ($returnCode === 0 && checkModule($module)) {
        $results['success'] = true;
        $results['method'] = 'cpan';
        $results['output'] = implode("\n", $output);
        return $results;
    }
    
    // Method 4: Force install with cpan
    $cmd = "cpan -fi $module 2>&1";
    exec($cmd, $output, $returnCode);
    $outputs[] = "cpan force: " . implode("\n", $output);
    if ($returnCode === 0 && checkModule($module)) {
        $results['success'] = true;
        $results['method'] = 'cpan_force';
        $results['output'] = implode("\n", $output);
        return $results;
    }
    
    // Method 5: Install dependencies first (for LWP::Protocol::https)
    if ($module === 'LWP::Protocol::https') {
        // Install IO::Socket::SSL first
        $cmd = "cpan -i IO::Socket::SSL 2>&1";
        exec($cmd, $depOutput, $depReturn);
        $outputs[] = "Dependency IO::Socket::SSL: " . implode("\n", $depOutput);
        
        // Try again
        $cmd = "cpan -i $module 2>&1";
        exec($cmd, $output, $returnCode);
        $outputs[] = "cpan (after dep): " . implode("\n", $output);
        if ($returnCode === 0 && checkModule($module)) {
            $results['success'] = true;
            $results['method'] = 'cpan_with_deps';
            $results['output'] = implode("\n", $output);
            return $results;
        }
    }
    
    // Method 6: Try using Perl's CPAN shell
    $cmd = "perl -MCPAN -e 'CPAN::Shell->install(\"$module\")' 2>&1";
    exec($cmd, $output, $returnCode);
    $outputs[] = "CPAN Shell: " . implode("\n", $output);
    if ($returnCode === 0 && checkModule($module)) {
        $results['success'] = true;
        $results['method'] = 'cpan_shell';
        $results['output'] = implode("\n", $output);
        return $results;
    }
    
    // All methods failed
    $results['success'] = false;
    $results['method'] = 'all_failed';
    $results['output'] = implode("\n\n=== SEPARATOR ===\n\n", $outputs);
    return $results;
}

// ============================================
// Process Actions
// ============================================
$action = isset($_POST['action']) ? $_POST['action'] : (isset($_GET['action']) ? $_GET['action'] : 'show_form');
$message = '';
$messageType = '';
$installResult = null;
$showInfoPopup = isset($_GET['info']) || isset($_POST['show_info']);
$popupModule = isset($_GET['module']) ? $_GET['module'] : (isset($_POST['module']) ? $_POST['module'] : '');

if ($action === 'install') {
    $moduleToInstall = isset($_POST['module_name']) ? trim($_POST['module_name']) : '';
    
    if (!empty($moduleToInstall)) {
        // Check if already installed
        $alreadyInstalled = checkModule($moduleToInstall);
        
        if ($alreadyInstalled) {
            $version = getModuleVersion($moduleToInstall);
            $path = getModulePath($moduleToInstall);
            $message = "✅ Module '$moduleToInstall' is already installed! (Version: $version)";
            $messageType = 'success';
            $installResult = [
                'status' => 'already_installed',
                'version' => $version,
                'path' => $path,
                'output' => "Module already installed at: $path"
            ];
        } else {
            // Try to install
            $result = installModule($moduleToInstall);
            
            // Check again with custom paths
            $nowInstalled = checkModule($moduleToInstall);
            
            if ($nowInstalled) {
                $version = getModuleVersion($moduleToInstall);
                $path = getModulePath($moduleToInstall);
                $message = "✅ Module '$moduleToInstall' installed successfully! (Version: $version)";
                $messageType = 'success';
                $installResult = [
                    'status' => 'installed',
                    'version' => $version,
                    'path' => $path,
                    'method' => $result['method'],
                    'output' => $result['output']
                ];
            } else {
                $message = "❌ Failed to install '$moduleToInstall'. Please check the output below.";
                $messageType = 'error';
                $installResult = [
                    'status' => 'failed',
                    'method' => $result['method'],
                    'output' => $result['output']
                ];
            }
        }
    } else {
        $message = "⚠️ Please enter a module name.";
        $messageType = 'error';
    }
}

// Handle Info popup
if (isset($_GET['show_info']) || isset($_POST['show_info'])) {
    $popupModule = isset($_GET['module']) ? $_GET['module'] : (isset($_POST['module']) ? $_POST['module'] : '');
    $showInfoPopup = true;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Perl Module Installer</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
               background: #f0f2f5; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; }
        
        .header { background: linear-gradient(135deg, #1a1a2e, #16213e); color: white;
                  padding: 30px; border-radius: 12px; margin-bottom: 20px; }
        .header h1 { font-size: 28px; }
        .header .sub { color: #8899bb; font-size: 14px; }
        
        .card { background: white; border-radius: 12px; padding: 20px;
                margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .card h2 { font-size: 18px; margin-bottom: 15px; color: #1a1a2e; }
        .card h3 { font-size: 15px; margin: 15px 0 10px; color: #374151; }
        
        .message { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .message.success { background: #dcfce7; color: #16a34a; border: 1px solid #86efac; }
        .message.error { background: #fee2e2; color: #dc2626; border: 1px solid #fecaca; }
        .message.warning { background: #fef3c7; color: #d97706; border: 1px solid #fde68a; }
        .message.info { background: #dbeafe; color: #2563eb; border: 1px solid #93c5fd; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 5px; color: #374151; }
        .form-group input[type="text"] { width: 100%; padding: 10px; border: 2px solid #e5e7eb;
                                         border-radius: 8px; font-size: 16px; }
        .form-group input[type="text"]:focus { border-color: #3b82f6; outline: none; }
        
        .btn { padding: 10px 25px; border: none; border-radius: 8px; font-size: 16px;
               font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .btn-primary { background: #3b82f6; color: white; }
        .btn-primary:hover { background: #2563eb; }
        .btn-success { background: #22c55e; color: white; }
        .btn-success:hover { background: #16a34a; }
        .btn-outline { background: transparent; color: #3b82f6; border: 2px solid #3b82f6; }
        .btn-outline:hover { background: #3b82f6; color: white; }
        .btn-info { background: #8b5cf6; color: white; }
        .btn-info:hover { background: #7c3aed; }
        .btn-sm { padding: 4px 10px; font-size: 12px; }
        
        .module-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 10px; }
        .module-item { padding: 12px; border: 1px solid #e5e7eb; border-radius: 8px;
                       display: flex; justify-content: space-between; align-items: center; }
        .module-item:hover { background: #f9fafb; }
        .module-name { font-weight: 600; }
        .module-desc { font-size: 12px; color: #6b7280; }
        .module-status { font-size: 12px; padding: 2px 10px; border-radius: 12px; }
        .module-status.installed { background: #dcfce7; color: #16a34a; }
        .module-status.missing { background: #fee2e2; color: #dc2626; }
        .module-status.found-custom { background: #dbeafe; color: #2563eb; }
        
        .output-box { background: #1a1a2e; color: #e5e7eb; padding: 15px; border-radius: 8px;
                      font-family: 'Courier New', monospace; font-size: 12px; 
                      overflow: auto; max-height: 400px; white-space: pre-wrap; word-wrap: break-word; }
        
        .search-box { margin-bottom: 15px; }
        .search-box input { width: 100%; padding: 10px; border: 2px solid #e5e7eb;
                            border-radius: 8px; font-size: 16px; }
        .search-box input:focus { border-color: #3b82f6; outline: none; }
        
        .quick-buttons { display: flex; flex-wrap: wrap; gap: 8px; margin: 10px 0; }
        .quick-btn { padding: 5px 12px; border: 1px solid #e5e7eb; border-radius: 6px;
                     background: white; cursor: pointer; font-size: 13px; }
        .quick-btn:hover { background: #3b82f6; color: white; border-color: #3b82f6; }
        
        .path-badge {
            display: inline-block;
            background: #f3f4f6;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 11px;
            color: #6b7280;
            font-family: monospace;
        }
        
        /* Modal/Popup styles */
        .modal-overlay {
            display: <?php echo $showInfoPopup ? 'flex' : 'none'; ?>;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.6);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        .modal-box {
            background: white;
            border-radius: 16px;
            max-width: 700px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            padding: 30px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            animation: modalSlideIn 0.3s ease-out;
        }
        @keyframes modalSlideIn {
            from { transform: translateY(-30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        .modal-box h2 { font-size: 24px; color: #1a1a2e; margin-bottom: 10px; }
        .modal-box h3 { font-size: 16px; margin: 20px 0 10px; color: #374151; }
        .modal-box .close-btn {
            float: right;
            background: none;
            border: none;
            font-size: 28px;
            cursor: pointer;
            color: #6b7280;
        }
        .modal-box .close-btn:hover { color: #1a1a2e; }
        .modal-box .code-block {
            background: #1a1a2e;
            color: #e5e7eb;
            padding: 15px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            overflow-x: auto;
            white-space: pre-wrap;
            margin: 10px 0;
        }
        .modal-box .code-block .comment { color: #6b7280; }
        .modal-box .code-block .keyword { color: #f472b6; }
        .modal-box .code-block .string { color: #34d399; }
        .modal-box .code-block .function { color: #60a5fa; }
        .modal-box .tip { background: #f0fdf4; padding: 15px; border-radius: 8px; 
                          border-left: 4px solid #22c55e; margin: 15px 0; }
        .modal-box .tip strong { color: #16a34a; }
        .modal-box .btn-copy {
            background: #3b82f6;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
        }
        .modal-box .btn-copy:hover { background: #2563eb; }
        
        .module-info {
            background: #f8fafc;
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
        }
        .module-info .label { color: #6b7280; font-size: 13px; }
        .module-info .value { font-weight: 600; font-family: monospace; }
        
        @media (max-width: 768px) {
            .module-grid { grid-template-columns: 1fr; }
            .modal-box { padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🐧 Perl Module Installer</h1>
            <div class="sub">cPanel Account: <?php echo htmlspecialchars($CPANEL_USER); ?></div>
        </div>
        
        <?php if ($message): ?>
        <div class="message <?php echo htmlspecialchars($messageType); ?>">
            <?php echo htmlspecialchars($message); ?>
            <?php if (isset($installResult['version'])): ?>
            <br><small>Version: <?php echo htmlspecialchars($installResult['version']); ?></small>
            <?php endif; ?>
            <?php if (isset($installResult['path']) && $installResult['path'] !== 'not found'): ?>
            <br><small>Path: <span class="path-badge"><?php echo htmlspecialchars($installResult['path']); ?></span></small>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($installResult['output']) && $installResult['output']): ?>
        <div class="card">
            <h3>Installation Output</h3>
            <div class="output-box"><?php echo htmlspecialchars($installResult['output']); ?></div>
        </div>
        <?php endif; ?>
        
        <div class="card">
            <h2>Install Module</h2>
            <form method="POST" action="">
                <input type="hidden" name="action" value="install">
                
                <div class="form-group">
                    <label for="module_name">Module Name</label>
                    <input type="text" id="module_name" name="module_name" 
                           placeholder="e.g., LWP::Protocol::https" 
                           list="module-suggestions" autocomplete="off">
                    <datalist id="module-suggestions">
                        <?php foreach ($commonModules as $module => $desc): ?>
                        <option value="<?php echo htmlspecialchars($module); ?>">
                            <?php echo htmlspecialchars($desc); ?>
                        </option>
                        <?php endforeach; ?>
                    </datalist>
                </div>
                
                <button type="submit" class="btn btn-primary">Install Module</button>
            </form>
            
            <div style="margin-top: 15px;">
                <h3>Quick Install</h3>
                <div class="quick-buttons">
                    <button class="quick-btn" onclick="setModule('LWP::Protocol::https')">LWP::Protocol::https</button>
                    <button class="quick-btn" onclick="setModule('HTML::TreeBuilder')">HTML::TreeBuilder</button>
                    <button class="quick-btn" onclick="setModule('JSON::XS')">JSON::XS</button>
                    <button class="quick-btn" onclick="setModule('LWP::UserAgent')">LWP::UserAgent</button>
                    <button class="quick-btn" onclick="setModule('HTTP::Cookies')">HTTP::Cookies</button>
                    <button class="quick-btn" onclick="setModule('DBI')">DBI</button>
                    <button class="quick-btn" onclick="setModule('XML::Simple')">XML::Simple</button>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>Available Modules</h2>
            <div class="search-box">
                <input type="text" id="searchModules" placeholder="Filter modules..." onkeyup="filterModules()">
            </div>
            <div class="module-grid" id="moduleGrid">
                <?php
                foreach ($commonModules as $module => $desc) {
                    $installed = checkModule($module);
                    $version = $installed ? getModuleVersion($module) : 'not installed';
                    $path = $installed ? getModulePath($module) : '';
                    $statusClass = $installed ? 'installed' : 'missing';
                    $statusText = $installed ? "✓ v$version" : '✗ Missing';
                    
                    // Check if installed in custom path
                    $isCustom = $installed && isCustomPath($path);
                    if ($isCustom) {
                        $statusClass = 'found-custom';
                        $statusText .= ' 📁';
                    }
                    ?>
                    <div class="module-item" data-module="<?php echo htmlspecialchars($module); ?>">
                        <div>
                            <div class="module-name"><?php echo htmlspecialchars($module); ?></div>
                            <div class="module-desc"><?php echo htmlspecialchars($desc); ?></div>
                            <?php if ($isCustom): ?>
                            <div style="font-size: 10px; color: #6b7280; margin-top: 3px;">
                                📁 <?php echo htmlspecialchars($path); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <span class="module-status <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                            <?php if (!$installed): ?>
                            <button class="btn btn-primary btn-sm" onclick="installModule('<?php echo htmlspecialchars($module); ?>')">Install</button>
                            <?php elseif ($isCustom): ?>
                            <button class="btn btn-info btn-sm" onclick="showCustomModuleInfo('<?php echo htmlspecialchars($module); ?>', '<?php echo htmlspecialchars($path); ?>', '<?php echo htmlspecialchars($version); ?>')">💡 Info</button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        
        <!-- Custom Module Info Popup -->
        <div class="modal-overlay" id="customInfoPopup">
            <div class="modal-box">
                <button class="close-btn" onclick="closeCustomInfoPopup()">&times;</button>
                <h2>💡 Custom Module: <span id="popupModuleName"></span></h2>
                
                <div class="module-info">
                    <div><span class="label">Module:</span> <span class="value" id="popupModule"></span></div>
                    <div><span class="label">Version:</span> <span class="value" id="popupVersion"></span></div>
                    <div><span class="label">Location:</span> <span class="value" id="popupPath"></span></div>
                </div>
                
                <div class="tip">
                    <strong>✅ This module is installed in your custom Perl directory</strong><br>
                    To use it in your Perl scripts, you need to tell Perl where to find it.
                </div>
                
                <h3>Add this to your Perl script:</h3>
                <div class="code-block" id="popupCodeBlock">
                    #!/usr/bin/perl
                    <span class="comment"># Add custom module paths</span>
                    <span class="keyword">use</span> <span class="function">lib</span> <span class="string">'/home/alceawis/perl/usr/share/perl5'</span>;
                    <span class="keyword">use</span> <span class="function">lib</span> <span class="string">'/home/alceawis/perl/usr/lib64/perl5'</span>;
                    <span class="keyword">use</span> <span class="function">lib</span> <span class="string">'/home/alceawis/perl/usr/site_lib'</span>;
                    
                    <span class="comment"># Now use the module</span>
                    <span class="keyword" id="popupUseLine">use LWP::Protocol::https;</span>
                    
                    <span class="comment"># Example usage:</span>
                    <span class="keyword">use</span> <span class="function">LWP::UserAgent</span>;
                    <span class="keyword">use</span> <span class="function">JSON::XS</span>;
                    
                    <span class="keyword">my</span> <span class="function">\$ua</span> = LWP::UserAgent->new();
                    <span class="keyword">my</span> <span class="function">\$response</span> = \$ua->get('https://api.example.com');
                </div>
                
                <h3>Or set environment variable (in PHP):</h3>
                <div class="code-block">
                    <span class="comment">// In PHP</span>
                    <span class="function">putenv</span>(<span class="string">'PERL5LIB=/home/alceawis/perl/usr/share/perl5:/home/alceawis/perl/usr/lib64/perl5'</span>);
                    
                    <span class="comment">// Then execute Perl</span>
                    <span class="function">exec</span>(<span class="string">"perl your_script.pl 2>&1"</span>, <span class="function">\$output</span>);
                </div>
                
                <button class="btn-copy" onclick="copyCustomCode()">📋 Copy Code Snippet</button>
                <button class="btn btn-primary" onclick="closeCustomInfoPopup()" style="margin-left: 10px;">Close</button>
            </div>
        </div>
        
        <script>
            // Custom module info popup
            var currentModule = '';
            var currentPath = '';
            var currentVersion = '';
            
            function showCustomModuleInfo(module, path, version) {
                currentModule = module;
                currentPath = path;
                currentVersion = version;
                
                document.getElementById('popupModuleName').textContent = module;
                document.getElementById('popupModule').textContent = module;
                document.getElementById('popupVersion').textContent = version;
                document.getElementById('popupPath').textContent = path;
                document.getElementById('popupUseLine').textContent = 'use ' + module + ';';
                
                document.getElementById('customInfoPopup').style.display = 'flex';
            }
            
            function closeCustomInfoPopup() {
                document.getElementById('customInfoPopup').style.display = 'none';
            }
            
            // Close on outside click
            document.getElementById('customInfoPopup').addEventListener('click', function(e) {
                if (e.target === this) {
                    closeCustomInfoPopup();
                }
            });
            
            function copyCustomCode() {
                const code = `# Add custom module paths
        use lib '/home/alceawis/perl/usr/share/perl5';
        use lib '/home/alceawis/perl/usr/lib64/perl5';
        use lib '/home/alceawis/perl/usr/site_lib';
        
        # Now use the module
        use ${currentModule};
        
        # Example usage with LWP::Protocol::https:
        use LWP::UserAgent;
        use JSON::XS;
        
        my \$ua = LWP::UserAgent->new();
        my \$response = \$ua->get('https://api.example.com');`;
                
                navigator.clipboard.writeText(code).then(() => {
                    alert('✅ Code copied to clipboard!');
                }).catch(() => {
                    // Fallback
                    const textarea = document.createElement('textarea');
                    textarea.value = code;
                    document.body.appendChild(textarea);
                    textarea.select();
                    document.execCommand('copy');
                    document.body.removeChild(textarea);
                    alert('✅ Code copied to clipboard!');
                });
            }
            
            function setModule(name) {
                document.getElementById('module_name').value = name;
                document.getElementById('module_name').focus();
            }
            
            function installModule(name) {
                document.getElementById('module_name').value = name;
                document.querySelector('form').submit();
            }
            
            function filterModules() {
                const input = document.getElementById('searchModules');
                const filter = input.value.toLowerCase();
                const items = document.querySelectorAll('.module-item');
                
                items.forEach(item => {
                    const module = item.dataset.module.toLowerCase();
                    if (module.includes(filter)) {
                        item.style.display = 'flex';
                    } else {
                        item.style.display = 'none';
                    }
                });
            }
            
            // Quick install buttons
            document.querySelectorAll('.quick-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    document.getElementById('module_name').value = this.textContent.trim();
                    document.querySelector('form').submit();
                });
            });
            
            // Keyboard shortcut: Escape to close modal
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeCustomInfoPopup();
                }
            });
        </script>
    </div>
</body>
</html>