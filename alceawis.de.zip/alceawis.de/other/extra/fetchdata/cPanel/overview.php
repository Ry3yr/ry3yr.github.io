<?php
/**
 * cPanel “ALL‑DATA” Dashboard
 *
 * Fetches and displays the most common per‑account data sets:
 *   • Domains
 *   • Email accounts (+quota / disk)
 *   • FTP accounts (+disk)
 *   • MySQL databases
 *   • Cron jobs
 *   • Disk / Bandwidth summary
 *
 * Requires a cPanel API token with full UAPI + API 2 permissions.
 * Function names follow cPanel docs: DomainInfo::list_domains, Email::list_pops_with_disk,
 * Ftp::list_ftp_with_disk, Mysql::list_databases, Cron::listcron (API 2),
 * StatsBar::get_stats (display=diskusage|bandwidthusage). :contentReference[oaicite:0]{index=0}
 */

/* ====== CONFIGURE ME ====== */
$CPANEL_HOST = 'https://cp179.sp-server.net:2083';
$CPANEL_USER = isset($_GET['user']) ? trim($_GET['user']) : 'alceawis';
$API_TOKEN   = isset($_GET['apitoken']) ? trim($_GET['apitoken']) : 'token';
$VERIFY_SSL  = true;                    // set true in production
/* =========================== */

/* ---------- low‑level HTTP helper ---------- */
function cp_http($url, $user, $token, $verify)
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ["Authorization: cpanel $user:$token"],
        CURLOPT_SSL_VERIFYPEER => $verify,
    ]);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($err) { return ['error' => $err]; }
    $json = json_decode($raw, true);
    return $json ?: ['error' => 'Invalid JSON from cPanel'];
}

/* ---------- UAPI wrapper ---------- */
function uapi($host, $user, $token, $module, $func, $params = [], $verify = false)
{
    $qs  = $params ? ('?' . http_build_query($params)) : '';
    $url = "$host/execute/$module/$func$qs";
    return cp_http($url, $user, $token, $verify);
}

/* ---------- API 2 wrapper ---------- */
function api2($host, $user, $token, $module, $func, $params = [], $verify = false)
{
    $base = "$host/json-api/cpanel?cpanel_jsonapi_user=$user"
          . "&cpanel_jsonapi_apiversion=2"
          . "&cpanel_jsonapi_module=$module"
          . "&cpanel_jsonapi_func=$func";
    $url  = $params ? $base . '&' . http_build_query($params) : $base;
    return cp_http($url, $user, $token, $verify);
}

/* ---------- HTML table helper ---------- */
function table($records)
{
    if (empty($records) || !is_array($records)) { return '<em>No data</em>'; }
    // ensure we have a list of rows
    $records = array_values($records);
    $cols = array_keys($records[0]);
    $html = "<table><thead><tr>";
    foreach ($cols as $c) { $html .= "<th>" . htmlspecialchars($c) . "</th>"; }
    $html .= "</tr></thead><tbody>";
    foreach ($records as $row) {
        $html .= "<tr>";
        foreach ($cols as $c) {
            $val = $row[$c];
            if (is_array($val)) $val = json_encode($val);
            $html .= "<td>" . htmlspecialchars((string)$val) . "</td>";
        }
        $html .= "</tr>";
    }
    return $html . "</tbody></table>";
}

/* ---------- Fetch everything ---------- */
$domains   = uapi($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'DomainInfo', 'list_domains',             [],             $VERIFY_SSL);
$emails    = uapi($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'Email',      'list_pops_with_disk',     [],             $VERIFY_SSL);
$ftps      = uapi($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'Ftp',        'list_ftp_with_disk',      [],             $VERIFY_SSL);
$databases = uapi($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'Mysql',      'list_databases',          [],             $VERIFY_SSL);
$crons     = api2($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'Cron',       'listcron',                [],             $VERIFY_SSL);
$stats     = uapi($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'StatsBar',   'get_stats', ['display' => 'diskusage|bandwidthusage'], $VERIFY_SSL);

/* ---------- Build dashboard ---------- */
echo <<<HTML
<!DOCTYPE html><html><head>
<meta charset="utf-8"><title>cPanel Account Dashboard</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;}
h1{font-size:28px;margin-bottom:10px;}
h2{margin:30px 0 10px;}
table{border-collapse:collapse;width:100%;}
th,td{border:1px solid #ccc;padding:6px 8px;text-align:left;font-size:14px;}
th{background:#f0f0f0;}
em{color:#666;}
</style>
</head><body>
<h1>cPanel Account Dashboard</h1>
HTML;

/* -- Domains -- */
echo "<h2>Domains</h2>";
echo isset($domains['data']) ? table($domains['data']) : '<em>Error: '.htmlspecialchars(json_encode($domains)).'</em>';

/* -- Email Accounts -- */
echo "<h2>Email Accounts</h2>";
echo isset($emails['data']) ? table($emails['data']) : '<em>Error: '.htmlspecialchars(json_encode($emails)).'</em>';

/* -- FTP Accounts -- */
echo "<h2>FTP Accounts</h2>";
echo isset($ftps['data']) ? table($ftps['data']) : '<em>Error: '.htmlspecialchars(json_encode($ftps)).'</em>';

/* -- MySQL Databases -- */
echo "<h2>MySQL Databases</h2>";
echo isset($databases['data']) ? table($databases['data']) : '<em>Error: '.htmlspecialchars(json_encode($databases)).'</em>';

/* -- Cron Jobs -- */
echo "<h2>Cron Jobs</h2>";
echo isset($crons['cpanelresult']['data']) ? table($crons['cpanelresult']['data']) : '<em>Error: '.htmlspecialchars(json_encode($crons)).'</em>';

/* -- Disk / Bandwidth Summary -- */
echo "<h2>Disk &amp; Bandwidth Summary</h2>";
echo isset($stats['data']) ? table($stats['data']) : '<em>Error: '.htmlspecialchars(json_encode($stats)).'</em>';

echo "</body></html>";
?>
