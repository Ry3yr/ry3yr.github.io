<?php
/**
 * cPanel "ALL‑DATA" Dashboard with FTP Password Management
 *
 * Fetches and displays the most common per‑account data sets:
 *   • Domains
 *   • Email accounts (+quota / disk)
 *   • FTP accounts (+disk + password management)
 *   • MySQL databases
 *   • Cron jobs
 *   • Disk / Bandwidth summary
 *
 * Features:
 *   • Reset FTP passwords and display new ones
 *   • Create new FTP accounts with visible passwords
 *   • All passwords are shown ONCE for security
 *
 * Requires a cPanel API token with full UAPI + API 2 permissions.
 */

/* ====== CONFIGURE ME ====== */
$CPANEL_HOST = 'https://cp179.sp-server.net:2083';
$CPANEL_USER = isset($_GET['user']) ? trim($_GET['user']) : 'alceawis';
$API_TOKEN   = isset($_GET['apitoken']) ? trim($_GET['apitoken']) : 'token';
$VERIFY_SSL  = true;                    // set true in production
/* =========================== */

session_start(); // For temporary password display

/* ---------- low‑level HTTP helper ---------- */
function cp_http($url, $user, $token, $verify)
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ["Authorization: cpanel $user:$token"],
        CURLOPT_SSL_VERIFYPEER => $verify,
    ]);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($err) { return ['error' => $err]; }
    $json = json_decode($raw, true);
    return $json ?: ['error' => 'Invalid JSON from cPanel'];
}

/* ---------- UAPI wrapper ---------- */
function uapi($host, $user, $token, $module, $func, $params = [], $verify = false)
{
    $qs  = $params ? ('?' . http_build_query($params)) : '';
    $url = "$host/execute/$module/$func$qs";
    return cp_http($url, $user, $token, $verify);
}

/* ---------- API 2 wrapper ---------- */
function api2($host, $user, $token, $module, $func, $params = [], $verify = false)
{
    $base = "$host/json-api/cpanel?cpanel_jsonapi_user=$user"
          . "&cpanel_jsonapi_apiversion=2"
          . "&cpanel_jsonapi_module=$module"
          . "&cpanel_jsonapi_func=$func";
    $url  = $params ? $base . '&' . http_build_query($params) : $base;
    return cp_http($url, $user, $token, $verify);
}

/* ---------- FTP Password Management Functions ---------- */
function reset_ftp_password($host, $user, $token, $ftp_user, $domain, $verify = false)
{
    // Generate a secure random password
    $new_password = bin2hex(random_bytes(10)); // 20 char hex password
    
    $params = [
        'user' => $ftp_user,
        'domain' => $domain,
        'password' => $new_password
    ];
    
    $result = uapi($host, $user, $token, 'Ftp', 'passwd', $params, $verify);
    
    if (isset($result['data']) && $result['data']['status'] == 1) {
        return ['success' => true, 'password' => $new_password, 'message' => 'Password reset successfully'];
    }
    return ['success' => false, 'error' => $result['errors'][0] ?? 'Unknown error'];
}

function create_ftp_account($host, $user, $token, $ftp_user, $domain, $password, $quota = 0, $homedir = '', $verify = false)
{
    $params = [
        'user' => $ftp_user,
        'domain' => $domain,
        'password' => $password,
        'quota' => $quota, // 0 = unlimited, in MB
    ];
    
    if (!empty($homedir)) {
        $params['homedir'] = $homedir;
    }
    
    $result = uapi($host, $user, $token, 'Ftp', 'add_ftp', $params, $verify);
    
    if (isset($result['data']) && isset($result['data']['status']) && $result['data']['status'] == 1) {
        return [
            'success' => true,
            'username' => $ftp_user,
            'domain' => $domain,
            'password' => $password,
            'quota' => $quota,
            'message' => 'FTP account created successfully'
        ];
    }
    $error_msg = $result['errors'][0] ?? $result['data']['message'] ?? 'Unknown error';
    return ['success' => false, 'error' => $error_msg];
}

function delete_ftp_account($host, $user, $token, $ftp_user, $domain, $verify = false)
{
    $params = [
        'user' => $ftp_user,
        'domain' => $domain,
        'destroy' => 1
    ];
    
    $result = uapi($host, $user, $token, 'Ftp', 'delete_ftp', $params, $verify);
    
    if (isset($result['data']) && $result['data']['status'] == 1) {
        return ['success' => true, 'message' => 'FTP account deleted successfully'];
    }
    return ['success' => false, 'error' => $result['errors'][0] ?? 'Unknown error'];
}

/* ---------- HTML table helper with FTP actions ---------- */
function table($records, $show_actions = false, $host = '', $user = '', $token = '', $verify = false)
{
    if (empty($records) || !is_array($records)) { return '<em>No data</em>'; }
    
    $records = array_values($records);
    $cols = array_keys($records[0]);
    $html = "<table><thead><tr>";
    foreach ($cols as $c) { 
        $display_name = ucfirst(str_replace('_', ' ', $c));
        $html .= "<th>" . htmlspecialchars($display_name) . "</th>"; 
    }
    $html .= "</tr></thead><tbody>";
    
    foreach ($records as $row) {
        $html .= "<tr>";
        foreach ($cols as $c) {
            $val = $row[$c];
            if (is_array($val)) $val = json_encode($val);
            $html .= "<td>" . htmlspecialchars((string)$val) . "</td>";
        }
        $html .= "</tr>";
    }
    return $html . "</tbody></table>";
}

/* ---------- Process FTP Actions ---------- */
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'reset_password':
                if (isset($_POST['ftp_user'], $_POST['ftp_domain'])) {
                    $result = reset_ftp_password(
                        $CPANEL_HOST, 
                        $CPANEL_USER, 
                        $API_TOKEN,
                        $_POST['ftp_user'],
                        $_POST['ftp_domain'],
                        $VERIFY_SSL
                    );
                    
                    if ($result['success']) {
                        $message = "Password reset successfully! New password: <strong>" . htmlspecialchars($result['password']) . "</strong><br>
                                   <span style='font-size:12px;color:#666;'>⚠️ This password will not be shown again. Save it now!</span>";
                        $message_type = 'success';
                        // Store in session temporarily (optional)
                        $_SESSION['last_ftp_password'] = $result['password'];
                    } else {
                        $message = "Error: " . htmlspecialchars($result['error']);
                        $message_type = 'error';
                    }
                }
                break;
                
            case 'create_ftp':
                if (isset($_POST['ftp_username'], $_POST['ftp_domain'])) {
                    $new_password = bin2hex(random_bytes(10));
                    $quota = isset($_POST['ftp_quota']) ? (int)$_POST['ftp_quota'] : 0;
                    $homedir = $_POST['ftp_homedir'] ?? '';
                    
                    $result = create_ftp_account(
                        $CPANEL_HOST,
                        $CPANEL_USER,
                        $API_TOKEN,
                        $_POST['ftp_username'],
                        $_POST['ftp_domain'],
                        $new_password,
                        $quota,
                        $homedir,
                        $VERIFY_SSL
                    );
                    
                    if ($result['success']) {
                        $message = "✅ FTP Account Created Successfully!<br>
                                   Username: <strong>" . htmlspecialchars($result['username'] . '@' . $result['domain']) . "</strong><br>
                                   Password: <strong>" . htmlspecialchars($result['password']) . "</strong><br>
                                   Quota: " . ($result['quota'] == 0 ? 'Unlimited' : $result['quota'] . ' MB') . "<br>
                                   <span style='font-size:12px;color:#666;'>⚠️ Save this password now. It won't be shown again!</span>";
                        $message_type = 'success';
                        $_SESSION['last_ftp_password'] = $result['password'];
                    } else {
                        $message = "Error creating FTP account: " . htmlspecialchars($result['error']);
                        $message_type = 'error';
                    }
                }
                break;
                
            case 'delete_ftp':
                if (isset($_POST['ftp_user'], $_POST['ftp_domain'])) {
                    $result = delete_ftp_account(
                        $CPANEL_HOST,
                        $CPANEL_USER,
                        $API_TOKEN,
                        $_POST['ftp_user'],
                        $_POST['ftp_domain'],
                        $VERIFY_SSL
                    );
                    
                    if ($result['success']) {
                        $message = "✅ " . htmlspecialchars($result['message']);
                        $message_type = 'success';
                    } else {
                        $message = "Error: " . htmlspecialchars($result['error']);
                        $message_type = 'error';
                    }
                }
                break;
        }
    }
}

/* ---------- Fetch FTP accounts with action buttons ---------- */
function get_ftp_accounts_with_actions($host, $user, $token, $verify = false)
{
    $ftps = uapi($host, $user, $token, 'Ftp', 'list_ftp_with_disk', [], $verify);
    
    if (!isset($ftps['data']) || !is_array($ftps['data'])) {
        return $ftps;
    }
    
    // Add action buttons to each FTP account
    foreach ($ftps['data'] as &$ftp_account) {
        $ftp_account['password_status'] = '🔒 Encrypted (cannot retrieve)';
        $ftp_account['actions'] = '
            <form method="post" style="display:inline-block; margin-right:5px;" onsubmit="return confirm(\'Reset password for ' . htmlspecialchars($ftp_account['user']) . '? A new random password will be generated.\')">
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="ftp_user" value="' . htmlspecialchars($ftp_account['user']) . '">
                <input type="hidden" name="ftp_domain" value="' . htmlspecialchars($ftp_account['domain']) . '">
                <button type="submit" style="background:#ffc107; color:#000; border:none; padding:4px 8px; cursor:pointer; border-radius:3px;">🔄 Reset Password</button>
            </form>
            <form method="post" style="display:inline-block;" onsubmit="return confirm(\'Delete FTP account ' . htmlspecialchars($ftp_account['user']) . '? This action cannot be undone.\')">
                <input type="hidden" name="action" value="delete_ftp">
                <input type="hidden" name="ftp_user" value="' . htmlspecialchars($ftp_account['user']) . '">
                <input type="hidden" name="ftp_domain" value="' . htmlspecialchars($ftp_account['domain']) . '">
                <button type="submit" style="background:#dc3545; color:#fff; border:none; padding:4px 8px; cursor:pointer; border-radius:3px;">🗑️ Delete</button>
            </form>
        ';
    }
    
    return $ftps;
}

/* ---------- Fetch everything ---------- */
$domains   = uapi($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'DomainInfo', 'list_domains',             [],             $VERIFY_SSL);
$emails    = uapi($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'Email',      'list_pops_with_disk',     [],             $VERIFY_SSL);
$ftps      = get_ftp_accounts_with_actions($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, $VERIFY_SSL);
$databases = uapi($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'Mysql',      'list_databases',          [],             $VERIFY_SSL);
$crons     = api2($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'Cron',       'listcron',                [],             $VERIFY_SSL);
$stats     = uapi($CPANEL_HOST, $CPANEL_USER, $API_TOKEN, 'StatsBar',   'get_stats', ['display' => 'diskusage|bandwidthusage'], $VERIFY_SSL);

// Get main domain for FTP creation form
$main_domain = '';
if (isset($domains['data']['main_domain'])) {
    $main_domain = $domains['data']['main_domain'];
} elseif (isset($domains['data'][0]['domain'])) {
    $main_domain = $domains['data'][0]['domain'];
}

/* ---------- Build dashboard ---------- */
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>cPanel Account Dashboard - FTP Password Manager</title>
<style>
    * {
        box-sizing: border-box;
    }
    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, Helvetica, sans-serif;
        margin: 0;
        padding: 20px;
        background: #f5f5f5;
    }
    .container {
        max-width: 1400px;
        margin: 0 auto;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        overflow: hidden;
    }
    .header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 20px 30px;
    }
    .header h1 {
        margin: 0;
        font-size: 28px;
    }
    .header p {
        margin: 5px 0 0;
        opacity: 0.9;
    }
    .content {
        padding: 30px;
    }
    .message {
        padding: 15px 20px;
        margin-bottom: 20px;
        border-radius: 5px;
        border-left: 4px solid;
        animation: slideIn 0.3s ease-out;
    }
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    .message.success {
        background: #d4edda;
        border-color: #28a745;
        color: #155724;
    }
    .message.error {
        background: #f8d7da;
        border-color: #dc3545;
        color: #721c24;
    }
    h2 {
        color: #333;
        border-bottom: 2px solid #667eea;
        padding-bottom: 8px;
        margin: 30px 0 20px 0;
        font-size: 22px;
    }
    table {
        border-collapse: collapse;
        width: 100%;
        background: white;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        margin-bottom: 20px;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 10px 12px;
        text-align: left;
        font-size: 14px;
    }
    th {
        background: #f8f9fa;
        font-weight: 600;
        color: #495057;
    }
    tr:hover {
        background: #f8f9fa;
    }
    em {
        color: #666;
        font-style: italic;
    }
    .form-container {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        margin: 20px 0 30px;
        border: 1px solid #e0e0e0;
    }
    .form-container h3 {
        margin-top: 0;
        color: #495057;
    }
    .form-group {
        margin-bottom: 15px;
    }
    .form-group label {
        display: inline-block;
        width: 120px;
        font-weight: 600;
        color: #495057;
    }
    .form-group input {
        padding: 8px 12px;
        border: 1px solid #ced4da;
        border-radius: 4px;
        width: 250px;
        font-size: 14px;
    }
    .form-group small {
        display: block;
        margin-left: 125px;
        color: #6c757d;
        font-size: 12px;
        margin-top: 4px;
    }
    button {
        background: #667eea;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 14px;
        transition: background 0.3s;
    }
    button:hover {
        background: #5a67d8;
    }
    .badge {
        background: #28a745;
        color: white;
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 11px;
        margin-left: 5px;
    }
    .footer {
        background: #f8f9fa;
        padding: 15px 30px;
        text-align: center;
        color: #6c757d;
        font-size: 12px;
        border-top: 1px solid #e0e0e0;
    }
    @media (max-width: 768px) {
        .content {
            padding: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input {
            width: 100%;
        }
        .form-group small {
            margin-left: 0;
        }
        table {
            font-size: 12px;
        }
        th, td {
            padding: 6px 8px;
        }
    }
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>🚀 cPanel Account Dashboard</h1>
        <p>User: <?php echo htmlspecialchars($CPANEL_USER); ?> | Complete Account Management with FTP Password Tools</p>
    </div>
    
    <div class="content">
        <?php if ($message): ?>
            <div class="message <?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <!-- FTP Account Creation Form -->
        <div class="form-container">
            <h3>➕ Create New FTP Account</h3>
            <form method="post">
                <input type="hidden" name="action" value="create_ftp">
                
                <div class="form-group">
                    <label>Username:</label>
                    <input type="text" name="ftp_username" placeholder="e.g., myftpuser" required pattern="[a-zA-Z0-9]+" title="Only letters and numbers">
                    <small>Letters and numbers only, no spaces</small>
                </div>
                
                <div class="form-group">
                    <label>Domain:</label>
                    <input type="text" name="ftp_domain" value="<?php echo htmlspecialchars($main_domain); ?>" required>
                    <small>Select the domain for this FTP account</small>
                </div>
                
                <div class="form-group">
                    <label>Quota (MB):</label>
                    <input type="number" name="ftp_quota" value="0" min="0">
                    <small>0 = Unlimited</small>
                </div>
                
                <div class="form-group">
                    <label>Home Directory:</label>
                    <input type="text" name="ftp_homedir" placeholder="Leave empty for default (/home/user/)">
                    <small>Optional: Specify custom home directory path</small>
                </div>
                
                <button type="submit">✨ Create FTP Account (Password will be shown)</button>
            </form>
        </div>
        
        <!-- Security Notice -->
        <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 10px 15px; margin-bottom: 20px; border-radius: 4px;">
            <strong>🔐 Security Notice:</strong>
            <ul style="margin: 8px 0 0 20px; padding: 0;">
                <li>Existing FTP passwords cannot be retrieved (they are encrypted)</li>
                <li>Use "Reset Password" to generate a new secure password</li>
                <li>New passwords are shown only once - save them immediately</li>
                <li>All actions are logged by cPanel for audit purposes</li>
            </ul>
        </div>
        
        <?php
        /* -- Domains -- */
        echo "<h2>🌐 Domains</h2>";
        if (isset($domains['data'])) {
            // Format domains nicely
            $domain_list = [];
            if (isset($domains['data']['main_domain'])) {
                $domain_list[] = ['domain' => $domains['data']['main_domain'], 'type' => 'Main Domain'];
                if (isset($domains['data']['addon_domains'])) {
                    foreach ($domains['data']['addon_domains'] as $addon) {
                        $domain_list[] = ['domain' => $addon, 'type' => 'Addon Domain'];
                    }
                }
                if (isset($domains['data']['sub_domains'])) {
                    foreach ($domains['data']['sub_domains'] as $sub) {
                        $domain_list[] = ['domain' => $sub, 'type' => 'Subdomain'];
                    }
                }
                echo table($domain_list);
            } else {
                echo table($domains['data']);
            }
        } else {
            echo '<em>Error: ' . htmlspecialchars(json_encode($domains)) . '</em>';
        }
        
        /* -- Email Accounts -- */
        echo "<h2>📧 Email Accounts</h2>";
        if (isset($emails['data'])) {
            echo table($emails['data']);
        } else {
            echo '<em>Error: ' . htmlspecialchars(json_encode($emails)) . '</em>';
        }
        
        /* -- FTP Accounts (with actions) -- */
        echo "<h2>📁 FTP Accounts <span class='badge'>Password Manager Active</span></h2>";
        if (isset($ftps['data']) && !empty($ftps['data'])) {
            echo table($ftps['data'], true);
        } else {
            echo '<em>No FTP accounts found or error occurred</em>';
            if (isset($ftps['error'])) {
                echo '<br><em>Error details: ' . htmlspecialchars($ftps['error']) . '</em>';
            }
        }
        
        /* -- MySQL Databases -- */
        echo "<h2>🗄️ MySQL Databases</h2>";
        if (isset($databases['data'])) {
            echo table($databases['data']);
        } else {
            echo '<em>Error: ' . htmlspecialchars(json_encode($databases)) . '</em>';
        }
        
        /* -- Cron Jobs -- */
        echo "<h2>⏰ Cron Jobs</h2>";
        if (isset($crons['cpanelresult']['data']) && !empty($crons['cpanelresult']['data'])) {
            echo table($crons['cpanelresult']['data']);
        } else {
            echo '<em>No cron jobs found or error occurred</em>';
        }
        
        /* -- Disk / Bandwidth Summary -- */
        echo "<h2>📊 Disk & Bandwidth Summary</h2>";
        if (isset($stats['data'])) {
            $stats_data = [];
            if (isset($stats['data']['diskusage'])) {
                $stats_data[] = ['Metric' => 'Disk Usage', 'Value' => $stats['data']['diskusage']];
            }
            if (isset($stats['data']['bandwidthusage'])) {
                $stats_data[] = ['Metric' => 'Bandwidth Usage', 'Value' => $stats['data']['bandwidthusage']];
            }
            if (!empty($stats_data)) {
                echo table($stats_data);
            } else {
                echo table($stats['data']);
            }
        } else {
            echo '<em>Error: ' . htmlspecialchars(json_encode($stats)) . '</em>';
        }
        ?>
        
        <!-- JavaScript for additional client-side password generation -->
        <script>
            // Optional: Add client-side password generation for testing
            function generateRandomPassword() {
                var length = 16;
                var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()";
                var password = "";
                for (var i = 0; i < length; i++) {
                    password += charset.charAt(Math.floor(Math.random() * charset.length));
                }
                return password;
            }
            
            // Show a warning before password reset
            document.querySelectorAll('form[onsubmit*="reset"]').forEach(form => {
                form.addEventListener('submit', function(e) {
                    if (!confirm('⚠️ WARNING: This will generate a NEW password for this FTP account.\n\nThe old password will stop working immediately.\n\nMake sure to save the new password when shown!\n\nContinue?')) {
                        e.preventDefault();
                    }
                });
            });
        </script>
    </div>
    
    <div class="footer">
        <p>cPanel Dashboard with FTP Password Management | API Token Authentication | Secure Connection: <?php echo $VERIFY_SSL ? '✅ Enabled' : '⚠️ Disabled (dev only)'; ?></p>
        <p>⚠️ Passwords are shown only once for security. Save them immediately.</p>
    </div>
</div>
</body>
</html>