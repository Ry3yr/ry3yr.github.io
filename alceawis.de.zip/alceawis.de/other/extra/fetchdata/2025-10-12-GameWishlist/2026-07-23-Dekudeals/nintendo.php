<?php
// Simple PHP script to show discounted games from Deku Deals wishlist
// Usage: ?compact - shows widget with ALL games, collapsed by default

// Fetch and parse the HTML
$html = file_get_contents('https://www.dekudeals.com/wishlist/nw7vnrstb9');

$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($html);
libxml_clear_errors();

$xpath = new DOMXPath($dom);

// Find all game items
$games = $xpath->query("//div[contains(@class, 'd-block') and contains(@class, 'col')]/div[contains(@class, 'd-flex') and contains(@class, 'position-relative')]");

$discountedGames = [];

foreach ($games as $game) {
    $link = $xpath->query(".//a[contains(@class, 'main-link')]", $game)->item(0);
    if (!$link) continue;
    
    $name = trim($link->nodeValue);
    $url = 'https://www.dekudeals.com' . $link->getAttribute('href');
    
    $priceDiv = $xpath->query(".//div[contains(@class, 'd-flex') and contains(@class, 'align-items-center') and contains(@class, 'text-tight')]", $game)->item(0);
    if (!$priceDiv) continue;
    
    $original = $xpath->query(".//s[contains(@class, 'text-muted')]", $priceDiv)->item(0);
    $current = $xpath->query(".//strong", $priceDiv)->item(0);
    $badge = $xpath->query(".//span[contains(@class, 'badge-danger')]", $priceDiv)->item(0);
    
    // Get sale end date if available
    $endDate = 'N/A';
    $dateDiv = $xpath->query(".//div[contains(@class, 'd-flex')]/small", $game)->item(0);
    if ($dateDiv) {
        $dateText = trim($dateDiv->nodeValue);
        if (strpos($dateText, 'Sale ends') !== false) {
            $endDate = str_replace('Sale ends ', '', $dateText);
        }
    }
    
    // Only get discounted games
    if ($badge && $original && $current) {
        $origPrice = floatval(str_replace(['€', ','], ['', '.'], trim($original->nodeValue)));
        $currPrice = floatval(str_replace(['€', ','], ['', '.'], trim($current->nodeValue)));
        $discountPercent = round((($origPrice - $currPrice) / $origPrice) * 100);
        
        $discountedGames[] = [
            'name' => $name,
            'url' => $url,
            'original' => trim($original->nodeValue),
            'current' => trim($current->nodeValue),
            'discount' => $discountPercent,
            'end_date' => $endDate
        ];
    }
}

// Sort by discount (highest first)
usort($discountedGames, function($a, $b) {
    return $b['discount'] - $a['discount'];
});

$totalCount = count($discountedGames);

// Handle compact mode
$compact = isset($_GET['compact']);

if ($compact) {
    // Show widget with ALL games, COLLAPSED by default
    ?>
    <div style="font-family: Arial, sans-serif; max-width: 500px; background: white; border-radius: 10px; padding: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <div style="display: flex; justify-content: space-between; align-items: center; cursor: pointer;" onclick="toggleGames()">
            <h4 style="margin: 0;">🎮 Discounted Games</h4>
            <span style="background: #dc3545; color: white; padding: 3px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;"><?php echo $totalCount; ?></span>
        </div>
        <div id="gameList" style="margin-top: 10px; display: none;">
            <?php foreach ($discountedGames as $game): ?>
                <div style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 14px;">
                    <a href="<?php echo $game['url']; ?>" target="_blank" style="color: #333; text-decoration: none; font-weight: bold;">
                        <?php echo htmlspecialchars($game['name']); ?>
                    </a>
                    <div style="display: flex; gap: 8px; align-items: center; margin-top: 2px; flex-wrap: wrap;">
                        <span style="text-decoration: line-through; color: #999; font-size: 12px;"><?php echo $game['original']; ?></span>
                        <span style="font-weight: bold; color: #28a745;"><?php echo $game['current']; ?></span>
                        <span style="background: #dc3545; color: white; padding: 1px 6px; border-radius: 10px; font-size: 10px;">-<?php echo $game['discount']; ?>%</span>
                        <?php if ($game['end_date'] != 'N/A'): ?>
                            <span style="color: #666; font-size: 10px;">⏰ <?php echo $game['end_date']; ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <script>
    function sendHeight() {
        if (window.parent && window.parent !== window) {
            var h = document.documentElement.scrollHeight;
            window.parent.postMessage({ height: h }, '*');
        }
    }
    
    function toggleGames() {
        var list = document.getElementById('gameList');
        if (list.style.display === 'none') {
            list.style.display = 'block';
        } else {
            list.style.display = 'none';
        }
        // Send height multiple times with delays to ensure proper rendering
        setTimeout(sendHeight, 10);
        setTimeout(sendHeight, 50);
        setTimeout(sendHeight, 150);
        setTimeout(sendHeight, 300);
    }
    
    // Send height on load and after any potential layout shifts
    window.addEventListener('load', function() {
        setTimeout(sendHeight, 100);
        setTimeout(sendHeight, 300);
        setTimeout(sendHeight, 500);
    });
    
    // Also send height on resize
    window.addEventListener('resize', function() {
        setTimeout(sendHeight, 50);
    });
    
    // MutationObserver to detect changes in the DOM
    if (window.MutationObserver) {
        var observer = new MutationObserver(function() {
            setTimeout(sendHeight, 50);
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true
        });
    }
    </script>
    <?php
    exit;
}

// Full view with all games
?><!DOCTYPE html>
<html>
<head>
    <title>Discounted Games</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: #f5f5f5; }
        .widget { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .badge { background: #dc3545; color: white; padding: 5px 15px; border-radius: 20px; font-size: 14px; }
        .game-item { padding: 12px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
        .game-item:last-child { border-bottom: none; }
        .game-name { font-weight: bold; color: #333; text-decoration: none; }
        .game-name:hover { color: #007bff; }
        .prices { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .original { text-decoration: line-through; color: #999; }
        .current { font-weight: bold; color: #28a745; }
        .discount-badge { background: #dc3545; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
        .end-date { color: #666; font-size: 12px; }
        .compact-link { margin-bottom: 15px; display: inline-block; color: #007bff; text-decoration: none; }
        .compact-link:hover { text-decoration: underline; }
        .stats { background: #e7f3ff; padding: 15px; margin: 20px 0; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="widget">
        <div class="header">
            <h2>🎮 Discounted Games</h2>
            <span class="badge"><?php echo $totalCount; ?> games on sale</span>
        </div>
        
        <a href="?compact" class="compact-link">▼ View Compact Widget</a>
        
        <div class="stats">
            <strong>All <?php echo $totalCount; ?> discounted games</strong>
        </div>
        
        <?php if ($totalCount > 0): ?>
            <?php foreach ($discountedGames as $game): ?>
                <div class="game-item">
                    <a href="<?php echo $game['url']; ?>" target="_blank" class="game-name">
                        <?php echo htmlspecialchars($game['name']); ?>
                    </a>
                    <div class="prices">
                        <span class="original"><?php echo $game['original']; ?></span>
                        <span class="current"><?php echo $game['current']; ?></span>
                        <span class="discount-badge">-<?php echo $game['discount']; ?>%</span>
                        <?php if ($game['end_date'] != 'N/A'): ?>
                            <span class="end-date">⏰ <?php echo $game['end_date']; ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align: center; color: #999; padding: 20px;">No discounted games found</p>
        <?php endif; ?>
    </div>
</body>
</html>