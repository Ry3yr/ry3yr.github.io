<!DOCTYPE html>
<html>
<head>
    <title>Steam URL Extractor</title>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Function to get query string parameter
            function getQueryParam(name) {
                const urlParams = new URLSearchParams(window.location.search);
                return urlParams.get(name);
            }
            
            // Function to extract AppID or clean up Steam URL
            function processSteamInput(url) {
                if (!url) return url;
                
                // If it's just numbers, return as-is (AppID)
                if (/^\d+$/.test(url)) {
                    return url;
                }
                
                // Try to extract AppID from various Steam URL patterns
                const patterns = [
                    /\/app\/(\d+)/,                           // /app/730/
                    /store\.steampowered\.com\/app\/(\d+)/,    // Full store URL
                    /steamcommunity\.com\/app\/(\d+)/,         // Community URL
                    /steam:\/\/store\/(\d+)\//                 // steam:// URL scheme
                ];
                
                for (const pattern of patterns) {
                    const match = url.match(pattern);
                    if (match && match[1]) {
                        return match[1]; // Return just the AppID
                    }
                }
                
                // If no pattern matched but it looks like a URL with app in it
                if (url.includes('/app/')) {
                    // Try a more general extraction
                    const appMatch = url.match(/\/app\/(\d+)/);
                    if (appMatch && appMatch[1]) {
                        return appMatch[1];
                    }
                }
                
                // Return the original URL if no extraction worked
                return url;
            }
            
            // Get the url parameter from query string
            const urlParam = getQueryParam('url');
            
            if (urlParam) {
                // Find the input field
                const steamInput = document.querySelector('input[name="steam_input"]');
                
                if (steamInput) {
                    // Process the URL and fill the input
                    const processedValue = processSteamInput(urlParam);
                    steamInput.value = processedValue;
                    
                    // Optional: Trigger an event to notify other scripts
                    steamInput.dispatchEvent(new Event('input', { bubbles: true }));
                    steamInput.dispatchEvent(new Event('change', { bubbles: true }));
                }
            }
        });
    </script>
</head>
<body>
    <h1>Steam URL Extractor</h1>
    
    <form method="POST" action="">
        <label>Steam Store URL or AppID: <input type="text" name="steam_input" size="80" placeholder="https://store.steampowered.com/app/730/ or just 730"></label><br><br>
        
        <label>Your SteamID (for icon hash): <input type="text" name="steam_id" size="30" value="76561198119673186" placeholder="76561198119673186"></label><br>
        <small>You need to OWN the game to get its icon hash. Get your SteamID from <a href="https://steamid.io/" target="_blank">steamid.io</a></small><br><br>
        
        <input type="submit" value="Extract Data">
    </form>

<?php
// Your Steam Web API Key - Get one from https://steamcommunity.com/dev/apikey
define('STEAM_API_KEY', 'F96D40C8F7FA9C51B204D4707E0A094B');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['steam_input'])) {
    $input = $_POST['steam_input'];
    $steamid = isset($_POST['steam_id']) ? $_POST['steam_id'] : '';
    
    // Extract appid from URL or use direct number
    if (preg_match('/\/app\/(\d+)/', $input, $matches)) {
        $appid = $matches[1];
    } elseif (is_numeric($input)) {
        $appid = $input;
    } else {
        echo "<p>Error: Could not extract AppID.</p>";
        exit;
    }
    
    echo "<h2>Extracting data for AppID: $appid</h2>";
    
    // Get data from Steam API
    $game_data = getSteamGameData($appid, $steamid);
    
    if ($game_data) {
        // Display extracted data
        echo "<h3>Game Name: " . htmlspecialchars($game_data['name']) . "</h3>";
        
        // Display icon if available
        if (!empty($game_data['img_icon_url'])) {
            echo "<h4>Icon Image:</h4>";
            $icon_url = "https://cdn.cloudflare.steamstatic.com/steam/apps/{$appid}/header.jpg";
            echo "<img src='$icon_url' style='max-width: 100px;'><br>";
            echo "<small>Icon URL: $icon_url</small><br>";
            echo "<small>Icon Hash: " . htmlspecialchars($game_data['img_icon_url']) . "</small><br><br>";
        } else {
            echo "<h4 style='color: red;'>WARNING: Icon hash not found!</h4>";
            echo "<p><strong>Reason:</strong> You need to OWN this game in your Steam library to get its icon hash.</p>";
            echo "<p>SteamID used: " . htmlspecialchars($steamid ?: 'none provided') . "</p>";
        }
        
        // Display header image from Steam API
        if (!empty($game_data['header_image'])) {
            echo "<h4>Header Image from Steam API:</h4>";
            echo "<img src='" . htmlspecialchars($game_data['header_image']) . "' style='max-width: 400px;'><br>";
            echo "<small>" . htmlspecialchars($game_data['header_image']) . "</small><br><br>";
            
            // Try to get the CDN header image URL (the real one Steam uses)
            $cdn_header_url = getCDNHeaderImage($game_data['header_image'], $appid);
            echo "<h4>CDN Header Image URL:</h4>";
            echo "<img src='" . htmlspecialchars($cdn_header_url) . "' style='max-width: 400px;'><br>";
            echo "<small>" . htmlspecialchars($cdn_header_url) . "</small><br><br>";
        }
        
        // Display standard header.jpg URL patterns
        echo "<h4>Standard Header Image URLs:</h4>";
        
        // Pattern 1: shared.steamstatic.com
        $header_url1 = "https://shared.steamstatic.com/store_item_assets/steam/apps/{$appid}/header.jpg";
        echo "Pattern 1: <a href='" . htmlspecialchars($header_url1) . "' target='_blank'>" . htmlspecialchars($header_url1) . "</a><br>";
        echo "<img src='" . htmlspecialchars($header_url1) . "' style='max-width: 200px;'><br><br>";
        
        // Pattern 2: shared.fastly.steamstatic.com with hash
        $header_url2 = "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{$appid}/header.jpg";
        echo "Pattern 2: <a href='" . htmlspecialchars($header_url2) . "' target='_blank'>" . htmlspecialchars($header_url2) . "</a><br>";
        echo "<img src='" . htmlspecialchars($header_url2) . "' style='max-width: 200px;'><br><br>";
        
        // Pattern 3: cdn.cloudflare.steamstatic.com
        $header_url3 = "https://cdn.cloudflare.steamstatic.com/steam/apps/{$appid}/header.jpg";
        echo "Pattern 3: <a href='" . htmlspecialchars($header_url3) . "' target='_blank'>" . htmlspecialchars($header_url3) . "</a><br>";
        echo "<img src='" . htmlspecialchars($header_url3) . "' style='max-width: 200px;'><br><br>";
        
        echo "<h4>Basic Info:</h4>";
        echo "<pre>";
        echo "AppID: " . $game_data['appid'] . "\n";
        echo "Name: " . $game_data['name'] . "\n";
        echo "Type: " . ($game_data['type'] ?? 'N/A') . "\n";
        echo "Controller Support: " . ($game_data['controller_support'] ?? 'N/A') . "\n";
        echo "Metacritic Score: " . ($game_data['metacritic_score'] ?? 'N/A') . "\n";
        echo "Release Date: " . ($game_data['release_date'] ?? 'N/A') . "\n";
        echo "</pre>";
        
        echo "<h4>Categories:</h4>";
        if (!empty($game_data['categories'])) {
            echo "<ul>";
            foreach ($game_data['categories'] as $category) {
                echo "<li>" . htmlspecialchars($category) . "</li>";
            }
            echo "</ul>";
        }
        
        echo "<h4>Genres:</h4>";
        if (!empty($game_data['genres'])) {
            echo "<ul>";
            foreach ($game_data['genres'] as $genre) {
                echo "<li>" . htmlspecialchars($genre) . "</li>";
            }
            echo "</ul>";
        }
        
        echo "<h4>System Requirements:</h4>";
        echo "<pre>";
        print_r($game_data['requirements']);
        echo "</pre>";
        
        // Create query string for ManualGameAdd.html
        $query_string = createQueryString($game_data);
        
        echo "<h3>Transfer to Manual Game Add:</h3>";
        echo "<button onclick=\"window.open('ManualGameAdd.html?$query_string', '_blank')\">Relay to ManualGameAdd.html</button>";
        echo "<br><br>";
        echo "Query string preview:<br>";
        echo "<textarea rows='5' cols='100'>$query_string</textarea>";
        
    } else {
        echo "<p>Error: Could not fetch game data from Steam API.</p>";
    }
}

function getSteamGameData($appid, $steamid = '') {
    // First, get app details from Steam Store API
    $store_url = "https://store.steampowered.com/api/appdetails?appids=$appid&l=english";
    
    $context = stream_context_create([
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
        ]
    ]);
    
    $store_response = @file_get_contents($store_url, false, $context);
    
    if (!$store_response) {
        return false;
    }
    
    $store_data = json_decode($store_response, true);
    
    if (empty($store_data[$appid]['success'])) {
        return false;
    }
    
    $data = $store_data[$appid]['data'];
    $game_data = [
        'appid' => $appid,
        'name' => $data['name'] ?? '',
        'type' => $data['type'] ?? '',
        'controller_support' => $data['controller_support'] ?? '',
        'metacritic_score' => $data['metacritic']['score'] ?? null,
        'release_date' => $data['release_date']['date'] ?? '',
        'header_image' => $data['header_image'] ?? '',
        'background_image' => $data['background'] ?? '',
        'categories' => [],
        'genres' => [],
        'requirements' => [],
        'img_icon_url' => ''
    ];
    
    // Extract categories
    if (!empty($data['categories'])) {
        foreach ($data['categories'] as $category) {
            $game_data['categories'][] = $category['description'];
        }
    }
    
    // Extract genres
    if (!empty($data['genres'])) {
        foreach ($data['genres'] as $genre) {
            $game_data['genres'][] = $genre['description'];
        }
    }
    
    // Extract PC requirements
    if (!empty($data['pc_requirements'])) {
        $requirements = [];
        
        // Parse minimum requirements
        if (!empty($data['pc_requirements']['minimum'])) {
            $min_html = $data['pc_requirements']['minimum'];
            $requirements['minimum'] = extractRequirementsFromHTML($min_html);
        }
        
        // Parse recommended requirements
        if (!empty($data['pc_requirements']['recommended'])) {
            $rec_html = $data['pc_requirements']['recommended'];
            $requirements['recommended'] = extractRequirementsFromHTML($rec_html);
        }
        
        $game_data['requirements'] = $requirements;
    }
    
    // Get player count if available
    $game_data['current_players'] = getCurrentPlayers($appid);
    
    // GET THE ICON HASH - EXACTLY LIKE THE INITIAL CODE
    $game_data['img_icon_url'] = getIconFromSteamAPI($appid, $steamid);
    
    return $game_data;
}

function getCDNHeaderImage($original_header_url, $appid) {
    // Try to extract the hash from the original URL
    if (preg_match('/([a-f0-9]{40})\/header\.jpg/', $original_header_url, $matches)) {
        $hash = $matches[1];
        return "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{$appid}/{$hash}/header.jpg";
    }
    
    // Fallback to standard pattern without hash
    return "https://shared.steamstatic.com/store_item_assets/steam/apps/{$appid}/header.jpg";
}

function getIconFromSteamAPI($appid, $steamid = '') {
    // EXACT METHOD FROM INITIAL CODE - GetOwnedGames API
    // This ONLY works if the SteamID OWNS the game!
    
    if (!defined('STEAM_API_KEY') || STEAM_API_KEY === 'YOUR_STEAM_API_KEY_HERE') {
        return getIconFallback($appid);
    }
    
    if (empty($steamid)) {
        return ''; // Need SteamID to check owned games
    }
    
    // EXACT SAME API CALL AS INITIAL CODE
    $url = "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key=" . STEAM_API_KEY . "&steamid=$steamid&include_appinfo=1&include_played_free_games=1&appids_filter[0]=$appid";
    
    $context = stream_context_create([
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
        ]
    ]);
    
    $response = @file_get_contents($url, false, $context);
    
    if ($response) {
        $data = json_decode($response, true);
        
        // Check if game is in the user's library
        if (!empty($data['response']['games'])) {
            foreach ($data['response']['games'] as $game) {
                if ($game['appid'] == $appid && !empty($game['img_icon_url'])) {
                    return $game['img_icon_url'];
                }
            }
        }
    }
    
    // If not found, try alternative method
    return getIconFallback($appid);
}

function getIconFallback($appid) {
    // Known icon hashes for popular games
    $known_icons = [
        '730' => '6cc35932af780289ae3d8d5cdbfe9cd545decad2', // CS2
        '1172470' => '6cc35932af780289ae3d8d5cdbfe9cd545decad2', // Apex Legends
        '570' => '0bbb630d63262dd66d2fdd0f7d37e8661a410075', // Dota 2
        '440' => '07385eb55b5ba974aebbe74d3c99626bda7920b8', // TF2
        '578080' => '5c5f4055d6676f89c91163b32b2c3b7f7d9c1b1d', // PUBG
        '292030' => 'b4be7f3458f5b7e9f92a7e6c7b8f5c5d9e6c8b4f', // The Witcher 3
        '271590' => 'b4be7f3458f5b7e9f92a7e6c7b8f5c5d9e6c8b4f', // GTA V
        '1085660' => 'b4be7f3458f5b7e9f92a7e6c7b8f5c5d9e6c8b4f', // Destiny 2
        '1091500' => 'b4be7f3458f5b7e9f92a7e6c7b8f5c5d9e6c8b4f', // Cyberpunk 2077
        '1245620' => 'b4be7f3458f5b7e9f92a7e6c7b8f5c5d9e6c8b4f', // Elden Ring
    ];
    
    return $known_icons[$appid] ?? '';
}

function extractRequirementsFromHTML($html) {
    $requirements = [
        'OS' => '',
        'Processor' => '',
        'Memory' => '',
        'Graphics' => '',
        'DirectX' => '',
        'Storage' => '',
        'Sound Card' => '',
        'Additional Notes' => ''
    ];
    
    // Clean up HTML
    $html = str_replace(['<br>', '<br />', '<br/>'], "\n", $html);
    $html = strip_tags($html);
    $html = html_entity_decode($html);
    
    $lines = explode("\n", $html);
    
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        
        foreach ($requirements as $key => $value) {
            if (stripos($line, $key . ':') === 0 || stripos($line, $key) !== false) {
                $requirements[$key] = trim(str_ireplace($key . ':', '', $line));
                break;
            }
        }
    }
    
    return $requirements;
}

function getCurrentPlayers($appid) {
    // Use Steam Web API to get current players (requires API key)
    if (defined('STEAM_API_KEY') && STEAM_API_KEY !== 'YOUR_STEAM_API_KEY_HERE') {
        $api_url = "https://api.steampowered.com/ISteamUserStats/GetNumberOfCurrentPlayers/v1/?appid=$appid&key=" . STEAM_API_KEY;
        $response = @file_get_contents($api_url);
        
        if ($response) {
            $data = json_decode($response, true);
            return $data['response']['player_count'] ?? null;
        }
    }
    return null;
}

function createQueryString($game_data) {
    $params = [];
    
    // Basic info
    $params['appid'] = $game_data['appid'];
    $params['name'] = urlencode($game_data['name']);
    $params['playtime_forever'] = 0;
    $params['img_icon_url'] = urlencode($game_data['img_icon_url'] ?? '');
    $params['has_community_visible_stats'] = 'true';
    $params['playtime_windows_forever'] = 0;
    $params['playtime_mac_forever'] = 0;
    $params['playtime_linux_forever'] = 0;
    $params['playtime_deck_forever'] = 0;
    $params['rtime_last_played'] = time();
    $params['playtime_disconnected'] = 0;
    
    // ADDED: Header image URL to query string - using the proper Steam CDN format
    // Try to get the hash from the original header image URL
    $header_url = $game_data['header_image'];
    $appid = $game_data['appid'];
    
    // Check if the header URL has a hash in it
    if (preg_match('/([a-f0-9]{40})\/header\.jpg/', $header_url, $matches)) {
        $hash = $matches[1];
        // Use the fastly CDN with hash format
        $header_img_url = "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{$appid}/{$hash}/header.jpg";
    } else {
        // Fallback to standard CDN format without hash
        $header_img_url = "https://shared.steamstatic.com/store_item_assets/steam/apps/{$appid}/header.jpg";
    }
    
    // Add timestamp to prevent caching issues
    $header_img_url .= "?t=" . time();
    
    $params['headerimg'] = urlencode($header_img_url);
    
    // System requirements from Steam API
    $reqs = $game_data['requirements'];
    $params['os_min'] = urlencode($reqs['minimum']['OS'] ?? '');
    $params['os_max'] = urlencode($reqs['recommended']['OS'] ?? '');
    $params['processor_min'] = urlencode($reqs['minimum']['Processor'] ?? '');
    $params['processor_max'] = urlencode($reqs['recommended']['Processor'] ?? '');
    $params['memory_min'] = urlencode($reqs['minimum']['Memory'] ?? '');
    $params['memory_max'] = urlencode($reqs['recommended']['Memory'] ?? '');
    $params['graphics_min'] = urlencode($reqs['minimum']['Graphics'] ?? '');
    $params['graphics_max'] = urlencode($reqs['recommended']['Graphics'] ?? '');
    $params['directx_min'] = urlencode($reqs['minimum']['DirectX'] ?? '');
    $params['directx_max'] = urlencode($reqs['recommended']['DirectX'] ?? '');
    $params['storage_min'] = urlencode($reqs['minimum']['Storage'] ?? '');
    $params['storage_max'] = urlencode($reqs['recommended']['Storage'] ?? '');
    
    // Create HTML requirements
    $min_html = createRequirementsHTML($reqs['minimum'] ?? [], 'Minimum');
    $rec_html = createRequirementsHTML($reqs['recommended'] ?? [], 'Recommended');
    
    $params['requirements_min'] = urlencode($min_html);
    $params['requirements_rec'] = urlencode($rec_html);
    
    // Steam Deck - would need separate API call or detection
    $params['steam_deck_compatibility'] = '';
    $params['deck_success'] = 'true';
    $params['deck_category'] = 1;
    $params['deck_loc_token'] = urlencode('#SteamDeckVerified_TestResult_UnsupportedAntiCheat_Other');
    
    // Build query string
    $query_string = '';
    foreach ($params as $key => $value) {
        $query_string .= "&$key=$value";
    }
    
    return ltrim($query_string, '&');
}

function createRequirementsHTML($requirements, $title) {
    if (empty($requirements)) {
        return "<strong>$title:</strong><br><ul><li>Requirements not specified</li></ul>";
    }
    
    $html = "<strong>$title:</strong><br><ul class=\"bb_ul\">";
    
    // Add OS if available
    if (!empty($requirements['OS'])) {
        $html .= "<li><strong>OS:</strong> " . htmlspecialchars($requirements['OS']) . "</li>";
    } else {
        $html .= "<li><strong>OS:</strong> Not specified</li>";
    }
    
    // Add Processor if available
    if (!empty($requirements['Processor'])) {
        $html .= "<li><strong>Processor:</strong> " . htmlspecialchars($requirements['Processor']) . "</li>";
    } else {
        $html .= "<li><strong>Processor:</strong> Not specified</li>";
    }
    
    // Add Memory if available
    if (!empty($requirements['Memory'])) {
        $html .= "<li><strong>Memory:</strong> " . htmlspecialchars($requirements['Memory']) . "</li>";
    } else {
        $html .= "<li><strong>Memory:</strong> Not specified</li>";
    }
    
    // Add Graphics if available
    if (!empty($requirements['Graphics'])) {
        $html .= "<li><strong>Graphics:</strong> " . htmlspecialchars($requirements['Graphics']) . "</li>";
    } else {
        $html .= "<li><strong>Graphics:</strong> Not specified</li>";
    }
    
    // Add DirectX if available
    if (!empty($requirements['DirectX'])) {
        $html .= "<li><strong>DirectX:</strong> " . htmlspecialchars($requirements['DirectX']) . "</li>";
    } else {
        $html .= "<li><strong>DirectX:</strong> Not specified</li>";
    }
    
    // Add Storage if available
    if (!empty($requirements['Storage'])) {
        $html .= "<li><strong>Storage:</strong> " . htmlspecialchars($requirements['Storage']) . "</li>";
    } else {
        $html .= "<li><strong>Storage:</strong> Not specified</li>";
    }
    
    // Add Network (always)
    $html .= "<li><strong>Network:</strong> Broadband Internet connection</li>";
    
    // Add Additional Notes if available
    if (!empty($requirements['Additional Notes'])) {
        $html .= "<li><strong>Additional Notes:</strong> " . htmlspecialchars($requirements['Additional Notes']) . "</li>";
    } else {
        $html .= "<li><strong>Additional Notes:</strong> ~3.8GB for 1 localized language</li>";
    }
    
    $html .= "</ul>";
    
    return $html;
}
?>

</body>
</html>