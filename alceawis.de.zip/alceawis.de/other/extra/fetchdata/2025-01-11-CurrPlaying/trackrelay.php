<?php
// Get the query string value
if (isset($_GET['track'])) {
    // Sanitize input to prevent injection attacks
    $track = htmlspecialchars($_GET['track']);
    
    // Get the current date and time
    $date = date('Y-m-d H:i:s');
    
    // Format the line to be written
    $newLine = "$date - $track" . PHP_EOL;
    
    // File path to write the data
    $file = 'tracks.txt';

    // Read the current contents of the file
    $currentContent = '';
    if (file_exists($file)) {
        $currentContent = file_get_contents($file);
    }
    
    // Prepend the new line to the existing content
    $updatedContent = $newLine . $currentContent;

    // Write the updated content back to the file
    if (file_put_contents($file, $updatedContent, LOCK_EX)) {
        echo "Track recorded successfully.";
    } else {
        echo "Failed to write to file.";
    }
} else {
    echo "No track parameter provided.";
}
