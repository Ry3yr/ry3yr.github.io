<?php
define('CLIENT_ID', '');
define('CLIENT_SECRET', '');
define('REDIRECT_URI', 'https://alcea-wisteria.de/PHP//0demo/2025-04-05-SocialMediaMediaXtractor/2025-06-20-RedditCommentPoster/index.php');
define('USER_AGENT', 'RedditCommenter/1.0 by JadedDetail');
