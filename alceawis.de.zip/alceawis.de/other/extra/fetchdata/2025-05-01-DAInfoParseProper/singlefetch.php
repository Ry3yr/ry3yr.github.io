<?php
$url = isset($_GET['url']) ? $_GET['url'] : 'https://www.deviantart.com/aoimatsuri/art/2025-04-11-Sleepy-1182078924';
$encodedUrl = urlencode($url);
$oembedUrl = "https://backend.deviantart.com/oembed?url={$encodedUrl}";

$json = file_get_contents($oembedUrl);
if ($json !== false) {
    $data = json_decode($json, true);
    
    if ($data) {
        $pageTitle = $data['title'] ?? 'No Title Found';
        $pubDate = $data['pubdate'] ?? 'Unknown date';
        $stats = $data['community']['statistics']['_attributes'] ?? [];
        $favorites = $stats['favorites'] ?? 0;
        $comments = $stats['comments'] ?? 0;
        $views = $stats['views'] ?? 0;
        
        // Simple date extraction - just get the date part before 'T'
        if (strpos($pubDate, 'T') !== false) {
            $dateParts = explode('T', $pubDate);
            $formattedDate = $dateParts[0];
        } else {
            $formattedDate = $pubDate;
        }
        
        echo "({$formattedDate}) <a href=\"{$url}\" target=\"_blank\">{$pageTitle}</a>\n";
        echo "Favs: {$favorites} ";
        echo "Comments: <span style='color: lightgray; opacity: 0.2; display: inline;'>{$comments}</span> ";
        echo "Views: {$views}\n";
    }
}
?>