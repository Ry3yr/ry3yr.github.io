<?php
// Check if the 'url' query string exists
$url = isset($_GET['url']) ? $_GET['url'] : 'https://www.deviantart.com/aoimatsuri/art/2025-04-11-Sleepy-1182078924';

$html = file_get_contents($url);
if ($html !== false) {
    // Use regex to extract the title
    preg_match('/<title>(.*?)<\/title>/', $html, $titleMatch);
    $pageTitle = isset($titleMatch[1]) ? $titleMatch[1] : 'No Title Found';

    // Remove " by aoimatsuri on DeviantArt"
    $pageTitle = preg_replace('/\s+by\s+[^ ]+\s+on\s+DeviantArt$/', '', $pageTitle);

    // Use regex to extract numbers within <span> tags
    preg_match_all('/<span>(\d+)<\/span>/', $html, $matches);
    
    // Ensure we have at least three numbers to display
    if (count($matches[1]) >= 3) {
        $lastThreeNumbers = array_slice($matches[1], -3);
        
        // Output with title and link, followed by labels
        echo "<a href=\"$url\" target=\"_blank\">$pageTitle</a>\n";
        echo "Favs: " . $lastThreeNumbers[0] . "\n";
        echo "Comments: " . $lastThreeNumbers[1] . "\n";
        echo "Views: " . $lastThreeNumbers[2] . "\n";
    } else {
        echo "Not enough numbers found.";
    }
} else {
    echo "Failed to retrieve content from the URL.";
}
?>