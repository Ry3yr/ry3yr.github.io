<?php

// URL of the RSS feed
$url = 'https://backend.deviantart.com/rss.xml?type=deviation&q=by%3Aaoimatsuri+sort%3Atime+meta%3Aall';

// Load the RSS feed
$xml = simplexml_load_file($url);

// Check if the XML was loaded successfully
if ($xml === false) {
    echo "Failed to load XML.";
    exit;
}

$count = 0; // Counter for processed links
$maxLinks = 5; // Maximum number of links to process

foreach ($xml->channel->item as $item) {
    if ($count >= $maxLinks) {
        break; // Stop after 5 links
    }

    $link = (string)$item->link;
    $encodedLink = urlencode($link);
    $targetUrl = "https://alcea-wisteria.de/PHP/0demo/00-PHP-Test/singlefetch.php?url=$encodedLink";
    $result = file_get_contents($targetUrl);

    echo $result . "<br>";

    $count++;
}
?>
