
<a target="_blank" href="fivefetch.php?user=aoikurayami1" style=color:lightgray>aoikurayami1</a><hr>

<?php
// Get the 'user' parameter or use default
$user = isset($_GET['user']) && !empty($_GET['user']) ? $_GET['user'] : 'aoimatsuri';
$user = htmlspecialchars($user); // sanitize input

$url = "https://www.deviantart.com/" . urlencode($user);

// Use cURL to fetch the page
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0'); // mimic a browser
$html = curl_exec($ch);
curl_close($ch);

// Load HTML into DOM parser
$dom = new DOMDocument();
libxml_use_internal_errors(true); // suppress HTML errors
$dom->loadHTML($html);
libxml_clear_errors();

// Search for the element that may contain the watchers info
$xpath = new DOMXPath($dom);
$nodes = $xpath->query("//*[contains(text(), 'Watchers')]");

$counter = 0;
foreach ($nodes as $node) {
    echo "" . trim($node->textContent) . "\n";
    $counter++;
    if ($counter == 1) {
        break;
    }
}
?><br>




<?php

// Get username from query string, fallback to 'aoimatsuri'
$user = isset($_GET['user']) ? $_GET['user'] : 'aoimatsuri';

// Construct the RSS feed URL with the dynamic username
$url = "https://backend.deviantart.com/rss.xml?type=deviation&q=by%3A{$user}+sort%3Atime+meta%3Aall";

// Load the RSS feed
$xml = simplexml_load_file($url);

// Check if the XML was loaded successfully
if ($xml === false) {
    echo "Failed to load XML.";
    exit;
}

$count = 0; // Counter for processed links
$maxLinks = 5; // Maximum number of links to process

// External CSS for styling the content
echo "<style>
    .comment {
        color: lightgray;
        opacity: 0.2;
        display: inline;
    }
</style>";

foreach ($xml->channel->item as $item) {
    if ($count >= $maxLinks) {
        break; // Stop after 5 links
    }

    $link = (string)$item->link;
    $encodedLink = urlencode($link);
    $targetUrl = "https://alcea-wisteria.de/PHP/0demo/00-PHP-Test/singlefetch.php?url=$encodedLink";
    $result = file_get_contents($targetUrl);

    // Echo the result, which should now have the correct styling
    echo $result . "<br>";

    $count++;
}
?>
