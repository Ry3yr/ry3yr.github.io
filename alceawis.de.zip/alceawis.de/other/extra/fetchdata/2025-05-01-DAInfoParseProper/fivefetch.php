
<a target="_blank" href="fivefetch.php?user=aoikurayami1" style=color:lightgray>aoikurayami1</a><hr>
<?php
$user = isset($_GET['user']) && !empty($_GET['user']) ? $_GET['user'] : 'aoimatsuri';
$user = htmlspecialchars($user);
$url = "https://www.deviantart.com/" . urlencode($user);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
$html = curl_exec($ch);
curl_close($ch);
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($html);
libxml_clear_errors();
$xpath = new DOMXPath($dom);
$nodes = $xpath->query("//*[contains(text(), 'Watchers')]");
$counter = 0;
foreach ($nodes as $node) {
    echo "" . trim($node->textContent) . "\n";
    $counter++;
    if ($counter == 1) {
        break;
    }
}
?><br>



<?php
$user = isset($_GET['user']) ? $_GET['user'] : 'aoimatsuri';
$rssUrl = "https://backend.deviantart.com/rss.xml?type=deviation&q=by%3A{$user}+sort%3Atime+meta%3Aall";
$maxLinks = 5;
$xml = @simplexml_load_file($rssUrl);
if ($xml === false) {
    echo "Failed to load RSS feed.";
    exit;
}
function curl_get_contents($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0'); // Required for DeviantArt
    $output = curl_exec($ch);
    if (curl_errno($ch)) {
        $output = "cURL error: " . curl_error($ch);
    }
    curl_close($ch);
    return $output;
}
echo "<style>
    body { font-family: Arial; }
    .entry { margin-bottom: 20px; }
    .entry a { font-weight: bold; color: #3366cc; }
    .fetched { margin-left: 10px; color: #444; }
</style>";
$count = 0;
foreach ($xml->channel->item as $item) {
    if ($count >= $maxLinks) break;
    $originalUrl = (string)$item->link;
    $encodedUrl = rawurlencode($originalUrl);
    $base = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'];
    $fetchUrl = $base . dirname($_SERVER['PHP_SELF']) . "/singlefetch.php?url=$encodedUrl";
    $response = curl_get_contents($fetchUrl);
    echo "<div class='entry'>
            <!--<a href='$originalUrl' target='_blank'>$originalUrl</a>-->
            <div class='fetched'>$response</div>
          </div>";

    $count++;
}
?>



