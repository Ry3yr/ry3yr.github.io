<?php
// URL of the RSS feed
$url = 'https://backend.deviantart.com/rss.xml?type=deviation&q=by%3Aaoimatsuri+sort%3Atime+meta%3Aall';

// Load the RSS feed
$xml = simplexml_load_file($url);

// Check if the XML was loaded successfully
if ($xml === false) {
    echo "Failed to load XML.";
    exit;
}

// Extract and display all URLs with line breaks
foreach ($xml->channel->item as $item) {
    echo (string)$item->link . "<br>";
}
?>