<?php
$correct_username = "admin";
$correct_password = "4869"; // Use a strong password for production
session_start();
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
echo "Welcome, you are logged in!<hr>";
} else {
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$username = $_POST['username'];
$password = $_POST['password'];
if ($username === $correct_username && $password === $correct_password) {
$_SESSION['logged_in'] = true;
echo "Login successful. Welcome!";
header("Location: " . $_SERVER['PHP_SELF']);
exit;
} else {
echo "Invalid username or password.<hr>";
}
}
echo '<form method="post">
<label for="username">Username:</label>
<input type="text" id="username" name="username" required><br>
<label for="password">Password:</label>
<input type="password" id="password" name="password" required><br>
<button type="submit">Login</button>
</form>';
exit();
}
?>




<?php
$images = [];
$small_images = [];
$page_title = '';
$submitted_url = '';

if (isset($_POST['url'])) {
    $submitted_url = trim($_POST['url']);
    $url = filter_var($submitted_url, FILTER_VALIDATE_URL);

    if ($url) {
        $parsed_url = parse_url($url);
        $base_host = $parsed_url['host'];

        $html = @file_get_contents($url);

        if ($html) {
            libxml_use_internal_errors(true);
            $doc = new DOMDocument();
            $doc->loadHTML($html);

            // Get page title
            $title_nodes = $doc->getElementsByTagName('title');
            if ($title_nodes->length > 0) {
                $page_title = $title_nodes->item(0)->nodeValue;
            }

            // Get image tags
            $tags = $doc->getElementsByTagName('img');
            foreach ($tags as $tag) {
                $src = $tag->getAttribute('src');
                if (!$src) continue;

                // Make relative URLs absolute
                if (parse_url($src, PHP_URL_SCHEME) === null) {
                    $src = rtrim($url, '/') . '/' . ltrim($src, '/');
                }

                $img_host = parse_url($src, PHP_URL_HOST);
                if (!$img_host || $img_host === $base_host) {
                    $size = @getimagesize($src);
                    if ($size) {
                        $img_data = [
                            'src' => $src,
                            'width' => $size[0],
                            'height' => $size[1],
                            'area' => $size[0] * $size[1]
                        ];

                        if ($size[0] >= 300) {
                            $images[] = $img_data;
                        } else {
                            $small_images[] = $img_data;
                        }
                    }
                }
            }

            // Sort both sets by resolution descending
            usort($images, fn($a, $b) => $b['area'] - $a['area']);
            usort($small_images, fn($a, $b) => $b['area'] - $a['area']);
        } else {
            echo "<p>❌ Failed to fetch content from the URL.</p>";
        }
    } else {
        echo "<p>❌ Invalid URL provided.</p>";
    }
}
?>

<form method="post" style="margin-bottom: 20px;">
    <label for="url">Enter a URL:</label><br>
    <input type="text" name="url" id="url" placeholder="https://example.com"
           style="width: 300px;" required value="<?= htmlspecialchars($submitted_url) ?>"><br><br>
    <button type="submit">Fetch Images</button>
</form>

<?php if (!empty($images) || !empty($small_images)): ?>
    <form method="get" action="process.php" id="imageForm">
        <div style="margin-bottom: 20px;">
            <label>Page URL:</label><br>
            <input type="text" name="url" style="width: 100%;"
                   value="<?= htmlspecialchars($submitted_url) ?>"><br><br>

            <label>Page Title:</label><br>
            <input type="text" name="title" style="width: 100%;"
                   value="<?= htmlspecialchars($page_title) ?>">
        </div>

        <h2>Internal Images (Sorted by Size):</h2>

        <div style="display: flex; flex-wrap: wrap; gap: 10px;">
            <?php foreach ($images as $index => $img): ?>
                <div style="position: relative; text-align: center;">
                    <img src="<?= htmlspecialchars($img['src']) ?>"
                         alt="Image"
                         style="max-width: 200px; max-height: 200px; display: block;">
                    <input type="checkbox"
                           data-src="<?= htmlspecialchars($img['src']) ?>"
                           class="img-check"
                           style="position: absolute; bottom: 5px; right: 5px;">
                    <br><small><?= $img['width'] ?>×<?= $img['height'] ?></small>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if (!empty($small_images)): ?>
            <details style="margin-top: 20px;">
                <summary>Show small images (width &lt; 300px)</summary>
                <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
                    <?php foreach ($small_images as $img): ?>
                        <div style="position: relative; text-align: center;">
                            <img src="<?= htmlspecialchars($img['src']) ?>"
                                 alt="Image"
                                 style="max-width: 200px; max-height: 200px; display: block;">
                            <input type="checkbox"
                                   data-src="<?= htmlspecialchars($img['src']) ?>"
                                   class="img-check"
                                   style="position: absolute; bottom: 5px; right: 5px;">
                            <br><small><?= $img['width'] ?>×<?= $img['height'] ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            </details>
        <?php endif; ?>

        <br><br>
        <button type="submit">Submit Selected Images</button>
    </form>

    <script>
        document.getElementById('imageForm').addEventListener('submit', function(e) {
            const checkboxes = document.querySelectorAll('.img-check');
            let count = 1;

            checkboxes.forEach(cb => {
                if (cb.checked) {
                    cb.setAttribute('name', 'img' + count);
                    cb.setAttribute('value', cb.getAttribute('data-src'));
                    count++;
                } else {
                    cb.removeAttribute('name'); // Do not submit unchecked
                }
            });
        });
    </script>
<?php endif; ?>
