<?php
// Base URL to use for constructing full URLs
$base_url = 'https://hub.vroid.com';

// URL of the page to fetch
$url = $base_url . '/en/users/75406576';

// Define the HTTP context options
$options = array(
    'http' => array(
        'method' => 'GET',
        'header' => 'Referer: ' . $base_url . "\r\n"
    ),
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false
    )
);

// Create the stream context
$context = stream_context_create($options);

// Fetch the HTML content
$html = file_get_contents($url, false, $context);

// Check if we got the HTML content
if ($html === false) {
    die('Failed to retrieve HTML');
}

// Load HTML into DOMDocument
$doc = new DOMDocument();
libxml_use_internal_errors(true); // Suppress warnings for malformed HTML
$doc->loadHTML($html);
libxml_clear_errors();

// Use DOMXPath to query the document
$xpath = new DOMXPath($doc);

// Query to find all href attributes starting with /characters/
$nodes = $xpath->query('//a[starts-with(@href, "/characters/")]');

// Array to keep track of unique URLs
$unique_urls = array();

// Process nodes and store unique URLs
foreach ($nodes as $node) {
    // Construct full URL
    $full_url = $base_url . $node->getAttribute('href');
    
    // Add URL to the array if it's not already present
    if (!in_array($full_url, $unique_urls)) {
        $unique_urls[] = $full_url;
    }
}

// Parse the limit parameter from the URL
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : count($unique_urls);

// Ensure limit is positive and does not exceed the number of unique URLs
$limit = max(1, min($limit, count($unique_urls)));

// Slice the array to include only the number of items specified by the limit
$unique_urls = array_slice($unique_urls, 0, $limit);

// Display unique URLs and corresponding iframes
if (count($unique_urls) > 0) {
    echo "";
    foreach ($unique_urls as $url) {
        // Display the URL as a clickable link that opens in a new tab
        //echo '<a href="' . $url . '" target="_blank">' . $url . '</a><br>' . "\n";
        
        // Encode URL for use in query string
        $encoded_url = urlencode($url);
        
        // Display the iframe
        echo '<iframe src="singlemodelstats.php?vroidurl=' . $encoded_url . '" width="420" height="195" frameborder="0"></iframe><br><br>' . "\n";
    }
} else {
    echo "No unique character URLs found.\n";
}
?>
