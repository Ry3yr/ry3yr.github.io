<?php
$base_url = 'https://hub.vroid.com';
$url = $base_url . '/en/users/75406576';
$options = array(
    'http' => array(
        'method' => 'GET',
        'header' => 'Referer: ' . $base_url . "\r\n"
    ),
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false
    )
);
$context = stream_context_create($options);
$html = file_get_contents($url, false, $context);
if ($html === false) {
    die('Failed to retrieve HTML');
}
$doc = new DOMDocument();
libxml_use_internal_errors(true);
$doc->loadHTML($html);
libxml_clear_errors();
$xpath = new DOMXPath($doc);
$nodes = $xpath->query('//a[starts-with(@href, "/characters/")]');
$unique_urls = array();
foreach ($nodes as $node) {
    $full_url = $base_url . $node->getAttribute('href');
    if (!in_array($full_url, $unique_urls)) {
        $unique_urls[] = $full_url;
    }
}
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : count($unique_urls);
$limit = max(1, min($limit, count($unique_urls)));
$unique_urls = array_slice($unique_urls, 0, $limit);
if (count($unique_urls) > 0) {
    echo "";
    foreach ($unique_urls as $url) {
        // Display the URL as a clickable link that opens in a new tab
        //echo '<a href="' . $url . '" target="_blank">' . $url . '</a><br>' . "\n";
        
        // Encode URL for use in query string
        $encoded_url = urlencode($url);
        
        // Display the iframe
        echo '<iframe src="singlemodelstats.php?vroidurl=' . $encoded_url . '" width="420" height="195" frameborder="0"></iframe><br><br>' . "\n";
    }
} else {
    echo "No unique character URLs found.\n";
}
?>
