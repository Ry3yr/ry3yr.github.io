<?php
/**
 * MP4 Link Extractor
 * Extracts MP4 video URLs from any webpage
 * Usage: 
 *   - Direct: extract_mp4.php?link=https://example.com/video-page
 *   - Form input: via textfield submission
 */

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to extract MP4 links using cURL
function extractMp4Links($url) {
    $mp4Links = [];
    
    // Validate URL
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return ['error' => 'Invalid URL provided'];
    }
    
    // Initialize cURL
    $ch = curl_init();
    
    // Set cURL options
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false, // For HTTPS sites with self-signed certs
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_HEADER => false,
        CURLOPT_ENCODING => '', // Handle compressed responses
        CURLOPT_MAXREDIRS => 5
    ]);
    
    // Execute cURL request
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    
    curl_close($ch);
    
    // Check for cURL errors
    if ($curlError) {
        return ['error' => "cURL Error: $curlError"];
    }
    
    // Check HTTP response code
    if ($httpCode !== 200) {
        return ['error' => "HTTP Error: $httpCode"];
    }
    
    if (!$response) {
        return ['error' => 'No response received from the server'];
    }
    
    // Extract MP4 links using regex
    // Pattern 1: src="*.mp4"
    preg_match_all('/src=["\']([^"\']+\.mp4[^"\']*)["\']/i', $response, $matches1);
    
    // Pattern 2: href="*.mp4"
    preg_match_all('/href=["\']([^"\']+\.mp4[^"\']*)["\']/i', $response, $matches2);
    
    // Pattern 3: content="*.mp4" (meta tags)
    preg_match_all('/content=["\']([^"\']+\.mp4[^"\']*)["\']/i', $response, $matches3);
    
    // Pattern 4: video source without quotes
    preg_match_all('/(?:src|href|data-video-url|data-src)=([^\s>]+\.mp4[^\s>]*)/i', $response, $matches4);
    
    // Pattern 5: JSON embedded URLs
    preg_match_all('/["\'](https?:\/\/[^"\']+\.mp4[^"\']*)["\']/i', $response, $matches5);
    
    // Pattern 6: Any .mp4 in the page source
    preg_match_all('/(https?:\/\/[^\s<>"\']+\.mp4[^\s<>"\']*)/i', $response, $matches6);
    
    // Merge all matches
    $allMatches = array_merge(
        $matches1[1] ?? [],
        $matches2[1] ?? [],
        $matches3[1] ?? [],
        $matches4[1] ?? [],
        $matches5[1] ?? [],
        $matches6[1] ?? []
    );
    
    // Clean and deduplicate URLs
    foreach ($allMatches as $link) {
        // Clean the URL (remove trailing quotes, spaces, etc.)
        $link = trim($link, '"\' ');
        
        // Convert relative URLs to absolute
        if (strpos($link, 'http') !== 0) {
            $parsedUrl = parse_url($url);
            $baseUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
            
            if (strpos($link, '//') === 0) {
                $link = $parsedUrl['scheme'] . ':' . $link;
            } elseif (strpos($link, '/') === 0) {
                $link = $baseUrl . $link;
            } else {
                $path = dirname($parsedUrl['path'] ?? '');
                $link = $baseUrl . ($path !== '/' ? $path . '/' : '/') . $link;
            }
        }
        
        // Only add valid MP4 URLs
        if (filter_var($link, FILTER_VALIDATE_URL) && !in_array($link, $mp4Links)) {
            $mp4Links[] = $link;
        }
    }
    
    return empty($mp4Links) ? ['message' => 'No MP4 links found'] : $mp4Links;
}

// Handle the extraction request
$extractedLinks = null;
$submittedUrl = '';
$error = null;

// Check for URL from query string first
if (isset($_GET['link']) && !empty($_GET['link'])) {
    $submittedUrl = $_GET['link'];
    $extractedLinks = extractMp4Links($submittedUrl);
    
    // Check for errors
    if (isset($extractedLinks['error'])) {
        $error = $extractedLinks['error'];
        $extractedLinks = null;
    }
} 
// Check for POST submission from textfield
elseif (isset($_POST['url']) && !empty($_POST['url'])) {
    $submittedUrl = $_POST['url'];
    $extractedLinks = extractMp4Links($submittedUrl);
    
    // Check for errors
    if (isset($extractedLinks['error'])) {
        $error = $extractedLinks['error'];
        $extractedLinks = null;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MP4 Link Extractor</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }
        
        .content {
            padding: 40px;
        }
        
        .input-group {
            margin-bottom: 30px;
        }
        
        label {
            display: block;
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
            font-size: 1.1em;
        }
        
        input[type="url"] {
            width: 100%;
            padding: 15px;
            font-size: 1em;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        input[type="url"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 1.1em;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: transform 0.2s ease;
            width: 100%;
        }
        
        button:hover {
            transform: translateY(-2px);
        }
        
        button:active {
            transform: translateY(0);
        }
        
        .results {
            margin-top: 40px;
            padding-top: 30px;
            border-top: 2px solid #f0f0f0;
        }
        
        .results h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 1.5em;
        }
        
        .link-list {
            list-style: none;
        }
        
        .link-list li {
            background: #f8f9fa;
            margin-bottom: 15px;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #667eea;
            word-break: break-all;
        }
        
        .link-list a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }
        
        .link-list a:hover {
            text-decoration: underline;
        }
        
        .error {
            background: #fee;
            color: #c33;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #c33;
            margin-top: 20px;
        }
        
        .info {
            background: #e3f2fd;
            color: #1976d2;
            padding: 15px;
            border-radius: 10px;
            margin-top: 20px;
        }
        
        .video-preview {
            margin-top: 30px;
        }
        
        .video-preview video {
            width: 100%;
            max-width: 100%;
            border-radius: 10px;
            margin-top: 10px;
        }
        
        @media (max-width: 768px) {
            .header h1 {
                font-size: 1.8em;
            }
            
            .content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎬 MP4 Link Extractor</h1>
            <p>Extract video links from any webpage</p>
        </div>
        
        <div class="content">
            <form method="POST" action="">
                <div class="input-group">
                    <label for="url">Enter Page URL:</label>
                    <input type="url" 
                           name="url" 
                           id="url" 
                           placeholder="https://example.com/video-page" 
                           value="<?php echo htmlspecialchars($submittedUrl); ?>"
                           required>
                </div>
                <button type="submit">Extract MP4 Links 🚀</button>
            </form>
            
            <?php if ($error): ?>
                <div class="error">
                    <strong>⚠️ Error:</strong> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($extractedLinks && !isset($extractedLinks['error']) && !isset($extractedLinks['message'])): ?>
                <div class="results">
                    <h2>📹 Found MP4 Links (<?php echo count($extractedLinks); ?>)</h2>
                    <ul class="link-list">
                        <?php foreach ($extractedLinks as $index => $link): ?>
                            <li>
                                <strong>Link <?php echo $index + 1; ?>:</strong><br>
                                <a href="<?php echo htmlspecialchars($link); ?>" target="_blank">
                                    <?php echo htmlspecialchars($link); ?>
                                </a>
                                <br>
                                <small>
                                    <a href="<?php echo htmlspecialchars($link); ?>" download>⬇️ Download</a> | 
                                    <a href="#" onclick="copyToClipboard('<?php echo htmlspecialchars($link); ?>'); return false;">📋 Copy Link</a>
                                </small>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    
                    <?php if (count($extractedLinks) === 1): ?>
                        <div class="video-preview">
                            <h3>🎥 Video Preview:</h3>
                            <video controls>
                                <source src="<?php echo htmlspecialchars($extractedLinks[0]); ?>" type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        </div>
                    <?php endif; ?>
                </div>
            <?php elseif ($extractedLinks && isset($extractedLinks['message'])): ?>
                <div class="info">
                    ℹ️ <?php echo htmlspecialchars($extractedLinks['message']); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Link copied to clipboard!');
            }, function(err) {
                console.error('Could not copy text: ', err);
            });
        }
        
        // Auto-extract from query string on page load
        <?php if (isset($_GET['link']) && !empty($_GET['link']) && !$extractedLinks && !$error): ?>
        // Show loading message
        document.querySelector('.results')?.remove();
        <?php endif; ?>
    </script>
</body>
</html>