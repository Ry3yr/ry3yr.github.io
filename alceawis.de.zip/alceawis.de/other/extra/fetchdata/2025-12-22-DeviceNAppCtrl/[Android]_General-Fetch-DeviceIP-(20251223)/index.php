<?php
if (isset($_GET['text'])) {
    $text = $_GET['text'];

    // Optional: normalize line endings or sanitize
    // $text = str_replace(["\r\n", "\r"], "\n", $text);

    file_put_contents('address.txt', $text);
    echo "address.txt updated successfully.";
} else {
    echo "No text parameter provided.";
}
