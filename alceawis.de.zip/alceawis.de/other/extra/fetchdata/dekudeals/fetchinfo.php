<?php
// Check if the "url" query string parameter exists
if (isset($_GET['url'])) {
    // Get the URL value from the query string
    $url = $_GET['url'];
} else {
    // Default URL if the "url" parameter is not provided
    $url = "https://www.dekudeals.com/items/figment";
}

// Fetch the HTML content
$html = file_get_contents($url);

// Find the name using regular expressions
$namePattern = "/<span class='display-5'>(.*?)<\/span>/";
preg_match($namePattern, $html, $nameMatches);

// Find the MSRP value using regular expressions
$msrpPattern = '/<strong>MSRP:<\/strong>\s*([^<]+)/';
preg_match($msrpPattern, $html, $msrpMatches);

// Find the Download size value using regular expressions
$downloadSizePattern = '/<strong>Download size:<\/strong>\s*([^<]+)/';
preg_match($downloadSizePattern, $html, $downloadSizeMatches);

// Find the og:image content using regular expressions
$imagePattern = '/<meta content=\'(.*?)\' name=\'og:image\' property=\'og:image\'>/';
preg_match($imagePattern, $html, $imageMatches);

// Extract the name, MSRP value, Download size, and og:image content from the matches
$name = !empty($nameMatches[1]) ? $nameMatches[1] : "Name not found";
$msrpValue = !empty($msrpMatches[1]) ? trim($msrpMatches[1]) : "MSRP value not found";
$downloadSize = !empty($downloadSizeMatches[1]) ? trim($downloadSizeMatches[1]) : "Download size not found";
$imageUrl = !empty($imageMatches[1]) ? $imageMatches[1] : "og:image content not found";

// Display the name, MSRP value, Download size, and og:image content
echo "Name: " . $name . "<br>";
echo "MSRP: " . $msrpValue . "<br>";
echo "Download size: " . $downloadSize . "<br>";
echo $imageUrl;

// Generate the query string
$queryString = http_build_query([
    'name' => $name,
    'pricePaid' => $msrpValue,
    'gameSize' => $downloadSize,
    'url' => $url,
    'image' => $imageUrl
]);

// Generate the URL with the query string
$targetUrl = "info.html?" . $queryString;
?>

<!-- Add the button -->
<button onclick="sendToHtml()">Send to HTML</button>

<!-- JavaScript function to send the variables as query strings -->
<script>
    function sendToHtml() {
        // Redirect to the target URL
        window.location.href = "<?php echo $targetUrl; ?>";
    }
</script>