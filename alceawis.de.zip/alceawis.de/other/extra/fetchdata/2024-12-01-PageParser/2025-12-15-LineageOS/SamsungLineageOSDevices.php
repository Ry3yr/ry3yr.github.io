<?php

libxml_use_internal_errors(true);

// Fetch the devices page
$html = file_get_contents('https://wiki.lineageos.org/devices/');

$dom = new DOMDocument();
$dom->loadHTML($html);

$xpath = new DOMXPath($dom);

/**
 * 1. Get the Samsung devices container
 */
$devicesDiv = $xpath->query(
    "//div[contains(concat(' ', normalize-space(@class), ' '), ' devices ')][@data-vendor='samsung']"
);

if ($devicesDiv->length === 0) {
    die('Samsung devices div not found');
}

/**
 * 2. Get all device items inside it
 */
$items = $xpath->query(
    ".//div[contains(concat(' ', normalize-space(@class), ' '), ' item ')]",
    $devicesDiv->item(0)
);

$samsungDevices = [];

foreach ($items as $item) {
    $nameNode = $xpath->query(".//span[@class='devicename']", $item)->item(0);
    $linkNode = $xpath->query(".//a[@href]", $item)->item(0);
    $imageNode = $xpath->query(".//img", $item)->item(0);

    if ($nameNode && $linkNode && $imageNode) {
        $deviceName = trim($nameNode->textContent);
        $deviceUrl = 'https://wiki.lineageos.org' . $linkNode->getAttribute('href');
        $deviceImageUrl = 'https://wiki.lineageos.org' . $imageNode->getAttribute('src'); // Prepend the base URL
        $codename = $xpath->query(".//span[@class='codename']", $item)->item(0)->textContent;

        // Construct install URL
        $installUrl = $deviceUrl . '/install';

        // Store device info along with install details link and image URL
        $samsungDevices[] = [
            'name' => $deviceName,
            'url'  => $deviceUrl,
            'install_url' => $installUrl,
            'image_url' => $deviceImageUrl
        ];
    }
}

// Check for device query parameter
$deviceFilterValue = isset($_GET['device']) ? htmlspecialchars($_GET['device']) : '';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Samsung Devices - LineageOS</title>
    <style>
        .device-container {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .filter-container {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f5f5f5;
            border-radius: 5px;
        }
        .filter-input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .filter-input:focus {
            outline: none;
            border-color: #007cba;
            box-shadow: 0 0 0 1px #007cba;
        }
        .device-item {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .device-image {
            width: 50px;
            height: 50px;
            margin-right: 10px;
            object-fit: contain;
        }
        .no-results {
            text-align: center;
            padding: 20px;
            color: #666;
            font-style: italic;
        }
        .results-count {
            margin-top: 10px;
            color: #666;
            font-size: 14px;
        }
        .query-hint {
            margin-top: 5px;
            font-size: 12px;
            color: #666;
        }
        .query-hint a {
            color: #007cba;
            text-decoration: none;
        }
        .query-hint a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="filter-container">
        <h2>Samsung Devices with LineageOS Support</h2>
        <input type="text" 
               id="deviceFilter" 
               class="filter-input" 
               placeholder="Type to filter devices by name (e.g., Galaxy, Note, S9, etc.)"
               value="<?php echo $deviceFilterValue; ?>"
               onkeyup="filterDevices()">
        <div id="resultsCount" class="results-count"></div>
        <div class="query-hint">
            <?php if (!empty($deviceFilterValue)): ?>
                Filtered by query string: "<?php echo $deviceFilterValue; ?>" | 
                <a href="<?php echo strtok($_SERVER['REQUEST_URI'], '?'); ?>">Clear filter</a>
            <?php endif; ?>
        </div>
    </div>

    <div id="devicesList">
        <?php foreach ($samsungDevices as $device): ?>
            <div class="device-container" data-device-name="<?php echo htmlspecialchars(strtolower($device['name'])); ?>">
                <div class="device-item">
                    <img src="<?php echo $device['image_url']; ?>" 
                         alt="<?php echo htmlspecialchars($device['name']); ?>" 
                         class="device-image">
                    <a href="<?php echo $device['url']; ?>" target="_blank">
                        <?php echo htmlspecialchars($device['name']); ?>
                    </a>
                </div>
                
                <details onclick="loadIframe('iframe_<?php echo urlencode($device['name']); ?>', '<?php echo $device['install_url']; ?>')">
                    <summary>Installation Instructions</summary>
                    <iframe id="iframe_<?php echo urlencode($device['name']); ?>" 
                            width="100%" 
                            height="600" 
                            frameborder="0" 
                            src="about:blank"
                            style="border: 1px solid #ddd; border-radius: 4px; margin-top: 10px;">
                        Your browser does not support iframes.
                    </iframe>
                </details>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        function loadIframe(id, url) {
            var iframe = document.getElementById(id);
            if (iframe && iframe.src === 'about:blank') {
                iframe.src = url;
            }
        }

        function filterDevices() {
            var input = document.getElementById('deviceFilter');
            var filter = input.value.toLowerCase();
            var devices = document.getElementsByClassName('device-container');
            var visibleCount = 0;
            
            for (var i = 0; i < devices.length; i++) {
                var deviceName = devices[i].getAttribute('data-device-name');
                if (deviceName.indexOf(filter) > -1) {
                    devices[i].style.display = '';
                    visibleCount++;
                } else {
                    devices[i].style.display = 'none';
                }
            }
            
            // Update results count
            var resultsCount = document.getElementById('resultsCount');
            resultsCount.textContent = visibleCount + ' of ' + devices.length + ' devices shown';
            
            // Show no results message
            var noResultsMsg = document.getElementById('noResultsMessage');
            if (visibleCount === 0 && filter.length > 0) {
                if (!noResultsMsg) {
                    noResultsMsg = document.createElement('div');
                    noResultsMsg.id = 'noResultsMessage';
                    noResultsMsg.className = 'no-results';
                    noResultsMsg.textContent = 'No devices found matching "' + filter + '"';
                    document.getElementById('devicesList').appendChild(noResultsMsg);
                }
            } else if (noResultsMsg) {
                noResultsMsg.remove();
            }
        }
        
        // Initialize page with filter if query parameter exists
        document.addEventListener('DOMContentLoaded', function() {
            var devices = document.getElementsByClassName('device-container');
            var deviceFilter = document.getElementById('deviceFilter');
            
            // Update results count
            document.getElementById('resultsCount').textContent = devices.length + ' devices found';
            
            // Apply filter if query parameter exists
            var filterValue = deviceFilter.value;
            if (filterValue) {
                filterDevices();
                
                // Optionally scroll to first visible device
                setTimeout(function() {
                    var firstVisible = document.querySelector('.device-container[style=""]');
                    if (firstVisible) {
                        firstVisible.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }
                }, 100);
            }
        });
    </script>
</body>
</html>