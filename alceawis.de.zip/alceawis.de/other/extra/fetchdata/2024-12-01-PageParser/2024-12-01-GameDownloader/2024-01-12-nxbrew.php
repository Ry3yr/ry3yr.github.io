<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to fetch webpage content using cURL
function fetch_webpage($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $content = curl_exec($ch);
    curl_close($ch);
    return $content;
}

// Determine current page number
$pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$nextPage = $pageNumber + 1;
$prevPage = max(1, $pageNumber - 1); // Ensure it doesn't go below page 1

// Generate URLs for navigation
$baseURL = 'https://nxbrew.net';
$currentPageURL = $baseURL . ($pageNumber > 1 ? "/page/$pageNumber" : '');
$nextPageURL = "$baseURL/page/$nextPage";
$prevPageURL = $prevPage > 1 ? "$baseURL/page/$prevPage" : $baseURL;

// Navigation links at the top
echo "<div style='text-align: center; margin: 20px 0;'>
        <a href='?page=$prevPage' style='font-size: 24px; text-decoration: none;'>« Previous</a> |
        <a href='?page=$nextPage' style='font-size: 24px; text-decoration: none;'>Next »</a>
      </div>";

// Fetch the main page content
$htmlContent = fetch_webpage($currentPageURL);

// Load main page HTML content into DOMDocument
$dom = new DOMDocument();
libxml_use_internal_errors(true); // Suppress parsing errors
$dom->loadHTML($htmlContent);
libxml_clear_errors();

// Use DOMXPath to find all <h2 class="post-title"> links
$xpath = new DOMXPath($dom);
$nodes = $xpath->query('//h2[contains(@class, "post-title")]/a');

echo "<ul>";
foreach ($nodes as $node) {
    $postTitle = $node->textContent; // Get the title of the post
    $postLink = $node->getAttribute('href'); // Get the link to the post

    // Fetch the content of the post page
    $postContent = fetch_webpage($postLink);
    $postDom = new DOMDocument();
    libxml_use_internal_errors(true); // Suppress parsing errors for the post page
    $postDom->loadHTML($postContent);
    libxml_clear_errors();
    $postXpath = new DOMXPath($postDom);

    // Find the first element with has-background and an image inside
    $backgroundElement = $postXpath->query('//div[contains(@class, "has-background")]');
    $imageElement = $postXpath->query('//figure[@class="wp-block-media-text__media"]/img');

    // Extract the style attribute from the background element
    $backgroundStyle = $backgroundElement->length > 0 ? $backgroundElement->item(0)->getAttribute('style') : '';

    // Extract the image source
    $imgSrc = '';
    if ($imageElement->length > 0) {
        $imgSrc = $imageElement->item(0)->getAttribute('src');
    }

    // Display the post title with the primary link
    echo "<li style='$backgroundStyle'>";
    if ($imgSrc) {
        echo "<a href='$postLink' target='_blank'><img src='$imgSrc' alt='$postTitle' style='width:10%;'></a><br>";
    }
    echo "<a href='$postLink' target='_blank'>$postTitle</a></li>";

    // Find all links containing 1fichier and MegaUp
    //$downloadLinks = $postXpath->query('//a[contains(@href, "1fichier.com") or contains(@href, "megaup.net")]');
    $downloadLinks = $postXpath->query('//a[contains(@href, "1fichier.com") or contains(@href, "megaup.net") or contains(@href, "ouo.io")]');

    
    echo "<details><ul>";
    foreach ($downloadLinks as $link) {
        $href = $link->getAttribute('href');
        $linkTitle = $link->getAttribute('title');
        if (!$linkTitle) {
            $linkTitle = $link->textContent ?: 'Download Link';
        }
        echo "<li><a href='$href' target='_blank'>$linkTitle</a></li>";
    }
    echo "</ul></details><hr>";
}
echo "</ul>";

// Navigation links at the bottom
echo "<div style='text-align: center; margin: 20px 0;'>
        <a href='?page=$prevPage' style='font-size: 24px; text-decoration: none;'>« Previous</a> |
        <a href='?page=$nextPage' style='font-size: 24px; text-decoration: none;'>Next »</a>
      </div>";
?>
