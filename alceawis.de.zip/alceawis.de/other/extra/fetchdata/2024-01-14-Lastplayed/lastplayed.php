<?php
$correct_username = "admin";
$correct_password = "4869"; // Use a strong password for production
session_start();
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
echo "Welcome, you are logged in!<hr>";
} else {
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$username = $_POST['username'];
$password = $_POST['password'];
if ($username === $correct_username && $password === $correct_password) {
$_SESSION['logged_in'] = true;
echo "Login successful. Welcome!";
header("Location: " . $_SERVER['PHP_SELF']);
exit;
} else {
echo "Invalid username or password.<hr>";
}
}
echo '<form method="post">
<label for="username">Username:</label>
<input type="text" id="username" name="username" required><br>
<label for="password">Password:</label>
<input type="password" id="password" name="password" required><br>
<button type="submit">Login</button>
</form>';
exit();
}
?>




<?php
$currentContent = file_get_contents('current.html');
$targetContent = file_get_contents('oldentries.html');
$updatedContent = $currentContent . $targetContent;
$linkpattern = '/<a\b[^>]*>(.*?)<\/a>/'; //remove link
$replacement = '';
$updatedContent = preg_replace($linkpattern, $replacement, $updatedContent);
file_put_contents('oldentries.html', $updatedContent);
?>


<?php
if(isset($_GET['gamename'])) {
    $gamename = $_GET['gamename'];
    $currentDateTime = date('Y-m-d H:i:s');
    $htmlContent = '<u>LastPlayed:</u> ' . $gamename . ' - (' . $currentDateTime . ') <a target="_blank" href="oldentries.html" style="color:gray">(old)</a><br>';
    file_put_contents('current.html', $htmlContent);
    //echo "Successfully updated current.html with the game name: $gamename and current date and time.";

    // Output the iframe with cache busting
    echo "<iframe src='current.html?" . time() . "' style='width: 100%; border: none;'></iframe>";
    echo '<script>window.onload = function() { window.close(); }</script>';
} else {
    echo "<iframe src='current.html?" . time() . "' style='width: 100%; border: none;'></iframe>";
    echo '<script>window.onload = function() { window.close(); }</script>';
    sleep(5);
}
?>
