<?php
// Get the RSS URL from the query string
$rss_url = isset($_GET['rss_url']) ? $_GET['rss_url'] : '';

if (!empty($rss_url)) {
    // Initialize cURL
    $ch = curl_init();
    
    // Set cURL options
    curl_setopt_array($ch, [
        CURLOPT_URL => $rss_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10, // 10 seconds timeout
        CURLOPT_CONNECTTIMEOUT => 5, // 5 seconds connection timeout
        CURLOPT_FOLLOWLOCATION => true, // Follow redirects
        CURLOPT_MAXREDIRS => 5, // Maximum redirects to follow
        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; RSS-Parser/1.0; +http://yourdomain.com)',
        CURLOPT_SSL_VERIFYPEER => true, // Verify SSL certificates
        CURLOPT_SSL_VERIFYHOST => 2, // Verify host
        CURLOPT_ENCODING => '', // Handle compressed responses
        CURLOPT_FAILONERROR => true // Fail on HTTP error codes
    ]);
    
    // Execute cURL request
    $rss_feed = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    
    // Check for cURL errors
    if ($rss_feed === false) {
        header('HTTP/1.1 500 Internal Server Error');
        header('Content-Type: application/json');
        echo json_encode([
            'error' => 'Failed to fetch RSS feed',
            'details' => $curl_error,
            'http_code' => $http_code
        ]);
        curl_close($ch);
        exit;
    }
    
    // Check HTTP response code
    if ($http_code !== 200) {
        header('HTTP/1.1 ' . $http_code);
        header('Content-Type: application/json');
        echo json_encode([
            'error' => 'HTTP request failed',
            'http_code' => $http_code,
            'details' => 'Server returned non-200 status code'
        ]);
        curl_close($ch);
        exit;
    }
    
    curl_close($ch);
    
    // Try to parse the RSS feed as XML
    try {
        // Disable libxml errors and allow user to fetch error information as needed
        libxml_use_internal_errors(true);
        
        $rss = new SimpleXMLElement($rss_feed);
        
        // Convert the RSS feed to an array
        $rss_array = json_decode(json_encode($rss), true);
        
        // Add success indicator
        $response = [
            'success' => true,
            'data' => $rss_array
        ];
        
        // Convert the array to JSON and output it
        header('Content-Type: application/json');
        echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        
    } catch (Exception $e) {
        header('HTTP/1.1 500 Internal Server Error');
        header('Content-Type: application/json');
        
        // Get libxml errors if any
        $libxml_errors = [];
        foreach (libxml_get_errors() as $error) {
            $libxml_errors[] = [
                'message' => trim($error->message),
                'line' => $error->line,
                'column' => $error->column
            ];
        }
        
        echo json_encode([
            'error' => 'String could not be parsed as XML',
            'details' => $e->getMessage(),
            'libxml_errors' => $libxml_errors,
            'received_data_preview' => substr($rss_feed, 0, 500) // Show first 500 chars for debugging
        ]);
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    header('Content-Type: application/json');
    echo json_encode([
        'error' => 'No RSS URL provided',
        'usage' => 'Please provide an rss_url parameter: ?rss_url=https://example.com/feed.xml'
    ]);
}
?>