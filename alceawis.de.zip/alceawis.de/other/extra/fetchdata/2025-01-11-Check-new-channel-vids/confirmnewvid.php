<a target="_blank" href="checkchannels.php" style="color:blue">ReFetch</a>
<hr>

<?php

// Function to get the latest video URL and title from the YouTube RSS feed
function getLatestVideoFromRSS($channelId) {
    $rssUrl = "https://www.youtube.com/feeds/videos.xml?channel_id=$channelId";
    $rssData = @simplexml_load_file($rssUrl);

    if ($rssData && isset($rssData->entry[0])) {
        $latestVideoUrl = (string)$rssData->entry[0]->link['href'];
        $videoTitle = (string)$rssData->entry[0]->title;

        return [
            'url'   => $latestVideoUrl,
            'title' => $videoTitle
        ];
    }
    return null;
}

// Read the ytlist.txt file
$ytListFile = 'ytlist.txt';
$lines = file($ytListFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

// Loop through each line
foreach ($lines as $line) {

    preg_match(
        '/(https:\/\/www\.youtube\.com\/channel\/[a-zA-Z0-9_-]+)\s-\s(https:\/\/www\.youtube\.com\/watch\?v=[a-zA-Z0-9_-]+)\s(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+00:00)/',
        $line,
        $matches
    );

    if (count($matches) !== 4) {
        echo "Invalid format in line: $line<br>\n";
        continue;
    }

    $channelUrl = $matches[1];
    $videoUrl   = $matches[2];
    $timestamp  = $matches[3];

    // Extract channel ID
    preg_match('/channel\/([a-zA-Z0-9_-]+)/', $channelUrl, $channelMatches);
    $channelId = $channelMatches[1] ?? null;

    if (!$channelId) {
        echo "Invalid channel ID: $channelUrl<br>\n";
        continue;
    }

    // Fetch latest video
    $latestVideo = getLatestVideoFromRSS($channelId);

    if (!$latestVideo) {
        echo "Error retrieving RSS for channel: $channelUrl<br>\n";
        continue;
    }

    $linkUrl  = $latestVideo['url'];
    $linkText = htmlspecialchars($latestVideo['title']);

    // Build EMBED URL
    parse_str(parse_url($linkUrl, PHP_URL_QUERY), $queryParams);
    $videoId  = $queryParams['v'] ?? null;
    $embedUrl = $videoId ? "https://www.youtube.com/embed/$videoId" : null;

    // Output
    if ($linkUrl === $videoUrl) {
        echo $line .
            " <span style='color: gray; font-weight: bold;'>same</span> " .
            "<a href='$linkUrl' target='_blank'>$linkText</a>";
    } else {
        echo $line .
            " <span style='color: green; font-weight: bold;'>new</span> " .
            "<a href='$linkUrl' target='_blank'>$linkText</a>";
    }

    if ($embedUrl) {
        echo " <a href='$embedUrl' target='_blank' style='color:#555;'>[EMBED]</a>";
    }

    echo "<br>\n";
}
?>
