<a target="_blank" href="checkchannels.php" style="color:blue">ReFetch</a>
<hr>

<?php

// Function to get the latest video URL, title, and publication date from the YouTube RSS feed
function getLatestVideoFromRSS($channelId) {
    $rssUrl = "https://www.youtube.com/feeds/videos.xml?channel_id=$channelId";
    
    // Use cURL with headers to avoid being blocked
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $rssUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/atom+xml, application/xml, text/xml, */*',
        'Accept-Language: en-US,en;q=0.9',
        'Accept-Encoding: gzip, deflate',
        'Connection: keep-alive'
    ]);
    
    // Handle compressed responses
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    // Check if request was successful
    if ($httpCode !== 200 || !$response) {
        return null;
    }
    
    // Parse the XML response
    $rssData = simplexml_load_string($response);
    
    if ($rssData && isset($rssData->entry[0])) {
        // More robust parsing for video URL
        $latestVideoUrl = null;
        foreach ($rssData->entry[0]->link as $link) {
            if ($link['rel'] == 'alternate') {
                $latestVideoUrl = (string)$link['href'];
                break;
            }
        }
        
        // Get video title (primary method)
        $videoTitle = (string)$rssData->entry[0]->title;
        
        // Fallback: if title is empty, try media:group title
        if (empty($videoTitle) && isset($rssData->entry[0]->children('media', true)->group->title)) {
            $videoTitle = (string)$rssData->entry[0]->children('media', true)->group->title;
        }
        
        // Additional fallback: if still empty, try a different media namespace approach
        if (empty($videoTitle)) {
            $media = $rssData->entry[0]->children('http://search.yahoo.com/mrss/');
            if (isset($media->group->title)) {
                $videoTitle = (string)$media->group->title;
            }
        }
        
        // Get the actual publication date from YouTube's RSS feed
        $publishedDate = (string)$rssData->entry[0]->published;

        if ($latestVideoUrl && $videoTitle) {
            return [
                'url'   => $latestVideoUrl,
                'title' => $videoTitle,
                'date'  => $publishedDate  // Actual video publication date
            ];
        }
    }
    return null;
}

// Read the ytlist.txt file
$ytListFile = 'ytlist.txt';

if (!file_exists($ytListFile)) {
    echo "Error: $ytListFile not found.<br>\n";
    exit;
}

$lines = file($ytListFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if (empty($lines)) {
    echo "No channels found in $ytListFile.<br>\n";
    exit;
}

// Loop through each line
foreach ($lines as $index => $line) {
    
    // Add delay between requests to avoid rate limiting (0.5 seconds)
    if ($index > 0) {
        usleep(500000);
    }
    
    preg_match(
        '/(https:\/\/www\.youtube\.com\/channel\/[a-zA-Z0-9_-]+)\s-\s(https:\/\/www\.youtube\.com\/watch\?v=[a-zA-Z0-9_-]+)\s(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+00:00)/',
        $line,
        $matches
    );
    
    // Skip invalid lines silently (no error output)
    if (count($matches) !== 4) {
        continue;  // Just skip it, don't dwell on it
    }
    
    $channelUrl = $matches[1];
    $videoUrl   = $matches[2];
    // $oldTimestamp = $matches[3];  // NOT USED ANYMORE - we use the real video date instead
    
    // Extract channel ID
    preg_match('/channel\/([a-zA-Z0-9_-]+)/', $channelUrl, $channelMatches);
    $channelId = $channelMatches[1] ?? null;
    
    if (!$channelId) {
        continue;  // Skip invalid channel IDs silently
    }
    
    // Fetch latest video
    $latestVideo = getLatestVideoFromRSS($channelId);
    
    if (!$latestVideo) {
        // Silent skip on RSS errors too
        continue;
    }
    
    $linkUrl     = $latestVideo['url'];
    $linkText    = htmlspecialchars($latestVideo['title']);
    $actualDate  = $latestVideo['date'];  // USE THE REAL VIDEO DATE FROM YOUTUBE
    
    // Build EMBED URL
    parse_str(parse_url($linkUrl, PHP_URL_QUERY), $queryParams);
    $videoId  = $queryParams['v'] ?? null;
    $embedUrl = $videoId ? "https://www.youtube.com/embed/$videoId" : null;
    
    // Output: channel - videoUrl ACTUAL_DATE new/old Title [EMBED]
    echo htmlspecialchars($channelUrl) . " - " . htmlspecialchars($videoUrl) . " " . htmlspecialchars($actualDate);
    
    if ($linkUrl === $videoUrl) {
        echo " <span style='color: gray; font-weight: bold;'>same</span> ";
    } else {
        echo " <span style='color: green; font-weight: bold;'>new</span> ";
    }
    
    echo "<a href='" . htmlspecialchars($linkUrl) . "' target='_blank'>" . $linkText . "</a>";
    
    if ($embedUrl) {
        echo " <a href='" . htmlspecialchars($embedUrl) . "' target='_blank' style='color:#555;'>[EMBED]</a>";
    }
    
    echo "<br>\n";
}

?>