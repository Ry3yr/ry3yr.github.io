<?php

class YouTubeChannelVideos {
    private $apiKey;
    private $channelInput;
    private $thumbnailDir;
    
    public function __construct($apiKey, $channelInput) {
        $this->apiKey = $apiKey;
        $this->channelInput = $channelInput;
        $this->thumbnailDir = __DIR__ . '/thumbnails/';
        
        if (!file_exists($this->thumbnailDir)) {
            mkdir($this->thumbnailDir, 0777, true);
        }
    }
    
    private function extractChannelIdentifier() {
        $input = trim($this->channelInput);
        
        if (preg_match('/^UC[\w-]{22}$/', $input)) {
            return ['type' => 'id', 'value' => $input];
        }
        
        if (preg_match('/@([\w-]+)/', $input, $matches)) {
            return ['type' => 'handle', 'value' => '@' . $matches[1]];
        }
        
        if (preg_match('/^[\w-]+$/', $input) && !preg_match('/^UC/', $input)) {
            return ['type' => 'handle', 'value' => '@' . $input];
        }
        
        return null;
    }
    
    private function getChannelId() {
        $identifier = $this->extractChannelIdentifier();
        
        if (!$identifier) {
            return null;
        }
        
        if ($identifier['type'] === 'id') {
            return $identifier['value'];
        }
        
        $handle = ltrim($identifier['value'], '@');
        
        $url = "https://www.googleapis.com/youtube/v3/channels?part=id&forHandle={$handle}&key={$this->apiKey}";
        $response = $this->makeCurlRequest($url);
        
        if ($response && isset($response['items'][0]['id'])) {
            return $response['items'][0]['id'];
        }
        
        $searchUrl = "https://www.googleapis.com/youtube/v3/search?part=snippet&q={$handle}&type=channel&maxResults=1&key={$this->apiKey}";
        $searchResponse = $this->makeCurlRequest($searchUrl);
        
        if ($searchResponse && isset($searchResponse['items'][0]['snippet']['channelId'])) {
            return $searchResponse['items'][0]['snippet']['channelId'];
        }
        
        return null;
    }
    
    private function fetchAndSaveThumbnail($url, $videoId) {
        $thumbnailPath = $this->thumbnailDir . $videoId . '.jpg';
        
        if (file_exists($thumbnailPath)) {
            return 'thumbnails/' . $videoId . '.jpg';
        }
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $imageData = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200 && $imageData) {
            file_put_contents($thumbnailPath, $imageData);
            return 'thumbnails/' . $videoId . '.jpg';
        }
        
        return null;
    }
    
    public function getLatestVideos($limit = 5) {
        $channelId = $this->getChannelId();
        
        if (!$channelId) {
            return ['error' => 'Channel not found'];
        }
        
        $channelUrl = "https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id={$channelId}&key={$this->apiKey}";
        $channelData = $this->makeCurlRequest($channelUrl);
        
        if (!$channelData || !isset($channelData['items'][0]['contentDetails']['relatedPlaylists']['uploads'])) {
            return ['error' => 'Unable to find uploads playlist'];
        }
        
        $uploadsPlaylistId = $channelData['items'][0]['contentDetails']['relatedPlaylists']['uploads'];
        
        $playlistUrl = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId={$uploadsPlaylistId}&maxResults={$limit}&key={$this->apiKey}";
        $playlistData = $this->makeCurlRequest($playlistUrl);
        
        if (!$playlistData || !isset($playlistData['items'])) {
            return ['error' => 'Unable to fetch videos'];
        }
        
        $videos = [];
        foreach ($playlistData['items'] as $item) {
            $videoId = $item['snippet']['resourceId']['videoId'];
            $thumbnailUrl = $item['snippet']['thumbnails']['high']['url'];
            
            $localThumbnail = $this->fetchAndSaveThumbnail($thumbnailUrl, $videoId);
            
            $videos[] = [
                'id' => $videoId,
                'title' => $item['snippet']['title'],
                'description' => $item['snippet']['description'],
                'published_at' => $item['snippet']['publishedAt'],
                'thumbnail_url' => $thumbnailUrl,
                'local_thumbnail' => $localThumbnail,
                'video_url' => "https://www.youtube.com/watch?v={$videoId}",
                'embed_url' => "https://www.youtube.com/embed/{$videoId}"
            ];
        }
        
        return $videos;
    }
    
    private function makeCurlRequest($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            return null;
        }
        
        return json_decode($response, true);
    }
    
    public function displayVideos($videos, $prefilledText = '') {
        if (isset($videos['error'])) {
            echo "<div class='error' style='color: red; padding: 20px; background: #ffeeee; border-radius: 5px;'>";
            echo "Error: " . htmlspecialchars($videos['error']);
            echo "</div>";
            return;
        }
        
        if (empty($videos)) {
            echo "<p>No videos found.</p>";
            return;
        }
        
        echo "<div class='textbox-container' style='margin-bottom: 30px; padding: 15px; background: #f5f5f5; border-radius: 8px;'>";
        echo "<label for='videoUrl' style='display: block; margin-bottom: 8px; font-weight: bold;'>Video URL / Info:</label>";
        echo "<input type='text' id='videoUrl' name='videoUrl' value='" . htmlspecialchars($prefilledText) . "' ";
        echo "style='width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;' placeholder='Enter video URL or information here...'>";
        echo "</div>";
        
        echo "<div class='videos-grid' style='display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;'>";
        
        foreach ($videos as $video) {
            echo "<div class='video-card' style='border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; background: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);'>";
            
            echo "<a href='" . htmlspecialchars($video['video_url']) . "' target='_blank' style='text-decoration: none;'>";
            
            if ($video['local_thumbnail'] && file_exists($video['local_thumbnail'])) {
                echo "<img src='" . htmlspecialchars($video['local_thumbnail']) . "' ";
            } else {
                echo "<img src='" . htmlspecialchars($video['thumbnail_url']) . "' ";
            }
            echo "alt='" . htmlspecialchars($video['title']) . "' ";
            echo "style='width: 100%; height: auto; display: block;'>";
            echo "</a>";
            
            echo "<div class='video-info' style='padding: 15px;'>";
            echo "<h3 style='margin: 0 0 10px 0; font-size: 16px; line-height: 1.3;'>";
            echo "<a href='" . htmlspecialchars($video['video_url']) . "' target='_blank' style='color: #333; text-decoration: none;'>";
            echo htmlspecialchars($video['title']);
            echo "</a>";
            echo "</h3>";
            
            $date = new DateTime($video['published_at']);
            echo "<p style='color: #666; font-size: 12px; margin: 0 0 10px 0;'>";
            echo "Published: " . $date->format('F j, Y');
            echo "</p>";
            
            $shortDesc = substr($video['description'], 0, 100);
            if (strlen($video['description']) > 100) {
                $shortDesc .= '...';
            }
            echo "<p style='color: #555; font-size: 13px; line-height: 1.4; margin: 0;'>";
            echo htmlspecialchars($shortDesc);
            echo "</p>";
            
            echo "</div>";
            echo "</div>";
        }
        
        echo "</div>";
    }
}

$apiKey = isset($_GET['api_key']) ? $_GET['api_key'] : (isset($_GET['apikey']) ? $_GET['apikey'] : '');
$channel = isset($_GET['channel']) ? $_GET['channel'] : (isset($_GET['c']) ? $_GET['c'] : '');
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 5;
$limit = max(1, min(50, $limit));

if (empty($apiKey) || empty($channel)) {
    die('<div style="color: red; padding: 20px; font-family: Arial, sans-serif;">
        <h2>Missing Parameters</h2>
        <p>Usage: <code>?api_key=YOUR_API_KEY&channel=@alceasgamingbouquet</code></p>
        <p>Parameters:</p>
        <ul>
            <li><strong>api_key</strong> or <strong>apikey</strong> - Your YouTube Data API v3 key</li>
            <li><strong>channel</strong> or <strong>c</strong> - Channel handle (@handle), channel ID (UC...), or full URL</li>
            <li><strong>limit</strong> - (optional) Number of videos (1-50, default: 5)</li>
        </ul>
        <p>Example: <code>?api_key=AIzaSy...&channel=@alceasgamingbouquet&limit=5</code></p>
    </div>');
}

$youtube = new YouTubeChannelVideos($apiKey, $channel);
$videos = $youtube->getLatestVideos($limit);

$prefilledText = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://');
$prefilledText .= $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YouTube Channel Videos</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .content {
            padding: 30px;
        }
        
        .channel-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            word-break: break-all;
        }
        
        .channel-info a {
            color: #ee5a24;
            text-decoration: none;
            font-weight: bold;
        }
        
        .channel-info a:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .content {
                padding: 15px;
            }
            
            .videos-grid {
                grid-template-columns: 1fr !important;
            }
        }
        
        .video-card {
            transition: transform 0.3s ease;
        }
        
        .video-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎮 YouTube Channel Videos</h1>
            <p>Latest Content - Thumbnails Fetched & Stored Locally via PHP</p>
        </div>
        
        <div class="content">
            <div class="channel-info">
                📺 <strong>Channel:</strong> 
                <a href="https://www.youtube.com/" . htmlspecialchars($channel) target="_blank">
                    <?php echo htmlspecialchars($channel); ?>
                </a>
            </div>
            
            <?php
            $youtube->displayVideos($videos, $prefilledText);
            ?>
        </div>
    </div>
</body>
</html>