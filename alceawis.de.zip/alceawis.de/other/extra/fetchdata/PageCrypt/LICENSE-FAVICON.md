License for favicon.ico:

This favicon was generated using the following graphics from Twitter Twemoji:

- Graphics Title: 1f512.svg
- Graphics Author: Copyright 2020 Twitter, Inc and other contributors (https://github.com/twitter/twemoji)
- Graphics Source: https://github.com/twitter/twemoji/blob/master/assets/svg/1f512.svg
- Graphics License: CC-BY 4.0 (https://creativecommons.org/licenses/by/4.0/)
