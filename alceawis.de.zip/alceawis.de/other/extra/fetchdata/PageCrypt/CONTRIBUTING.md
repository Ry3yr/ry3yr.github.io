# Contributing to PageCrypt

Thank you for taking the time to contribute!

There are no specific guidelines for contributing to this project, but I want to make it clear that contributions are always welcome!

This project has already accepted the generous contributions of **Zoltán Gálli** and **Nial Francis**. For details, read [the PageCrypt FAQ](https://www.maxlaumeister.com/pagecrypt/). Hopefully, you're next!

If you have any questions, please don't hesitate to open a GitHub issue or [email me](https://www.maxlaumeister.com/contact/) directly.
