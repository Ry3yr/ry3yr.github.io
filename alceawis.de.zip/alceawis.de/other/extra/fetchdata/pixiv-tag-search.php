<?php
/**
 * Fetch up to $limit NEW artwork entries for a given tag via Pixiv Ajax endpoint.
 * Skips any artwork IDs already seen by the user (passed from the browser).
 */
function fetchPixivTagResults($tag, $startPage, $limit, $seenIds = []) {
    $allItems = [];
    $page = $startPage;
    $seenSet = array_flip($seenIds); // O(1) lookup

    while (count($allItems) < $limit) {
        $url = 'https://www.pixiv.net/ajax/search/illustrations/'
             . rawurlencode($tag)
             . '?word=' . rawurlencode($tag)
             . '&s_mode=s_tag'
             . '&order=date_d'
             . '&mode=all'
             . '&type=illust_and_ugoira'
             . '&p=' . $page;

        $context = stream_context_create([
            'http' => [
                'header' => "User-Agent: Mozilla/5.0\r\nReferer: https://www.pixiv.net/\r\n",
                'timeout' => 10
            ],
            'ssl' => ['verify_peer' => false]
        ]);

        $response = @file_get_contents($url, false, $context);
        if (!$response) break;

        $data = json_decode($response, true);
        $items = $data['body']['illust']['data']
              ?? $data['body']['illustManga']['data']
              ?? [];

        if (empty($items)) break;

        foreach ($items as $item) {
            $id = $item['id'];
            // Skip if we've already shown this one in a previous request
            if (isset($seenSet[$id])) {
                continue;
            }
            $allItems[] = [
                'id'    => $id,
                'title' => $item['title'],
                'url'   => 'https://www.pixiv.net/artworks/' . $id
            ];
            if (count($allItems) >= $limit) break 2;
        }

        $page++;
        usleep(300000);
    }

    return $allItems;
}

// --- Configuration ---
$tag   = 'キャラ配布(コイカツ)';
$limit = 100;

$startPage = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;

// Read seen IDs sent from the browser (comma-separated, or JSON array)
$seenIds = [];
if (!empty($_GET['seen'])) {
    if (is_array($_GET['seen'])) {
        $seenIds = array_map('strval', $_GET['seen']);
    } else {
        // comma-separated fallback
        $seenIds = array_filter(array_map('trim', explode(',', $_GET['seen'])));
    }
}

$results = fetchPixivTagResults($tag, $startPage, $limit, $seenIds);

$pixivTagPageUrl = 'https://www.pixiv.net/en/tags/'
                 . rawurlencode($tag)
                 . '/illustrations?p=' . $startPage;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Pixiv Tag Results: <?= htmlspecialchars($tag) ?></title>
<style>
    body { font-family: system-ui, sans-serif; max-width: 900px; margin: 2rem auto; padding: 0 1rem; }
    .result { margin: .35rem 0; }
    .result a { text-decoration: none; color: #0066cc; }
    .result a:hover { text-decoration: underline; }
    .count { color: #666; margin-bottom: 1rem; }
    .nav { display: flex; gap: .75rem; align-items: center; margin: 1.5rem 0; flex-wrap: wrap; }
    .nav a, .nav button {
        padding: .4rem .9rem; border: 1px solid #ccc; border-radius: 6px;
        background: #f8f8f8; cursor: pointer; text-decoration: none; color: #222;
    }
    .nav a:hover, .nav button:hover { background: #eee; }
    .nav input[type="number"] { width: 80px; padding: .35rem; }
    .note { color: #666; font-size: .9rem; margin-top: 1rem; }
</style>
</head>
<body>

<h1>Tag: <?= htmlspecialchars($tag) ?></h1>
<p class="count">
    Showing up to <?= $limit ?> <strong>new</strong> results starting from Pixiv page <?= $startPage ?>.
    <br>
    <small>
        Fetched <?= count($results) ?> items
        (<?= count($seenIds) ?> previously seen items were skipped).
        <a href="<?= htmlspecialchars($pixivTagPageUrl) ?>" target="_blank" rel="noopener">Open this page on Pixiv</a>
    </small>
</p>

<?php if (empty($results)): ?>
    <p>No new results found. Try going to a later page.</p>
<?php else: ?>
    <div id="results">
        <?php foreach ($results as $r): ?>
            <div class="result" data-id="<?= htmlspecialchars($r['id']) ?>">
                <a href="<?= htmlspecialchars($r['url']) ?>" target="_blank" rel="noopener">
                    <?= htmlspecialchars($r['title']) ?>
                </a>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="nav">
        <?php if ($startPage > 1): ?>
            <a href="#" class="prev-link" data-page="<?= max(1, $startPage - 1) ?>">&laquo; Prev</a>
        <?php endif; ?>

        <form method="get" action="" id="pageForm" style="display:flex; gap:.5rem; align-items:center;">
            <label for="p">Go to Pixiv page:</label>
            <input type="number" id="p" name="p" min="1"
                   value="<?= htmlspecialchars($startPage) ?>">
            <button type="submit">Go</button>
        </form>

        <a href="#" class="next-link" data-page="<?= $startPage + 1 ?>">Next &raquo;</a>
    </div>
<?php endif; ?>

<p class="note">
    Seen artwork IDs are stored in your browser and sent to the server on each request,
    so the server skips fetching them again — reducing load on Pixiv.
</p>

<script>
(function () {
    const STORAGE_KEY = 'pixivSeenIds';

    function loadSeen() {
        try {
            return new Set(JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'));
        } catch (e) {
            return new Set();
        }
    }

    function saveSeen(set) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.from(set)));
        } catch (e) { /* ignore quota errors */ }
    }

    // Add newly displayed IDs to the seen set
    const seen = loadSeen();
    document.querySelectorAll('#results .result').forEach(el => {
        seen.add(el.dataset.id);
    });
    saveSeen(seen);

    // Helper to add the seen IDs to a URL
    function withSeen(url) {
        const u = new URL(url, window.location.href);
        u.searchParams.set('seen', JSON.stringify(Array.from(seen)));
        return u.toString();
    }

    // Wire up Next / Prev links so they carry the seen list
    document.querySelectorAll('.next-link, .prev-link').forEach(a => {
        a.addEventListener('click', function (e) {
            e.preventDefault();
            window.location.href = withSeen('?p=' + this.dataset.page);
        });
    });

    // Wire up the page-number form so it carries the seen list
    const form = document.getElementById('pageForm');
    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            const p = document.getElementById('p').value;
            window.location.href = withSeen('?p=' + encodeURIComponent(p));
        });
    }
})();
</script>

</body>
</html>