<?php
/**
 * Parabolic SAR Strategy Analyzer with Clear Investment Signals
 * Supports: ?symbol=SYMBOL&interval=1d&period=3mo
 */

class ParabolicSARStrategy {
    private $symbol;
    private $interval;
    private $period;
    private $data = [];
    private $sarData = [];
    private $signals = [];
    private $trades = [];
    private $performance = [];
    private $forecast = [];
    private $step = 0.02;
    private $maxStep = 0.2;
    
    public function __construct($symbol, $interval = '1d', $period = '3mo') {
        $this->symbol = strtoupper($symbol);
        $this->interval = $interval;
        $this->period = $period;
    }
    
    public function fetchData() {
        $url = "https://query1.finance.yahoo.com/v8/finance/chart/{$this->symbol}?interval={$this->interval}&range={$this->period}";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'Accept-Language: en-US,en;q=0.9',
            'Origin: https://finance.yahoo.com',
            'Referer: https://finance.yahoo.com/'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200 && !empty($response)) {
            $json = json_decode($response, true);
            if (isset($json['chart']['result'][0])) {
                return $this->parseData($json);
            }
        }
        
        return $this->fetchDataAlt();
    }
    
    private function fetchDataAlt() {
        $end = time();
        $start = strtotime('-3 months');
        $url = "https://query1.finance.yahoo.com/v7/finance/download/{$this->symbol}?interval={$this->interval}&period1={$start}&period2={$end}";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        if (empty($response)) {
            throw new Exception("Unable to fetch data for {$this->symbol}");
        }
        
        return $this->parseCSV($response);
    }
    
    private function parseCSV($csv) {
        $lines = explode("\n", trim($csv));
        if (count($lines) < 2) {
            throw new Exception("Invalid CSV data");
        }
        
        $this->data = [];
        for ($i = count($lines) - 1; $i >= 1; $i--) {
            $row = str_getcsv($lines[$i]);
            if (count($row) >= 6 && !empty($row[0]) && is_numeric($row[4])) {
                $this->data[] = [
                    'timestamp' => strtotime($row[0]),
                    'date' => $row[0],
                    'open' => floatval($row[1]),
                    'high' => floatval($row[2]),
                    'low' => floatval($row[3]),
                    'close' => floatval($row[4]),
                    'volume' => intval($row[5] ?? 0)
                ];
            }
        }
        
        if (empty($this->data)) {
            throw new Exception("No valid data rows found");
        }
        
        return $this->data;
    }
    
    private function parseData($json) {
        $result = $json['chart']['result'][0];
        $timestamps = $result['timestamp'] ?? [];
        $quote = $result['indicators']['quote'][0] ?? [];
        
        if (empty($timestamps) || empty($quote['close'])) {
            throw new Exception("No price data available");
        }
        
        $this->data = [];
        for ($i = 0; $i < count($timestamps); $i++) {
            $close = $quote['close'][$i] ?? null;
            if ($close !== null && $close > 0) {
                $this->data[] = [
                    'timestamp' => $timestamps[$i],
                    'date' => date('Y-m-d H:i:s', $timestamps[$i]),
                    'open' => $quote['open'][$i] ?? $close,
                    'high' => $quote['high'][$i] ?? $close,
                    'low' => $quote['low'][$i] ?? $close,
                    'close' => $close,
                    'volume' => $quote['volume'][$i] ?? 0
                ];
            }
        }
        
        return $this->data;
    }
    
    public function calculateSAR() {
        if (empty($this->data) || count($this->data) < 3) {
            throw new Exception("Insufficient data for SAR calculation");
        }
        
        $n = count($this->data);
        $this->sarData = [];
        
        $trend = ($this->data[1]['close'] > $this->data[0]['close']) ? 1 : -1;
        $extremePoint = ($trend > 0) ? $this->data[1]['high'] : $this->data[1]['low'];
        $sar = ($trend > 0) ? $this->data[0]['low'] : $this->data[0]['high'];
        $af = $this->step;
        
        for ($i = 0; $i < $n - 1; $i++) {
            $high = $this->data[$i]['high'];
            $low = $this->data[$i]['low'];
            
            $this->sarData[$i] = [
                'sar' => $sar,
                'trend' => $trend
            ];
            
            if ($trend > 0) {
                if ($sar > $low) {
                    $trend = -1;
                    $sar = $extremePoint;
                    $extremePoint = $low;
                    $af = $this->step;
                } else {
                    if ($high > $extremePoint) {
                        $extremePoint = $high;
                        $af = min($af + $this->step, $this->maxStep);
                    }
                    $sar = $sar + $af * ($extremePoint - $sar);
                    if ($i > 0 && $sar > $this->data[$i - 1]['low']) {
                        $sar = $this->data[$i - 1]['low'];
                    }
                    if ($sar > $low) {
                        $sar = $low;
                    }
                }
            } else {
                if ($sar < $high) {
                    $trend = 1;
                    $sar = $extremePoint;
                    $extremePoint = $high;
                    $af = $this->step;
                } else {
                    if ($low < $extremePoint) {
                        $extremePoint = $low;
                        $af = min($af + $this->step, $this->maxStep);
                    }
                    $sar = $sar + $af * ($extremePoint - $sar);
                    if ($i > 0 && $sar < $this->data[$i - 1]['high']) {
                        $sar = $this->data[$i - 1]['high'];
                    }
                    if ($sar < $high) {
                        $sar = $high;
                    }
                }
            }
        }
        
        $last = $n - 1;
        $this->sarData[$last] = [
            'sar' => $sar,
            'trend' => $trend
        ];
        
        return $this->sarData;
    }
    
    public function generateSignalsAndBacktest() {
        if (empty($this->sarData) || empty($this->data)) {
            throw new Exception("Calculate SAR first");
        }
        
        $this->signals = [];
        $this->trades = [];
        $n = min(count($this->data), count($this->sarData));
        
        $position = null;
        $entryPrice = null;
        $entryIndex = null;
        $entrySAR = null;
        
        for ($i = 0; $i < $n; $i++) {
            $signal = 'none';
            $trend = 'neutral';
            $sar = $this->sarData[$i]['sar'] ?? null;
            $close = $this->data[$i]['close'] ?? null;
            
            if ($sar !== null && $close !== null) {
                if ($sar < $close) {
                    $trend = 'uptrend';
                } elseif ($sar > $close) {
                    $trend = 'downtrend';
                }
                
                if ($i > 0 && isset($this->sarData[$i - 1])) {
                    $prevSar = $this->sarData[$i - 1]['sar'];
                    $prevClose = $this->data[$i - 1]['close'];
                    
                    if ($prevSar > $prevClose && $sar < $close) {
                        $signal = 'buy';
                        if ($position === 'short') {
                            $this->closeTrade($entryIndex, $i, 'short', $entryPrice, $close, $entrySAR, $sar);
                        }
                        $position = 'long';
                        $entryPrice = $close;
                        $entryIndex = $i;
                        $entrySAR = $sar;
                    }
                    
                    if ($prevSar < $prevClose && $sar > $close) {
                        $signal = 'sell';
                        if ($position === 'long') {
                            $this->closeTrade($entryIndex, $i, 'long', $entryPrice, $close, $entrySAR, $sar);
                        }
                        $position = 'short';
                        $entryPrice = $close;
                        $entryIndex = $i;
                        $entrySAR = $sar;
                    }
                }
            }
            
            $this->signals[] = [
                'date' => $this->data[$i]['date'],
                'close' => $close,
                'sar' => $sar,
                'trend' => $trend,
                'signal' => $signal,
                'distance_pct' => ($sar !== null && $close !== null) ? round((($close - $sar) / $close) * 100, 2) : null
            ];
        }
        
        if ($position !== null && $entryIndex !== null) {
            $lastIndex = $n - 1;
            $lastClose = $this->data[$lastIndex]['close'];
            $lastSAR = $this->sarData[$lastIndex]['sar'];
            $this->closeTrade($entryIndex, $lastIndex, $position, $entryPrice, $lastClose, $entrySAR, $lastSAR);
        }
        
        return $this->signals;
    }
    
    private function closeTrade($entryIdx, $exitIdx, $direction, $entryPrice, $exitPrice, $entrySAR, $exitSAR) {
        $priceChange = ($direction === 'long') ? 
            ($exitPrice - $entryPrice) / $entryPrice : 
            ($entryPrice - $exitPrice) / $entryPrice;
        
        $this->trades[] = [
            'entry_date' => $this->data[$entryIdx]['date'],
            'exit_date' => $this->data[$exitIdx]['date'],
            'direction' => $direction,
            'entry_price' => round($entryPrice, 2),
            'exit_price' => round($exitPrice, 2),
            'price_change_pct' => round($priceChange * 100, 2),
            'candles_held' => $exitIdx - $entryIdx,
            'win' => $priceChange > 0
        ];
    }
    
    public function calculatePerformance() {
        if (empty($this->trades)) {
            $this->performance = [
                'total_trades' => 0,
                'winning_trades' => 0,
                'losing_trades' => 0,
                'win_rate' => 0,
                'avg_win' => 0,
                'avg_loss' => 0,
                'total_return' => 0,
                'profit_factor' => 0,
                'max_drawdown' => 0,
                'win_loss_ratio' => 0,
                'avg_candles_held' => 0
            ];
            return $this->performance;
        }
        
        $totalTrades = count($this->trades);
        $winningTrades = array_filter($this->trades, function($t) { return $t['win']; });
        $losingTrades = array_filter($this->trades, function($t) { return !$t['win']; });
        
        $winRate = $totalTrades > 0 ? (count($winningTrades) / $totalTrades) * 100 : 0;
        $avgWin = !empty($winningTrades) ? array_sum(array_column($winningTrades, 'price_change_pct')) / count($winningTrades) : 0;
        $avgLoss = !empty($losingTrades) ? array_sum(array_column($losingTrades, 'price_change_pct')) / count($losingTrades) : 0;
        
        $totalReturn = array_sum(array_column($this->trades, 'price_change_pct'));
        $avgCandlesHeld = $totalTrades > 0 ? array_sum(array_column($this->trades, 'candles_held')) / $totalTrades : 0;
        
        $grossProfit = !empty($winningTrades) ? array_sum(array_column($winningTrades, 'price_change_pct')) : 0;
        $grossLoss = !empty($losingTrades) ? abs(array_sum(array_column($losingTrades, 'price_change_pct'))) : 0;
        $profitFactor = $grossLoss > 0 ? $grossProfit / $grossLoss : ($grossProfit > 0 ? 999 : 0);
        
        $cumulative = 0;
        $maxDrawdown = 0;
        $peak = 0;
        foreach ($this->trades as $trade) {
            $cumulative += $trade['price_change_pct'];
            if ($cumulative > $peak) $peak = $cumulative;
            $drawdown = $peak - $cumulative;
            if ($drawdown > $maxDrawdown) $maxDrawdown = $drawdown;
        }
        
        $winLossRatio = $avgLoss != 0 ? abs($avgWin / $avgLoss) : 0;
        
        $this->performance = [
            'total_trades' => $totalTrades,
            'winning_trades' => count($winningTrades),
            'losing_trades' => count($losingTrades),
            'win_rate' => round($winRate, 2),
            'avg_win' => round($avgWin, 2),
            'avg_loss' => round($avgLoss, 2),
            'total_return' => round($totalReturn, 2),
            'profit_factor' => round($profitFactor, 2),
            'max_drawdown' => round($maxDrawdown, 2),
            'win_loss_ratio' => round($winLossRatio, 2),
            'avg_candles_held' => round($avgCandlesHeld, 1)
        ];
        
        return $this->performance;
    }
    
    public function generateForecast() {
        if (empty($this->signals) || empty($this->performance)) {
            return ['error' => 'Insufficient data for forecast'];
        }
        
        $perf = $this->performance;
        $lastSignal = end($this->signals);
        $currentPrice = $lastSignal['close'] ?? 0;
        $currentSAR = $lastSignal['sar'] ?? 0;
        $trend = $lastSignal['trend'] ?? 'neutral';
        
        $forecast = [
            'current_price' => $currentPrice,
            'current_sar' => $currentSAR,
            'trend' => $trend,
            'confidence' => 'MEDIUM',
            'scenarios' => []
        ];
        
        $avgCandles = $perf['avg_candles_held'] ?? 20;
        
        $recentData = array_slice($this->data, -10);
        $avgMove = 0;
        if (count($recentData) > 1) {
            $changes = [];
            for ($i = 1; $i < count($recentData); $i++) {
                $changes[] = abs(($recentData[$i]['close'] - $recentData[$i-1]['close']) / $recentData[$i-1]['close']);
            }
            $avgMove = array_sum($changes) / count($changes) * 100;
        }
        
        if ($trend === 'uptrend') {
            $bestGain = $perf['avg_win'] * 1.2;
            $forecast['scenarios'][] = [
                'name' => '🚀 Best Case',
                'projected_price' => round($currentPrice * (1 + $bestGain / 100), 2),
                'gain_pct' => round($bestGain, 2)
            ];
            
            $forecast['scenarios'][] = [
                'name' => '📈 Likely Case',
                'projected_price' => round($currentPrice * (1 + $perf['avg_win'] / 100), 2),
                'gain_pct' => $perf['avg_win']
            ];
            
            $conservativeGain = $perf['avg_win'] * 0.6;
            $forecast['scenarios'][] = [
                'name' => '📊 Conservative',
                'projected_price' => round($currentPrice * (1 + $conservativeGain / 100), 2),
                'gain_pct' => round($conservativeGain, 2)
            ];
            
            $sarTarget = $currentSAR * 1.08;
            $forecast['scenarios'][] = [
                'name' => '🎯 SAR Target',
                'projected_price' => round($sarTarget, 2),
                'gain_pct' => round(($sarTarget - $currentPrice) / $currentPrice * 100, 2)
            ];
            
            $forecast['stop_loss'] = round($currentSAR * 0.98, 2);
            $forecast['take_profit_1'] = round($currentPrice * (1 + $perf['avg_win'] / 100), 2);
            $forecast['take_profit_2'] = round($currentPrice * (1 + $perf['avg_win'] * 1.5 / 100), 2);
            
        } elseif ($trend === 'downtrend') {
            $bestLoss = $perf['avg_loss'] * 1.2;
            $forecast['scenarios'][] = [
                'name' => '📉 Best Case',
                'projected_price' => round($currentPrice * (1 - abs($bestLoss) / 100), 2),
                'gain_pct' => round($bestLoss, 2)
            ];
            
            $forecast['scenarios'][] = [
                'name' => '📊 Likely Case',
                'projected_price' => round($currentPrice * (1 - abs($perf['avg_loss']) / 100), 2),
                'gain_pct' => $perf['avg_loss']
            ];
            
            $conservativeLoss = $perf['avg_loss'] * 0.6;
            $forecast['scenarios'][] = [
                'name' => '🟡 Conservative',
                'projected_price' => round($currentPrice * (1 - abs($conservativeLoss) / 100), 2),
                'gain_pct' => round($conservativeLoss, 2)
            ];
            
            $sarTarget = $currentSAR * 0.92;
            $forecast['scenarios'][] = [
                'name' => '🎯 SAR Target',
                'projected_price' => round($sarTarget, 2),
                'gain_pct' => round(($sarTarget - $currentPrice) / $currentPrice * 100, 2)
            ];
            
            $forecast['stop_loss'] = round($currentSAR * 1.02, 2);
            $forecast['take_profit_1'] = round($currentPrice * (1 - abs($perf['avg_loss']) / 100), 2);
            $forecast['take_profit_2'] = round($currentPrice * (1 - abs($perf['avg_loss']) * 1.5 / 100), 2);
        } else {
            $forecast['scenarios'][] = [
                'name' => '⏸️ Sideways',
                'projected_price' => round($currentPrice, 2),
                'gain_pct' => 0
            ];
            $forecast['stop_loss'] = round($currentPrice * 0.95, 2);
            $forecast['take_profit_1'] = round($currentPrice * 1.05, 2);
            $forecast['take_profit_2'] = round($currentPrice * 1.10, 2);
        }
        
        $forecast['time_horizon'] = round($avgCandles, 0) . " candles";
        $forecast['avg_daily_volatility'] = round($avgMove, 2) . "%";
        
        if ($perf['total_trades'] >= 10 && $perf['win_rate'] >= 60) {
            $forecast['confidence'] = 'HIGH';
        } elseif ($perf['total_trades'] >= 5 && $perf['win_rate'] >= 50) {
            $forecast['confidence'] = 'MEDIUM';
        } else {
            $forecast['confidence'] = 'LOW';
        }
        
        $this->forecast = $forecast;
        return $forecast;
    }
    
    public function getChartData() {
        $chartData = [
            'labels' => [],
            'prices' => [],
            'sar' => [],
            'signals' => [],
            'signal_labels' => []
        ];
        
        $n = min(count($this->data), count($this->sarData));
        $start = max(0, $n - 60);
        
        for ($i = $start; $i < $n; $i++) {
            $chartData['labels'][] = date('Y-m-d', strtotime($this->data[$i]['date']));
            $chartData['prices'][] = round($this->data[$i]['close'], 2);
            $chartData['sar'][] = round($this->sarData[$i]['sar'] ?? 0, 2);
            
            $signal = $this->signals[$i]['signal'] ?? 'none';
            $chartData['signals'][] = $signal;
            $chartData['signal_labels'][] = $signal === 'buy' ? 'BUY' : ($signal === 'sell' ? 'SELL' : '');
        }
        
        return $chartData;
    }
    
    /**
     * Generate clear investment signal
     */
    public function getInvestmentSignal() {
        $perf = $this->performance;
        $lastSignal = end($this->signals);
        $trend = $lastSignal['trend'] ?? 'neutral';
        $currentPrice = $lastSignal['close'] ?? 0;
        $currentSAR = $lastSignal['sar'] ?? 0;
        
        $signal = [
            'action' => 'NO INVEST',
            'color' => '#gray',
            'icon' => '⏸️',
            'direction' => 'NEUTRAL',
            'reason' => [],
            'confidence' => 'LOW',
            'levels' => []
        ];
        
        // Calculate signal strength score (0-100)
        $score = 0;
        $maxScore = 0;
        
        // Trend alignment (40 points)
        if ($trend === 'uptrend') {
            $score += 20;
            $maxScore += 40;
            if ($currentPrice > $currentSAR * 1.05) {
                $score += 20;
                $signal['reason'][] = '✅ Strong uptrend (price 5%+ above SAR)';
            } else {
                $score += 10;
                $signal['reason'][] = '✅ Uptrend (price above SAR)';
            }
        } elseif ($trend === 'downtrend') {
            $score += 20;
            $maxScore += 40;
            if ($currentPrice < $currentSAR * 0.95) {
                $score += 20;
                $signal['reason'][] = '✅ Strong downtrend (price 5%+ below SAR)';
            } else {
                $score += 10;
                $signal['reason'][] = '✅ Downtrend (price below SAR)';
            }
        } else {
            $signal['reason'][] = '⚠️ Sideways market (no clear trend)';
        }
        
        // Historical performance (30 points)
        $maxScore += 30;
        if ($perf['win_rate'] >= 60) {
            $score += 15;
            $signal['reason'][] = '✅ Excellent win rate (' . $perf['win_rate'] . '%)';
        } elseif ($perf['win_rate'] >= 50) {
            $score += 10;
            $signal['reason'][] = '✅ Good win rate (' . $perf['win_rate'] . '%)';
        } elseif ($perf['win_rate'] >= 40) {
            $score += 5;
            $signal['reason'][] = '⚠️ Average win rate (' . $perf['win_rate'] . '%)';
        } else {
            $signal['reason'][] = '❌ Poor win rate (' . $perf['win_rate'] . '%)';
        }
        
        if ($perf['profit_factor'] >= 2) {
            $score += 15;
            $signal['reason'][] = '✅ Excellent profit factor (' . $perf['profit_factor'] . ')';
        } elseif ($perf['profit_factor'] >= 1.5) {
            $score += 10;
            $signal['reason'][] = '✅ Good profit factor (' . $perf['profit_factor'] . ')';
        } elseif ($perf['profit_factor'] >= 1) {
            $score += 5;
            $signal['reason'][] = '⚠️ Average profit factor (' . $perf['profit_factor'] . ')';
        } else {
            $signal['reason'][] = '❌ Poor profit factor (' . $perf['profit_factor'] . ')';
        }
        
        // Risk assessment (20 points)
        $maxScore += 20;
        if ($perf['max_drawdown'] < 10) {
            $score += 20;
            $signal['reason'][] = '✅ Low drawdown (' . $perf['max_drawdown'] . '%)';
        } elseif ($perf['max_drawdown'] < 20) {
            $score += 10;
            $signal['reason'][] = '✅ Moderate drawdown (' . $perf['max_drawdown'] . '%)';
        } else {
            $signal['reason'][] = '⚠️ High drawdown (' . $perf['max_drawdown'] . '%)';
        }
        
        // Data quality (10 points)
        $maxScore += 10;
        if ($perf['total_trades'] >= 10) {
            $score += 10;
            $signal['reason'][] = '✅ Sufficient trade data (' . $perf['total_trades'] . ' trades)';
        } elseif ($perf['total_trades'] >= 5) {
            $score += 5;
            $signal['reason'][] = '⚠️ Limited trade data (' . $perf['total_trades'] . ' trades)';
        } else {
            $signal['reason'][] = '❌ Insufficient trade data (' . $perf['total_trades'] . ' trades)';
        }
        
        // Calculate percentage score
        $scorePct = $maxScore > 0 ? round(($score / $maxScore) * 100) : 0;
        
        // Determine confidence
        if ($scorePct >= 80) {
            $signal['confidence'] = 'HIGH';
        } elseif ($scorePct >= 60) {
            $signal['confidence'] = 'MEDIUM';
        } else {
            $signal['confidence'] = 'LOW';
        }
        
        // Determine action based on trend and score
        if ($trend === 'uptrend' && $scorePct >= 50) {
            $signal['action'] = 'LONG INVEST';
            $signal['color'] = '#00b894';
            $signal['icon'] = '📈';
            $signal['direction'] = 'BUY (LONG)';
            $signal['levels'] = [
                'entry' => $currentPrice,
                'stop_loss' => $currentSAR * 0.98,
                'take_profit_1' => $currentPrice * (1 + $perf['avg_win'] / 100),
                'take_profit_2' => $currentPrice * (1 + $perf['avg_win'] * 1.5 / 100)
            ];
            $signal['reason'][] = '🎯 Recommendation: BUY - Uptrend confirmed';
        } elseif ($trend === 'downtrend' && $scorePct >= 50) {
            $signal['action'] = 'SHORT INVEST';
            $signal['color'] = '#e17055';
            $signal['icon'] = '📉';
            $signal['direction'] = 'SELL (SHORT)';
            $signal['levels'] = [
                'entry' => $currentPrice,
                'stop_loss' => $currentSAR * 1.02,
                'take_profit_1' => $currentPrice * (1 - abs($perf['avg_loss']) / 100),
                'take_profit_2' => $currentPrice * (1 - abs($perf['avg_loss']) * 1.5 / 100)
            ];
            $signal['reason'][] = '🎯 Recommendation: SELL SHORT - Downtrend confirmed';
        } else {
            $signal['action'] = 'NO INVEST';
            $signal['color'] = '#fdcb6e';
            $signal['icon'] = '⏸️';
            $signal['direction'] = 'WAIT';
            if ($scorePct < 50) {
                $signal['reason'][] = '⚠️ Strategy score below threshold (' . $scorePct . '%)';
            }
            if ($trend === 'neutral') {
                $signal['reason'][] = '⚠️ No clear trend detected';
            }
            $signal['reason'][] = '⏸️ Recommendation: WAIT for better setup';
        }
        
        $signal['score'] = $scorePct;
        $signal['score_label'] = $scorePct >= 80 ? 'STRONG' : ($scorePct >= 60 ? 'GOOD' : ($scorePct >= 40 ? 'WEAK' : 'POOR'));
        
        return $signal;
    }
    
    public function getResults() {
        try {
            $this->fetchData();
            if (empty($this->data)) {
                throw new Exception("No data retrieved");
            }
            $this->calculateSAR();
            $this->generateSignalsAndBacktest();
            $this->calculatePerformance();
            $this->generateForecast();
            
            $summary = [
                'symbol' => $this->symbol,
                'interval' => $this->interval,
                'period' => $this->period,
                'total_candles' => count($this->data),
                'current_price' => !empty($this->data) ? round(end($this->data)['close'], 2) : null,
                'current_sar' => !empty($this->sarData) ? round(end($this->sarData)['sar'], 2) : null,
                'current_trend' => !empty($this->signals) ? end($this->signals)['trend'] : 'neutral',
                'last_signal' => !empty($this->signals) ? end($this->signals)['signal'] : 'none'
            ];
            
            $perf = $this->performance;
            $v = [];
            if ($perf['win_rate'] >= 60) $v['win_rate'] = 'EXCELLENT';
            elseif ($perf['win_rate'] >= 50) $v['win_rate'] = 'GOOD';
            elseif ($perf['win_rate'] >= 40) $v['win_rate'] = 'AVERAGE';
            else $v['win_rate'] = 'POOR';
            
            if ($perf['profit_factor'] >= 2) $v['profit_factor'] = 'EXCELLENT';
            elseif ($perf['profit_factor'] >= 1.5) $v['profit_factor'] = 'GOOD';
            elseif ($perf['profit_factor'] >= 1) $v['profit_factor'] = 'AVERAGE';
            else $v['profit_factor'] = 'POOR';
            
            if ($perf['total_return'] >= 20) $v['total_return'] = 'EXCELLENT';
            elseif ($perf['total_return'] >= 10) $v['total_return'] = 'GOOD';
            elseif ($perf['total_return'] >= 0) $v['total_return'] = 'AVERAGE';
            else $v['total_return'] = 'POOR';
            
            $score = 0;
            if ($perf['win_rate'] >= 50) $score++;
            if ($perf['profit_factor'] >= 1.5) $score++;
            if ($perf['total_return'] >= 10) $score++;
            if ($perf['win_loss_ratio'] >= 1.5) $score++;
            if ($perf['max_drawdown'] < 15) $score++;
            
            if ($score >= 4) {
                $v['overall'] = 'STRONG BUY SIGNAL - Strategy is highly profitable';
                $v['confidence'] = 'HIGH';
            } elseif ($score >= 3) {
                $v['overall'] = 'BUY SIGNAL - Strategy shows positive results';
                $v['confidence'] = 'MEDIUM';
            } elseif ($score >= 2) {
                $v['overall'] = 'NEUTRAL - Strategy needs improvement';
                $v['confidence'] = 'LOW';
            } else {
                $v['overall'] = 'AVOID - Strategy is not profitable';
                $v['confidence'] = 'VERY LOW';
            }
            
            return [
                'success' => true,
                'timestamp' => date('Y-m-d H:i:s'),
                'summary' => $summary,
                'performance' => $perf,
                'verdict' => $v,
                'forecast' => $this->forecast,
                'signal' => $this->getInvestmentSignal(),
                'chart' => $this->getChartData(),
                'trades' => array_reverse($this->trades),
                'signals' => array_slice($this->signals, -30)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}

// ============================================
// ROUTING
// ============================================

$symbol = isset($_GET['symbol']) ? trim($_GET['symbol']) : null;
$interval = isset($_GET['interval']) ? trim($_GET['interval']) : '1d';
$period = isset($_GET['period']) ? trim($_GET['period']) : '3mo';

$isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
          strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

$acceptsJson = isset($_GET['format']) && strtolower($_GET['format']) == 'json';
$acceptHeader = isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false;

if ($isAjax || $acceptsJson || $acceptHeader) {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    
    $strategy = new ParabolicSARStrategy(
        $symbol ? $symbol : 'MSTR', 
        $interval, 
        $period
    );
    echo json_encode($strategy->getResults(), JSON_PRETTY_PRINT);
    exit;
}

// ============================================
// HTML PAGE
// ============================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parabolic SAR Strategy Analyzer</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; background: #f0f2f5; color: #1a1a2e; padding: 20px; }
        .container { max-width: 1400px; margin: 0 auto; }
        
        .header { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: white; padding: 30px 40px; border-radius: 16px; margin-bottom: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        .header h1 { font-size: 28px; font-weight: 700; margin-bottom: 10px; }
        .header .subtitle { opacity: 0.8; font-size: 14px; }
        .header .meta { display: flex; gap: 30px; margin-top: 15px; flex-wrap: wrap; }
        .header .meta span { background: rgba(255,255,255,0.1); padding: 5px 15px; border-radius: 20px; font-size: 13px; }
        
        .search-box { background: white; padding: 20px 30px; border-radius: 12px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .search-box label { font-weight: 600; font-size: 14px; color: #555; }
        .search-box input, .search-box select { padding: 10px 16px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px; }
        .search-box input:focus, .search-box select:focus { outline: none; border-color: #1a1a2e; }
        .search-box input { flex: 1; min-width: 120px; }
        .search-box button { padding: 10px 30px; background: #1a1a2e; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; transition: background 0.3s; }
        .search-box button:hover { background: #2d2d5e; }
        
        /* INVESTMENT SIGNAL - BIG BANNER */
        .signal-banner {
            border-radius: 16px;
            padding: 30px 40px;
            margin-bottom: 30px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            border: 3px solid;
            text-align: center;
        }
        .signal-banner.long { background: linear-gradient(135deg, #d4edda 0%, #b7e4c7 100%); border-color: #00b894; }
        .signal-banner.short { background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%); border-color: #e17055; }
        .signal-banner.noinvest { background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%); border-color: #fdcb6e; }
        
        .signal-banner .icon { font-size: 60px; display: block; margin-bottom: 5px; }
        .signal-banner .action { font-size: 36px; font-weight: 800; }
        .signal-banner .direction { font-size: 20px; font-weight: 600; margin: 5px 0; }
        .signal-banner .score { font-size: 16px; font-weight: 500; margin-top: 8px; }
        .signal-banner .score .badge { padding: 4px 16px; border-radius: 20px; font-weight: 700; }
        .signal-banner .score .badge.strong { background: #00b894; color: white; }
        .signal-banner .score .badge.good { background: #fdcb6e; color: #2d3436; }
        .signal-banner .score .badge.weak { background: #e17055; color: white; }
        .signal-banner .score .badge.poor { background: #636e72; color: white; }
        
        .signal-banner .levels {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin: 15px 0 10px;
            flex-wrap: wrap;
        }
        .signal-banner .levels .level {
            background: rgba(255,255,255,0.7);
            padding: 8px 20px;
            border-radius: 10px;
            font-size: 14px;
        }
        .signal-banner .levels .level strong { display: block; font-size: 18px; }
        
        .signal-banner .reasons {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 8px 20px;
            margin-top: 12px;
            font-size: 14px;
        }
        .signal-banner .reasons span { background: rgba(255,255,255,0.6); padding: 4px 12px; border-radius: 8px; }
        
        .dashboard-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 30px; }
        @media (max-width: 992px) { .dashboard-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 600px) { .dashboard-grid { grid-template-columns: 1fr; } }
        
        .stat-card { background: white; padding: 22px 24px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
        .stat-card .label { font-size: 13px; color: #888; text-transform: uppercase; font-weight: 600; }
        .stat-card .value { font-size: 28px; font-weight: 700; margin: 8px 0 4px; }
        .stat-card .change { font-size: 13px; color: #666; }
        
        .verdict-banner { background: white; border-radius: 12px; padding: 25px 30px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); border-left: 6px solid #1a1a2e; }
        .verdict-banner .verdict-title { font-size: 20px; font-weight: 700; }
        .verdict-banner .verdict-sub { color: #666; margin-top: 5px; font-size: 14px; }
        .verdict-banner .verdict-details { display: flex; gap: 30px; margin-top: 15px; flex-wrap: wrap; }
        .verdict-banner .verdict-details .item { display: flex; align-items: center; gap: 8px; font-size: 14px; }
        
        .badge { padding: 3px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .badge.excellent { background: #d4edda; color: #155724; }
        .badge.good { background: #cce5ff; color: #004085; }
        .badge.average { background: #fff3cd; color: #856404; }
        .badge.poor { background: #f8d7da; color: #721c24; }
        .badge.high { background: #28a745; color: white; }
        .badge.medium { background: #ffc107; color: #212529; }
        .badge.low { background: #dc3545; color: white; }
        
        .section { background: white; border-radius: 12px; padding: 25px 30px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
        .section h2 { font-size: 18px; font-weight: 700; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; }
        .section h2 .count { font-size: 13px; font-weight: 400; color: #888; }
        
        .chart-container { position: relative; height: 400px; margin-top: 15px; }
        
        .table-wrap { overflow-x: auto; max-height: 400px; overflow-y: auto; }
        .table-wrap::-webkit-scrollbar { width: 6px; }
        .table-wrap::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 10px; }
        .table-wrap::-webkit-scrollbar-thumb { background: #ccc; border-radius: 10px; }
        
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        table th { background: #f8f9fa; text-align: left; padding: 12px 15px; font-weight: 600; color: #555; border-bottom: 2px solid #e0e0e0; }
        table td { padding: 10px 15px; border-bottom: 1px solid #f0f0f0; }
        table tr:hover td { background: #fafafa; }
        
        .signal-buy { color: #00b894; font-weight: 600; }
        .signal-sell { color: #e17055; font-weight: 600; }
        .signal-none { color: #b2bec3; }
        .trend-uptrend { color: #00b894; }
        .trend-downtrend { color: #e17055; }
        .trend-neutral { color: #fdcb6e; }
        .win { color: #00b894; font-weight: 600; }
        .loss { color: #e17055; font-weight: 600; }
        
        .loading { text-align: center; padding: 60px 20px; }
        .loading .spinner { display: inline-block; width: 40px; height: 40px; border: 4px solid #f0f0f0; border-top-color: #1a1a2e; border-radius: 50%; animation: spin 0.8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .loading p { margin-top: 15px; color: #888; }
        
        .error-box { background: #f8d7da; color: #721c24; padding: 20px 25px; border-radius: 12px; border-left: 6px solid #dc3545; margin-bottom: 30px; display: none; }
        
        .forecast-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 15px;
        }
        @media (max-width: 768px) { .forecast-grid { grid-template-columns: 1fr; } }
        
        .forecast-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 18px 22px;
            border-left: 4px solid #1a1a2e;
        }
        .forecast-card .name { font-weight: 700; font-size: 15px; }
        .forecast-card .price { font-size: 22px; font-weight: 700; margin: 5px 0; }
        .forecast-card .price.green { color: #00b894; }
        .forecast-card .price.red { color: #e17055; }
        
        .forecast-summary {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-top: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px 20px;
        }
        @media (max-width: 600px) { .forecast-summary { grid-template-columns: 1fr; } }
        
        .forecast-summary .item { text-align: center; }
        .forecast-summary .item .label { font-size: 12px; color: #888; text-transform: uppercase; }
        .forecast-summary .item .value { font-size: 18px; font-weight: 700; }
        
        @media (max-width: 600px) {
            .header { padding: 20px; }
            .header h1 { font-size: 22px; }
            .search-box { padding: 15px 20px; }
            .stat-card .value { font-size: 22px; }
            .section { padding: 15px 18px; }
            .signal-banner { padding: 20px; }
            .signal-banner .action { font-size: 28px; }
            .signal-banner .levels { gap: 15px; }
        }
    </style>
</head>
<body>
    <div class="container" id="app">
        <div class="header">
            <h1>📈 Parabolic SAR Strategy Analyzer</h1>
            <div class="subtitle">Clear investment signals: LONG INVEST | SHORT INVEST | NO INVEST</div>
            <div class="meta">
                <span id="symbolDisplay">Symbol: <?php echo htmlspecialchars($symbol ? $symbol : 'MSTR'); ?></span>
                <span id="intervalDisplay">Interval: <?php echo htmlspecialchars($interval); ?></span>
                <span id="periodDisplay">Period: <?php echo htmlspecialchars($period); ?></span>
                <span id="timestampDisplay">Updated: --</span>
            </div>
        </div>
        
        <div class="search-box">
            <label for="symbolInput">Symbol:</label>
            <input type="text" id="symbolInput" value="<?php echo htmlspecialchars($symbol ? $symbol : 'MSTR'); ?>" placeholder="e.g. AAPL, TSLA, BTC-USD">
            <label for="intervalSelect">Interval:</label>
            <select id="intervalSelect">
                <option value="1d" <?php echo $interval == '1d' ? 'selected' : ''; ?>>1 Day</option>
                <option value="1h" <?php echo $interval == '1h' ? 'selected' : ''; ?>>1 Hour</option>
                <option value="30m" <?php echo $interval == '30m' ? 'selected' : ''; ?>>30 Min</option>
                <option value="15m" <?php echo $interval == '15m' ? 'selected' : ''; ?>>15 Min</option>
                <option value="5m" <?php echo $interval == '5m' ? 'selected' : ''; ?>>5 Min</option>
                <option value="1wk" <?php echo $interval == '1wk' ? 'selected' : ''; ?>>1 Week</option>
                <option value="1mo" <?php echo $interval == '1mo' ? 'selected' : ''; ?>>1 Month</option>
            </select>
            <label for="periodSelect">Period:</label>
            <select id="periodSelect">
                <option value="1mo" <?php echo $period == '1mo' ? 'selected' : ''; ?>>1 Month</option>
                <option value="3mo" <?php echo $period == '3mo' ? 'selected' : ''; ?>>3 Months</option>
                <option value="6mo" <?php echo $period == '6mo' ? 'selected' : ''; ?>>6 Months</option>
                <option value="1y" <?php echo $period == '1y' ? 'selected' : ''; ?>>1 Year</option>
                <option value="2y" <?php echo $period == '2y' ? 'selected' : ''; ?>>2 Years</option>
                <option value="5y" <?php echo $period == '5y' ? 'selected' : ''; ?>>5 Years</option>
            </select>
            <button onclick="analyze()">🔍 Analyze</button>
        </div>
        
        <div id="loading" class="loading" style="display:none;">
            <div class="spinner"></div>
            <p>Analyzing data for <span id="loadingSymbol"><?php echo htmlspecialchars($symbol ? $symbol : 'MSTR'); ?></span>...</p>
        </div>
        
        <div id="errorBox" class="error-box"></div>
        
        <div id="results" style="display:none;">
            <!-- INVESTMENT SIGNAL - BIG BANNER -->
            <div id="signalBanner"></div>
            
            <div class="dashboard-grid" id="statsGrid"></div>
            <div class="verdict-banner" id="verdictBanner"></div>
            
            <div class="section" id="chartSection">
                <h2>📊 Price & SAR Chart <span class="count">(Last 60 candles)</span></h2>
                <div class="chart-container">
                    <canvas id="priceChart"></canvas>
                </div>
            </div>
            
            <div class="section" id="forecastSection">
                <h2>📊 Price Forecast <span class="count">(Next <?php echo $interval; ?> period projection)</span></h2>
                <div id="forecastContent"></div>
            </div>
            
            <div class="section" id="tradesSection">
                <h2>📊 Trade History <span class="count" id="tradeCount"></span></h2>
                <div class="table-wrap">
                    <table>
                        <thead><tr><th>Entry Date</th><th>Exit Date</th><th>Direction</th><th>Entry</th><th>Exit</th><th>P&L %</th><th>Candles</th><th>Result</th></tr></thead>
                        <tbody id="tradesBody"></tbody>
                    </table>
                </div>
            </div>
            
            <div class="section" id="signalsSection">
                <h2>🔔 Recent Signals <span class="count" id="signalCount"></span></h2>
                <div class="table-wrap">
                    <table>
                        <thead><tr><th>Date</th><th>Close</th><th>SAR</th><th>Trend</th><th>Signal</th><th>Distance %</th></tr></thead>
                        <tbody id="signalsBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        let chartInstance = null;
        
        function analyze() {
            const symbol = document.getElementById('symbolInput').value.trim() || 'MSTR';
            const interval = document.getElementById('intervalSelect').value;
            const period = document.getElementById('periodSelect').value;
            
            document.getElementById('symbolDisplay').textContent = `Symbol: ${symbol.toUpperCase()}`;
            document.getElementById('intervalDisplay').textContent = `Interval: ${interval}`;
            document.getElementById('periodDisplay').textContent = `Period: ${period}`;
            document.getElementById('loadingSymbol').textContent = symbol.toUpperCase();
            
            document.getElementById('loading').style.display = 'block';
            document.getElementById('results').style.display = 'none';
            document.getElementById('errorBox').style.display = 'none';
            
            const url = new URL(window.location);
            url.searchParams.set('symbol', symbol);
            url.searchParams.set('interval', interval);
            url.searchParams.set('period', period);
            window.history.pushState({}, '', url);
            
            const params = new URLSearchParams({
                symbol: symbol,
                interval: interval,
                period: period,
                format: 'json'
            });
            
            fetch(window.location.pathname + '?' + params.toString(), {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(res => res.json())
            .then(data => {
                document.getElementById('loading').style.display = 'none';
                
                if (!data.success) {
                    showError(data.error || 'Analysis failed');
                    return;
                }
                
                renderResults(data);
                document.getElementById('results').style.display = 'block';
                document.getElementById('timestampDisplay').textContent = `Updated: ${data.timestamp || '--'}`;
            })
            .catch(err => {
                document.getElementById('loading').style.display = 'none';
                showError('Network error: ' + err.message);
            });
        }
        
        function showError(msg) {
            const box = document.getElementById('errorBox');
            box.textContent = '❌ ' + msg;
            box.style.display = 'block';
        }
        
        function renderResults(data) {
            const summary = data.summary || {};
            const perf = data.performance || {};
            const v = data.verdict || {};
            const signal = data.signal || {};
            const forecast = data.forecast || {};
            const chartData = data.chart || {};
            const trades = data.trades || [];
            const signals = data.signals || [];
            
            // === INVESTMENT SIGNAL BANNER ===
            renderSignalBanner(signal);
            
            // Stats
            const stats = [
                { label: 'Current Price', value: summary.current_price ? `$${summary.current_price}` : '--', change: `SAR: $${summary.current_sar || '--'}` },
                { label: 'Trend', value: summary.current_trend || 'neutral', change: `Last Signal: ${summary.last_signal || 'none'}` },
                { label: 'Win Rate', value: `${perf.win_rate || 0}%`, change: `${perf.winning_trades || 0}W / ${perf.losing_trades || 0}L` },
                { label: 'Total Return', value: `${perf.total_return || 0}%`, change: `Profit Factor: ${perf.profit_factor || 0}` }
            ];
            
            document.getElementById('statsGrid').innerHTML = stats.map(s => `
                <div class="stat-card">
                    <div class="label">${s.label}</div>
                    <div class="value">${s.value}</div>
                    <div class="change">${s.change}</div>
                </div>
            `).join('');
            
            // Verdict
            const verdictItems = [
                { label: 'Win Rate', value: v.win_rate || 'N/A', badge: badgeClass(v.win_rate) },
                { label: 'Profit Factor', value: v.profit_factor || 'N/A', badge: badgeClass(v.profit_factor) },
                { label: 'Total Return', value: v.total_return || 'N/A', badge: badgeClass(v.total_return) }
            ];
            
            document.getElementById('verdictBanner').innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
                    <div>
                        <div class="verdict-title">${v.overall || 'Analysis Complete'}</div>
                        <div class="verdict-sub">Confidence: <span class="badge ${v.confidence === 'HIGH' ? 'high' : (v.confidence === 'MEDIUM' ? 'medium' : 'low')}">${v.confidence || 'LOW'}</span></div>
                    </div>
                </div>
                <div class="verdict-details">
                    ${verdictItems.map(item => `
                        <div class="item">${item.label}: <span class="badge ${item.badge}">${item.value}</span></div>
                    `).join('')}
                </div>
                ${perf.total_trades > 0 ? `<div style="margin-top:12px; font-size:14px; color:#555; border-top:1px solid #eee; padding-top:12px;">📊 ${perf.total_trades} total trades • ${perf.winning_trades} wins • ${perf.losing_trades} losses • Max DD: ${perf.max_drawdown}% • Avg Win: ${perf.avg_win}% • Avg Loss: ${perf.avg_loss}%</div>` : ''}
            `;
            
            // Chart
            renderChart(chartData);
            
            // Forecast
            renderForecast(forecast, summary);
            
            // Trades
            document.getElementById('tradeCount').textContent = `(${trades.length} trades)`;
            if (trades.length === 0) {
                document.getElementById('tradesBody').innerHTML = `<tr><td colspan="8" style="text-align:center; color:#888; padding:30px;">No trades recorded</td></tr>`;
            } else {
                document.getElementById('tradesBody').innerHTML = trades.map(t => `
                    <tr>
                        <td>${t.entry_date || '--'}</td>
                        <td>${t.exit_date || '--'}</td>
                        <td><strong>${t.direction === 'long' ? '🟢 LONG' : '🔴 SHORT'}</strong></td>
                        <td>$${t.entry_price}</td>
                        <td>$${t.exit_price}</td>
                        <td class="${t.win ? 'win' : 'loss'}">${t.price_change_pct}%</td>
                        <td>${t.candles_held}</td>
                        <td>${t.win ? '✅ WIN' : '❌ LOSS'}</td>
                    </tr>
                `).join('');
            }
            
            // Signals
            document.getElementById('signalCount').textContent = `(${signals.length} signals)`;
            if (signals.length === 0) {
                document.getElementById('signalsBody').innerHTML = `<tr><td colspan="6" style="text-align:center; color:#888; padding:30px;">No signals detected</td></tr>`;
            } else {
                document.getElementById('signalsBody').innerHTML = signals.map(s => {
                    const signalClass = s.signal === 'buy' ? 'signal-buy' : (s.signal === 'sell' ? 'signal-sell' : 'signal-none');
                    const signalText = s.signal === 'buy' ? '🟢 BUY' : (s.signal === 'sell' ? '🔴 SELL' : '—');
                    const trendClass = `trend-${s.trend}`;
                    return `
                        <tr>
                            <td>${s.date || '--'}</td>
                            <td>$${(s.close || 0).toFixed(2)}</td>
                            <td>$${(s.sar || 0).toFixed(2)}</td>
                            <td class="${trendClass}">${s.trend || 'neutral'}</td>
                            <td class="${signalClass}">${signalText}</td>
                            <td>${s.distance_pct !== null ? s.distance_pct + '%' : '—'}</td>
                        </tr>
                    `;
                }).join('');
            }
        }
        
        function renderSignalBanner(signal) {
            const container = document.getElementById('signalBanner');
            
            if (!signal || !signal.action) {
                container.innerHTML = `<p style="color:#888;">No signal data available</p>`;
                return;
            }
            
            const action = signal.action || 'NO INVEST';
            const actionClass = action === 'LONG INVEST' ? 'long' : (action === 'SHORT INVEST' ? 'short' : 'noinvest');
            const color = signal.color || '#888';
            const icon = signal.icon || '⏸️';
            const direction = signal.direction || 'WAIT';
            const score = signal.score || 0;
            const scoreLabel = signal.score_label || 'POOR';
            const confidence = signal.confidence || 'LOW';
            const reasons = signal.reason || [];
            const levels = signal.levels || {};
            
            let levelsHTML = '';
            if (levels.entry) {
                levelsHTML = `
                    <div class="levels">
                        <div class="level">📌 Entry: <strong>$${levels.entry}</strong></div>
                        <div class="level">🛑 Stop: <strong>$${levels.stop_loss}</strong></div>
                        <div class="level">🎯 TP1: <strong>$${levels.take_profit_1}</strong></div>
                        <div class="level">🚀 TP2: <strong>$${levels.take_profit_2}</strong></div>
                    </div>
                `;
            }
            
            const reasonsHTML = reasons.length > 0 ? 
                `<div class="reasons">${reasons.map(r => `<span>${r}</span>`).join('')}</div>` : '';
            
            container.innerHTML = `
                <div class="signal-banner ${actionClass}">
                    <span class="icon">${icon}</span>
                    <div class="action" style="color:${color};">${action}</div>
                    <div class="direction">${direction} • Confidence: <span class="badge ${confidence === 'HIGH' ? 'high' : (confidence === 'MEDIUM' ? 'medium' : 'low')}">${confidence}</span></div>
                    <div class="score">Strategy Score: <span class="badge ${scoreLabel.toLowerCase()}">${score}% - ${scoreLabel}</span></div>
                    ${levelsHTML}
                    ${reasonsHTML}
                </div>
            `;
        }
        
        function renderChart(chartData) {
            const ctx = document.getElementById('priceChart').getContext('2d');
            
            if (chartInstance) {
                chartInstance.destroy();
            }
            
            if (!chartData || !chartData.labels || chartData.labels.length === 0) {
                document.getElementById('chartSection').innerHTML += `<p style="color:#888; text-align:center; padding:20px;">No chart data available</p>`;
                return;
            }
            
            const buyPoints = [];
            const sellPoints = [];
            
            chartData.signals.forEach((signal, index) => {
                if (signal === 'buy') {
                    buyPoints.push({ x: index, y: chartData.prices[index] });
                } else if (signal === 'sell') {
                    sellPoints.push({ x: index, y: chartData.prices[index] });
                }
            });
            
            chartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: chartData.labels,
                    datasets: [
                        {
                            label: 'Close Price',
                            data: chartData.prices,
                            borderColor: '#2d3436',
                            backgroundColor: 'rgba(45, 52, 54, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.1,
                            pointRadius: 1
                        },
                        {
                            label: 'SAR',
                            data: chartData.sar,
                            borderColor: '#e17055',
                            backgroundColor: 'rgba(225, 112, 85, 0.2)',
                            borderWidth: 2,
                            borderDash: [5, 5],
                            fill: false,
                            tension: 0.1,
                            pointRadius: 3,
                            pointStyle: 'circle',
                            pointBackgroundColor: '#e17055'
                        },
                        {
                            label: 'BUY Signal',
                            data: buyPoints,
                            borderColor: '#00b894',
                            backgroundColor: '#00b894',
                            pointRadius: 8,
                            pointStyle: 'triangle',
                            showLine: false
                        },
                        {
                            label: 'SELL Signal',
                            data: sellPoints,
                            borderColor: '#e17055',
                            backgroundColor: '#e17055',
                            pointRadius: 8,
                            pointStyle: 'triangle',
                            rotation: 180,
                            showLine: false
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { mode: 'index', intersect: false },
                    plugins: {
                        legend: { position: 'top', labels: { usePointStyle: true, padding: 20 } },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    if (context.dataset.label === 'BUY Signal' || context.dataset.label === 'SELL Signal') {
                                        return context.dataset.label + ' at $' + context.parsed.y.toFixed(2);
                                    }
                                    return context.dataset.label + ': $' + context.parsed.y.toFixed(2);
                                }
                            }
                        }
                    },
                    scales: {
                        y: { beginAtZero: false, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { callback: function(value) { return '$' + value.toFixed(2); } } },
                        x: { grid: { display: false }, ticks: { maxRotation: 45, autoSkip: true, maxTicksLimit: 20 } }
                    }
                }
            });
        }
        
        function renderForecast(forecast, summary) {
            const container = document.getElementById('forecastContent');
            
            if (!forecast || !forecast.scenarios) {
                container.innerHTML = `<p style="color:#888;">Insufficient data for forecast</p>`;
                return;
            }
            
            const trend = forecast.trend || 'neutral';
            const trendEmoji = trend === 'uptrend' ? '📈' : (trend === 'downtrend' ? '📉' : '➡️');
            const trendColor = trend === 'uptrend' ? '#00b894' : (trend === 'downtrend' ? '#e17055' : '#fdcb6e');
            
            let html = `
                <div style="display:flex; gap:20px; flex-wrap:wrap; align-items:center; margin-bottom:10px;">
                    <span>Current: <strong>$${forecast.current_price || summary.current_price}</strong></span>
                    <span>SAR: <strong>$${forecast.current_sar || summary.current_sar}</strong></span>
                    <span>Trend: <strong style="color:${trendColor};">${trendEmoji} ${trend}</strong></span>
                    <span>Confidence: <span class="badge ${forecast.confidence === 'HIGH' ? 'high' : (forecast.confidence === 'MEDIUM' ? 'medium' : 'low')}">${forecast.confidence || 'LOW'}</span></span>
                </div>
            `;
            
            html += `<div class="forecast-grid">`;
            forecast.scenarios.forEach(s => {
                const isGain = s.gain_pct >= 0;
                const priceClass = isGain ? 'green' : 'red';
                const sign = isGain ? '+' : '';
                html += `
                    <div class="forecast-card">
                        <div class="name">${s.name}</div>
                        <div class="price ${priceClass}">$${s.projected_price} <span style="font-size:14px; font-weight:400;">(${sign}${s.gain_pct}%)</span></div>
                    </div>
                `;
            });
            html += `</div>`;
            
            if (forecast.stop_loss || forecast.take_profit_1) {
                html += `
                    <div class="forecast-summary">
                        <div class="item"><div class="label">🛑 Stop Loss</div><div class="value" style="color:#e17055;">$${forecast.stop_loss || '--'}</div></div>
                        <div class="item"><div class="label">🎯 Take Profit 1</div><div class="value" style="color:#00b894;">$${forecast.take_profit_1 || '--'}</div></div>
                        <div class="item"><div class="label">🚀 Take Profit 2</div><div class="value" style="color:#004085;">$${forecast.take_profit_2 || '--'}</div></div>
                    </div>
                `;
            }
            
            if (forecast.time_horizon || forecast.avg_daily_volatility) {
                html += `
                    <div style="margin-top:12px; font-size:13px; color:#888; border-top:1px solid #eee; padding-top:10px;">
                        ${forecast.time_horizon ? `⏱️ Time horizon: ~${forecast.time_horizon}` : ''}
                        ${forecast.avg_daily_volatility ? ` • 📊 Avg volatility: ${forecast.avg_daily_volatility}` : ''}
                    </div>
                `;
            }
            
            container.innerHTML = html;
        }
        
        function badgeClass(value) {
            if (value === 'EXCELLENT' || value === 'HIGH') return 'excellent';
            if (value === 'GOOD' || value === 'MEDIUM') return 'good';
            if (value === 'AVERAGE' || value === 'LOW') return 'average';
            if (value === 'POOR' || value === 'VERY LOW') return 'poor';
            return 'average';
        }
        
        document.addEventListener('DOMContentLoaded', () => {
            <?php if ($symbol): ?>
            setTimeout(analyze, 500);
            <?php endif; ?>
            document.getElementById('symbolInput').addEventListener('keydown', e => {
                if (e.key === 'Enter') analyze();
            });
        });
    </script>
</body>
</html>