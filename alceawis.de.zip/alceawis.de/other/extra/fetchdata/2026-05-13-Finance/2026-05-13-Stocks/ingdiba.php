<?php
/**
 * ING Stock Dashboard - Production Ready v2.3
 * Now supports: ISIN, Company Name, AND Ticker Symbols (AAPL, NVDA, etc.)
 */

// ============================================
// API CLIENT CLASS - COMPLETE
// ============================================
class IngApiClient {
    private $baseUrl = 'https://component-api.wertpapiere.ing.de';
    private $systemUrl = 'https://wertpapiere.ing.de';
    private $userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';
    private $cache = [];
    private $cacheTTL = 60;
    
    private function get($endpoint, $params = [], $useCache = true) {
        $cacheKey = $endpoint . '?' . http_build_query($params);
        
        if ($useCache && isset($this->cache[$cacheKey]) && $this->cache[$cacheKey]['expires'] > time()) {
            return $this->cache[$cacheKey]['data'];
        }
        
        $url = $this->baseUrl . $endpoint;
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_USERAGENT => $this->userAgent,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json, text/plain, */*',
                'Accept-Language: de-DE,de;q=0.9',
                'Referer: ' . $this->systemUrl . '/investieren/aktienportrait/',
                'Origin: ' . $this->systemUrl,
            ],
            CURLOPT_ENCODING => '',
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($response === false || $httpCode !== 200) {
            return ['success' => false, 'error' => $error ?: 'HTTP ' . $httpCode];
        }
        
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return ['success' => false, 'error' => 'JSON Error: ' . json_last_error_msg()];
        }
        
        $result = ['success' => true, 'data' => $data];
        
        if ($useCache) {
            $this->cache[$cacheKey] = [
                'data' => $result,
                'expires' => time() + $this->cacheTTL
            ];
        }
        
        return $result;
    }
    
    // ============================================
    // ALL DISCOVERED ENDPOINTS
    // ============================================
    
    public function getInstrumentHeader($isin) {
        return $this->get('/api/v1/instrument-header', [
            'isinOrSearchTerm' => $isin,
            'isKnownIsin' => 'true',
            'includeAvailableExchanges' => 'true'
        ]);
    }
    
    public function getLocalHeader($isin) {
        return $this->get('/api/v1/components/localheader/' . $isin);
    }
    
    public function validateAssetClass($isin) {
        return $this->get('/api/v1/components/validateassetclass/' . $isin, [
            'assetClass' => 'Share'
        ]);
    }
    
    public function getLogo($isin) {
        return $this->get('/api/v1/components/logo', [
            'isin' => $isin,
            'assetClass' => 'Share'
        ]);
    }
    
    public function getChart($isin) {
        return $this->get('/api/v1/components/chart', ['isins' => $isin]);
    }
    
    public function getChartToolData($isin, $range = '1M') {
        return $this->get('/api/v1/charts/charttooldata/' . $isin, [
            'timeRange' => $range,
            'exchangeId' => 2779,
            'exchangeCode' => 'TGT',
            'currencyId' => 814
        ]);
    }
    
    public function getInformationTextBox($isin, $category = 'TradingConditions') {
        return $this->get('/api/v1/components/informationtextbox/' . $isin, [
            'category' => $category
        ]);
    }
    
    public function getDividendOverview($isin) {
        return $this->get('/api/v1/share/dividend-overview/' . $isin);
    }
    
    public function getDividends($isin) {
        return $this->getDividendOverview($isin);
    }
    
    public function getKeyFigures($isin) {
        return $this->get('/api/v1/share/keyfigures/' . $isin);
    }
    
    public function getAnalysis($isin) {
        return $this->get('/api/v1/share/analysis/' . $isin);
    }
    
    public function getTechnicalAnalysis($isin) {
        return $this->get('/api/v1/components/technicalanalysis/' . $isin);
    }
    
    public function getNews($isin, $limit = 5) {
        $result = $this->get('/api/v1/components/instrumentNews/' . $isin);
        if ($result['success'] && isset($result['data']['items'])) {
            $result['data']['items'] = array_slice($result['data']['items'], 0, $limit);
        }
        return $result;
    }
    
    public function getCompanyEvents($isin, $count = 3) {
        return $this->get('/api/v1/share/companyevents/' . $isin, ['itemCount' => $count]);
    }
    
    public function getPerformanceComparison($isin) {
        return $this->get('/api/v1/components/performancecomparison/' . $isin);
    }
    
    public function getDescription($isin) {
        return $this->get('/api/v1/components/description/' . $isin);
    }
    
    public function getLeverageProducts($isin) {
        return $this->get('/api/v1/components/leverageproductsdata/' . $isin);
    }
    
    public function getShareAlternatives($isin) {
        return $this->get('/api/v1/share/sharealternatives/' . $isin);
    }
    
    public function getConsumerProtection($isin) {
        return $this->get('/api/v1/components/consumerprotection/' . $isin);
    }
    
    /**
     * SEARCH - Supports ISIN, Company Name, AND Ticker Symbols
     */
        /**
     * Search shares using the instrument-search API (from dump analysis)
     * Endpoint: GET /api/v1/instrument-search/share/search?pageNumber=1&orderBy=name&orderDirection=none&searchTerm={TERM}&savingsPlan=false
     */
    public function searchShare($query, $pageNumber = 1, $pageSize = 10) {
        return $this->get('/api/v1/instrument-search/share/search', [
            'pageNumber' => $pageNumber,
            'pageSize' => $pageSize,
            'orderBy' => 'name',
            'orderDirection' => 'none',
            'searchTerm' => $query,
            'savingsPlan' => 'false'
        ]);
    }

    /**
     * SEARCH - Supports ISIN, Company Name, AND Ticker Symbols (AAPL, NVDA, etc.)
     * Uses the new instrument-search API as primary, with fallbacks to legacy endpoints
     */
    public function searchBySymbol($query) {
        $query = trim($query);
        if (empty($query)) {
            return ['success' => false, 'data' => ['results' => []], 'error' => 'Empty search query'];
        }

        // Strategy 1: If it looks like an ISIN (2 letters + 10 chars)
        if (preg_match('/^[A-Z]{2}[A-Z0-9]{10}$/', $query)) {
            $result = $this->getInstrumentHeader($query);
            if ($result['success'] && isset($result['data']['name'])) {
                return [
                    'success' => true,
                    'data' => ['results' => [[
                        'isin' => $query,
                        'name' => $result['data']['name'],
                        'symbol' => $result['data']['symbol'] ?? $result['data']['ticker'] ?? 'N/A',
                        'price' => $result['data']['price'] ?? 'N/A',
                        'currency' => $result['data']['currency'] ?? 'EUR'
                    ]]]
                ];
            }
        }

        // Strategy 2: Use instrument-search/share/search API (from dump analysis - primary search)
        $result = $this->searchShare($query);
        if ($result['success'] && isset($result['data']['items']) && is_array($result['data']['items']) && count($result['data']['items']) > 0) {
            $items = $result['data']['items'];
            $results = [];
            foreach ($items as $item) {
                $results[] = [
                    'isin' => $item['isin'] ?? 'N/A',
                    'name' => $item['name'] ?? 'N/A',
                    'symbol' => $item['wkn'] ?? 'N/A',  // wkn is the closest to symbol in this API
                    'price' => $item['price'] ?? 'N/A',
                    'currency' => $item['currencyIsoCode'] ?? 'EUR'
                ];
            }
            return [
                'success' => true,
                'data' => [
                    'results' => $results,
                    'totalCount' => $result['data']['totalCount'] ?? count($results),
                    'pageNumber' => $result['data']['pageNumber'] ?? 1,
                    'totalPages' => $result['data']['totalPages'] ?? 1
                ]
            ];
        }

        // Strategy 3: Try validateassetclass (legacy fallback)
        $result = $this->get('/api/v1/components/validateassetclass', [
            'isinOrSearchTerm' => $query,
            'assetClass' => 'Share'
        ]);

        if ($result['success']) {
            if (isset($result['data']['results']) && is_array($result['data']['results']) && count($result['data']['results']) > 0) {
                return $result;
            }
            if (isset($result['data']['name']) && isset($result['data']['isin'])) {
                return [
                    'success' => true,
                    'data' => ['results' => [[
                        'isin' => $result['data']['isin'],
                        'name' => $result['data']['name'],
                        'symbol' => $result['data']['symbol'] ?? $result['data']['ticker'] ?? 'N/A'
                    ]]]
                ];
            }
        }

        // Strategy 4: Use instrument-header with search (legacy fallback)
        $result = $this->get('/api/v1/instrument-header', [
            'isinOrSearchTerm' => $query,
            'isKnownIsin' => 'false',
            'includeAvailableExchanges' => 'true'
        ]);

        if ($result['success']) {
            // Check for results array
            if (isset($result['data']['results']) && is_array($result['data']['results']) && count($result['data']['results']) > 0) {
                return $result;
            }

            // Check for direct single result
            if (isset($result['data']['name'])) {
                $isin = $result['data']['isin'] ?? $query;
                $symbol = $result['data']['symbol'] ?? $result['data']['ticker'] ?? 'N/A';
                return [
                    'success' => true,
                    'data' => ['results' => [[
                        'isin' => $isin,
                        'name' => $result['data']['name'],
                        'symbol' => $symbol,
                        'price' => $result['data']['price'] ?? 'N/A',
                        'currency' => $result['data']['currency'] ?? 'EUR'
                    ]]]
                ];
            }
        }

        // Strategy 5: Try direct ISIN lookup with localheader
        if (preg_match('/^[A-Z]{2}[A-Z0-9]{10}$/', $query)) {
            $result = $this->get('/api/v1/components/localheader/' . $query);
            if ($result['success'] && isset($result['data']['name'])) {
                return [
                    'success' => true,
                    'data' => ['results' => [[
                        'isin' => $query,
                        'name' => $result['data']['name'],
                        'symbol' => $result['data']['symbol'] ?? $result['data']['ticker'] ?? 'N/A'
                    ]]]
                ];
            }
        }

        return ['success' => false, 'data' => ['results' => []], 'error' => 'No results found'];
    }
    public function extractPriceData($isin) {
        $result = $this->getInstrumentHeader($isin);
        if (!$result['success']) {
            return ['success' => false, 'error' => $result['error']];
        }
        
        $data = $result['data'];
        return [
            'success' => true,
            'isin' => $isin,
            'name' => $data['name'] ?? 'N/A',
            'symbol' => $data['symbol'] ?? $data['ticker'] ?? 'N/A',
            'price' => $data['price'] ?? $data['lastPrice'] ?? 'N/A',
            'bid' => $data['bid'] ?? 'N/A',
            'ask' => $data['ask'] ?? 'N/A',
            'change' => $data['change'] ?? 'N/A',
            'change_percent' => $data['changePercent'] ?? 'N/A',
            'currency' => $data['currency'] ?? 'EUR',
            'volume' => $data['volume'] ?? 'N/A',
            'high' => $data['high'] ?? 'N/A',
            'low' => $data['low'] ?? 'N/A',
            'timestamp' => $data['timestamp'] ?? date('Y-m-d H:i:s'),
            'marketState' => $data['marketState'] ?? 'N/A',
            'raw' => $data
        ];
    }
    
    /**
     * Fetch ALL data for an ISIN in one call
     */
    public function fetchAllData($isin, $range = '1M') {
        return [
            'price' => $this->extractPriceData($isin),
            'keyfigures' => $this->getKeyFigures($isin),
            'chart' => $this->getChart($isin),
            'charttool' => $this->getChartToolData($isin, $range),
            'description' => $this->getDescription($isin),
            'news' => $this->getNews($isin, 5),
            'dividends' => $this->getDividends($isin),
            'analysis' => $this->getAnalysis($isin),
            'technical' => $this->getTechnicalAnalysis($isin),
            'events' => $this->getCompanyEvents($isin, 3),
            'performance' => $this->getPerformanceComparison($isin),
            'localheader' => $this->getLocalHeader($isin),
            'validate' => $this->validateAssetClass($isin),
            'logo' => $this->getLogo($isin),
            'leverage' => $this->getLeverageProducts($isin),
            'alternatives' => $this->getShareAlternatives($isin),
            'consumerprotection' => $this->getConsumerProtection($isin),
        ];
    }
}

// ============================================
// JSON MODE - Output raw data
// ============================================
function outputJson($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET');
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ============================================
// PROCESS REQUEST
// ============================================
$client = new IngApiClient();
$jsonMode = isset($_GET['json']) || isset($_GET['api']);
$firstMatch = isset($_GET['firstmatch']);
$isin = isset($_GET['isin']) ? trim($_GET['isin']) : '';
$symbol = isset($_GET['symbol']) ? trim($_GET['symbol']) : '';
$range = isset($_GET['range']) ? trim($_GET['range']) : '1M';
$searchResults = [];
$message = '';
$priceData = null;

// ============================================
// POPULAR STOCKS WITH TICKERS
// ============================================
$popularStocks = [
    ['isin' => 'US0378331005', 'name' => 'Apple Inc.', 'symbol' => 'AAPL'],
    ['isin' => 'US5949181045', 'name' => 'Microsoft Corp.', 'symbol' => 'MSFT'],
    ['isin' => 'US02079K3059', 'name' => 'Alphabet Inc.', 'symbol' => 'GOOGL'],
    ['isin' => 'US88160R1014', 'name' => 'Tesla Inc.', 'symbol' => 'TSLA'],
    ['isin' => 'US30303M1027', 'name' => 'Meta Platforms', 'symbol' => 'META'],
    ['isin' => 'US4581401001', 'name' => 'Intel Corp.', 'symbol' => 'INTC'],
    ['isin' => 'US67066G1040', 'name' => 'NVIDIA Corp.', 'symbol' => 'NVDA'],
    ['isin' => 'US0231351067', 'name' => 'Amazon.com Inc.', 'symbol' => 'AMZN'],
    ['isin' => 'DE0005557508', 'name' => 'Allianz SE', 'symbol' => 'ALV'],
    ['isin' => 'DE000BASF111', 'name' => 'BASF SE', 'symbol' => 'BAS'],
    ['isin' => 'DE0007100000', 'name' => 'BMW AG', 'symbol' => 'BMW'],
    ['isin' => 'DE0007236101', 'name' => 'Siemens AG', 'symbol' => 'SIE'],
];

// Create a quick lookup for symbols
$symbolToIsin = [];
foreach ($popularStocks as $stock) {
    $symbolToIsin[strtoupper($stock['symbol'])] = $stock['isin'];
}

// ============================================
// SEARCH LOGIC - Now handles tickers!
// ============================================
if (!empty($symbol) && empty($isin)) {
    // Check if it's a known ticker symbol
    $upperSymbol = strtoupper($symbol);
    if (isset($symbolToIsin[$upperSymbol])) {
        $isin = $symbolToIsin[$upperSymbol];
        $message = '✅ Found: ' . $upperSymbol . ' (ticker)';
    } else {
        $searchResult = $client->searchBySymbol($symbol);

        if ($searchResult['success'] && isset($searchResult['data']['results']) && count($searchResult['data']['results']) > 0) {
            $searchResults = $searchResult['data']['results'];
            if (count($searchResults) === 1) {
                $isin = $searchResults[0]['isin'];
                $message = '✅ Found: ' . htmlspecialchars($searchResults[0]['name']);
            } elseif ($jsonMode && $firstMatch && count($searchResults) > 1) {
                // JSON mode + firstmatch: auto-select first result and fetch its details
                $isin = $searchResults[0]['isin'];
                $message = '✅ Auto-selected first match: ' . htmlspecialchars($searchResults[0]['name']);
                $searchResults = []; // Clear so we proceed to fetch detail data
            } else {
                $message = count($searchResults) . ' results found. Please select one:';
            }
        } else {
            $message = 'No results found for "' . htmlspecialchars($symbol) . '"';
            // Show suggestions
        }
    }
}

// Default ISIN if none provided
if (empty($isin) && empty($symbol)) {
    $isin = ''; // Allianz
}

// ============================================
// FETCH DATA
// ============================================
$allData = [];
$fetchSuccess = false;

if (!empty($isin)) {
    $allData = $client->fetchAllData($isin, $range);
    $priceData = $allData['price'] ?? null;
    $fetchSuccess = $priceData && $priceData['success'];
    
    // If we have price data, add to symbol lookup
    if ($fetchSuccess && isset($priceData['symbol']) && $priceData['symbol'] !== 'N/A') {
        $symbolToIsin[strtoupper($priceData['symbol'])] = $isin;
    }
}

// ============================================
// JSON MODE OUTPUT
// ============================================
if ($jsonMode) {
    $response = [
        'status' => 'success',
        'timestamp' => date('c'),
        'query' => [
            'isin' => $isin,
            'symbol' => $symbol,
            'range' => $range
        ]
    ];
    
    // Add search results if any
    if (!empty($searchResults)) {
        $response['search'] = [
            'query' => $symbol,
            'results' => $searchResults,
            'count' => count($searchResults)
        ];
    }
    
    // Add data if fetch was successful
    if ($fetchSuccess) {
        $response['data'] = [];
        
        // Add price data (clean, without raw)
        if (isset($allData['price'])) {
            $price = $allData['price'];
            $response['data']['price'] = [
                'isin' => $price['isin'] ?? 'N/A',
                'name' => $price['name'] ?? 'N/A',
                'symbol' => $price['symbol'] ?? 'N/A',
                'price' => $price['price'] ?? 'N/A',
                'bid' => $price['bid'] ?? 'N/A',
                'ask' => $price['ask'] ?? 'N/A',
                'change' => $price['change'] ?? 'N/A',
                'change_percent' => $price['change_percent'] ?? 'N/A',
                'currency' => $price['currency'] ?? 'EUR',
                'volume' => $price['volume'] ?? 'N/A',
                'high' => $price['high'] ?? 'N/A',
                'low' => $price['low'] ?? 'N/A',
                'timestamp' => $price['timestamp'] ?? 'N/A',
                'market_state' => $price['marketState'] ?? 'N/A'
            ];
        }
        
        // Add key figures
        if (isset($allData['keyfigures']) && $allData['keyfigures']['success']) {
            $response['data']['keyfigures'] = $allData['keyfigures']['data'];
        }
        
        // Add description
        if (isset($allData['description']) && $allData['description']['success']) {
            $response['data']['description'] = $allData['description']['data']['description'] ?? 'N/A';
        }
        
        // Add news
        if (isset($allData['news']) && $allData['news']['success'] && isset($allData['news']['data']['items'])) {
            $response['data']['news'] = $allData['news']['data']['items'];
        }
        
        // Add dividends
        if (isset($allData['dividends']) && $allData['dividends']['success'] && isset($allData['dividends']['data']['items'])) {
            $response['data']['dividends'] = $allData['dividends']['data']['items'];
        }
        
        // Add analysis
        if (isset($allData['analysis']) && $allData['analysis']['success']) {
            $response['data']['analysis'] = $allData['analysis']['data'];
        }
        
        // Add technical analysis
        if (isset($allData['technical']) && $allData['technical']['success']) {
            $response['data']['technical'] = $allData['technical']['data'];
        }
        
        // Add events
        if (isset($allData['events']) && $allData['events']['success'] && isset($allData['events']['data']['items'])) {
            $response['data']['events'] = $allData['events']['data']['items'];
        }
        
        // Add chart data (simplified)
        if (isset($allData['charttool']) && $allData['charttool']['success'] && isset($allData['charttool']['data']['data'])) {
            $response['data']['chart'] = $allData['charttool']['data']['data'];
        } elseif (isset($allData['chart']) && $allData['chart']['success'] && isset($allData['chart']['data']['data'])) {
            $response['data']['chart'] = $allData['chart']['data']['data'];
        }
        
        // Add performance data
        if (isset($allData['performance']) && $allData['performance']['success']) {
            $response['data']['performance'] = $allData['performance']['data'];
        }
        
        // Add local header data
        if (isset($allData['localheader']) && $allData['localheader']['success']) {
            $response['data']['localheader'] = $allData['localheader']['data'];
        }
        
        // Add logo
        if (isset($allData['logo']) && $allData['logo']['success']) {
            $response['data']['logo'] = $allData['logo']['data'];
        }
        
        // Add leverage products
        if (isset($allData['leverage']) && $allData['leverage']['success']) {
            $response['data']['leverage'] = $allData['leverage']['data'];
        }
        
        // Add share alternatives
        if (isset($allData['alternatives']) && $allData['alternatives']['success']) {
            $response['data']['alternatives'] = $allData['alternatives']['data'];
        }
        
        // Add consumer protection
        if (isset($allData['consumerprotection']) && $allData['consumerprotection']['success']) {
            $response['data']['consumerprotection'] = $allData['consumerprotection']['data'];
        }
        
    } elseif (!empty($searchResults) && count($searchResults) > 1) {
        // Multiple search results
        $response['status'] = 'multiple_results';
        $response['message'] = 'Multiple results found. Please refine your search.';
        $response['search'] = [
            'query' => $symbol,
            'results' => $searchResults,
            'count' => count($searchResults)
        ];
    } elseif (!$fetchSuccess) {
        $response['status'] = 'error';
        $response['message'] = 'No data found for ISIN: ' . $isin . ( $symbol ? ' or symbol: ' . $symbol : '' );
        $response['suggestion'] = 'Try searching for "AAPL", "NVDA", "BMW", or "apple"';
    }
    
    outputJson($response, $fetchSuccess ? 200 : 404);
}

// ============================================
// PREPARE CHART DATA FOR HTML
// ============================================
$chartLabels = [];
$chartValues = [];
if (isset($allData['charttool']) && $allData['charttool']['success'] && 
    isset($allData['charttool']['data']['data']) && is_array($allData['charttool']['data']['data'])) {
    $points = $allData['charttool']['data']['data'];
    foreach ($points as $point) {
        $timestamp = $point['timestamp'] ?? $point['date'] ?? 0;
        if (is_numeric($timestamp) && $timestamp > 1000000) {
            $chartLabels[] = date('H:i', $timestamp / 1000);
        } elseif (is_string($timestamp)) {
            $chartLabels[] = date('H:i', strtotime($timestamp));
        } else {
            $chartLabels[] = count($chartLabels);
        }
        $chartValues[] = $point['price'] ?? $point['close'] ?? $point['value'] ?? 0;
    }
}

if (empty($chartLabels) && isset($allData['chart']) && $allData['chart']['success'] && 
    isset($allData['chart']['data']['data']) && is_array($allData['chart']['data']['data'])) {
    $points = $allData['chart']['data']['data'];
    foreach ($points as $point) {
        $timestamp = $point['timestamp'] ?? $point['date'] ?? 0;
        if (is_numeric($timestamp) && $timestamp > 1000000) {
            $chartLabels[] = date('H:i', $timestamp / 1000);
        } elseif (is_string($timestamp)) {
            $chartLabels[] = date('H:i', strtotime($timestamp));
        } else {
            $chartLabels[] = count($chartLabels);
        }
        $chartValues[] = $point['price'] ?? $point['close'] ?? $point['value'] ?? 0;
    }
}

if (count($chartLabels) > 150) {
    $chartLabels = array_slice($chartLabels, -150);
    $chartValues = array_slice($chartValues, -150);
}

$changeClass = 'text-secondary';
$changeIcon = '';
if ($priceData && $priceData['success']) {
    $change = floatval($priceData['change']);
    if ($change > 0) { $changeClass = 'positive'; $changeIcon = 'fa-arrow-up'; }
    elseif ($change < 0) { $changeClass = 'negative'; $changeIcon = 'fa-arrow-down'; }
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $priceData && $priceData['success'] ? htmlspecialchars($priceData['name']) . ' (' . htmlspecialchars($priceData['symbol']) . ') - ' : ''; ?>ING Stock Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { --ing-orange: #ff6b00; --ing-blue: #003399; }
        body { background: #f0f2f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        .navbar-brand { font-weight: 700; color: var(--ing-orange) !important; }
        .navbar-brand i { color: var(--ing-blue); }
        .stock-card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid rgba(0,0,0,0.04);
        }
        .price-main { font-size: 2.8rem; font-weight: 700; letter-spacing: -0.5px; }
        .price-change { font-size: 1.3rem; font-weight: 600; }
        .price-change.positive { color: #22a67e; }
        .price-change.negative { color: #dc3545; }
        .metric-label { color: #6c757d; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
        .metric-value { font-size: 1.1rem; font-weight: 600; margin-top: 2px; }
        .search-box {
            background: white;
            border-radius: 50px;
            padding: 8px 20px;
            border: 2px solid #e9ecef;
            transition: all 0.3s;
        }
        .search-box:focus-within { border-color: var(--ing-orange); box-shadow: 0 0 0 3px rgba(255,107,0,0.15); }
        .search-box input { border: none; outline: none; padding: 8px 0; width: 200px; background: transparent; }
        .search-box button { border: none; background: transparent; color: var(--ing-orange); }
        .json-badge {
            background: #28a745;
            color: white;
            font-size: 0.7rem;
            padding: 2px 10px;
            border-radius: 20px;
            margin-left: 8px;
        }
        .news-item { padding: 10px 0; border-bottom: 1px solid #f0f2f5; }
        .news-item:last-child { border-bottom: none; }
        .news-item .date { font-size: 0.7rem; color: #999; }
        .search-result-item { padding: 10px 15px; border-bottom: 1px solid #f0f2f5; cursor: pointer; transition: background 0.2s; }
        .search-result-item:hover { background: #f8f9fa; }
        .search-result-item:last-child { border-bottom: none; }
        .chart-container { position: relative; height: 350px; }
        .suggestion-tag {
            display: inline-block;
            padding: 5px 15px;
            margin: 4px;
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 0.85rem;
        }
        .suggestion-tag:hover {
            background: var(--ing-orange);
            color: white;
            border-color: var(--ing-orange);
            transform: translateY(-2px);
        }
        .suggestion-tag .ticker { 
            color: #6c757d; 
            font-weight: 600;
            font-size: 0.7rem;
        }
        .suggestion-tag:hover .ticker { color: rgba(255,255,255,0.8); }
        .refresh-btn { background: none; border: none; color: var(--ing-orange); transition: transform 0.3s; }
        .refresh-btn:hover { transform: rotate(180deg); }
        .api-link { 
            color: var(--ing-orange); 
            text-decoration: none;
            font-size: 0.85rem;
        }
        .api-link:hover { text-decoration: underline; }
        .search-hint {
            font-size: 0.75rem;
            color: #6c757d;
            padding: 2px 10px;
        }
        @media (max-width: 768px) { 
            .price-main { font-size: 2rem; } 
            .search-box input { width: 120px; }
        }
    </style>
</head>
<body>

<!-- NAVIGATION -->
<nav class="navbar navbar-expand-lg bg-white shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand" href="?">
            <i class="fas fa-chart-line me-2"></i>ING Stock Dashboard
            <span class="json-badge">JSON API</span>
        </a>
        <div class="d-flex align-items-center gap-2">
            <form method="GET" class="d-flex align-items-center flex-wrap gap-2" id="searchForm">
                <div class="search-box d-flex align-items-center">
                    <i class="fas fa-search text-muted me-2"></i>
                    <input type="text" name="symbol" placeholder="Ticker, name, ISIN..." 
                           value="<?php echo htmlspecialchars($symbol); ?>"
                           id="searchInput">
                    <button type="submit"><i class="fas fa-arrow-right"></i></button>
                </div>
                <div class="search-box d-flex align-items-center">
                    <i class="fas fa-barcode text-muted me-2"></i>
                    <input type="text" name="isin" placeholder="ISIN..." 
                           value="<?php echo htmlspecialchars($isin); ?>" style="width:150px;">
                    <button type="submit"><i class="fas fa-arrow-right"></i></button>
                </div>
                <button type="button" class="refresh-btn" onclick="location.reload();" title="Refresh">
                    <i class="fas fa-sync-alt fa-lg"></i>
                </button>
            </form>
        </div>
    </div>
</nav>

<div class="container">

<!-- Search Tips -->
<div class="alert alert-info alert-dismissible fade show">
    <i class="fas fa-lightbulb me-2"></i>
    <strong>Search by:</strong>
    <span class="badge bg-secondary ms-1">Ticker</span> AAPL, NVDA, TSLA, MSFT
    <span class="badge bg-secondary ms-2">Name</span> Apple, Tesla, BMW
    <span class="badge bg-secondary ms-2">ISIN</span> US0378331005, DE0005557508
    <span class="mx-2">•</span>
    <a href="?symbol=AAPL&json" class="api-link" target="_blank"><i class="fas fa-code"></i> JSON</a>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>

<!-- MESSAGES -->
<?php if ($message): ?>
    <div class="alert <?php echo strpos($message, '✅') !== false ? 'alert-success' : 'alert-info'; ?> alert-dismissible fade show">
        <i class="fas <?php echo strpos($message, '✅') !== false ? 'fa-check-circle' : 'fa-info-circle'; ?> me-2"></i>
        <?php echo $message; ?>
        <?php if (!empty($searchResults) && count($searchResults) > 1): ?>
            <span class="ms-2">
                <a href="?symbol=<?php echo urlencode($symbol); ?>&json" class="api-link" target="_blank">
                    <i class="fas fa-code me-1"></i>JSON
                </a>
            </span>
        <?php endif; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- SUGGESTIONS -->
<?php if (!empty($searchResults) && count($searchResults) > 1): ?>
    <div class="stock-card">
        <h6 class="mb-3"><i class="fas fa-list me-2"></i>Search Results (<?php echo count($searchResults); ?>)</h6>
        <?php foreach ($searchResults as $result): ?>
            <div class="search-result-item" onclick="window.location='?symbol=<?php echo urlencode($result['symbol'] ?? $result['isin']); ?>'">
                <strong><?php echo htmlspecialchars($result['name'] ?? 'N/A'); ?></strong>
                <?php if (isset($result['symbol']) && $result['symbol'] !== 'N/A'): ?>
                    <span class="badge bg-warning text-dark ms-2"><i class="fas fa-tag me-1"></i><?php echo htmlspecialchars($result['symbol']); ?></span>
                <?php endif; ?>
                <span class="badge bg-secondary ms-2"><?php echo htmlspecialchars($result['isin']); ?></span>
                <?php if (isset($result['price']) && $result['price'] !== 'N/A'): ?>
                    <span class="badge bg-light text-dark ms-2">€<?php echo number_format(floatval($result['price']), 2); ?></span>
                <?php endif; ?>
                <a href="?symbol=<?php echo urlencode($result['symbol'] ?? $result['isin']); ?>&json" class="api-link ms-2" target="_blank">
                    <i class="fas fa-code"></i>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <div class="stock-card">
        <h6 class="mb-3"><i class="fas fa-lightbulb me-2"></i>Popular Stocks</h6>
        <div class="d-flex flex-wrap">
            <?php foreach ($popularStocks as $stock): ?>
                <span class="suggestion-tag" onclick="window.location='?symbol=<?php echo urlencode($stock['symbol']); ?>'">
                    <?php echo htmlspecialchars($stock['name']); ?>
                    <span class="ticker">[<?php echo htmlspecialchars($stock['symbol']); ?>]</span>
                </span>
            <?php endforeach; ?>
        </div>
        <div class="search-hint mt-2">
            <i class="fas fa-info-circle me-1"></i>
            Try typing: <strong>AAPL</strong> (Apple), <strong>NVDA</strong> (NVIDIA), <strong>TSLA</strong> (Tesla), <strong>MSFT</strong> (Microsoft)
        </div>
    </div>
<?php endif; ?>

<!-- MAIN STOCK DATA -->
<?php if ($priceData && $priceData['success']): ?>
    <div class="row">
        <div class="col-lg-8">
            <!-- Price Card -->
            <div class="stock-card">
                <div class="d-flex justify-content-between align-items-start flex-wrap">
                    <div>
                        <h2 class="mb-0">
                            <?php echo htmlspecialchars($priceData['name']); ?>
                            <?php if ($priceData['symbol'] !== 'N/A'): ?>
                                <span class="badge bg-warning text-dark fs-6 ms-2">
                                    <i class="fas fa-tag me-1"></i><?php echo htmlspecialchars($priceData['symbol']); ?>
                                </span>
                            <?php endif; ?>
                        </h2>
                        <span class="text-muted">
                            <i class="fas fa-hashtag me-1"></i><?php echo htmlspecialchars($priceData['isin']); ?>
                            <a href="?symbol=<?php echo urlencode($priceData['symbol']); ?>&json" class="api-link ms-2" target="_blank">
                                <i class="fas fa-code"></i> JSON
                            </a>
                        </span>
                    </div>
                    <div class="text-end">
                        <div class="price-main"><?php echo number_format(floatval($priceData['price']), 2); ?>
                            <small class="text-muted fs-6"><?php echo htmlspecialchars($priceData['currency']); ?></small>
                        </div>
                        <div class="price-change <?php echo $changeClass; ?>">
                            <i class="fas <?php echo $changeIcon; ?> me-1"></i>
                            <?php echo number_format(floatval($priceData['change']), 2); ?> 
                            (<?php echo number_format(floatval($priceData['change_percent']), 2); ?>%)
                        </div>
                        <div class="text-muted small">Updated: <?php echo date('H:i:s', strtotime($priceData['timestamp'])); ?></div>
                    </div>
                </div>
                
                <div class="row mt-4 g-3">
                    <div class="col-4 col-md-2">
                        <div class="metric-label">Bid</div>
                        <div class="metric-value"><?php echo number_format(floatval($priceData['bid']), 2); ?></div>
                    </div>
                    <div class="col-4 col-md-2">
                        <div class="metric-label">Ask</div>
                        <div class="metric-value"><?php echo number_format(floatval($priceData['ask']), 2); ?></div>
                    </div>
                    <div class="col-4 col-md-2">
                        <div class="metric-label">High</div>
                        <div class="metric-value"><?php echo number_format(floatval($priceData['high']), 2); ?></div>
                    </div>
                    <div class="col-4 col-md-2">
                        <div class="metric-label">Low</div>
                        <div class="metric-value"><?php echo number_format(floatval($priceData['low']), 2); ?></div>
                    </div>
                    <div class="col-4 col-md-2">
                        <div class="metric-label">Volume</div>
                        <div class="metric-value"><?php echo number_format(floatval($priceData['volume'])); ?></div>
                    </div>
                    <div class="col-4 col-md-2">
                        <div class="metric-label">Spread</div>
                        <div class="metric-value">
                            <?php 
                            $spread = floatval($priceData['ask']) - floatval($priceData['bid']);
                            echo number_format($spread, 2);
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Chart -->
            <div class="stock-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0"><i class="fas fa-chart-area me-2"></i>Price Chart - <?php echo htmlspecialchars($priceData['symbol']); ?></h5>
                    <div class="btn-group btn-group-sm" role="group">
                        <a href="?symbol=<?php echo urlencode($priceData['symbol']); ?>&range=1D" class="btn btn-outline-secondary <?php echo $range == '1D' ? 'active' : ''; ?>">1D</a>
                        <a href="?symbol=<?php echo urlencode($priceData['symbol']); ?>&range=1W" class="btn btn-outline-secondary <?php echo $range == '1W' ? 'active' : ''; ?>">1W</a>
                        <a href="?symbol=<?php echo urlencode($priceData['symbol']); ?>&range=1M" class="btn btn-outline-secondary <?php echo $range == '1M' ? 'active' : ''; ?>">1M</a>
                        <a href="?symbol=<?php echo urlencode($priceData['symbol']); ?>&range=3M" class="btn btn-outline-secondary <?php echo $range == '3M' ? 'active' : ''; ?>">3M</a>
                        <a href="?symbol=<?php echo urlencode($priceData['symbol']); ?>&range=1Y" class="btn btn-outline-secondary <?php echo $range == '1Y' ? 'active' : ''; ?>">1Y</a>
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="priceChart"></canvas>
                </div>
                <?php if (empty($chartLabels)): ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-chart-line fa-2x mb-2 d-block"></i>
                        No chart data available.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Right Column -->
        <div class="col-lg-4">
            <!-- Key Figures -->
            <?php if (isset($allData['keyfigures']) && $allData['keyfigures']['success']): ?>
            <div class="stock-card">
                <h6 class="mb-3"><i class="fas fa-chart-pie me-2"></i>Key Figures</h6>
                <div class="row g-2">
                    <?php 
                    $displayKeys = [
                        'priceEarningsRatio' => 'P/E Ratio',
                        'marketCapitalization' => 'Market Cap',
                        'dividendYield' => 'Dividend Yield',
                        'earningsPerShare' => 'EPS',
                        'priceToBookRatio' => 'P/B Ratio'
                    ];
                    foreach ($displayKeys as $key => $label):
                        if (isset($allData['keyfigures']['data'][$key])):
                    ?>
                        <div class="col-6">
                            <div class="metric-label"><?php echo $label; ?></div>
                            <div class="metric-value small">
                                <?php 
                                $value = $allData['keyfigures']['data'][$key];
                                if (strpos($key, 'Capitalization') !== false) {
                                    echo '€' . number_format($value / 1000000000, 2) . 'B';
                                } elseif (strpos($key, 'Yield') !== false) {
                                    echo number_format($value, 2) . '%';
                                } else {
                                    echo number_format($value, 2);
                                }
                                ?>
                            </div>
                        </div>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Description -->
            <?php if (isset($allData['description']) && $allData['description']['success'] && isset($allData['description']['data']['description'])): ?>
            <div class="stock-card">
                <h6 class="mb-2"><i class="fas fa-file-alt me-2"></i>Description</h6>
                <p class="text-muted small mb-0" style="max-height: 150px; overflow-y: auto;">
                    <?php echo nl2br(htmlspecialchars(substr($allData['description']['data']['description'], 0, 400))); ?>
                    <?php if (strlen($allData['description']['data']['description']) > 400): ?>...<?php endif; ?>
                </p>
            </div>
            <?php endif; ?>

            <!-- Dividends -->
            <?php if (isset($allData['dividends']) && $allData['dividends']['success'] && isset($allData['dividends']['data']['items']) && count($allData['dividends']['data']['items']) > 0): ?>
            <div class="stock-card">
                <h6 class="mb-3"><i class="fas fa-coins me-2"></i>Dividend History</h6>
                <div style="max-height: 200px; overflow-y: auto;">
                    <?php foreach (array_slice($allData['dividends']['data']['items'], 0, 4) as $item): ?>
                        <div class="news-item">
                            <div class="fw-semibold small">€<?php echo number_format($item['amount'] ?? 0, 2); ?></div>
                            <div class="date">
                                <i class="far fa-calendar me-1"></i>
                                <?php echo isset($item['date']) ? date('d.m.Y', strtotime($item['date'])) : 'N/A'; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- News -->
            <?php if (isset($allData['news']) && $allData['news']['success'] && isset($allData['news']['data']['items']) && count($allData['news']['data']['items']) > 0): ?>
            <div class="stock-card">
                <h6 class="mb-3"><i class="fas fa-newspaper me-2"></i>Latest News</h6>
                <div style="max-height: 300px; overflow-y: auto;">
                <?php foreach ($allData['news']['data']['items'] as $item): ?>
                    <div class="news-item">
                        <div class="fw-semibold small"><?php echo htmlspecialchars($item['headline'] ?? 'N/A'); ?></div>
                        <div class="date">
                            <i class="far fa-clock me-1"></i>
                            <?php echo isset($item['timestamp']) ? date('d.m.Y H:i', strtotime($item['timestamp'])) : 'N/A'; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

<?php elseif (empty($searchResults)): ?>
    <div class="alert alert-warning">
        <i class="fas fa-exclamation-triangle me-2"></i>
        No data found. Try:
        <ul class="mt-2 mb-0">
            <li><strong>Ticker:</strong> AAPL, NVDA, TSLA, MSFT, BMW, ALV</li>
            <li><strong>Name:</strong> Apple, Tesla, BMW, Allianz</li>
            <li><strong>ISIN:</strong> US0378331005, DE0005557508</li>
        </ul>
    </div>
<?php endif; ?>

<!-- FOOTER -->
<footer class="text-center text-muted small py-4 border-top mt-4">
    <i class="fas fa-database me-1"></i> Data from ING Component API 
    <span class="mx-2">•</span> 
    <i class="far fa-clock me-1"></i> <?php echo date('d.m.Y H:i:s'); ?>
    <span class="mx-2">•</span>
    <a href="#" onclick="location.reload();" class="text-decoration-none">
        <i class="fas fa-sync-alt me-1"></i>Refresh
    </a>
    <span class="mx-2">•</span>
    <a href="?<?php echo $_SERVER['QUERY_STRING']; ?>&json" class="text-decoration-none" target="_blank">
        <i class="fas fa-code me-1"></i>JSON
    </a>
</footer>

</div>

<!-- SCRIPTS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
<?php if (!empty($chartLabels) && !empty($chartValues) && $priceData && $priceData['success']): ?>
const ctx = document.getElementById('priceChart')?.getContext('2d');
if (ctx) {
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($chartLabels); ?>,
            datasets: [{
                label: 'Price (<?php echo htmlspecialchars($priceData['currency'] ?? 'EUR'); ?>)',
                data: <?php echo json_encode($chartValues); ?>,
                borderColor: '#ff6b00',
                backgroundColor: 'rgba(255, 107, 0, 0.08)',
                borderWidth: 2.5,
                pointRadius: 0,
                pointHoverRadius: 7,
                fill: true,
                tension: 0.2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { display: false }, ticks: { maxTicksLimit: 20, font: { size: 9 } } },
                y: { grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { callback: v => '€' + v.toFixed(2), font: { size: 10 } } }
            },
            interaction: { intersect: false, mode: 'index' }
        }
    });
}
<?php endif; ?>
console.log('📊 ING Stock Dashboard v2.3 loaded');
console.log('📡 Search by: Ticker (AAPL), Name (Apple), ISIN (US0378331005)');
console.log('📡 JSON API: Add ?json to any query');
</script>

</body>
</html>
