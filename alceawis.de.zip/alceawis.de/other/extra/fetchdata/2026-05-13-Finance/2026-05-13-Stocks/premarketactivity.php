<?php
function getPremarketActivity($region = 'america') {
    $url = "https://scanner.tradingview.com/{$region}/scan";
    
    $payload = json_encode([
        "columns" => [
            "name", 
            "close", 
            "volume", 
            "premarket_volume",
            "premarket_change",
            "premarket_change_abs",
            "market_cap_basic",
            "exchange"
        ],
        "filter" => [
            ["left" => "exchange", "operation" => "in_range", "right" => ["AMEX", "NASDAQ", "NYSE", "LSE", "TSE", "EURONEXT", "ASX", "BSE", "NSE", "HKEX"]]
        ],
        "options" => ["lang" => "en"],
        "range" => [0, 250],
        "sort" => ["sortBy" => "premarket_volume", "sortOrder" => "desc"]
    ]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ["error" => "CURL Error for {$region}: " . $error];
    }

    $data = json_decode($response, true);
    
    if (isset($data['data']) && is_array($data['data'])) {
        $stocks = [];
        $hasData = false;
        foreach ($data['data'] as $item) {
            $d = $item['d'];
            $premarket_volume = isset($d[3]) ? (int)$d[3] : 0;
            
            // ONLY include stocks that actually have premarket volume > 0
            if ($premarket_volume > 0) {
                $hasData = true;
                $stocks[] = [
                    'ticker' => $d[0] ?? 'N/A',
                    'price' => $d[1] ?? 0,
                    'volume' => $d[2] ?? 0,
                    'premarket_volume' => $premarket_volume,
                    'premarket_change' => $d[4] ?? 0,
                    'premarket_change_abs' => $d[5] ?? 0,
                    'market_cap' => $d[6] ?? 0,
                    'exchange' => $d[7] ?? 'Unknown',
                    'region' => strtoupper($region)
                ];
            }
        }
        
        if (!$hasData) {
            return ["error" => "No premarket data for {$region}"];
        }
        
        return $stocks;
    }
    
    return ["error" => "No data received from {$region}"];
}

// All regions
$regions = [
    'america', 'canada', 'germany', 'france', 'italy', 'spain', 
    'netherlands', 'uk', 'japan', 'hongkong', 'india', 'australia', 
    'brazil', 'mexico', 'sweden', 'norway', 'denmark', 'finland', 
    'switzerland', 'singapore', 'malaysia', 'indonesia', 'philippines', 
    'thailand', 'vietnam', 'taiwan', 'turkey', 'israel', 'egypt',
    'southkorea', 'southafrica'
];

// Fetch from all regions
$allStocks = [];
$errors = [];
$regionStats = [];

foreach ($regions as $region) {
    $result = getPremarketActivity($region);
    
    if (isset($result['error'])) {
        $errors[] = $result['error'];
        continue;
    }
    
    if (is_array($result) && !empty($result)) {
        $regionStats[strtoupper($region)] = count($result);
        $allStocks = array_merge($allStocks, $result);
    }
}

// Remove duplicates based on ticker symbol
$uniqueStocks = [];
$seenTickers = [];

foreach ($allStocks as $stock) {
    $tickerKey = strtoupper($stock['ticker']);
    
    if (!isset($seenTickers[$tickerKey])) {
        $seenTickers[$tickerKey] = $stock;
    } else {
        // Keep the one with higher premarket volume
        if ($stock['premarket_volume'] > $seenTickers[$tickerKey]['premarket_volume']) {
            $seenTickers[$tickerKey] = $stock;
        }
    }
}

$stocks = array_values($seenTickers);

// Handle sorting
$sortColumn = isset($_GET['sort']) ? $_GET['sort'] : 'premarket_volume';
$sortOrder = isset($_GET['order']) && $_GET['order'] === 'asc' ? 'asc' : 'desc';

$sortMap = [
    'ticker' => 'ticker',
    'price' => 'price',
    'premarket_volume' => 'premarket_volume',
    'premarket_change' => 'premarket_change',
    'premarket_change_abs' => 'premarket_change_abs',
    'exchange' => 'exchange',
    'region' => 'region'
];

$sortKey = isset($sortMap[$sortColumn]) ? $sortMap[$sortColumn] : 'premarket_volume';

usort($stocks, function($a, $b) use ($sortKey, $sortOrder) {
    if ($a[$sortKey] == $b[$sortKey]) {
        return 0;
    }
    if (is_numeric($a[$sortKey]) && is_numeric($b[$sortKey])) {
        $result = $a[$sortKey] < $b[$sortKey] ? -1 : 1;
    } else {
        $result = strcasecmp($a[$sortKey], $b[$sortKey]);
    }
    return $sortOrder === 'asc' ? $result : -$result;
});

function getNextOrder($column) {
    $currentSort = isset($_GET['sort']) ? $_GET['sort'] : '';
    $currentOrder = isset($_GET['order']) ? $_GET['order'] : 'desc';
    if ($currentSort === $column) {
        return $currentOrder === 'desc' ? 'asc' : 'desc';
    }
    return 'desc';
}

function getSortIcon($column) {
    $currentSort = isset($_GET['sort']) ? $_GET['sort'] : '';
    $currentOrder = isset($_GET['order']) ? $_GET['order'] : 'desc';
    if ($currentSort === $column) {
        return $currentOrder === 'desc' ? ' ▼' : ' ▲';
    }
    return '';
}

function formatChange($value) {
    $symbol = $value >= 0 ? '+' : '';
    return $symbol . number_format($value, 2) . '%';
}

// Calculate stats
$totalStocks = count($stocks);
$gainers = count(array_filter($stocks, function($s) { return $s['premarket_change'] > 0; }));
$losers = count(array_filter($stocks, function($s) { return $s['premarket_change'] < 0; }));
$regionsCount = count(array_unique(array_column($stocks, 'region')));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Global Premarket Activity Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #e0e0e0;
            padding: 30px;
            min-height: 100vh;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: #1a1a1a;
            border-radius: 15px;
            padding: 30px;
            border: 1px solid #ffd700;
            box-shadow: 0 0 40px rgba(255, 215, 0, 0.1);
        }
        h1 {
            text-align: center;
            font-size: 42px;
            font-weight: 700;
            color: #ffd700;
            text-shadow: 0 0 30px rgba(255, 215, 0, 0.3);
            margin-bottom: 5px;
            letter-spacing: 2px;
        }
        .subtitle {
            text-align: center;
            color: #b8960f;
            font-size: 14px;
            margin-bottom: 30px;
            letter-spacing: 1px;
        }
        .stats-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #2a2a2a;
            padding: 15px 25px;
            border-radius: 10px;
            margin-bottom: 25px;
            border: 1px solid #ffd70033;
            flex-wrap: wrap;
            gap: 10px;
        }
        .stat-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .stat-label {
            color: #999;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .stat-value {
            color: #ffd700;
            font-weight: 600;
            font-size: 16px;
        }
        .stat-value.green { color: #00ff88; }
        .stat-value.red { color: #ff4444; }
        .table-wrapper {
            overflow-x: auto;
            border-radius: 10px;
            border: 1px solid #ffd70033;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        thead {
            background: linear-gradient(135deg, #2a1f00, #1a1000);
        }
        th {
            padding: 16px 20px;
            text-align: left;
            color: #ffd700;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 12px;
            border-bottom: 2px solid #ffd700;
            white-space: nowrap;
            cursor: pointer;
            user-select: none;
            transition: all 0.3s ease;
        }
        th:hover {
            background: #3a2a0a;
            color: #fff;
        }
        th a {
            color: #ffd700;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        th a:hover {
            color: #fff;
        }
        td {
            padding: 14px 20px;
            border-bottom: 1px solid #333;
            transition: all 0.3s ease;
        }
        tr:hover td {
            background: #2a2a2a;
        }
        tr:last-child td {
            border-bottom: none;
        }
        .ticker-cell a {
            color: #ffd700;
            text-decoration: none;
            font-weight: 700;
            font-size: 15px;
            transition: all 0.3s;
            display: inline-block;
        }
        .ticker-cell a:hover {
            color: #fff;
            text-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
            transform: scale(1.05);
        }
        .volume-cell {
            font-weight: 600;
            color: #ffd700;
            font-family: 'Courier New', monospace;
        }
        .change-positive {
            color: #00ff88;
            font-weight: 600;
        }
        .change-negative {
            color: #ff4444;
            font-weight: 600;
        }
        .rank-badge {
            display: inline-block;
            background: #ffd700;
            color: #0a0a0a;
            font-weight: 700;
            font-size: 11px;
            padding: 2px 10px;
            border-radius: 20px;
            min-width: 30px;
            text-align: center;
        }
        .region-tag {
            display: inline-block;
            background: #3a2a0a;
            color: #ffd700;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            border: 1px solid #ffd70044;
        }
        .error-box {
            background: #2a0a0a;
            border: 1px solid #ff4444;
            color: #ff6666;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            margin: 20px 0;
        }
        .sort-indicator {
            display: inline-block;
            margin-left: 5px;
            font-size: 11px;
        }
        .refresh-btn {
            background: #ffd700;
            color: #0a0a0a;
            padding: 10px 25px;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .refresh-btn:hover {
            background: #fff;
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(255, 215, 0, 0.3);
        }
        .region-breakdown {
            display: flex;
            flex-wrap: wrap;
            gap: 5px 15px;
            margin: -15px 0 20px 0;
            padding: 10px 20px;
            background: #222;
            border-radius: 8px;
            border: 1px solid #ffd70022;
        }
        .region-breakdown span {
            font-size: 12px;
            color: #aaa;
        }
        .region-breakdown .count {
            color: #ffd700;
            font-weight: 600;
        }
        @media (max-width: 768px) {
            body { padding: 15px; }
            .container { padding: 15px; }
            h1 { font-size: 28px; }
            th, td { padding: 10px 12px; font-size: 12px; }
            .stats-bar { flex-direction: column; align-items: flex-start; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px; margin-bottom:10px;">
            <h1>🌍 GLOBAL PREMARKET ACTIVITY</h1>
            <a href="?" class="refresh-btn">🔄 Refresh Data</a>
        </div>
        <div class="subtitle">UNIFIED VIEW • ACTIVE REGIONS ONLY • NO DUPLICATES</div>

        <?php if (!empty($errors)): ?>
            <div class="error-box">
                ⚠️ <?php echo count($errors); ?> regions with no premarket data (off-market hours)
            </div>
        <?php endif; ?>

        <?php if (empty($stocks)): ?>
            <div class="error-box">❌ No active premarket data found in any region</div>
        <?php else: ?>
            <div class="stats-bar">
                <div class="stat-item">
                    <span class="stat-label">📊 Total Stocks</span>
                    <span class="stat-value"><?php echo number_format($totalStocks); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">🌍 Active Regions</span>
                    <span class="stat-value"><?php echo $regionsCount; ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">🟢 Gainers</span>
                    <span class="stat-value green"><?php echo number_format($gainers); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">🔴 Losers</span>
                    <span class="stat-value red"><?php echo number_format($losers); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">📈 Top Gain</span>
                    <span class="stat-value green"><?php 
                        if (!empty($stocks)) {
                            $max = max(array_column($stocks, 'premarket_change'));
                            echo number_format($max, 2) . '%';
                        } else {
                            echo 'N/A';
                        }
                    ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">📉 Top Loss</span>
                    <span class="stat-value red"><?php 
                        if (!empty($stocks)) {
                            $min = min(array_column($stocks, 'premarket_change'));
                            echo number_format($min, 2) . '%';
                        } else {
                            echo 'N/A';
                        }
                    ?></span>
                </div>
            </div>
            
            <?php if (!empty($regionStats)): ?>
            <div class="region-breakdown">
                <?php foreach ($regionStats as $region => $count): ?>
                    <span>📍 <?php echo $region; ?>: <span class="count"><?php echo $count; ?></span></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th style="cursor:default;">#</th>
                            <th>
                                <a href="?sort=ticker&order=<?php echo getNextOrder('ticker'); ?>">
                                    Ticker<span class="sort-indicator"><?php echo getSortIcon('ticker'); ?></span>
                                </a>
                            </th>
                            <th>
                                <a href="?sort=exchange&order=<?php echo getNextOrder('exchange'); ?>">
                                    Exchange<span class="sort-indicator"><?php echo getSortIcon('exchange'); ?></span>
                                </a>
                            </th>
                            <th>
                                <a href="?sort=region&order=<?php echo getNextOrder('region'); ?>">
                                    Region<span class="sort-indicator"><?php echo getSortIcon('region'); ?></span>
                                </a>
                            </th>
                            <th>
                                <a href="?sort=price&order=<?php echo getNextOrder('price'); ?>">
                                    Price<span class="sort-indicator"><?php echo getSortIcon('price'); ?></span>
                                </a>
                            </th>
                            <th>
                                <a href="?sort=premarket_volume&order=<?php echo getNextOrder('premarket_volume'); ?>">
                                    Premarket Volume<span class="sort-indicator"><?php echo getSortIcon('premarket_volume'); ?></span>
                                </a>
                            </th>
                            <th>
                                <a href="?sort=premarket_change&order=<?php echo getNextOrder('premarket_change'); ?>">
                                    Change %<span class="sort-indicator"><?php echo getSortIcon('premarket_change'); ?></span>
                                </a>
                            </th>
                            <th>
                                <a href="?sort=premarket_change_abs&order=<?php echo getNextOrder('premarket_change_abs'); ?>">
                                    Change (Abs)<span class="sort-indicator"><?php echo getSortIcon('premarket_change_abs'); ?></span>
                                </a>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $rank = 1;
                        $base_url = "https://alceawis.de/other/extra/fetchdata/2026-05-13-Finance/2026-05-13-Stocks/process.php?symbol=";
                        foreach ($stocks as $stock): 
                            $change = $stock['premarket_change'];
                            $changeClass = $change >= 0 ? 'change-positive' : 'change-negative';
                            $regionName = strtoupper($stock['region']);
                        ?>
                        <tr>
                            <td><span class="rank-badge"><?php echo $rank++; ?></span></td>
                            <td class="ticker-cell">
                                <a href="<?php echo $base_url . urlencode($stock['ticker']); ?>" target="_blank">
                                    <?php echo htmlspecialchars($stock['ticker']); ?>
                                </a>
                            </td>
                            <td><?php echo htmlspecialchars($stock['exchange']); ?></td>
                            <td><span class="region-tag"><?php echo $regionName; ?></span></td>
                            <td>$<?php echo number_format($stock['price'], 2); ?></td>
                            <td class="volume-cell"><?php echo number_format($stock['premarket_volume']); ?></td>
                            <td class="<?php echo $changeClass; ?>">
                                <?php echo formatChange($change); ?>
                            </td>
                            <td><?php echo number_format($stock['premarket_change_abs'], 2); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>