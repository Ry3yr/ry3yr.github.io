<!--?symbol=xyzs--->
<?php
/**
 * Robinhood Stock Data Fetcher
 * Usage: ?symbol=ILLR
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type to JSON
header('Content-Type: application/json; charset=utf-8');

// Get symbol from URL parameter
$symbol = isset($_GET['symbol']) ? strtoupper(trim($_GET['symbol'])) : '';

if (empty($symbol)) {
    echo json_encode([
        'error' => 'Missing symbol parameter. Usage: ?symbol=ILLR',
        'status' => 400
    ], JSON_PRETTY_PRINT);
    exit;
}

// Build URL
$url = "https://robinhood.com/us/en/stocks/{$symbol}/";

// Initialize cURL
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HEADER => false,
]);

$html = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    echo json_encode([
        'error' => 'cURL Error: ' . $curlError,
        'status' => 500
    ], JSON_PRETTY_PRINT);
    exit;
}

if ($httpCode !== 200) {
    echo json_encode([
        'error' => "HTTP Error: {$httpCode}",
        'status' => $httpCode
    ], JSON_PRETTY_PRINT);
    exit;
}

// Extract data from __NEXT_DATA__ script
$data = extractNextData($html);

if (!$data) {
    echo json_encode([
        'error' => 'Could not extract data from page. Symbol may not exist.',
        'status' => 404
    ], JSON_PRETTY_PRINT);
    exit;
}

// Format and display the data
$result = formatStockData($data, $symbol);

echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

/**
 * Extract the __NEXT_DATA__ JSON from HTML
 */
function extractNextData($html) {
    // Look for the __NEXT_DATA__ script tag
    if (preg_match('/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/s', $html, $matches)) {
        return json_decode($matches[1], true);
    }
    return null;
}

/**
 * Format the extracted data into a clean structure
 */
function formatStockData($data, $symbol) {
    $result = [
        'symbol' => $symbol,
        'timestamp' => date('Y-m-d H:i:s'),
        'source_url' => "https://robinhood.com/us/en/stocks/{$symbol}/",
        'status' => 200
    ];

    // Extract page props
    $props = $data['props']['pageProps'] ?? [];

    // Get instrument data
    if (isset($props['instrument'])) {
        $instrument = $props['instrument'];
        $result['instrument'] = [
            'id' => $instrument['id'] ?? null,
            'symbol' => $instrument['symbol'] ?? $symbol,
            'name' => $instrument['name'] ?? null,
            'simple_name' => $instrument['simple_name'] ?? null,
            'type' => $instrument['type'] ?? null,
            'state' => $instrument['state'] ?? null,
            'tradeable' => $instrument['tradeable'] ?? null,
            'list_date' => $instrument['list_date'] ?? null,
            'country' => $instrument['country'] ?? null,
            'affiliate' => $instrument['affiliate'] ?? null,
        ];
    }

    // Get quote data
    if (isset($props['quote'])) {
        $quote = $props['quote'];
        $result['quote'] = [
            'current_price' => $quote['last_trade_price'] ?? null,
            'extended_hours_price' => $quote['last_extended_hours_trade_price'] ?? null,
            'previous_close' => $quote['previous_close'] ?? null,
            'ask_price' => $quote['ask_price'] ?? null,
            'bid_price' => $quote['bid_price'] ?? null,
            'day_high' => null,
            'day_low' => null,
            'volume' => null,
            'updated_at' => $quote['updated_at'] ?? null,
            'trading_halted' => $quote['trading_halted'] ?? null,
            'has_traded' => $quote['has_traded'] ?? null,
        ];
    }

    // Get fundamentals data
    $fundamentals = null;
    if (isset($props['dehydratedState']['queries'])) {
        foreach ($props['dehydratedState']['queries'] as $query) {
            if (isset($query['queryKey']) && is_array($query['queryKey']) && 
                in_array('fundamentals', $query['queryKey'])) {
                $fundamentals = $query['state']['data'] ?? null;
                break;
            }
        }
    }

    if ($fundamentals) {
        $result['fundamentals'] = [
            'market_cap' => isset($fundamentals['market_cap']) ? (float)$fundamentals['market_cap'] : null,
            'shares_outstanding' => isset($fundamentals['shares_outstanding']) ? (float)$fundamentals['shares_outstanding'] : null,
            'pe_ratio' => isset($fundamentals['pe_ratio']) ? (float)$fundamentals['pe_ratio'] : null,
            'pb_ratio' => isset($fundamentals['pb_ratio']) ? (float)$fundamentals['pb_ratio'] : null,
            'dividend_yield' => isset($fundamentals['dividend_yield']) ? (float)$fundamentals['dividend_yield'] : null,
            'high_52_weeks' => isset($fundamentals['high_52_weeks']) ? (float)$fundamentals['high_52_weeks'] : null,
            'high_52_weeks_date' => $fundamentals['high_52_weeks_date'] ?? null,
            'low_52_weeks' => isset($fundamentals['low_52_weeks']) ? (float)$fundamentals['low_52_weeks'] : null,
            'low_52_weeks_date' => $fundamentals['low_52_weeks_date'] ?? null,
            'average_volume' => isset($fundamentals['average_volume']) ? (float)$fundamentals['average_volume'] : null,
            'average_volume_2_weeks' => isset($fundamentals['average_volume_2_weeks']) ? (float)$fundamentals['average_volume_2_weeks'] : null,
            'average_volume_30_days' => isset($fundamentals['average_volume_30_days']) ? (float)$fundamentals['average_volume_30_days'] : null,
            'float' => isset($fundamentals['float']) ? (float)$fundamentals['float'] : null,
            'description' => $fundamentals['description'] ?? null,
            'ceo' => $fundamentals['ceo'] ?? null,
            'headquarters_city' => $fundamentals['headquarters_city'] ?? null,
            'headquarters_state' => $fundamentals['headquarters_state'] ?? null,
            'sector' => $fundamentals['sector'] ?? null,
            'industry' => $fundamentals['industry'] ?? null,
            'num_employees' => isset($fundamentals['num_employees']) ? (int)$fundamentals['num_employees'] : null,
            'year_founded' => isset($fundamentals['year_founded']) ? (int)$fundamentals['year_founded'] : null,
            'financial_status' => isset($fundamentals['financial_status_description']) ? $fundamentals['financial_status_description'] : null,
        ];
    }

    // Get news data
    $news = null;
    if (isset($props['dehydratedState']['queries'])) {
        foreach ($props['dehydratedState']['queries'] as $query) {
            if (isset($query['queryKey']) && is_array($query['queryKey']) && 
                in_array('articles', $query['queryKey'])) {
                $news = $query['state']['data'] ?? null;
                break;
            }
        }
    }

    if ($news && is_array($news)) {
        $result['news'] = array_map(function($item) {
            return [
                'title' => $item['title'] ?? null,
                'source' => $item['source'] ?? null,
                'date' => $item['date'] ?? null,
                'url' => $item['url'] ?? null,
                'image' => $item['image'] ?? null,
            ];
        }, array_slice($news, 0, 10));
    }

    // Get earnings data
    $earnings = null;
    if (isset($props['dehydratedState']['queries'])) {
        foreach ($props['dehydratedState']['queries'] as $query) {
            if (isset($query['queryKey']) && is_array($query['queryKey']) && 
                in_array('earnings', $query['queryKey'])) {
                $earnings = $query['state']['data'] ?? null;
                break;
            }
        }
    }

    if ($earnings && is_array($earnings)) {
        $result['earnings'] = array_map(function($item) {
            $data = [
                'year' => $item['year'] ?? null,
                'quarter' => $item['quarter'] ?? null,
                'eps_actual' => isset($item['eps']['actual']) ? (float)$item['eps']['actual'] : null,
                'eps_estimate' => isset($item['eps']['estimate']) ? (float)$item['eps']['estimate'] : null,
            ];
            
            if (isset($item['report']['date'])) {
                $data['report_date'] = $item['report']['date'];
                $data['report_timing'] = $item['report']['timing'] ?? null;
                $data['report_verified'] = $item['report']['verified'] ?? null;
            }
            
            return $data;
        }, $earnings);
    }

    // Get market hours
    $hours = null;
    if (isset($props['dehydratedState']['queries'])) {
        foreach ($props['dehydratedState']['queries'] as $query) {
            if (isset($query['queryKey']) && is_array($query['queryKey'])) {
                foreach ($query['queryKey'] as $key) {
                    if (is_string($key) && strpos($key, 'hours-') === 0) {
                        $hours = $query['state']['data'] ?? null;
                        break 2;
                    }
                }
            }
        }
    }

    if ($hours) {
        $result['market_hours'] = [
            'date' => $hours['date'] ?? null,
            'is_open' => $hours['is_open'] ?? null,
            'next_open' => $hours['next_open_hours'] ?? null,
            'previous_open' => $hours['previous_open_hours'] ?? null,
        ];
    }

    return $result;
}