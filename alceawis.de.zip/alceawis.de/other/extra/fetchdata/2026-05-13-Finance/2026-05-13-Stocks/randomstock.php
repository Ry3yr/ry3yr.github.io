<?php
ini_set('memory_limit', '512M');
set_time_limit(0);

function errorHandler($errno, $errstr, $errfile, $errline) {
    echo json_encode(['error' => "$errstr in $errfile on line $errline"]);
    exit;
}
set_error_handler("errorHandler");

$ajaxMode = $_GET['ajax'] ?? '';
$checkGrowth = isset($_GET['growth']);
$checkVolgain = isset($_GET['volgain']);
$checkSpike = isset($_GET['spike']);

$cacheFile     = __DIR__ . '/gettex_isins_cache.json';
$notAStockFile = __DIR__ . '/notastock.json';
$stocksFile    = __DIR__ . '/stocks.json';
$progressFile  = __DIR__ . '/progress.json';

if ($ajaxMode === 'start') {
    header('Content-Type: application/json');
    file_put_contents($progressFile, json_encode([
        'status' => 'starting',
        'checked' => 0,
        'validFound' => 0,
        'noGrowth' => 0,
        'invalid' => 0,
        'currentIsin' => '',
        'done' => false,
        'result' => null,
        'started' => time()
    ]));
    echo json_encode(['ok' => true]);
    exit;
}

if ($ajaxMode === 'poll') {
    header('Content-Type: application/json');
    if (!file_exists($progressFile)) {
        echo json_encode(['error' => 'Progress file not found']);
        exit;
    }
    readfile($progressFile);
    exit;
}

if ($ajaxMode === 'run') {
    ignore_user_abort(true);
    set_time_limit(0);
    header('Content-Type: text/plain');
    echo "0\n";
    ob_flush();
    flush();
    if ($checkSpike) {
        runSpikeSearch($progressFile);
    } elseif ($checkVolgain) {
        runVolgainSearch($progressFile);
    } else {
        runGrowthSearch($progressFile);
    }
    exit;
}

if (!$checkGrowth && !$checkSpike && !$checkVolgain) {
    runNormalMode();
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Finding Growth Stock...</title>
    <meta charset="utf-8">
    <style>
        * { box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; margin: 0; padding: 40px 20px; background: #0f172a; color: #e2e8f0; min-height: 100vh; display: flex; flex-direction: column; align-items: center; }
        h1 { font-size: 1.8rem; margin-bottom: 10px; color: #f8fafc; }
        .subtitle { color: #94a3b8; margin-bottom: 30px; font-size: 0.95rem; }
        .card { background: #1e293b; border-radius: 16px; padding: 30px; width: 100%; max-width: 600px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); }
        .progress-container { margin: 20px 0; }
        .progress-bar-bg { background: #334155; border-radius: 12px; height: 24px; overflow: hidden; position: relative; }
        .progress-bar-fill { background: linear-gradient(90deg, #22c55e, #16a34a); height: 100%; border-radius: 12px; width: 0%; transition: width 0.4s ease; position: relative; }
        .progress-bar-fill::after { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent); animation: shimmer 1.5s infinite; }
        @keyframes shimmer { 0% { transform: translateX(-100%); } 100% { transform: translateX(100%); } }
        .progress-text { text-align: center; margin-top: 8px; font-size: 0.9rem; color: #94a3b8; }
        .stats-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin: 20px 0; }
        .stat-box { background: #0f172a; border-radius: 10px; padding: 14px; text-align: center; border: 1px solid #334155; }
        .stat-value { font-size: 1.5rem; font-weight: 700; color: #f8fafc; }
        .stat-label { font-size: 0.75rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 4px; }
        .stat-value.green { color: #22c55e; }
        .stat-value.red { color: #ef4444; }
        .stat-value.yellow { color: #eab308; }
        .current-activity { background: #0f172a; border-radius: 10px; padding: 14px 18px; margin: 15px 0; font-family: 'SF Mono', monospace; font-size: 0.85rem; color: #94a3b8; border-left: 3px solid #3b82f6; min-height: 48px; }
        .current-activity .label { color: #64748b; }
        .current-activity .isin { color: #60a5fa; font-weight: 600; }
        .log { background: #0f172a; border-radius: 10px; padding: 14px; margin-top: 15px; max-height: 200px; overflow-y: auto; font-family: 'SF Mono', monospace; font-size: 0.8rem; color: #64748b; border: 1px solid #334155; }
        .log-entry { padding: 2px 0; border-bottom: 1px solid #1e293b; }
        .log-entry:last-child { border-bottom: none; }
        .log .ok { color: #22c55e; }
        .log .skip { color: #ef4444; }
        .log .nogrowth { color: #eab308; }
        .result-overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.95); z-index: 100; align-items: center; justify-content: center; flex-direction: column; }
        .result-overlay.active { display: flex; }
        .result-card { background: #1e293b; border-radius: 20px; padding: 40px; text-align: center; max-width: 500px; width: 90%; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); border: 2px solid #22c55e; }
        .result-card .badge { display: inline-block; background: #22c55e; color: #fff; padding: 8px 20px; border-radius: 20px; font-size: 0.85rem; font-weight: 600; margin-bottom: 20px; }
        .result-isin { font-size: 2rem; font-weight: 800; color: #f8fafc; letter-spacing: 0.05em; margin: 15px 0; }
        .result-ticker { color: #94a3b8; font-size: 1.1rem; margin-bottom: 25px; }
        .btn { display: inline-block; padding: 14px 32px; background: #3b82f6; color: #fff; text-decoration: none; border-radius: 10px; font-weight: 600; font-size: 1rem; border: none; cursor: pointer; transition: background 0.2s; }
        .btn:hover { background: #2563eb; }
        .btn-secondary { background: #475569; margin-left: 10px; }
        .btn-secondary:hover { background: #334155; }
        .error-box { background: #7f1d1d; border: 1px solid #ef4444; color: #fecaca; padding: 20px; border-radius: 10px; margin-top: 20px; display: none; }
        #workerFrame { position: absolute; width: 1px; height: 1px; left: -9999px; top: -9999px; border: none; opacity: 0; }
    </style>
</head>
<body>
    <h1>?? Finding a Growth Stock</h1>
    <div class="subtitle">Scanning Gettex ISINs for 50%+ total return with accelerating trend</div>
    <div class="card">
        <div class="progress-container">
            <div class="progress-bar-bg"><div class="progress-bar-fill" id="progressBar"></div></div>
            <div class="progress-text" id="progressText">Initializing...</div>
        </div>
        <div class="stats-grid">
            <div class="stat-box"><div class="stat-value" id="statChecked">0</div><div class="stat-label">Checked</div></div>
            <div class="stat-box"><div class="stat-value green" id="statValid">0</div><div class="stat-label">Valid Stocks</div></div>
            <div class="stat-box"><div class="stat-value yellow" id="statNoGrowth">0</div><div class="stat-label">No Growth</div></div>
            <div class="stat-box"><div class="stat-value red" id="statInvalid">0</div><div class="stat-label">Invalid / ETF</div></div>
        </div>
        <div class="current-activity" id="currentActivity">
            <span class="label">Status:</span> <span id="statusText">Starting search...</span><br>
            <span class="label">Current:</span> <span class="isin" id="currentIsin"></span>
        </div>
        <div class="log" id="log"></div>
        <div class="error-box" id="errorBox"></div>
    </div>
    <div class="result-overlay" id="resultOverlay">
        <div class="result-card">
            <div class="badge">? Growth Stock Found</div>
            <div class="result-isin" id="resultIsin"></div>
            <div class="result-ticker" id="resultTicker"></div>
            <a href="#" class="btn" id="openBtn" target="_blank">Open in Analyzer</a>
            <a href="" onclick="location.href=location.href;return false;" class="btn btn-secondary">Find Another</a>
        </div>
    </div>
    <iframe id="workerFrame"></iframe>
    <script>
    (function() {
        var AJAX_URL = window.location.href.split('?')[0];
        var els = {
            bar: document.getElementById('progressBar'), text: document.getElementById('progressText'),
            checked: document.getElementById('statChecked'), valid: document.getElementById('statValid'),
            noGrowth: document.getElementById('statNoGrowth'), invalid: document.getElementById('statInvalid'),
            status: document.getElementById('statusText'), current: document.getElementById('currentIsin'),
            log: document.getElementById('log'), error: document.getElementById('errorBox'),
            overlay: document.getElementById('resultOverlay'), resultIsin: document.getElementById('resultIsin'),
            resultTicker: document.getElementById('resultTicker'), openBtn: document.getElementById('openBtn'),
            workerFrame: document.getElementById('workerFrame')
        };
        var pollInterval = null;
        fetch(AJAX_URL + '?ajax=start').then(function(r){return r.json();}).then(function(data){
            if(data.error)throw new Error(data.error);
            pollInterval = setInterval(pollProgress, 800);
            els.workerFrame.src = AJAX_URL + '?ajax=run';
        }).catch(function(e){ els.error.style.display='block'; els.error.textContent=e.message; });
        function pollProgress(){
            fetch(AJAX_URL + '?ajax=poll').then(function(r){return r.json();}).then(function(data){
                if(data.error){ els.error.style.display='block'; els.error.textContent=data.error; return; }
                els.checked.textContent=data.checked; els.valid.textContent=data.validFound;
                els.noGrowth.textContent=data.noGrowth; els.invalid.textContent=data.invalid;
                els.bar.style.width=(data.done?100:Math.min(95,(data.checked/3000)*100))+'%';
                if(data.currentIsin){ els.current.textContent=data.currentIsin; els.status.textContent='Analyzing...'; }
                els.text.textContent='Checked '+data.checked+' ISINs � '+data.validFound+' valid � '+data.noGrowth+' no growth';
                if(data.done){
                    clearInterval(pollInterval);
                    if(data.result){
                        els.resultIsin.textContent=data.result.isin; els.resultTicker.textContent=data.result.ticker;
                        var processUrl='https://alceawis.de/other/extra/fetchdata/2026-05-13-Finance/2026-05-13-Stocks/process.php?symbol='+encodeURIComponent(data.result.isin)+'&currency=USD';
                        els.openBtn.href=processUrl;
                        setTimeout(function(){window.open(processUrl,'_blank');els.overlay.classList.add('active');},600);
                    } else {
                        els.error.style.display='block'; els.error.textContent=data.message||'No growth stock found.';
                    }
                }
            }).catch(function(){});
        }
    })();
    </script>
</body>
</html>
<?php exit; ?>

<?php
function runNormalMode() {
    global $cacheFile, $notAStockFile, $stocksFile;
    $needUpdate = true;
    if (file_exists($cacheFile)) {
        $fh = fopen($cacheFile, 'r');
        if ($fh) {
            $head = fread($fh, 100);
            fclose($fh);
            if (preg_match('/"timestamp":(\d+)/', $head, $m)) {
                if ((time() - (int)$m[1]) < 86400) $needUpdate = false;
            }
        }
    }
    if ($needUpdate) updateAllIsinsCache();

    $totalCacheIsins = 0;
    if (file_exists($cacheFile)) {
        $fh = fopen($cacheFile, 'r');
        if ($fh) { $head = fread($fh, 200); fclose($fh); }
        if (preg_match('/"count":(\d+)/', $head, $m)) $totalCacheIsins = (int)$m[1];
    }

    $stocksCount = 0;
    if (file_exists($stocksFile)) {
        $fh  = fopen($stocksFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/"isin"\s*:\s*"([A-Z]{2}[A-Z0-9]{10})"/', $buf, $m);
            $stocksCount += count($m[1]);
            $buf = substr($buf, -50);
        }
        fclose($fh);
    }

    $invalidIsinsCount = 0;
    if (file_exists($notAStockFile)) {
        $fh  = fopen($notAStockFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/(?:[\[,])\s*"([A-Z]{2}[A-Z0-9]{10})"\s*(?:,|\])/', $buf, $m);
            $invalidIsinsCount += count($m[1]);
            $buf = substr($buf, -60);
        }
        fclose($fh);
    }

    $validIsin = null; $validTicker = null; $checkedIsins = []; $invalidFound = []; $seenThisRun = [];
    $maxTotal = 3000; $batchSize = 10; $sampleSize = 200;
    $invalidTypes = ['ETF','MUTUALFUND','INDEX','CRYPTOCURRENCY','FUTURE','OPTION','BOND','PENNY_STOCK','PREFERRED_STOCK','REIT','UNIT','RIGHT','WARRANT','STRUCTURED','CURRENCY'];

    while (!$validIsin && count($checkedIsins) < $maxTotal) {
        $candidates = streamSampleIsins($cacheFile, $stocksFile, $notAStockFile, $seenThisRun, $sampleSize);
        if (empty($candidates)) break;
        foreach ($candidates as $isin) $seenThisRun[$isin] = 1;
        $offset = 0;
        while ($offset < count($candidates) && !$validIsin) {
            $batch = array_slice($candidates, $offset, $batchSize);
            $offset += $batchSize;
            array_push($checkedIsins, ...$batch);
            $mh = curl_multi_init(); $handles = [];
            foreach ($batch as $isin) {
                $ch = curl_init("https://query1.finance.yahoo.com/v1/finance/search?q=" . urlencode($isin) . "&quotesCount=1&newsCount=0");
                curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true]);
                curl_multi_add_handle($mh, $ch);
                $handles[$isin] = $ch;
            }
            do { curl_multi_exec($mh, $running); curl_multi_select($mh); } while ($running > 0);
            $validBatch = []; $newInvalid = [];
            foreach ($handles as $isin => $ch) {
                $body = curl_multi_getcontent($ch); curl_multi_remove_handle($mh, $ch); curl_close($ch);
                $data = json_decode($body, true); $quote = $data['quotes'][0] ?? null; $quoteType = $quote['quoteType'] ?? '';
                if (!$quote || $quoteType !== 'EQUITY' || in_array($quoteType, $invalidTypes)) {
                    $newInvalid[] = $isin; $invalidFound[] = $isin; $invalidIsinsCount++; continue;
                }
                $ticker = $quote['symbol'] ?? null; if ($ticker) $validBatch[$isin] = $ticker;
            }
            curl_multi_close($mh);
            if (!empty($newInvalid)) appendToNotAStock($notAStockFile, $newInvalid);
            if (!empty($validBatch)) { reset($validBatch); $validIsin = key($validBatch); $validTicker = current($validBatch); break; }
        }
        unset($candidates);
    }
    if (!$validIsin) die("No valid ISIN found after checking " . count($checkedIsins) . " candidates.");

    echo '<!DOCTYPE html><html><head><title>Valid ISIN Found</title><style>body{font-family:monospace;margin:50px;text-align:center;} .isin{font-size:28px;font-weight:bold;margin:20px;padding:15px;background:#d4edda;color:#155724;border-radius:5px;display:inline-block;} .btn{display:inline-block;padding:10px 20px;background:#007bff;color:white;text-decoration:none;border-radius:5px;margin:10px;cursor:pointer;border:none;font-size:16px;} .btn:hover{background:#0056b3;} .info{background:#e8f4f8;padding:15px;border-radius:5px;margin:20px auto;max-width:600px;text-align:left;} .count{margin:6px;color:#666;}</style></head><body><h1>Valid ISIN Found!</h1><a href="" onclick="location.reload();return false;" class="btn">Find Another</a><div class="info"><div class="count">Total ISINs in cache: ' . number_format($totalCacheIsins) . '</div><div class="count">ISINs already in stocks.json: ' . number_format($stocksCount) . '</div><div class="count">Invalid ISINs (notastock.json): ' . number_format($invalidIsinsCount) . '</div><div class="count">Checked this session: ' . count($checkedIsins) . '</div></div><div class="isin">' . htmlspecialchars($validIsin) . '</div><form id="redirectForm" action="https://alceawis.de/other/extra/fetchdata/2026-05-13-Finance/2026-05-13-Stocks/process.php" method="get" target="_blank"><input type="hidden" name="symbol" value="' . htmlspecialchars($validIsin) . '"><input type="hidden" name="currency" value="USD"><input type="submit" value="Open in process.php" class="btn"></form><script>document.getElementById("redirectForm").submit();</script></body></html>';
}

function runSpikeSearch($progressFile) {
    global $cacheFile, $notAStockFile, $stocksFile;
    ignore_user_abort(true);

    $needUpdate = true;
    if (file_exists($cacheFile)) {
        $fh = fopen($cacheFile, 'r');
        if ($fh) {
            $head = fread($fh, 100);
            fclose($fh);
            if (preg_match('/"timestamp":(\d+)/', $head, $m)) {
                if ((time() - (int)$m[1]) < 86400) $needUpdate = false;
            }
        }
    }
    if ($needUpdate) updateAllIsinsCache();

    $excludeSet = [];
    if (file_exists($stocksFile)) {
        $fh = fopen($stocksFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/"isin"\s*:\s*"([A-Z]{2}[A-Z0-9]{10})"/', $buf, $m);
            foreach ($m[1] as $isin) $excludeSet[$isin] = 1;
            $buf = substr($buf, -50);
        }
        fclose($fh);
    }
    if (file_exists($notAStockFile)) {
        $fh = fopen($notAStockFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/(?:[\[,])\s*"([A-Z]{2}[A-Z0-9]{10})"\s*(?:,|\])/', $buf, $m);
            foreach ($m[1] as $isin) $excludeSet[$isin] = 1;
            $buf = substr($buf, -60);
        }
        fclose($fh);
    }

    $validIsin = null; $validTicker = null;
    $checkedIsins = []; $invalidFound = []; $noSpikeIsins = [];
    $validFound = 0;
    $maxTotal = 3000; $batchSize = 40; $sampleSize = 200;

    $invalidTypes = ['ETF','MUTUALFUND','INDEX','CRYPTOCURRENCY','FUTURE','OPTION','BOND','PENNY_STOCK','PREFERRED_STOCK','REIT','UNIT','RIGHT','WARRANT','STRUCTURED','CURRENCY'];

    writeProgress($progressFile, [
        'status' => 'searching', 'checked' => 0, 'validFound' => 0, 'noGrowth' => 0,
        'invalid' => 0, 'currentIsin' => '', 'done' => false, 'result' => null
    ]);

    while (!$validIsin && count($checkedIsins) < $maxTotal) {
        $candidates = streamSampleIsinsFast($cacheFile, $excludeSet, $sampleSize);
        if (empty($candidates)) {
            $candidates = streamSampleIsinsFast($cacheFile, [], $sampleSize);
            if (empty($candidates)) break;
        }

        $offset = 0;
        while ($offset < count($candidates) && !$validIsin) {
            $batch = array_slice($candidates, $offset, $batchSize);
            $offset += $batchSize;

            $batch = array_filter($batch, function($isin) use ($checkedIsins) {
                return !in_array($isin, $checkedIsins);
            });
            if (empty($batch)) continue;

            array_push($checkedIsins, ...$batch);

            writeProgress($progressFile, [
                'checked' => count($checkedIsins),
                'currentIsin' => $batch[0] ?? ''
            ]);

            $mh = curl_multi_init(); $handles = [];
            foreach ($batch as $isin) {
                $ch = curl_init("https://query1.finance.yahoo.com/v1/finance/search?q=" . urlencode($isin) . "&quotesCount=1&newsCount=0");
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 10,
                    CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true
                ]);
                curl_multi_add_handle($mh, $ch);
                $handles[$isin] = $ch;
            }
            do { curl_multi_exec($mh, $running); if ($running > 0) curl_multi_select($mh, 0.05); } while ($running > 0);

            $validBatch = []; $newInvalid = [];
            foreach ($handles as $isin => $ch) {
                $body = curl_multi_getcontent($ch); curl_multi_remove_handle($mh, $ch); curl_close($ch);
                $data = json_decode($body, true); $quote = $data['quotes'][0] ?? null; $quoteType = $quote['quoteType'] ?? '';
                if (!$quote || $quoteType !== 'EQUITY' || in_array($quoteType, $invalidTypes)) {
                    $newInvalid[] = $isin; $invalidFound[] = $isin; continue;
                }
                $ticker = $quote['symbol'] ?? null; if ($ticker) $validBatch[$isin] = $ticker;
            }
            curl_multi_close($mh);

            if (!empty($newInvalid)) {
                appendToNotAStock($notAStockFile, $newInvalid);
                foreach ($newInvalid as $isin) $excludeSet[$isin] = 1;
            }

            writeProgress($progressFile, ['invalid' => count($invalidFound)]);

            if (empty($validBatch)) continue;

            $validFound += count($validBatch);
            writeProgress($progressFile, ['validFound' => $validFound]);

            $mh2 = curl_multi_init(); $chartHandles = [];
            foreach ($validBatch as $isin => $ticker) {
                $ch = curl_init("https://query1.finance.yahoo.com/v8/finance/chart/{$ticker}?interval=1d&range=1mo");
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 12,
                    CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true
                ]);
                curl_multi_add_handle($mh2, $ch);
                $chartHandles[$isin] = ['ch' => $ch, 'ticker' => $ticker];
            }
            do { curl_multi_exec($mh2, $running2); if ($running2 > 0) curl_multi_select($mh2, 0.05); } while ($running2 > 0);

            foreach ($chartHandles as $isin => $info) {
                $body = curl_multi_getcontent($info['ch']); curl_multi_remove_handle($mh2, $info['ch']); curl_close($info['ch']);
                if (!$validIsin && hasSpikeFast($body)) {
                    $validIsin = $isin; $validTicker = $info['ticker'];
                    writeProgress($progressFile, [
                        'status' => 'found', 'done' => true,
                        'result' => ['isin' => $validIsin, 'ticker' => $validTicker]
                    ]);
                    curl_multi_close($mh2);
                    break 3;
                } else {
                    $noSpikeIsins[] = $isin;
                }
            }
            curl_multi_close($mh2);

            writeProgress($progressFile, ['noGrowth' => count($noSpikeIsins)]);
        }
        unset($candidates);
    }

    if (!$validIsin) {
        writeProgress($progressFile, [
            'done' => true, 'status' => 'notfound',
            'message' => "No valid ISIN with short squeeze pattern found after checking " . count($checkedIsins) . " candidates. " . count($noSpikeIsins) . " valid ISINs had no spike."
        ]);
    }
}
function runVolgainSearch($progressFile) {
    global $cacheFile, $notAStockFile, $stocksFile;
    ignore_user_abort(true);

    $needUpdate = true;
    if (file_exists($cacheFile)) {
        $fh = fopen($cacheFile, 'r');
        if ($fh) {
            $head = fread($fh, 100);
            fclose($fh);
            if (preg_match('/"timestamp":(\d+)/', $head, $m)) {
                if ((time() - (int)$m[1]) < 86400) $needUpdate = false;
            }
        }
    }
    if ($needUpdate) updateAllIsinsCache();

    $excludeSet = [];
    if (file_exists($stocksFile)) {
        $fh = fopen($stocksFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/"isin"\s*:\s*"([A-Z]{2}[A-Z0-9]{10})"/', $buf, $m);
            foreach ($m[1] as $isin) $excludeSet[$isin] = 1;
            $buf = substr($buf, -50);
        }
        fclose($fh);
    }
    if (file_exists($notAStockFile)) {
        $fh = fopen($notAStockFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/(?:[\[,])\s*"([A-Z]{2}[A-Z0-9]{10})"\s*(?:,|\])/', $buf, $m);
            foreach ($m[1] as $isin) $excludeSet[$isin] = 1;
            $buf = substr($buf, -60);
        }
        fclose($fh);
    }

    $validIsin = null; $validTicker = null;
    $checkedIsins = []; $invalidFound = []; $noVolgainIsins = [];
    $validFound = 0;
    $maxTotal = 3000; $batchSize = 40; $sampleSize = 200;

    $invalidTypes = ['ETF','MUTUALFUND','INDEX','CRYPTOCURRENCY','FUTURE','OPTION','BOND','PENNY_STOCK','PREFERRED_STOCK','REIT','UNIT','RIGHT','WARRANT','STRUCTURED','CURRENCY'];

    writeProgress($progressFile, [
        'status' => 'searching', 'checked' => 0, 'validFound' => 0, 'noGrowth' => 0,
        'invalid' => 0, 'currentIsin' => '', 'done' => false, 'result' => null
    ]);

    while (!$validIsin && count($checkedIsins) < $maxTotal) {
        $candidates = streamSampleIsinsFast($cacheFile, $excludeSet, $sampleSize);
        if (empty($candidates)) {
            $candidates = streamSampleIsinsFast($cacheFile, [], $sampleSize);
            if (empty($candidates)) break;
        }

        $offset = 0;
        while ($offset < count($candidates) && !$validIsin) {
            $batch = array_slice($candidates, $offset, $batchSize);
            $offset += $batchSize;

            $batch = array_filter($batch, function($isin) use ($checkedIsins) {
                return !in_array($isin, $checkedIsins);
            });
            if (empty($batch)) continue;

            array_push($checkedIsins, ...$batch);

            writeProgress($progressFile, [
                'checked' => count($checkedIsins),
                'currentIsin' => $batch[0] ?? ''
            ]);

            $mh = curl_multi_init(); $handles = [];
            foreach ($batch as $isin) {
                $ch = curl_init("https://query1.finance.yahoo.com/v1/finance/search?q=" . urlencode($isin) . "&quotesCount=1&newsCount=0");
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 10,
                    CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true
                ]);
                curl_multi_add_handle($mh, $ch);
                $handles[$isin] = $ch;
            }
            do { curl_multi_exec($mh, $running); if ($running > 0) curl_multi_select($mh, 0.05); } while ($running > 0);

            $validBatch = []; $newInvalid = [];
            foreach ($handles as $isin => $ch) {
                $body = curl_multi_getcontent($ch); curl_multi_remove_handle($mh, $ch); curl_close($ch);
                $data = json_decode($body, true); $quote = $data['quotes'][0] ?? null; $quoteType = $quote['quoteType'] ?? '';
                if (!$quote || $quoteType !== 'EQUITY' || in_array($quoteType, $invalidTypes)) {
                    $newInvalid[] = $isin; $invalidFound[] = $isin; continue;
                }
                $ticker = $quote['symbol'] ?? null; if ($ticker) $validBatch[$isin] = $ticker;
            }
            curl_multi_close($mh);

            if (!empty($newInvalid)) {
                appendToNotAStock($notAStockFile, $newInvalid);
                foreach ($newInvalid as $isin) $excludeSet[$isin] = 1;
            }

            writeProgress($progressFile, ['invalid' => count($invalidFound)]);

            if (empty($validBatch)) continue;

            $validFound += count($validBatch);
            writeProgress($progressFile, ['validFound' => $validFound]);

            $mh2 = curl_multi_init(); $chartHandles = [];
            foreach ($validBatch as $isin => $ticker) {
                $ch = curl_init("https://query1.finance.yahoo.com/v8/finance/chart/{$ticker}?interval=1d&range=3wk");
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 12,
                    CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true
                ]);
                curl_multi_add_handle($mh2, $ch);
                $chartHandles[$isin] = ['ch' => $ch, 'ticker' => $ticker];
            }
            do { curl_multi_exec($mh2, $running2); if ($running2 > 0) curl_multi_select($mh2, 0.05); } while ($running2 > 0);

            foreach ($chartHandles as $isin => $info) {
                $body = curl_multi_getcontent($info['ch']); curl_multi_remove_handle($mh2, $info['ch']); curl_close($info['ch']);
                if (!$validIsin && hasVolgainFast($body)) {
                    $validIsin = $isin; $validTicker = $info['ticker'];
                    writeProgress($progressFile, [
                        'status' => 'found', 'done' => true,
                        'result' => ['isin' => $validIsin, 'ticker' => $validTicker]
                    ]);
                    curl_multi_close($mh2);
                    break 3;
                } else {
                    $noVolgainIsins[] = $isin;
                }
            }
            curl_multi_close($mh2);

            writeProgress($progressFile, ['noGrowth' => count($noVolgainIsins)]);
        }
        unset($candidates);
    }

    if (!$validIsin) {
        writeProgress($progressFile, [
            'done' => true, 'status' => 'notfound',
            'message' => "No valid ISIN with volume-gain pattern found after checking " . count($checkedIsins) . " candidates. " . count($noVolgainIsins) . " valid ISINs had no volume-gain."
        ]);
    }
}


function runGrowthSearch($progressFile) {
    global $cacheFile, $notAStockFile, $stocksFile;
    ignore_user_abort(true);

    $needUpdate = true;
    if (file_exists($cacheFile)) {
        $fh = fopen($cacheFile, 'r');
        if ($fh) {
            $head = fread($fh, 100);
            fclose($fh);
            if (preg_match('/"timestamp":(\d+)/', $head, $m)) {
                if ((time() - (int)$m[1]) < 86400) $needUpdate = false;
            }
        }
    }
    if ($needUpdate) updateAllIsinsCache();

    // One-time load of permanent exclusions
    $excludeSet = [];
    if (file_exists($stocksFile)) {
        $fh = fopen($stocksFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/"isin"\s*:\s*"([A-Z]{2}[A-Z0-9]{10})"/', $buf, $m);
            foreach ($m[1] as $isin) $excludeSet[$isin] = 1;
            $buf = substr($buf, -50);
        }
        fclose($fh);
    }
    if (file_exists($notAStockFile)) {
        $fh = fopen($notAStockFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/(?:[\[,])\s*"([A-Z]{2}[A-Z0-9]{10})"\s*(?:,|\])/', $buf, $m);
            foreach ($m[1] as $isin) $excludeSet[$isin] = 1;
            $buf = substr($buf, -60);
        }
        fclose($fh);
    }

    $validIsin = null; $validTicker = null;
    $checkedIsins = []; $invalidFound = []; $noGrowthIsins = [];
    $validFound = 0;
    $maxTotal = 3000; $batchSize = 40; $sampleSize = 200;

    $invalidTypes = ['ETF','MUTUALFUND','INDEX','CRYPTOCURRENCY','FUTURE','OPTION','BOND','PENNY_STOCK','PREFERRED_STOCK','REIT','UNIT','RIGHT','WARRANT','STRUCTURED','CURRENCY'];

    writeProgress($progressFile, [
        'status' => 'searching', 'checked' => 0, 'validFound' => 0, 'noGrowth' => 0,
        'invalid' => 0, 'currentIsin' => '', 'done' => false, 'result' => null
    ]);

    while (!$validIsin && count($checkedIsins) < $maxTotal) {
        // FIX: Only exclude permanent exclusions, not this-run checked ISINs
        // The sampler returns random ISINs; duplicates are harmless (Yahoo caches)
        $candidates = streamSampleIsinsFast($cacheFile, $excludeSet, $sampleSize);
        if (empty($candidates)) {
            // Try once more with no exclusions at all  maybe cache is just small
            $candidates = streamSampleIsinsFast($cacheFile, [], $sampleSize);
            if (empty($candidates)) break;
        }

        $offset = 0;
        while ($offset < count($candidates) && !$validIsin) {
            $batch = array_slice($candidates, $offset, $batchSize);
            $offset += $batchSize;
            
            // Skip ISINs already checked this run
            $batch = array_filter($batch, function($isin) use ($checkedIsins) {
                return !in_array($isin, $checkedIsins);
            });
            if (empty($batch)) continue;
            
            array_push($checkedIsins, ...$batch);

            writeProgress($progressFile, [
                'checked' => count($checkedIsins),
                'currentIsin' => $batch[0] ?? ''
            ]);

            $mh = curl_multi_init(); $handles = [];
            foreach ($batch as $isin) {
                $ch = curl_init("https://query1.finance.yahoo.com/v1/finance/search?q=" . urlencode($isin) . "&quotesCount=1&newsCount=0");
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 10,
                    CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true
                ]);
                curl_multi_add_handle($mh, $ch);
                $handles[$isin] = $ch;
            }
            do { curl_multi_exec($mh, $running); if ($running > 0) curl_multi_select($mh, 0.05); } while ($running > 0);

            $validBatch = []; $newInvalid = [];
            foreach ($handles as $isin => $ch) {
                $body = curl_multi_getcontent($ch); curl_multi_remove_handle($mh, $ch); curl_close($ch);
                $data = json_decode($body, true); $quote = $data['quotes'][0] ?? null; $quoteType = $quote['quoteType'] ?? '';
                if (!$quote || $quoteType !== 'EQUITY' || in_array($quoteType, $invalidTypes)) {
                    $newInvalid[] = $isin; $invalidFound[] = $isin; continue;
                }
                $ticker = $quote['symbol'] ?? null; if ($ticker) $validBatch[$isin] = $ticker;
            }
            curl_multi_close($mh);

            if (!empty($newInvalid)) {
                appendToNotAStock($notAStockFile, $newInvalid);
                foreach ($newInvalid as $isin) $excludeSet[$isin] = 1;
            }

            writeProgress($progressFile, ['invalid' => count($invalidFound)]);

            if (empty($validBatch)) continue;

            $validFound += count($validBatch);
            writeProgress($progressFile, ['validFound' => $validFound]);

            $mh2 = curl_multi_init(); $chartHandles = [];
            foreach ($validBatch as $isin => $ticker) {
                $ch = curl_init("https://query1.finance.yahoo.com/v8/finance/chart/{$ticker}?interval=1d&range=3mo");
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 12,
                    CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true
                ]);
                curl_multi_add_handle($mh2, $ch);
                $chartHandles[$isin] = ['ch' => $ch, 'ticker' => $ticker];
            }
            do { curl_multi_exec($mh2, $running2); if ($running2 > 0) curl_multi_select($mh2, 0.05); } while ($running2 > 0);

            foreach ($chartHandles as $isin => $info) {
                $body = curl_multi_getcontent($info['ch']); curl_multi_remove_handle($mh2, $info['ch']); curl_close($info['ch']);
                if (!$validIsin && hasGrowthFast($body)) {
                    $validIsin = $isin; $validTicker = $info['ticker'];
                    writeProgress($progressFile, [
                        'status' => 'found', 'done' => true,
                        'result' => ['isin' => $validIsin, 'ticker' => $validTicker]
                    ]);
                    curl_multi_close($mh2);
                    break 3;
                } else {
                    $noGrowthIsins[] = $isin;
                }
            }
            curl_multi_close($mh2);

            writeProgress($progressFile, ['noGrowth' => count($noGrowthIsins)]);
        }
        unset($candidates);
    }

    if (!$validIsin) {
        writeProgress($progressFile, [
            'done' => true, 'status' => 'notfound',
            'message' => "No valid ISIN with growth found after checking " . count($checkedIsins) . " candidates. " . count($noGrowthIsins) . " valid ISINs had no growth."
        ]);
    }
}

function writeProgress($file, array $updates) {
    $data = [];
    if (file_exists($file)) $data = json_decode(file_get_contents($file), true) ?: [];
    $data = array_merge($data, $updates);
    file_put_contents($file, json_encode($data), LOCK_EX);
}

function streamSampleIsinsFast($cacheFile, array $excludeSet, $sampleSize = 200) {
    if (!file_exists($cacheFile)) return [];
    $exclude = $excludeSet;
    $fh = fopen($cacheFile, 'r');
    if (!$fh) return [];
    $reservoir = []; $count = 0; $buf = '';
    while (!feof($fh)) {
        $buf .= fread($fh, 8192);
        preg_match_all('/(?:[\[,])\s*"([A-Z]{2}[A-Z0-9]{10})"\s*(?:,|\])/', $buf, $matches);
        foreach ($matches[1] as $isin) {
            if (isset($exclude[$isin])) continue;
            $count++;
            if (count($reservoir) < $sampleSize) {
                $reservoir[] = $isin;
            } else {
                $j = random_int(0, $count - 1);
                if ($j < $sampleSize) $reservoir[$j] = $isin;
            }
        }
        $buf = substr($buf, -60);
    }
    fclose($fh);
    return $reservoir;
}

function hasSpikeFast($responseBody) {
    if (!$responseBody) return false;
    $data = json_decode($responseBody, true);
    $result = $data['chart']['result'][0] ?? null;
    if (!$result) return false;

    $closes = $result['indicators']['quote'][0]['close'] ?? [];
    $volumes = $result['indicators']['quote'][0]['volume'] ?? [];
    $prices = []; $vols = [];
    foreach ($closes as $i => $c) {
        if (isset($c) && $c > 0) {
            $prices[] = $c;
            $vols[] = isset($volumes[$i]) ? (int)$volumes[$i] : 0;
        }
    }
    $n = count($prices);
    if ($n < 15) return false;

    $lookback = min(7, $n - 1);
    $recentPrices = array_slice($prices, -$lookback);
    $recentVols = array_slice($vols, -$lookback);
    $prevPrices = array_slice($prices, 0, -$lookback);

    if (empty($prevPrices)) return false;

    $prevAvg = array_sum($prevPrices) / count($prevPrices);
    $recentMax = max($recentPrices);
    $recentMin = min($recentPrices);
    $spikePct = (($recentMax - $prevAvg) / $prevAvg) * 100;

    if ($spikePct < 15) return false;

    $recentAvgVol = array_sum($recentVols) / max(1, count($recentVols));
    $prevVols = array_slice($vols, 0, -$lookback);
    $prevAvgVol = !empty($prevVols) ? (array_sum($prevVols) / count($prevVols)) : 0;
    $volRatio = $prevAvgVol > 0 ? ($recentAvgVol / $prevAvgVol) : 0;

    $drawdown = (($recentMax - $recentMin) / $recentMax) * 100;

    $last3 = array_slice($recentPrices, -3);
    $trendUp = ($last3[count($last3)-1] > $last3[0]);

    if ($spikePct >= 25 && $volRatio >= 2.0 && $drawdown <= 30 && $trendUp) return true;
    if ($spikePct >= 15 && $volRatio >= 1.5 && $drawdown <= 40 && $trendUp) return true;
    return false;
}

function hasGrowthFast($responseBody) {
    if (!$responseBody) return false;
    $data = json_decode($responseBody, true);
    $result = $data['chart']['result'][0] ?? null;
    if (!$result) return false;
    $closes = $result['indicators']['quote'][0]['close'] ?? [];
    $prices = [];
    foreach ($closes as $c) { if (isset($c) && $c > 0) $prices[] = $c; }
    $n = count($prices);
    if ($n < 60) return false;
    $totalReturn = (($prices[$n-1] - $prices[0]) / $prices[0]) * 100;
    if ($totalReturn < 50) return false;
    $recentStart = $n - 30; $prevStart = $n - 60;
    $recentReturn = (($prices[$n-1] - $prices[$recentStart]) / $prices[$recentStart]) * 100;
    $prevReturn = (($prices[$recentStart-1] - $prices[$prevStart]) / $prices[$prevStart]) * 100;
    return $recentReturn > $prevReturn;
}

function hasVolgainFast($responseBody) {
    if (!$responseBody) return false;
    $data = json_decode($responseBody, true);
    $result = $data['chart']['result'][0] ?? null;
    if (!$result) return false;

    $closes = $result['indicators']['quote'][0]['close'] ?? [];
    $volumes = $result['indicators']['quote'][0]['volume'] ?? [];
    $prices = []; $vols = [];
    foreach ($closes as $i => $c) {
        if (isset($c) && $c > 0) {
            $prices[] = $c;
            $vols[] = isset($volumes[$i]) ? (int)$volumes[$i] : 0;
        }
    }
    $n = count($prices);
    if ($n < 8) return false;

    // Action window = last 5 days, quiet = everything before
    $actionWindowSize = min(5, $n);
    $actionStart = $n - $actionWindowSize;
    $actionPrices = array_slice($prices, $actionStart);
    $actionVols = array_slice($vols, $actionStart);
    $quietVols = array_slice($vols, 0, $actionStart);
    $quietPrices = array_slice($prices, 0, $actionStart);

    $quietAvgVol = count($quietVols) > 0 ? (array_sum($quietVols) / count($quietVols)) : 0;
    $quietMinPrice = count($quietPrices) > 0 ? min($quietPrices) : 0;
    if ($quietAvgVol <= 0 || $quietMinPrice <= 0) return false;

    // Find spike days in action window: vol >= 10x quiet AND price up >= 20%
    $spikeDays = [];
    $spikeThresholdVol = $quietAvgVol * 10;
    for ($i = 0; $i < count($actionVols); $i++) {
        $isVolSpike = $actionVols[$i] >= $spikeThresholdVol;
        $isPriceJump = false;
        if ($i > 0) {
            $prevPrice = $actionPrices[$i - 1];
            $isPriceJump = $prevPrice > 0 && (($actionPrices[$i] - $prevPrice) / $prevPrice) * 100 >= 20;
        } elseif ($actionStart > 0) {
            $prevPrice = $prices[$actionStart - 1];
            $isPriceJump = $prevPrice > 0 && (($actionPrices[$i] - $prevPrice) / $prevPrice) * 100 >= 20;
        }
        if ($isVolSpike && $isPriceJump) {
            $spikeDays[] = $i;
        }
    }

    // Fallback: volume >= 15x with any price up
    if (empty($spikeDays)) {
        $spikeThresholdVolLoose = $quietAvgVol * 15;
        for ($i = 0; $i < count($actionVols); $i++) {
            $isVolSpike = $actionVols[$i] >= $spikeThresholdVolLoose;
            $isPriceUp = false;
            if ($i > 0) {
                $isPriceUp = $actionPrices[$i] > $actionPrices[$i - 1];
            } elseif ($actionStart > 0) {
                $isPriceUp = $actionPrices[$i] > $prices[$actionStart - 1];
            }
            if ($isVolSpike && $isPriceUp) {
                $spikeDays[] = $i;
            }
        }
    }

    if (empty($spikeDays)) return false;

    // Spike must be recent (last 3 days of window)
    $lastSpikeIdx = $spikeDays[count($spikeDays) - 1];
    if ($lastSpikeIdx < count($actionPrices) - 3) return false;

    // Check continuation: price didn't crash > 20% after spike
    $spikePrice = $actionPrices[$lastSpikeIdx];
    $afterSpikePrices = array_slice($actionPrices, $lastSpikeIdx + 1);
    if (!empty($afterSpikePrices)) {
        $lastPrice = $actionPrices[count($actionPrices) - 1];
        $drawdown = (($spikePrice - $lastPrice) / $spikePrice) * 100;
        $maxAfter = max($afterSpikePrices);
        $hasContinuation = ($drawdown <= 20) || ($maxAfter > $spikePrice);
        if (!$hasContinuation) return false;
    }

    // Total gain from quiet low to current must be significant
    $currentPrice = $prices[$n - 1];
    $totalGain = (($currentPrice - $quietMinPrice) / $quietMinPrice) * 100;
    if ($totalGain < 30) return false;

    return true;
}

function appendToNotAStock($file, array $newIsins) {
    if (empty($newIsins)) return;
    if (!file_exists($file) || filesize($file) < 3) {
        $fh = fopen($file, 'w');
        fwrite($fh, '["' . implode('","', $newIsins) . '"]');
        fclose($fh);
        return;
    }
    $fh = fopen($file, 'r+');
    if (!$fh) return;
    $size = filesize($file); $pos = $size - 1;
    while ($pos >= 0) {
        fseek($fh, $pos); $c = fread($fh, 1);
        if ($c === ']') break;
        $pos--;
    }
    fseek($fh, $pos);
    fwrite($fh, ',"' . implode('","', $newIsins) . '"]');
    fclose($fh);
}

function updateAllIsinsCache() {
    $cacheFile = __DIR__ . '/gettex_isins_cache.json';
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://www.gettex.de/handel/delayed-data/posttrade-data/',
        CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_TIMEOUT => 30
    ]);
    $html = curl_exec($ch); $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($httpCode !== 200 || !$html) return false;
    preg_match_all('/href="(https:\/\/erdk\.bayerische-boerse\.de:8000\/delayed-data\/[^"]+\.csv\.gz)"/', $html, $matches);
    if (empty($matches[1])) return false;
    $outFh = fopen($cacheFile, 'w');
    fwrite($outFh, '{"timestamp":' . time() . ',"count":0,"isins":[');
    $first = true; $seen = []; $total = 0;
    foreach ($matches[1] as $url) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0',
            CURLOPT_TIMEOUT => 30, CURLOPT_RETURNTRANSFER => false
        ]);
        $tempFile = tmpfile(); curl_setopt($ch, CURLOPT_FILE, $tempFile);
        $ok = curl_exec($ch); curl_close($ch);
        if (!$ok) { fclose($tempFile); continue; }
        $meta = stream_get_meta_data($tempFile); $gz = gzopen($meta['uri'], 'rb');
        if (!$gz) { fclose($tempFile); continue; }
        gzgets($gz);
        while (!gzeof($gz)) {
            $line = gzgets($gz, 512);
            if (trim($line) === '') continue;
            $cols = str_getcsv($line); $isin = $cols[0] ?? '';
            if (!preg_match('/^[A-Z]{2}[A-Z0-9]{10}$/', $isin)) continue;
            if (isset($seen[$isin])) continue;
            $seen[$isin] = 1;
            fwrite($outFh, ($first ? '' : ',') . '"' . $isin . '"');
            $first = false; $total++;
        }
        gzclose($gz); fclose($tempFile); unset($seen); $seen = [];
    }
    fwrite($outFh, ']}'); fclose($outFh);
    $content = file_get_contents($cacheFile);
    $content = str_replace('"count":0', '"count":' . $total, $content);
    file_put_contents($cacheFile, $content);
    return true;
}

function streamSampleIsins($cacheFile, $stocksFile, $notAStockFile, $seenThisRun, $sampleSize = 200) {
    return streamSampleIsinsFast($cacheFile, [], $sampleSize);
}
?>
