<?php
ini_set('memory_limit', '512M');
set_time_limit(0);

function errorHandler($errno, $errstr, $errfile, $errline) {
    echo json_encode(['error' => "$errstr in $errfile on line $errline"]);
    exit;
}
set_error_handler("errorHandler");

$ajaxMode = $_GET['ajax'] ?? '';

$cacheFile     = __DIR__ . '/gettex_isins_cache.json';
$notAStockFile = __DIR__ . '/notastock.json';
$stocksFile    = __DIR__ . '/stocks.json';
$progressFile  = __DIR__ . '/progress.json';

if ($ajaxMode === 'start') {
    header('Content-Type: application/json');
    file_put_contents($progressFile, json_encode([
        'status' => 'starting',
        'checked' => 0,
        'validFound' => 0,
        'noBreakout' => 0,
        'invalid' => 0,
        'currentIsin' => '',
        'done' => false,
        'result' => null,
        'started' => time()
    ]));
    echo json_encode(['ok' => true]);
    exit;
}

if ($ajaxMode === 'poll') {
    header('Content-Type: application/json');
    if (!file_exists($progressFile)) {
        echo json_encode(['error' => 'Progress file not found']);
        exit;
    }
    readfile($progressFile);
    exit;
}

if ($ajaxMode === 'run') {
    ignore_user_abort(true);
    set_time_limit(0);
    header('Content-Type: text/plain');
    echo "0\n";
    ob_flush();
    flush();
    runBreakoutSearch($progressFile);
    exit;
}

// No normal mode. Direct page load starts the AJAX breakout scanner UI.
?>
<!DOCTYPE html>
<html>
<head>
    <title>Finding Breakout Stock...</title>
    <meta charset="utf-8">
    <style>
        * { box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; margin: 0; padding: 40px 20px; background: #0f172a; color: #e2e8f0; min-height: 100vh; display: flex; flex-direction: column; align-items: center; }
        h1 { font-size: 1.8rem; margin-bottom: 10px; color: #f8fafc; }
        .subtitle { color: #94a3b8; margin-bottom: 30px; font-size: 0.95rem; }
        .card { background: #1e293b; border-radius: 16px; padding: 30px; width: 100%; max-width: 600px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); }
        .progress-container { margin: 20px 0; }
        .progress-bar-bg { background: #334155; border-radius: 12px; height: 24px; overflow: hidden; position: relative; }
        .progress-bar-fill { background: linear-gradient(90deg, #22c55e, #16a34a); height: 100%; border-radius: 12px; width: 0%; transition: width 0.4s ease; position: relative; }
        .progress-bar-fill::after { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent); animation: shimmer 1.5s infinite; }
        @keyframes shimmer { 0% { transform: translateX(-100%); } 100% { transform: translateX(100%); } }
        .progress-text { text-align: center; margin-top: 8px; font-size: 0.9rem; color: #94a3b8; }
        .stats-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin: 20px 0; }
        .stat-box { background: #0f172a; border-radius: 10px; padding: 14px; text-align: center; border: 1px solid #334155; }
        .stat-value { font-size: 1.5rem; font-weight: 700; color: #f8fafc; }
        .stat-label { font-size: 0.75rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 4px; }
        .stat-value.green { color: #22c55e; }
        .stat-value.red { color: #ef4444; }
        .stat-value.yellow { color: #eab308; }
        .current-activity { background: #0f172a; border-radius: 10px; padding: 14px 18px; margin: 15px 0; font-family: 'SF Mono', monospace; font-size: 0.85rem; color: #94a3b8; border-left: 3px solid #3b82f6; min-height: 48px; }
        .current-activity .label { color: #64748b; }
        .current-activity .isin { color: #60a5fa; font-weight: 600; }
        .log { background: #0f172a; border-radius: 10px; padding: 14px; margin-top: 15px; max-height: 200px; overflow-y: auto; font-family: 'SF Mono', monospace; font-size: 0.8rem; color: #64748b; border: 1px solid #334155; }
        .log-entry { padding: 2px 0; border-bottom: 1px solid #1e293b; }
        .log-entry:last-child { border-bottom: none; }
        .log .ok { color: #22c55e; }
        .log .skip { color: #ef4444; }
        .log .nobreakout { color: #eab308; }
        .result-overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.95); z-index: 100; align-items: center; justify-content: center; flex-direction: column; }
        .result-overlay.active { display: flex; }
        .result-card { background: #1e293b; border-radius: 20px; padding: 40px; text-align: center; max-width: 500px; width: 90%; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); border: 2px solid #22c55e; }
        .result-card .badge { display: inline-block; background: #22c55e; color: #fff; padding: 8px 20px; border-radius: 20px; font-size: 0.85rem; font-weight: 600; margin-bottom: 20px; }
        .result-isin { font-size: 2rem; font-weight: 800; color: #f8fafc; letter-spacing: 0.05em; margin: 15px 0; }
        .result-ticker { color: #94a3b8; font-size: 1.1rem; margin-bottom: 25px; }
        .btn { display: inline-block; padding: 14px 32px; background: #3b82f6; color: #fff; text-decoration: none; border-radius: 10px; font-weight: 600; font-size: 1rem; border: none; cursor: pointer; transition: background 0.2s; }
        .btn:hover { background: #2563eb; }
        .btn-secondary { background: #475569; margin-left: 10px; }
        .btn-secondary:hover { background: #334155; }
        .error-box { background: #7f1d1d; border: 1px solid #ef4444; color: #fecaca; padding: 20px; border-radius: 10px; margin-top: 20px; display: none; }
        #workerFrame { position: absolute; width: 1px; height: 1px; left: -9999px; top: -9999px; border: none; opacity: 0; }
    </style>
</head>
<body>
    <h1>Finding a Breakout Stock</h1>
    <div class="subtitle">Scanning Gettex ISINs for high volume + consolidation breakout patterns</div>
    <div class="card">
        <div class="progress-container">
            <div class="progress-bar-bg"><div class="progress-bar-fill" id="progressBar"></div></div>
            <div class="progress-text" id="progressText">Initializing...</div>
        </div>
        <div class="stats-grid">
            <div class="stat-box"><div class="stat-value" id="statChecked">0</div><div class="stat-label">Checked</div></div>
            <div class="stat-box"><div class="stat-value green" id="statValid">0</div><div class="stat-label">Valid Stocks</div></div>
            <div class="stat-box"><div class="stat-value yellow" id="statNoBreakout">0</div><div class="stat-label">No Breakout</div></div>
            <div class="stat-box"><div class="stat-value red" id="statInvalid">0</div><div class="stat-label">Invalid / ETF</div></div>
        </div>
        <div class="current-activity" id="currentActivity">
            <span class="label">Status:</span> <span id="statusText">Starting search...</span><br>
            <span class="label">Current:</span> <span class="isin" id="currentIsin">-</span>
        </div>
        <div class="log" id="log"></div>
        <div class="error-box" id="errorBox"></div>
    </div>
    <div class="result-overlay" id="resultOverlay">
        <div class="result-card">
            <div class="badge">Breakout Stock Found</div>
            <div class="result-isin" id="resultIsin"></div>
            <div class="result-ticker" id="resultTicker"></div>
            <a href="#" class="btn" id="openBtn" target="_blank">Open in Analyzer</a>
            <a href="" onclick="location.href=location.href;return false;" class="btn btn-secondary">Find Another</a>
        </div>
    </div>
    <iframe id="workerFrame"></iframe>
    <script>
    (function() {
        var AJAX_URL = window.location.href.split('?')[0];
        var els = {
            bar: document.getElementById('progressBar'), text: document.getElementById('progressText'),
            checked: document.getElementById('statChecked'), valid: document.getElementById('statValid'),
            noBreakout: document.getElementById('statNoBreakout'), invalid: document.getElementById('statInvalid'),
            status: document.getElementById('statusText'), current: document.getElementById('currentIsin'),
            log: document.getElementById('log'), error: document.getElementById('errorBox'),
            overlay: document.getElementById('resultOverlay'), resultIsin: document.getElementById('resultIsin'),
            resultTicker: document.getElementById('resultTicker'), openBtn: document.getElementById('openBtn'),
            workerFrame: document.getElementById('workerFrame')
        };
        var pollInterval = null;
        fetch(AJAX_URL + '?ajax=start').then(function(r){return r.json();}).then(function(data){
            if(data.error)throw new Error(data.error);
            pollInterval = setInterval(pollProgress, 800);
            els.workerFrame.src = AJAX_URL + '?ajax=run';
        }).catch(function(e){ els.error.style.display='block'; els.error.textContent=e.message; });
        function pollProgress(){
            fetch(AJAX_URL + '?ajax=poll').then(function(r){return r.json();}).then(function(data){
                if(data.error){ els.error.style.display='block'; els.error.textContent=data.error; return; }
                els.checked.textContent=data.checked; els.valid.textContent=data.validFound;
                els.noBreakout.textContent=data.noBreakout; els.invalid.textContent=data.invalid;
                els.bar.style.width=(data.done?100:Math.min(95,(data.checked/3000)*100))+'%';
                if(data.currentIsin){ els.current.textContent=data.currentIsin; els.status.textContent='Analyzing...'; }
                els.text.textContent='Checked '+data.checked+' ISINs - '+data.validFound+' valid - '+data.noBreakout+' no breakout';
                if(data.done){
                    clearInterval(pollInterval);
                    if(data.result){
                        els.resultIsin.textContent=data.result.isin; els.resultTicker.textContent=data.result.ticker;
                        var processUrl='https://alceawis.de/other/extra/fetchdata/2026-05-13-Finance/2026-05-13-Stocks/process.php?symbol='+encodeURIComponent(data.result.isin)+'&currency=USD';
                        els.openBtn.href=processUrl;
                        setTimeout(function(){window.open(processUrl,'_blank');els.overlay.classList.add('active');},600);
                    } else {
                        els.error.style.display='block'; els.error.textContent=data.message||'No breakout stock found.';
                    }
                }
            }).catch(function(){});
        }
    })();
    </script>
</body>
</html>
<?php exit; ?>

<?php
function runBreakoutSearch($progressFile) {
    global $cacheFile, $notAStockFile, $stocksFile;
    ignore_user_abort(true);

    $needUpdate = true;
    if (file_exists($cacheFile)) {
        $fh = fopen($cacheFile, 'r');
        if ($fh) {
            $head = fread($fh, 100);
            fclose($fh);
            if (preg_match('/"timestamp":(\d+)/', $head, $m)) {
                if ((time() - (int)$m[1]) < 86400) $needUpdate = false;
            }
        }
    }
    if ($needUpdate) updateAllIsinsCache();

    $excludeSet = [];
    if (file_exists($stocksFile)) {
        $fh = fopen($stocksFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/"isin"\s*:\s*"([A-Z]{2}[A-Z0-9]{10})"/', $buf, $m);
            foreach ($m[1] as $isin) $excludeSet[$isin] = 1;
            $buf = substr($buf, -50);
        }
        fclose($fh);
    }
    if (file_exists($notAStockFile)) {
        $fh = fopen($notAStockFile, 'r');
        $buf = '';
        while (!feof($fh)) {
            $buf .= fread($fh, 8192);
            preg_match_all('/(?:[\[,])\s*"([A-Z]{2}[A-Z0-9]{10})"\s*(?:,|\])/', $buf, $m);
            foreach ($m[1] as $isin) $excludeSet[$isin] = 1;
            $buf = substr($buf, -60);
        }
        fclose($fh);
    }

    $validIsin = null; $validTicker = null;
    $checkedIsins = []; $invalidFound = []; $noBreakoutIsins = [];
    $validFound = 0;
    $maxTotal = 3000; $batchSize = 40; $sampleSize = 200;

    $invalidTypes = ['ETF','MUTUALFUND','INDEX','CRYPTOCURRENCY','FUTURE','OPTION','BOND','PENNY_STOCK','PREFERRED_STOCK','REIT','UNIT','RIGHT','WARRANT','STRUCTURED','CURRENCY'];

    writeProgress($progressFile, [
        'status' => 'searching', 'checked' => 0, 'validFound' => 0, 'noBreakout' => 0,
        'invalid' => 0, 'currentIsin' => '', 'done' => false, 'result' => null
    ]);

    while (!$validIsin && count($checkedIsins) < $maxTotal) {
        $candidates = streamSampleIsinsFast($cacheFile, $excludeSet, $sampleSize);
        if (empty($candidates)) {
            $candidates = streamSampleIsinsFast($cacheFile, [], $sampleSize);
            if (empty($candidates)) break;
        }

        $offset = 0;
        while ($offset < count($candidates) && !$validIsin) {
            $batch = array_slice($candidates, $offset, $batchSize);
            $offset += $batchSize;

            $batch = array_filter($batch, function($isin) use ($checkedIsins) {
                return !in_array($isin, $checkedIsins);
            });
            if (empty($batch)) continue;

            array_push($checkedIsins, ...$batch);

            writeProgress($progressFile, [
                'checked' => count($checkedIsins),
                'currentIsin' => $batch[0] ?? ''
            ]);

            $mh = curl_multi_init(); $handles = [];
            foreach ($batch as $isin) {
                $ch = curl_init("https://query1.finance.yahoo.com/v1/finance/search?q=" . urlencode($isin) . "&quotesCount=1&newsCount=0");
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 10,
                    CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true
                ]);
                curl_multi_add_handle($mh, $ch);
                $handles[$isin] = $ch;
            }
            do { curl_multi_exec($mh, $running); if ($running > 0) curl_multi_select($mh, 0.05); } while ($running > 0);

            $validBatch = []; $newInvalid = [];
            foreach ($handles as $isin => $ch) {
                $body = curl_multi_getcontent($ch); curl_multi_remove_handle($mh, $ch); curl_close($ch);
                $data = json_decode($body, true); $quote = $data['quotes'][0] ?? null; $quoteType = $quote['quoteType'] ?? '';
                if (!$quote || $quoteType !== 'EQUITY' || in_array($quoteType, $invalidTypes)) {
                    $newInvalid[] = $isin; $invalidFound[] = $isin; continue;
                }
                $ticker = $quote['symbol'] ?? null; if ($ticker) $validBatch[$isin] = $ticker;
            }
            curl_multi_close($mh);

            if (!empty($newInvalid)) {
                appendToNotAStock($notAStockFile, $newInvalid);
                foreach ($newInvalid as $isin) $excludeSet[$isin] = 1;
            }

            writeProgress($progressFile, ['invalid' => count($invalidFound)]);

            if (empty($validBatch)) continue;

            $validFound += count($validBatch);
            writeProgress($progressFile, ['validFound' => $validFound]);

            $mh2 = curl_multi_init(); $chartHandles = [];
            foreach ($validBatch as $isin => $ticker) {
                $ch = curl_init("https://query1.finance.yahoo.com/v8/finance/chart/{$ticker}?interval=1d&range=3mo");
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 12,
                    CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true
                ]);
                curl_multi_add_handle($mh2, $ch);
                $chartHandles[$isin] = ['ch' => $ch, 'ticker' => $ticker];
            }
            do { curl_multi_exec($mh2, $running2); if ($running2 > 0) curl_multi_select($mh2, 0.05); } while ($running2 > 0);

            foreach ($chartHandles as $isin => $info) {
                $body = curl_multi_getcontent($info['ch']); curl_multi_remove_handle($mh2, $info['ch']); curl_close($info['ch']);
                if (!$validIsin && hasBreakout($body)) {
                    $validIsin = $isin; $validTicker = $info['ticker'];
                    writeProgress($progressFile, [
                        'status' => 'found', 'done' => true,
                        'result' => ['isin' => $validIsin, 'ticker' => $validTicker]
                    ]);
                    curl_multi_close($mh2);
                    break 3;
                } else {
                    $noBreakoutIsins[] = $isin;
                }
            }
            curl_multi_close($mh2);

            writeProgress($progressFile, ['noBreakout' => count($noBreakoutIsins)]);
        }
        unset($candidates);
    }

    if (!$validIsin) {
        writeProgress($progressFile, [
            'done' => true, 'status' => 'notfound',
            'message' => "No valid ISIN with breakout pattern found after checking " . count($checkedIsins) . " candidates. " . count($noBreakoutIsins) . " valid ISINs had no breakout."
        ]);
    }
}

function hasBreakout($responseBody) {
    if (!$responseBody) return false;
    $data = json_decode($responseBody, true);
    $result = $data['chart']['result'][0] ?? null;
    if (!$result) return false;

    $closes = $result['indicators']['quote'][0]['close'] ?? [];
    $opens  = $result['indicators']['quote'][0]['open'] ?? [];
    $highs  = $result['indicators']['quote'][0]['high'] ?? [];
    $lows   = $result['indicators']['quote'][0]['low'] ?? [];
    $volumes = $result['indicators']['quote'][0]['volume'] ?? [];

    $bars = [];
    for ($i = 0; $i < count($closes); $i++) {
        if (isset($closes[$i]) && $closes[$i] > 0 && isset($opens[$i]) && isset($highs[$i]) && isset($lows[$i]) && isset($volumes[$i])) {
            $bars[] = [
                'open'   => (float)$opens[$i],
                'high'   => (float)$highs[$i],
                'low'    => (float)$lows[$i],
                'close'  => (float)$closes[$i],
                'volume' => (int)$volumes[$i]
            ];
        }
    }

    $n = count($bars);
    if ($n < 60) return false;

    // --- 1. Compute 50-day average volume ---
    $vol50 = 0;
    for ($i = $n - 50; $i < $n; $i++) {
        $vol50 += $bars[$i]['volume'];
    }
    $avgVol50 = $vol50 / 50;
    if ($avgVol50 <= 0) return false;

    // --- 2. STRICT DIRECTION CHECK: last 3 days must be net positive ---
    $last3Closes = [];
    for ($i = $n - 3; $i < $n; $i++) {
        $last3Closes[] = $bars[$i]['close'];
    }
    $lastClose = $last3Closes[count($last3Closes) - 1];
    $firstOfLast3 = $last3Closes[0];

    if ($lastClose <= $firstOfLast3) return false;
    $threeDayMomentum = (($lastClose - $firstOfLast3) / $firstOfLast3) * 100;
    if ($threeDayMomentum < 3) return false;

    // --- 3. Volume spike: at least 1 of last 3 days >= 150% of 50-day avg ---
    $spikeDays = 0;
    for ($i = $n - 3; $i < $n; $i++) {
        if ($bars[$i]['volume'] >= $avgVol50 * 1.5) {
            $spikeDays++;
        }
    }
    if ($spikeDays < 1) return false;

    // --- 4. Strong green candle(s) in last 3 days ---
    $greenCandleDays = 0;
    for ($i = $n - 3; $i < $n; $i++) {
        $bar = $bars[$i];
        $isGreen = $bar['close'] > $bar['open'];
        $body = abs($bar['close'] - $bar['open']);
        $range = $bar['high'] - $bar['low'];
        if ($range <= 0) continue;
        $closeNearHigh = ($bar['high'] - $bar['close']) / $range < 0.25;
        $strongBody = $body / $range >= 0.5;
        if ($isGreen && $closeNearHigh && $strongBody) {
            $greenCandleDays++;
        }
    }
    if ($greenCandleDays < 1) return false;

    // --- 5. Detect consolidation period (20-50 days before breakout) ---
    $consolidationStart = max(0, $n - 50);
    $consolidationEnd   = $n - 3;
    if ($consolidationEnd - $consolidationStart < 10) return false;

    $consolPrices = [];
    for ($i = $consolidationStart; $i <= $consolidationEnd; $i++) {
        $consolPrices[] = $bars[$i]['close'];
    }
    $consolMin = min($consolPrices);
    $consolMax = max($consolPrices);
    if ($consolMin <= 0) return false;
    $consolRangePct = (($consolMax - $consolMin) / $consolMin) * 100;

    if ($consolRangePct > 15) return false;

    // --- 6. Breakout must be ABOVE consolidation high ---
    if ($lastClose <= $consolMax) return false;
    $breakoutPct = (($lastClose - $consolMax) / $consolMax) * 100;
    if ($breakoutPct < 2) return false;

    // --- 7. Gap up check: last day should open above previous close ---
    $lastBar = $bars[$n - 1];
    $prevBar = $bars[$n - 2];
    $gapUp = $lastBar['open'] > $prevBar['close'];
    if (!$gapUp) return false;
    $gapPct = (($lastBar['open'] - $prevBar['close']) / $prevBar['close']) * 100;
    if ($gapPct < 1) return false;

    // --- 8. Volume confirmation: the gap-up day itself must have high volume ---
    if ($lastBar['volume'] < $avgVol50 * 1.5) return false;

    return true;
}

function writeProgress($file, array $updates) {
    $data = [];
    if (file_exists($file)) $data = json_decode(file_get_contents($file), true) ?: [];
    $data = array_merge($data, $updates);
    file_put_contents($file, json_encode($data), LOCK_EX);
}

function streamSampleIsinsFast($cacheFile, array $excludeSet, $sampleSize = 200) {
    if (!file_exists($cacheFile)) return [];
    $exclude = $excludeSet;
    $fh = fopen($cacheFile, 'r');
    if (!$fh) return [];
    $reservoir = []; $count = 0; $buf = '';
    while (!feof($fh)) {
        $buf .= fread($fh, 8192);
        preg_match_all('/(?:[\[,])\s*"([A-Z]{2}[A-Z0-9]{10})"\s*(?:,|\])/', $buf, $matches);
        foreach ($matches[1] as $isin) {
            if (isset($exclude[$isin])) continue;
            $count++;
            if (count($reservoir) < $sampleSize) {
                $reservoir[] = $isin;
            } else {
                $j = random_int(0, $count - 1);
                if ($j < $sampleSize) $reservoir[$j] = $isin;
            }
        }
        $buf = substr($buf, -60);
    }
    fclose($fh);
    return $reservoir;
}

function appendToNotAStock($file, array $newIsins) {
    if (empty($newIsins)) return;
    if (!file_exists($file) || filesize($file) < 3) {
        $fh = fopen($file, 'w');
        fwrite($fh, '["' . implode('","', $newIsins) . '"]');
        fclose($fh);
        return;
    }
    $fh = fopen($file, 'r+');
    if (!$fh) return;
    $size = filesize($file); $pos = $size - 1;
    while ($pos >= 0) {
        fseek($fh, $pos); $c = fread($fh, 1);
        if ($c === ']') break;
        $pos--;
    }
    fseek($fh, $pos);
    fwrite($fh, ',"' . implode('","', $newIsins) . '"]');
    fclose($fh);
}

function updateAllIsinsCache() {
    $cacheFile = __DIR__ . '/gettex_isins_cache.json';
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://www.gettex.de/handel/delayed-data/posttrade-data/',
        CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_TIMEOUT => 30
    ]);
    $html = curl_exec($ch); $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($httpCode !== 200 || !$html) return false;
    preg_match_all('/href="(https:\/\/erdk\.bayerische-boerse\.de:8000\/delayed-data\/[^"]+\.csv\.gz)"/', $html, $matches);
    if (empty($matches[1])) return false;
    $outFh = fopen($cacheFile, 'w');
    fwrite($outFh, '{"timestamp":' . time() . ',"count":0,"isins":[');
    $first = true; $seen = []; $total = 0;
    foreach ($matches[1] as $url) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0',
            CURLOPT_TIMEOUT => 30, CURLOPT_RETURNTRANSFER => false
        ]);
        $tempFile = tmpfile(); curl_setopt($ch, CURLOPT_FILE, $tempFile);
        $ok = curl_exec($ch); curl_close($ch);
        if (!$ok) { fclose($tempFile); continue; }
        $meta = stream_get_meta_data($tempFile); $gz = gzopen($meta['uri'], 'rb');
        if (!$gz) { fclose($tempFile); continue; }
        gzgets($gz);
        while (!gzeof($gz)) {
            $line = gzgets($gz, 512);
            if (trim($line) === '') continue;
            $cols = str_getcsv($line); $isin = $cols[0] ?? '';
            if (!preg_match('/^[A-Z]{2}[A-Z0-9]{10}$/', $isin)) continue;
            if (isset($seen[$isin])) continue;
            $seen[$isin] = 1;
            fwrite($outFh, ($first ? '' : ',') . '"' . $isin . '"');
            $first = false; $total++;
        }
        gzclose($gz); fclose($tempFile); unset($seen); $seen = [];
    }
    fwrite($outFh, ']}'); fclose($outFh);
    $content = file_get_contents($cacheFile);
    $content = str_replace('"count":0', '"count":' . $total, $content);
    file_put_contents($cacheFile, $content);
    return true;
}

function streamSampleIsins($cacheFile, $stocksFile, $notAStockFile, $seenThisRun, $sampleSize = 200) {
    return streamSampleIsinsFast($cacheFile, [], $sampleSize);
}
?>