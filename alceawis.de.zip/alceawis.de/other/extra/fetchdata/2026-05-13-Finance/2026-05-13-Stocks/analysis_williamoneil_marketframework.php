<!---https://www.reddit.com/r/swingtrading/comments/1vebr04/william_oneils_framework_for_market_follow/--->
<?php

/**
 * Market Follow-Through Day (FTD) Analyzer
 * Based on William O'Neil's framework for identifying new uptrends.
 *
 * Usage:
 *   - Web: market_ftd.php?symbol=QQQ
 *   - Web Compact: market_ftd.php?symbol=QQQ&compact
 *   - CLI: php market_ftd.php QQQ
 */

// --- Configuration ---
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

// --- Helper Functions ---

/**
 * Resolves a symbol to get the correct ticker (handles MSTR -> stock vs ETF)
 */
function resolveSymbol(string $symbol): ?string {
    $searchUrl = "https://query1.finance.yahoo.com/v1/finance/search?q={$symbol}&quotesCount=10&newsCount=0";
    
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $searchUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_USERAGENT => USER_AGENT,
        CURLOPT_HTTPHEADER => array(
            'Accept: application/json',
            'Accept-Encoding: gzip, deflate',
            'Connection: keep-alive',
        ),
        CURLOPT_ENCODING => '',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ));
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200 || $response === false) {
        return $symbol;
    }
    
    $data = json_decode($response, true);
    if (!isset($data['quotes']) || empty($data['quotes'])) {
        return $symbol;
    }
    
    // First, try to find exact match for the symbol
    foreach ($data['quotes'] as $quote) {
        if (strtoupper($quote['symbol']) === strtoupper($symbol)) {
            if (isset($quote['quoteType']) && $quote['quoteType'] === 'EQUITY') {
                return $quote['symbol'];
            }
        }
    }
    
    // If no exact match, find the first EQUITY (stock)
    foreach ($data['quotes'] as $quote) {
        if (isset($quote['quoteType']) && $quote['quoteType'] === 'EQUITY') {
            return $quote['symbol'];
        }
    }
    
    return $data['quotes'][0]['symbol'] ?? $symbol;
}

/**
 * Fetches daily OHLCV data from Yahoo Finance using the most recent data.
 */
function fetchMarketData(string $symbol): ?array {
    $resolvedSymbol = resolveSymbol($symbol);
    
    // Try multiple endpoints with different date ranges to get current data
    $endpoints = array(
        // Most recent 3 months first
        "https://query1.finance.yahoo.com/v8/finance/chart/{$resolvedSymbol}?interval=1d&range=3mo",
        "https://query2.finance.yahoo.com/v8/finance/chart/{$resolvedSymbol}?interval=1d&range=3mo",
        // If that fails, try 6 months
        "https://query1.finance.yahoo.com/v8/finance/chart/{$resolvedSymbol}?interval=1d&range=6mo",
        // Try with specific start date to force current data
        "https://query1.finance.yahoo.com/v8/finance/chart/{$resolvedSymbol}?interval=1d&period1=" . strtotime('-3 months'),
        // Last resort: 1 year but will check dates
        "https://query1.finance.yahoo.com/v8/finance/chart/{$resolvedSymbol}?interval=1d&range=1y",
    );
    
    foreach ($endpoints as $url) {
        $data = fetchYahooData($url);
        if ($data !== null && count($data) > 10) {
            // Check if the data is recent (within last 30 days)
            $lastDate = end($data);
            $lastTimestamp = strtotime($lastDate['date']);
            $thirtyDaysAgo = strtotime('-30 days');
            
            // If data is too old, continue to next endpoint
            if ($lastTimestamp < $thirtyDaysAgo) {
                continue;
            }
            return $data;
        }
    }
    
    return null;
}

/**
 * Fetch from Yahoo Finance with proper curl settings
 */
function fetchYahooData(string $url): ?array {
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_USERAGENT => USER_AGENT,
        CURLOPT_HTTPHEADER => array(
            'Accept: application/json',
            'Accept-Encoding: gzip, deflate',
            'Connection: keep-alive',
        ),
        CURLOPT_ENCODING => '',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_COOKIE => 'B=1;',
    ));
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($httpCode !== 200 || $response === false || !empty($error)) {
        return null;
    }
    
    return parseYahooResponse($response);
}

/**
 * Parse Yahoo Finance JSON response
 */
function parseYahooResponse(string $json): ?array {
    $data = json_decode($json, true);
    
    if (!isset($data['chart']['result'][0])) {
        return null;
    }

    $result = $data['chart']['result'][0];
    $timestamps = isset($result['timestamp']) ? $result['timestamp'] : array();
    $meta = isset($result['meta']) ? $result['meta'] : array();
    
    // Check if we got valid data
    if (isset($meta['dataAvailability']) && $meta['dataAvailability'] === false) {
        return null;
    }
    
    // Check if timestamps are from 2025 (too old)
    if (!empty($timestamps)) {
        $latestTimestamp = max($timestamps);
        $latestDate = date('Y', $latestTimestamp);
        $currentYear = date('Y');
        
        // If the latest data is from last year or earlier, skip it
        if ($latestDate < $currentYear) {
            return null;
        }
    }
    
    // Get close prices (prefer adjusted close)
    $closePrices = null;
    $volumes = null;
    
    if (isset($result['indicators']['adjclose'][0]['adjclose'])) {
        $closePrices = $result['indicators']['adjclose'][0]['adjclose'];
    } elseif (isset($result['indicators']['quote'][0]['close'])) {
        $closePrices = $result['indicators']['quote'][0]['close'];
    }
    
    if (isset($result['indicators']['quote'][0]['volume'])) {
        $volumes = $result['indicators']['quote'][0]['volume'];
    }

    if (empty($timestamps) || empty($closePrices) || empty($volumes)) {
        return null;
    }

    $marketData = array();
    for ($i = 0; $i < count($timestamps); $i++) {
        if ($closePrices[$i] !== null && $volumes[$i] !== null && $closePrices[$i] > 0) {
            $marketData[] = array(
                'date'   => date('Y-m-d', $timestamps[$i]),
                'close'  => (float) $closePrices[$i],
                'volume' => (int) $volumes[$i]
            );
        }
    }

    if (empty($marketData)) {
        return null;
    }
    
    // Sort chronologically (oldest first)
    usort($marketData, function($a, $b) {
        return strtotime($a['date']) - strtotime($b['date']);
    });
    
    return $marketData;
}

/**
 * Identifies the most recent Follow-Through Day (FTD) based on O'Neil's rules.
 */
function findFollowThroughDay(array $data): ?array {
    $n = count($data);
    if ($n < 10) {
        return null;
    }

    $ftds = array();

    for ($i = 5; $i < $n - 7; $i++) {
        // Find a low point
        $isLow = true;
        for ($j = max(0, $i - 5); $j < $i; $j++) {
            if ($data[$j]['close'] <= $data[$i]['close']) {
                $isLow = false;
                break;
            }
        }
        if (!$isLow) continue;

        if ($i + 1 >= $n) continue;
        if ($data[$i + 1]['close'] <= $data[$i]['close']) continue;

        $lowPrice = $data[$i]['close'];
        $lowDate = $data[$i]['date'];
        $rallyStartIdx = $i + 1;

        for ($dayOffset = 3; $dayOffset <= 6; $dayOffset++) {
            $checkIdx = $rallyStartIdx + $dayOffset;
            if ($checkIdx >= $n) break;

            $prevIdx = $checkIdx - 1;
            $current = $data[$checkIdx];
            $previous = $data[$prevIdx];

            $pctChange = (($current['close'] - $previous['close']) / $previous['close']) * 100;

            if ($pctChange >= 1.25 && $current['volume'] > $previous['volume']) {
                $dayNumber = $dayOffset + 1;
                $strength = ($dayNumber <= 5) ? 'Strong (early confirmation)' : 'Weaker (later confirmation, higher failure rate)';

                $cancelled = false;
                for ($k = $checkIdx + 1; $k < $n; $k++) {
                    if ($data[$k]['close'] < $lowPrice) {
                        $cancelled = true;
                        break;
                    }
                }

                $ftd = array(
                    'date' => $current['date'],
                    'close' => $current['close'],
                    'volume' => $current['volume'],
                    'pct_change' => round($pctChange, 2),
                    'day_number' => $dayNumber,
                    'strength' => $strength,
                    'low_price' => $lowPrice,
                    'low_date' => $lowDate,
                    'cancelled' => $cancelled,
                    'rally_start_date' => $data[$rallyStartIdx]['date'],
                    'prev_day_volume' => $previous['volume'],
                );

                $ftds[] = $ftd;
                break;
            }
        }
    }

    return empty($ftds) ? null : end($ftds);
}

// --- Main Execution ---

if (php_sapi_name() === 'cli') {
    $symbol = isset($argv[1]) ? $argv[1] : 'QQQ';
    $compact = false;
    $format = 'cli';
} else {
    $symbol = isset($_GET['symbol']) ? $_GET['symbol'] : 'QQQ';
    // Check if 'compact' parameter exists (regardless of value)
    $compact = array_key_exists('compact', $_GET);
    $format = isset($_GET['format']) ? $_GET['format'] : 'html';
}

$symbol = strtoupper(trim($symbol));
if (empty($symbol)) {
    $symbol = 'QQQ';
}

$data = fetchMarketData($symbol);

if ($data === null) {
    if (php_sapi_name() === 'cli') {
        echo "Error: Could not fetch current market data for symbol: {$symbol}\n";
        exit(1);
    } else {
        if ($compact) {
            // Super compact error widget - 80x20 style with border
            header('Content-Type: text/html');
            echo '<a href="?symbol=' . urlencode($symbol) . '" target="_blank" style="text-decoration:none;display:inline-block;">';
            echo '<span style="
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace;
                font-size: 8px;
                font-weight: 600;
                background: #1a1a2e;
                color: #ff6b6b;
                padding: 2px 6px;
                border-radius: 4px;
                border: 1px solid #ff6b6b;
                display: inline-block;
                white-space: nowrap;
                line-height: 1.4;
                letter-spacing: 0.3px;
                cursor:pointer;
            ">⚠️ ' . htmlspecialchars($symbol) . '</span>';
            echo '</a>';
        } else {
            header('Content-Type: text/html');
            echo "<!DOCTYPE html><html><head><title>Error</title></head><body>";
            echo "<h1>⚠️ Data Fetch Error</h1>";
            echo "<p>Could not fetch current market data for symbol: <strong>{$symbol}</strong></p>";
            echo "</body></html>";
        }
        exit;
    }
}

$ftd = findFollowThroughDay($data);

if (php_sapi_name() === 'cli') {
    // CLI Output
    echo "\n📊 William O'Neil Follow-Through Day Analysis\n";
    echo "============================================\n";
    echo "Symbol: {$symbol}\n";
    echo "Analysis Date: " . date('Y-m-d H:i:s') . "\n";
    echo "Data Points: " . count($data) . " days\n\n";
    
    echo "Recent Market Data (last 10 days):\n";
    echo "--------------------------------------------\n";
    $recent = array_slice($data, -10);
    foreach ($recent as $day) {
        echo $day['date'] . "  \$" . number_format($day['close'], 2) . "  Vol: " . number_format($day['volume']) . "\n";
    }
    echo "--------------------------------------------\n\n";
    
    if ($ftd === null) {
        echo "❌ NO FOLLOW-THROUGH DAY DETECTED\n";
    } else {
        if ($ftd['cancelled']) {
            echo "⚠️  FTD FOUND BUT CANCELLED\n";
        } else {
            echo "✅ FOLLOW-THROUGH DAY CONFIRMED!\n";
        }
        echo "--------------------------------------------\n";
        echo "FTD Date:          {$ftd['date']}\n";
        echo "Day Number:        Day {$ftd['day_number']}\n";
        echo "Strength:          {$ftd['strength']}\n";
        echo "Price Change:      +{$ftd['pct_change']}%\n";
        echo "Close Price:       \$" . number_format($ftd['close'], 2) . "\n";
        echo "Volume:            " . number_format($ftd['volume']) . "\n";
        echo "Recent Low:        \$" . number_format($ftd['low_price'], 2) . " on {$ftd['low_date']}\n";
        echo "Status:            " . ($ftd['cancelled'] ? "CANCELLED" : "ACTIVE ✅") . "\n";
        echo "--------------------------------------------\n";
        echo "Recommendation:    " . ($ftd['cancelled'] ? '⚠️ Go back to cash' : '✅ Safe to start buying') . "\n";
    }
    echo "\n";
    
} else {
    header('Content-Type: text/html');
    if ($compact) {
        echo generateSuperCompactWidget($symbol, $ftd, $data);
    } else {
        echo generateFullReport($symbol, $ftd, $data);
    }
}

/**
 * Generates a SUPER COMPACT widget (80x20 pixel style)
 * With border, rounded corners, and clickable to open full page
 */
function generateSuperCompactWidget(string $symbol, ?array $ftd, array $data): string {
    $lastPrice = end($data);
    $lastClose = $lastPrice['close'] ?? 0;
    
    // Determine status
    $statusText = '';
    $bgColor = '#1a1a2e';
    $borderColor = '#333';
    $textColor = '#888';
    $dotColor = '#666';
    $statusDisplay = '';
    
    if ($ftd !== null) {
        if ($ftd['cancelled']) {
            $statusText = 'CANC';
            $bgColor = '#2d1b00';
            $borderColor = '#ffc107';
            $textColor = '#ffc107';
            $dotColor = '#ffc107';
            $statusDisplay = '⚠️ CANCELLED';
        } else {
            $statusText = 'FTD';
            $bgColor = '#0a1f0a';
            $borderColor = '#28a745';
            $textColor = '#28a745';
            $dotColor = '#28a745';
            $statusDisplay = '✅ FTD CONFIRMED';
        }
    } else {
        $statusText = 'WAIT';
        $bgColor = '#1a1a2e';
        $borderColor = '#555';
        $textColor = '#6c757d';
        $dotColor = '#6c757d';
        $statusDisplay = '⏳ No FTD';
    }
    
    // Get day number if FTD exists
    $dayInfo = '';
    if ($ftd !== null && !$ftd['cancelled']) {
        $dayInfo = ' D' . $ftd['day_number'];
        if ($ftd['day_number'] <= 5) {
            $textColor = '#28a745';
            $borderColor = '#28a745';
        } else {
            $textColor = '#ffc107';
            $borderColor = '#ffc107';
        }
    }
    
    // Build the widget with border, rounded corners, and clickable link
    $html = '<a href="?symbol=' . urlencode($symbol) . '" target="_blank" style="text-decoration:none;display:inline-block;" title="' . htmlspecialchars($symbol) . ' - ' . $statusDisplay . '">';
    $html .= '<span style="
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace;
        font-size: 8px;
        font-weight: 600;
        background: ' . $bgColor . ';
        color: ' . $textColor . ';
        padding: 2px 7px;
        border-radius: 6px;
        border: 1.5px solid ' . $borderColor . ';
        display: inline-block;
        white-space: nowrap;
        line-height: 1.4;
        letter-spacing: 0.3px;
        cursor: pointer;
        transition: all 0.2s ease;
        box-shadow: 0 0 0 0 ' . $borderColor . '40;
    "
    onmouseover="this.style.boxShadow=\'0 0 12px ' . $borderColor . '60\'"
    onmouseout="this.style.boxShadow=\'0 0 0 0 ' . $borderColor . '40\'"
    >' . htmlspecialchars($symbol) . ' $' . number_format($lastClose, 0) . ' <span style="color:' . $dotColor . ';">●</span> ' . $statusText . $dayInfo . '</span>';
    $html .= '</a>';
    
    return $html;
}

/**
 * Generates full HTML report with collapsible recent data section
 */
function generateFullReport(string $symbol, ?array $ftd, array $data): string {
    $isCurrentData = false;
    if (!empty($data)) {
        $lastDate = end($data);
        $lastTimestamp = strtotime($lastDate['date']);
        $thirtyDaysAgo = strtotime('-30 days');
        if ($lastTimestamp > $thirtyDaysAgo) {
            $isCurrentData = true;
        }
    }
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>O\'Neil FTD Analysis - ' . htmlspecialchars($symbol) . '</title>
        <style>
            * { box-sizing: border-box; }
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; max-width: 1000px; margin: 0 auto; padding: 20px; background: #f0f2f5; }
            .container { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #1a1a2e; border-bottom: 3px solid #16213e; padding-bottom: 15px; margin-top: 0; }
            .status-box { padding: 20px; border-radius: 8px; margin: 20px 0; }
            .confirmed { background: #d4edda; border-left: 5px solid #28a745; }
            .cancelled { background: #fff3cd; border-left: 5px solid #ffc107; }
            .none { background: #f8d7da; border-left: 5px solid #dc3545; }
            .grid { display: grid; grid-template-columns: 180px 1fr; gap: 8px; margin: 15px 0; }
            .label { font-weight: 600; color: #555; }
            .value { color: #1a1a2e; }
            .badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
            .badge-success { background: #28a745; color: white; }
            .badge-warning { background: #ffc107; color: #333; }
            .badge-danger { background: #dc3545; color: white; }
            .badge-info { background: #17a2b8; color: white; }
            .footer { margin-top: 30px; padding-top: 15px; border-top: 1px solid #ddd; font-size: 13px; color: #888; }
            .tip { background: #e8f4f8; padding: 15px; border-radius: 6px; margin: 15px 0; }
            .tip strong { color: #0066cc; }
            .data-warning { background: #f8d7da; padding: 10px; border-radius: 6px; margin: 10px 0; color: #721c24; }
            
            details { margin: 20px 0; }
            summary { 
                cursor: pointer; 
                font-weight: 600; 
                font-size: 16px;
                padding: 12px 16px;
                background: #f8f9fa;
                border-radius: 8px;
                border: 1px solid #dee2e6;
                transition: all 0.2s;
                user-select: none;
                display: inline-block;
                width: 100%;
            }
            summary:hover { background: #e9ecef; }
            summary::-webkit-details-marker { color: #0066cc; }
            details[open] summary {
                border-bottom-left-radius: 0;
                border-bottom-right-radius: 0;
                border-bottom: none;
            }
            .details-content {
                padding: 15px;
                border: 1px solid #dee2e6;
                border-top: none;
                border-bottom-left-radius: 8px;
                border-bottom-right-radius: 8px;
                overflow-x: auto;
            }
            
            table { width: 100%; border-collapse: collapse; font-size: 13px; }
            th { background: #f0f2f5; padding: 8px; text-align: left; border-bottom: 2px solid #ddd; }
            td { padding: 6px 8px; border-bottom: 1px solid #eee; }
            .ftd-row { background: #d4edda !important; }
            .low-row { background: #ffeaa7 !important; }
            
            .compact-link {
                display: inline-block;
                margin: 10px 0;
                padding: 6px 12px;
                background: #16213e;
                color: white !important;
                text-decoration: none;
                border-radius: 4px;
                font-size: 12px;
            }
            .compact-link:hover { background: #1a1a2e; }
            
            .widget-demo {
                background: #1a1a2e;
                padding: 15px 20px;
                border-radius: 8px;
                margin: 15px 0;
                border: 1px solid #333;
            }
            .widget-demo label {
                color: #888;
                font-size: 11px;
                display: block;
                margin-bottom: 8px;
                font-weight: 600;
                letter-spacing: 0.5px;
            }
            .widget-demo .status-hint {
                color: #666;
                font-size: 9px;
                margin-top: 6px;
                font-family: monospace;
            }
            .widget-demo .status-hint span {
                display: inline-block;
                margin-right: 10px;
            }
            .color-dot {
                display: inline-block;
                width: 8px;
                height: 8px;
                border-radius: 50%;
                margin-right: 3px;
            }
            
            @media (max-width: 600px) { 
                .grid { grid-template-columns: 1fr; }
                .details-content { padding: 10px; }
                table { font-size: 11px; }
                td, th { padding: 4px 6px; }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📊 William O\'Neil Follow-Through Day Analysis</h1>
            <p><strong>Symbol:</strong> ' . htmlspecialchars($symbol) . '</p>
            <p><small>Analysis Date: ' . date('Y-m-d H:i:s') . ' | Data Points: ' . count($data) . ' days</small></p>
            
            <div class="widget-demo">
                <label>📱 Super Compact Widget (click to open full page in new tab)</label>
                ' . generateSuperCompactWidget($symbol, $ftd, $data) . '
                <div class="status-hint">
                    <span><span class="color-dot" style="background:#28a745;"></span> FTD Early (Day 4-5)</span>
                    <span><span class="color-dot" style="background:#ffc107;"></span> FTD Late (Day 6-7) or Cancelled</span>
                    <span><span class="color-dot" style="background:#6c757d;"></span> No FTD / Waiting</span>
                </div>
            </div>
            
            <a href="?symbol=' . urlencode($symbol) . '&compact" target="_blank" class="compact-link">📱 Open Compact Widget in New Tab</a>';

    if (!$isCurrentData) {
        $html .= '<div class="data-warning">
            ⚠️ <strong>Warning:</strong> The data being displayed may not be current.
        </div>';
    }

    // Collapsible Recent Market Data
    $html .= '<details>
        <summary>📈 Recent Market Data (click to expand/collapse)</summary>
        <div class="details-content">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Close Price</th>
                        <th>Volume</th>
                        <th>Note</th>
                    </tr>
                </thead>
                <tbody>';
    
    $recent = array_slice($data, -15);
    foreach ($recent as $day) {
        $note = '';
        $class = '';
        if ($ftd !== null) {
            if ($day['date'] === $ftd['date']) {
                $note = '🔴 FTD!';
                $class = 'ftd-row';
            } elseif ($ftd !== null && isset($ftd['low_date']) && $day['date'] === $ftd['low_date']) {
                $note = '📉 Low';
                $class = 'low-row';
            }
        }
        $html .= '<tr class="' . $class . '">
            <td>' . $day['date'] . '</td>
            <td>$' . number_format($day['close'], 2) . '</td>
            <td>' . number_format($day['volume']) . '</td>
            <td>' . $note . '</td>
        </tr>';
    }
    $html .= '</tbody></table>
        </div>
    </details>';

    if ($ftd === null) {
        $html .= '<div class="status-box none">
            <h3 style="margin:0;color:#721c24;">❌ No Follow-Through Day Detected</h3>
            <p style="margin:10px 0 0;">No recent FTD found in the current data.</p>
        </div>';
    } else {
        $statusClass = $ftd['cancelled'] ? 'cancelled' : 'confirmed';
        $statusIcon = $ftd['cancelled'] ? '⚠️' : '✅';
        $statusTitle = $ftd['cancelled'] ? 'FTD Found but CANCELLED' : 'Follow-Through Day CONFIRMED';
        
        $html .= '<div class="status-box ' . $statusClass . '">
            <h3 style="margin:0;">' . $statusIcon . ' ' . $statusTitle . '</h3>
            <p style="margin:10px 0 0;">' . ($ftd['cancelled'] 
                ? 'The market undercut the recent low. According to O\'Neil\'s rules, this signal is cancelled and you should go back to cash.'
                : 'O\'Neil\'s framework suggests this is a durable bottom. It may be safe to start putting money back to work.') . '</p>
        </div>
        
        <h2>📋 FTD Details</h2>
        <div class="grid">
            <div class="label">FTD Date:</div>
            <div class="value"><strong>' . $ftd['date'] . '</strong></div>
            
            <div class="label">Day Number:</div>
            <div class="value">Day ' . $ftd['day_number'] . ' of rally attempt</div>
            
            <div class="label">Strength:</div>
            <div class="value"><span class="badge ' . ($ftd['day_number'] <= 5 ? 'badge-success' : 'badge-warning') . '">' . $ftd['strength'] . '</span></div>
            
            <div class="label">Price Change:</div>
            <div class="value" style="color:#28a745;font-weight:bold;">+' . $ftd['pct_change'] . '%</div>
            
            <div class="label">Close Price:</div>
            <div class="value">$' . number_format($ftd['close'], 2) . '</div>
            
            <div class="label">Volume:</div>
            <div class="value">' . number_format($ftd['volume']) . ' (↑ vs previous day: ' . number_format($ftd['prev_day_volume']) . ')</div>
            
            <div class="label">Recent Low:</div>
            <div class="value">$' . number_format($ftd['low_price'], 2) . ' on ' . $ftd['low_date'] . '</div>
            
            <div class="label">Status:</div>
            <div class="value"><span class="badge ' . ($ftd['cancelled'] ? 'badge-danger' : 'badge-success') . '">' . ($ftd['cancelled'] ? 'CANCELLED' : 'ACTIVE') . '</span></div>
        </div>

        <div class="tip">
            <strong>📌 Recommendation:</strong> ' . ($ftd['cancelled'] ? '⚠️ Go back to cash and wait for a new low and fresh FTD.' : '✅ Safe to start putting money back to work (always use stop losses).') . '
        </div>

        <h2>📌 O\'Neil\'s Important Nuances</h2>
        <ul>
            <li><strong>Day ' . $ftd['day_number'] . ' confirmation:</strong> ' . ($ftd['day_number'] <= 5 ? '✅ Early confirmation (most powerful)' : '⚠️ Later confirmation (higher failure rate, can bull trap)') . '</li>
            <li><strong>NASDAQ leadership:</strong> ' . (in_array(strtoupper($symbol), array('QQQ', 'NDX', 'IXIC')) ? '✅ This is a NASDAQ symbol, which tends to lead in O\'Neil\'s framework' : 'ℹ️ Consider using QQQ for better leadership signals') . '</li>
            <li><strong>Failure rate:</strong> About 20-25% of FTDs fail. Always use stop losses.</li>
            <li><strong>Cancellation rule:</strong> If market undercuts the recent low, the signal is cancelled and you go back to cash.</li>
        </ul>';
    }

    $html .= '
        <div class="footer">
            <p><strong>Disclaimer:</strong> This is for educational purposes only. William O\'Neil\'s framework is just one perspective. Always do your own research and use proper risk management.</p>
            <p>Data source: Yahoo Finance | Framework: "How to Make Money in Stocks" by William O\'Neil</p>
            <p><small>Try other symbols: <a href="?symbol=QQQ">QQQ</a> | <a href="?symbol=SPY">SPY</a> | <a href="?symbol=DIA">DIA</a> | <a href="?symbol=AAPL">AAPL</a> | <a href="?symbol=MSTR">MSTR</a></small></p>
        </div>
        </div>
    </body>
    </html>';

    return $html;
}

?>
