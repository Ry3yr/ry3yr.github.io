<?php
/**
 * spreadcheck.php?symbol=RIG
 * spreadcheck.php?symbol=CA53687L2012
 * spreadcheck.php?symbol=LITSF
 * spreadcheck.php?symbol=RIG&compact=1
 * spreadcheck.php?action=history&symbol=RIG&target=8.00
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

const MAX_SPREAD_PCT = 5.0;
const FULL_ASK_SIZE  = 1000;
const FULL_BID_SIZE  = 1000;
const MIN_ASK_SIZE   = 100;
const MIN_BID_SIZE   = 100;

const ROBINHOOD_API = 'https://api.robinhood.com/quotes/{symbol}/';
const RH_HEADERS    = [
    'Accept: application/json',
    'User-Agent: Mozilla/5.0 (compatible; SpreadCheck/1.0)',
];
const YAHOO_UA      = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                    . 'AppleWebKit/537.36 (KHTML, like Gecko) '
                    . 'Chrome/131.0.0.0 Safari/537.36';

// ===========================================================================
// Bewertung (muss VOR der AJAX-Route definiert sein)
// ===========================================================================
function sizeCheck(string $sideLabel, ?int $size, int $full, int $min): array
{
    if ($size === null) {
        return ['label' => $sideLabel, 'ok' => false, 'detail' => 'k.A.', 'limited' => false];
    }
    if ($size >= $full) {
        return ['label' => $sideLabel, 'ok' => true, 'detail' => number_format($size) . ' Stk. (voll)', 'limited' => false];
    }
    if ($size >= $min) {
        return ['label' => $sideLabel, 'ok' => true, 'detail' => number_format($size) . ' Stk. (begrenzt)', 'limited' => true];
    }
    return ['label' => $sideLabel, 'ok' => false, 'detail' => number_format($size) . ' Stk. (zu dünn)', 'limited' => false];
}

function evaluate(array $d): array
{
    $checks = [];

    $checks[] = [
        'label'  => 'Handelbar',
        'ok'     => $d['tradeable'] && !$d['trading_halted'],
        'detail' => $d['tradeable'] ? ($d['trading_halted'] ? 'Ausgesetzt' : 'Ja') : 'Nein',
        'limited'=> false,
    ];

    $spreadPct = ($d['bid'] && $d['ask'] && $d['ask'] >= $d['bid'])
        ? ($d['ask'] - $d['bid']) / $d['ask'] * 100
        : null;

    $checks[] = [
        'label'  => 'Spread unter ' . MAX_SPREAD_PCT . ' %',
        'ok'     => $spreadPct !== null && $spreadPct <= MAX_SPREAD_PCT,
        'detail' => $spreadPct !== null ? number_format($spreadPct, 2) . ' %' : 'k.A.',
        'limited'=> false,
    ];

    $checks[] = sizeCheck('Verkaufsseite (Ask)', $d['ask_size'], FULL_ASK_SIZE, MIN_ASK_SIZE);
    $checks[] = sizeCheck('Kaufseite (Bid)',    $d['bid_size'], FULL_BID_SIZE, MIN_BID_SIZE);

    $failed  = array_values(array_filter($checks, fn($c) => !$c['ok']));
    $limited = (bool) array_filter($checks, fn($c) => !empty($c['limited']));

    if (!empty($failed))      $verdict = 'reject';
    elseif ($limited)         $verdict = 'limited';
    else                      $verdict = 'accept';

    return [
        'checks'     => $checks,
        'failed'     => $failed,
        'verdict'    => $verdict,
        'spread_pct' => $spreadPct,
        'limited'    => $limited,
    ];
}

// ===========================================================================
// Datenquellen
// ===========================================================================
function fetchRobinhood(string $symbol): ?array
{
    $url = str_replace('{symbol}', urlencode($symbol), ROBINHOOD_API);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_HTTPHEADER     => RH_HEADERS,
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false || $code !== 200) return null;
    $data = json_decode($body, true);
    return is_array($data) ? $data : null;
}

function resolveYahooSymbol(string $query): ?string
{
    $url = 'https://query2.finance.yahoo.com/v1/finance/search?'
         . http_build_query([
             'q'           => $query,
             'quotesCount' => 3,
             'newsCount'   => 0,
         ]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_USERAGENT      => YAHOO_UA,
        CURLOPT_HTTPHEADER     => ['Accept: application/json'],
    ]);
    $body = curl_exec($ch);
    curl_close($ch);
    if ($body === false) return null;

    $data = json_decode($body, true);
    foreach (($data['quotes'] ?? []) as $q) {
        if (!empty($q['symbol'])) return $q['symbol'];
    }
    return null;
}

function fetchYahooHistory(string $symbol, string $range = '5y'): ?array
{
    $url = 'https://query2.finance.yahoo.com/v8/finance/chart/'
         . urlencode($symbol)
         . '?interval=1d&range=' . urlencode($range);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_USERAGENT      => YAHOO_UA,
        CURLOPT_HTTPHEADER     => [
            'Accept: application/json',
            'Accept-Language: en-US,en;q=0.9',
        ],
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false || $code !== 200) return null;
    $data = json_decode($body, true);
    return $data['chart']['result'][0] ?? null;
}

// ===========================================================================
// Historische Analyse (3 Perioden + Recency + Trend + Drawdown)
// ===========================================================================
function analyzePeriod(string $symbol, float $target, string $range): array
{
    $result = fetchYahooHistory($symbol, $range);
    if ($result === null) {
        return ['error' => 'Keine Daten für ' . $range];
    }

    $quote = $result['indicators']['quote'][0] ?? [];
    $highs = $quote['high'] ?? [];

    $total   = 0;
    $reached = 0;
    $maxHigh = 0.0;
    $minLow  = PHP_FLOAT_MAX;

    foreach ($highs as $h) {
        if ($h === null) continue;
        $total++;
        if ($h > $maxHigh) $maxHigh = (float) $h;
        if ($h < $minLow)  $minLow  = (float) $h;
        if ($h >= $target) $reached++;
    }
    if ($minLow === PHP_FLOAT_MAX) $minLow = 0.0;
    if ($total === 0) return ['error' => 'Keine Datenpunkte für ' . $range];

    $pct   = ($reached / $total) * 100.0;
    $score = (int) round(min(100, $pct * 2));

    return [
        'range'    => $range,
        'total'    => $total,
        'reached'  => $reached,
        'pct'      => round($pct, 2),
        'score'    => $score,
        'max_high' => round($maxHigh, 4),
        'min_low'  => round($minLow, 4),
    ];
}

function determineTrend(array $periods): string
{
    // Vergleicht die Maxima der Perioden: Wenn das 1J-Max deutlich unter dem 5J-Max liegt → fallend
    $p1 = $periods['1y']['max_high'] ?? null;
    $p3 = $periods['3y']['max_high'] ?? null;
    $p5 = $periods['5y']['max_high'] ?? null;

    if ($p1 === null || $p5 === null || $p5 <= 0) return 'unbekannt';

    $ratio = $p1 / $p5;

    if ($ratio >= 0.85) return 'steigend';
    if ($ratio >= 0.5)  return 'seitwärts';
    if ($ratio >= 0.2)  return 'fallend';
    return 'stark fallend';
}

function drawdown(float $current, float $max): float
{
    if ($max <= 0) return 0.0;
    return (($current - $max) / $max) * 100.0;
}

function scoreTarget(string $symbol, float $target, float $currentPrice = 0.0): array
{
    $periods = [];
    foreach (['1y', '3y', '5y'] as $range) {
        $periods[$range] = analyzePeriod($symbol, $target, $range);
    }

    // Wenn eine Periode fehlschlägt, alles abbrechen
    foreach ($periods as $p) {
        if (isset($p['error'])) return ['error' => 'Historische Daten unvollständig.'];
    }

    // Recency-gewichteter Score
    $weighted = 0.5 * $periods['1y']['score']
              + 0.3 * $periods['3y']['score']
              + 0.2 * $periods['5y']['score'];
    $weighted = (int) round($weighted);

    // Trend + Drawdown
    $trend = determineTrend($periods);
    $dd5y  = $currentPrice > 0 ? drawdown($currentPrice, $periods['5y']['max_high']) : null;
    $dd1y  = $currentPrice > 0 ? drawdown($currentPrice, $periods['1y']['max_high']) : null;

    // --- Rating-Logik (strenger als vorher) ---
    // 1) Wenn das Ziel über dem 5J-Hoch liegt → unrealistisch
    if ($target > $periods['5y']['max_high']) {
        $rating = 'unrealistisch';
        $hint   = 'Ziel liegt über dem 5-Jahres-Hoch ('
                . number_format($periods['5y']['max_high'], 2) . ' $).';
    }
    // 2) Wenn das Ziel in den letzten 12 Monaten NIE erreicht wurde → unrealistisch
    elseif ($periods['1y']['reached'] === 0) {
        $rating = 'unrealistisch';
        $hint   = 'Ziel wurde in den letzten 12 Monaten nie erreicht.';
    }
    // 3) Wenn stark fallender Trend + starker Drawdown → spekulativ
    elseif ($trend === 'stark fallend' && $dd5y !== null && $dd5y < -80) {
        $rating = 'spekulativ';
        $hint   = 'Trend stark fallend (' . number_format($dd5y, 1) . ' % vom 5J-Hoch). '
                . 'Ziel in der aktuellen Verfassung unwahrscheinlich.';
    }
    // 4) Recency-Score-basiert
    elseif ($weighted >= 80) {
        $rating = 'realistisch';
        $hint   = 'Ziel wurde in allen Perioden häufig erreicht.';
    } elseif ($weighted >= 50) {
        $rating = 'möglich';
        $hint   = 'Ziel wurde in jüngerer Vergangenheit erreicht, ältere Perioden schwächer.';
    } elseif ($weighted >= 20) {
        $rating = 'spekulativ';
        $hint   = 'Ziel wurde selten erreicht – vor allem ältere Perioden tragen zum Score bei.';
    } else {
        $rating = 'unwahrscheinlich';
        $hint   = 'Ziel wurde fast nie erreicht.';
    }

    return [
        'symbol'      => $symbol,
        'target'      => $target,
        'score'       => $weighted,
        'rating'      => $rating,
        'hint'        => $hint,
        'trend'       => $trend,
        'drawdown_1y' => $dd1y !== null ? round($dd1y, 2) : null,
        'drawdown_5y' => $dd5y !== null ? round($dd5y, 2) : null,
        'periods'     => $periods,
        'max_high'    => $periods['5y']['max_high'],
    ];
}

// ===========================================================================
// AJAX-Route (VOR jeder HTML-Ausgabe)
// ===========================================================================
if (($_GET['action'] ?? '') === 'history') {
    header('Content-Type: application/json; charset=utf-8');
    $ajaxSymbol = isset($_GET['symbol']) ? strtoupper(trim($_GET['symbol'])) : '';
    $ajaxTarget = isset($_GET['target']) ? (float) str_replace(',', '.', $_GET['target']) : 0.0;
    $ajaxPrice  = isset($_GET['price'])  ? (float) str_replace(',', '.', $_GET['price'])  : 0.0;

    if ($ajaxSymbol === '' || $ajaxTarget <= 0) {
        echo json_encode(['error' => 'symbol und target erforderlich']);
        exit;
    }

    $yahooSymbol = resolveYahooSymbol($ajaxSymbol);
    if ($yahooSymbol === null) {
        echo json_encode(['error' => 'Symbol konnte nicht aufgelöst werden.']);
        exit;
    }

    echo json_encode(
        scoreTarget($yahooSymbol, $ajaxTarget, $ajaxPrice),
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

// ===========================================================================
// Eingabe
// ===========================================================================
$symbol  = isset($_GET['symbol'])  ? strtoupper(trim($_GET['symbol'])) : '';
$format  = $_GET['format']  ?? 'html';
$compact = isset($_GET['compact']) && $_GET['compact'] !== '0';

if ($symbol === '') {
    header('Content-Type: text/html; charset=utf-8');
    http_response_code(400);
    exit('<h1>Fehler: Parameter ?symbol= fehlt</h1>');
}

// ===========================================================================
// Datenbeschaffung mit 404-Fallback
// ===========================================================================
$source     = 'robinhood';
$displaySym = $symbol;
$raw        = fetchRobinhood($symbol);

if ($raw === null || isset($raw['_error'])) {
    $yahooSymbol = resolveYahooSymbol($symbol);
    if ($yahooSymbol !== null) {
        $chart = fetchYahooHistory($yahooSymbol, '5d');
        if ($chart !== null) {
            $meta     = $chart['meta'] ?? [];
            $quoteArr = $chart['indicators']['quote'][0] ?? [];
            $closes   = $quoteArr['close']  ?? [];
            $vols     = $quoteArr['volume'] ?? [];

            $lastClose  = null;
            $lastVolume = null;
            for ($i = count($closes) - 1; $i >= 0; $i--) {
                if (isset($closes[$i]) && $closes[$i] !== null) {
                    $lastClose  = (float) $closes[$i];
                    $lastVolume = isset($vols[$i]) ? (int) $vols[$i] : null;
                    break;
                }
            }

            $raw = [
                'symbol'           => $meta['symbol'] ?? $yahooSymbol,
                'last_trade_price' => $meta['regularMarketPrice'] ?? $lastClose,
                'previous_close'   => $meta['previousClose'] ?? null,
                'bid_price'        => null,
                'ask_price'        => null,
                'bid_size'         => null,
                'ask_size'         => null,
                'regular_volume'   => $lastVolume,
                '_source'          => 'yahoo',
            ];
            $source     = 'yahoo';
            $displaySym = $meta['symbol'] ?? $yahooSymbol;
        }
    }
}

if ($raw === null || (isset($raw['_error']) && !isset($raw['_source']))) {
    if ($compact) {
        header('Content-Type: text/html; charset=utf-8');
        $fullUrl = '?' . http_build_query(['symbol' => $symbol]);
        ?>
<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;background:transparent;overflow:hidden;}
a.widget{
    display:flex;align-items:center;justify-content:center;
    width:40px;height:15px;border-radius:3px;
    background:#555;color:#fff;font:9px/1 monospace;
    text-decoration:none;cursor:pointer;box-sizing:border-box;
}
</style></head><body>
<a class="widget" href="<?= htmlspecialchars($fullUrl) ?>" target="_blank" title="Fehler beim Laden">?</a>
</body></html>
        <?php
        exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    http_response_code(404);
    exit('<h1>Nicht gefunden</h1><p>Symbol ' . htmlspecialchars($symbol)
        . ' ist weder bei Robinhood noch bei Yahoo Finance verfügbar.</p>');
}

// ===========================================================================
// Normalisieren
// ===========================================================================
function normalize(array $raw, string $symbol): array
{
    return [
        'symbol'         => $raw['symbol'] ?? $symbol,
        'name'           => $raw['symbol'] ?? $symbol,
        'price'          => isset($raw['last_trade_price']) ? (float) $raw['last_trade_price'] : null,
        'previous_close' => isset($raw['previous_close'])   ? (float) $raw['previous_close']   : null,
        'bid'            => isset($raw['bid_price'])        ? (float) $raw['bid_price']        : null,
        'ask'            => isset($raw['ask_price'])        ? (float) $raw['ask_price']        : null,
        'bid_size'       => isset($raw['bid_size'])         ? (int)   $raw['bid_size']         : null,
        'ask_size'       => isset($raw['ask_size'])         ? (int)   $raw['ask_size']         : null,
        'volume'         => $raw['regular_volume'] ?? null,
        'tradeable'      => true,
        'trading_halted' => false,
        'timestamp'      => date('Y-m-d H:i:s'),
        'source'         => $raw['_source'] ?? 'robinhood',
    ];
}

$data       = normalize($raw, $symbol);
$evaluation = evaluate($data);
$verdict    = $evaluation['verdict'];

// ===========================================================================
// Widget
// ===========================================================================
if ($compact) {
    header('Content-Type: text/html; charset=utf-8');
    $fullUrl = '?' . http_build_query(['symbol' => $symbol]);

    $colors = [
        'accept'  => ['bg' => '#2ecc71', 'fg' => '#0f1115'],
        'limited' => ['bg' => '#f1c40f', 'fg' => '#0f1115'],
        'reject'  => ['bg' => '#e74c3c', 'fg' => '#ffffff'],
    ];
    $c = $colors[$verdict] ?? $colors['reject'];

    $short = $displaySym;
    if (strlen($short) > 5) $short = substr($short, 0, 5);

    $spreadText = $evaluation['spread_pct'] !== null
        ? number_format($evaluation['spread_pct'], 1) . '%'
        : '–';

    $title = $displaySym . ' – ' . strtoupper($verdict);
    if ($evaluation['spread_pct'] !== null) {
        $title .= ' · Spread ' . number_format($evaluation['spread_pct'], 2) . '%';
    }
    ?>
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title><?= htmlspecialchars($displaySym) ?></title><style>
html,body{margin:0;padding:0;background:transparent;overflow:hidden;}
a.widget{
    display:flex;align-items:center;justify-content:space-between;
    width:40px;height:15px;padding:0 3px;border-radius:3px;
    background:<?= $c['bg'] ?>;color:<?= $c['fg'] ?>;
    font:9px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",monospace;
    font-weight:600;letter-spacing:.1px;
    text-decoration:none;cursor:pointer;
    transition:filter .15s ease;
    box-sizing:border-box;
}
a.widget:hover{filter:brightness(1.1);}
a.widget .dot{
    width:4px;height:4px;border-radius:50%;
    background:<?= $c['fg'] ?>;opacity:.85;flex-shrink:0;
}
a.widget .label{
    flex:1;text-align:center;white-space:nowrap;overflow:hidden;
    font-size:8px;
}
a.widget .spread{
    white-space:nowrap;font-size:8px;opacity:.9;
}
</style></head><body>
<a class="widget"
   href="<?= htmlspecialchars($fullUrl) ?>"
   target="_blank"
   rel="noopener"
   title="<?= htmlspecialchars($title) ?>">
    <span class="dot"></span>
    <span class="label"><?= htmlspecialchars($short) ?></span>
    <span class="spread"><?= htmlspecialchars($spreadText) ?></span>
</a>
</body></html>
    <?php
    exit;
}

// ===========================================================================
// JSON
// ===========================================================================
if ($format === 'json') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'symbol'     => $symbol,
        'data'       => $data,
        'evaluation' => $evaluation,
        'raw'        => $raw,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// ===========================================================================
// Vollansicht
// ===========================================================================
header('Content-Type: text/html; charset=utf-8');
$failed       = $evaluation['failed'];
$checks       = $evaluation['checks'];
$spreadPct    = $evaluation['spread_pct'];
$buyPrefill   = $data['price'] !== null ? number_format($data['price'], 4, '.', '') : '';
$limitedSizes = array_values(array_filter($checks, fn($c) => !empty($c['limited'])));
$sourceBadge  = $source === 'yahoo' ? 'Yahoo Finance' : 'Robinhood';
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($displaySym) ?> – Handelbarkeits-Check</title>
<style>
    :root {
        --bg:#0f1115; --card:#1a1d24; --card2:#232730;
        --text:#e8eaed; --muted:#9aa0a6;
        --green:#2ecc71; --red:#e74c3c; --yellow:#f1c40f;
        --border:#2a2f3a; --accent:#4a9eff;
    }
    * { box-sizing: border-box; }
    body {
        margin:0; padding:24px; background:var(--bg); color:var(--text);
        font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
        line-height:1.5;
    }
    .container { max-width:720px; margin:0 auto; }
    .header { display:flex; align-items:baseline; gap:12px; margin-bottom:4px; flex-wrap:wrap; }
    .header h1 { margin:0; font-size:28px; }
    .ticker { font-family:monospace; font-size:16px; color:var(--muted); }
    .source-badge {
        font-size:11px; padding:2px 8px; border-radius:10px;
        background:var(--card2); color:var(--muted);
        text-transform:uppercase; letter-spacing:.5px;
    }
    .subtitle { color:var(--muted); margin-bottom:24px; }

    .verdict {
        display:flex; align-items:center; gap:16px;
        padding:20px 24px; border-radius:12px;
        margin-bottom:24px; font-size:18px; font-weight:600;
    }
    .verdict.accept  { background:rgba(46,204,113,.12); border:1px solid var(--green);  color:var(--green); }
    .verdict.limited { background:rgba(241,196,15,.12); border:1px solid var(--yellow); color:var(--yellow); }
    .verdict.reject  { background:rgba(231,76,60,.12);  border:1px solid var(--red);    color:var(--red); }
    .verdict .icon { font-size:32px; }
    .verdict .text small {
        display:block; font-weight:400; font-size:14px;
        color:var(--muted); margin-top:4px;
    }

    .price-row { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:24px; }
    .price-box {
        background:var(--card); border:1px solid var(--border);
        border-radius:10px; padding:16px; text-align:center;
    }
    .price-box .label { font-size:12px; color:var(--muted); text-transform:uppercase; letter-spacing:.5px; }
    .price-box .value { font-size:22px; font-weight:600; margin-top:6px; }
    .price-box.bid .value { color:var(--red); }
    .price-box.ask .value { color:var(--green); }

    h2 {
        font-size:16px; text-transform:uppercase; letter-spacing:.5px;
        color:var(--muted); margin:32px 0 12px;
    }

    .check {
        display:flex; align-items:center; gap:14px;
        background:var(--card); border:1px solid var(--border);
        border-radius:10px; padding:14px 18px; margin-bottom:8px;
    }
    .check .dot { width:10px; height:10px; border-radius:50%; flex-shrink:0; }
    .check.ok           .dot { background:var(--green); box-shadow:0 0 8px var(--green); }
    .check.ok.limited   .dot { background:var(--yellow); box-shadow:0 0 8px var(--yellow); }
    .check.fail         .dot { background:var(--red);   box-shadow:0 0 8px var(--red); }
    .check .label { flex:1; }
    .check .detail { font-family:monospace; color:var(--muted); font-size:14px; }
    .check.fail .detail { color:var(--red); }
    .check.ok.limited .detail { color:var(--yellow); }

    .calc {
        background:var(--card); border:1px solid var(--border);
        border-radius:12px; padding:20px; margin-top:24px;
    }
    .calc-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:14px; }
    .calc label {
        display:block; font-size:12px; color:var(--muted);
        text-transform:uppercase; letter-spacing:.5px; margin-bottom:6px;
    }
    .calc input[type="text"] {
        width:100%; background:var(--card2); border:1px solid var(--border);
        border-radius:8px; padding:10px 12px; color:var(--text);
        font-size:16px; font-family:monospace;
    }
    .calc input[type="text"]:focus { outline:none; border-color:var(--accent); }

    .radio-row {
        display:flex; gap:18px; margin:6px 0 16px;
        font-size:14px; color:var(--muted);
    }
    .radio-row label { display:flex; align-items:center; gap:6px; cursor:pointer; }
    .radio-row input[type="radio"] { accent-color:var(--accent); }

    .result-grid {
        display:grid; grid-template-columns:1fr 1fr; gap:10px;
        margin-top:16px; padding-top:16px;
        border-top:1px solid var(--border);
    }
    .result-item { display:flex; justify-content:space-between; font-size:14px; padding:6px 0; }
    .result-item .k { color:var(--muted); }
    .result-item .v { font-family:monospace; font-weight:600; }
    .result-item .v.pos  { color:var(--green); }
    .result-item .v.neg  { color:var(--red); }
    .result-item .v.warn { color:var(--yellow); }
    .result-wide { grid-column:1 / -1; }

    .history-block {
        margin-top:18px; padding-top:16px;
        border-top:1px solid var(--border);
    }
    .btn-history {
        width:100%; padding:11px 16px;
        background:var(--accent); color:#fff;
        border:none; border-radius:8px;
        font-size:14px; font-weight:600; cursor:pointer;
        transition:opacity .15s ease;
    }
    .btn-history:disabled { opacity:.4; cursor:not-allowed; }
    .btn-history:not(:disabled):hover { opacity:.9; }
    .history-result {
        margin-top:12px;
        background:var(--card2); border-radius:8px;
        padding:14px 16px; font-size:14px;
    }
    .history-result .score-line {
        display:flex; justify-content:space-between;
        align-items:baseline; margin-bottom:6px;
    }
    .history-result .score-line .score {
        font-family:monospace; font-weight:700; font-size:18px;
    }
    .history-result .rating {
        font-weight:600; text-transform:uppercase;
        letter-spacing:.5px; font-size:12px;
    }
    .history-result .rating.realistisch   { color:var(--green); }
    .history-result .rating.moeglich      { color:var(--green); }
    .history-result .rating.spekulativ    { color:var(--yellow); }
    .history-result .rating.unwahrscheinlich,
    .history-result .rating.unrealistisch { color:var(--red); }
    .history-result .bar {
        height:6px; background:rgba(255,255,255,.08);
        border-radius:3px; overflow:hidden; margin:8px 0 10px;
    }
    .history-result .bar > div {
        height:100%; background:var(--accent);
        transition:width .4s ease;
    }
    .history-result .periods {
        width:100%; margin-top:10px; border-collapse:collapse;
        font-size:12px;
    }
    .history-result .periods th,
    .history-result .periods td {
        padding:5px 8px; text-align:left;
        border-bottom:1px solid rgba(255,255,255,.05);
    }
    .history-result .periods th { color:var(--muted); font-weight:500; }
    .history-result .periods td.num { font-family:monospace; text-align:right; }
    .history-result .trend-line {
        margin-top:10px; font-size:13px;
    }
    .history-result .trend-line .trend-tag {
        display:inline-block; padding:2px 8px; border-radius:10px;
        background:rgba(255,255,255,.08); font-weight:600;
        text-transform:uppercase; letter-spacing:.5px; font-size:11px;
    }
    .history-result .trend-tag.steigend      { color:var(--green); background:rgba(46,204,113,.15); }
    .history-result .trend-tag.seitwaerts    { color:var(--yellow); background:rgba(241,196,15,.15); }
    .history-result .trend-tag.fallend,
    .history-result .trend-tag.stark-fallend { color:var(--red); background:rgba(231,76,60,.15); }
    .history-result .details {
        font-size:12px; color:var(--muted); line-height:1.6; margin-top:10px;
    }

    .explain {
        background:var(--card2); border-left:3px solid var(--yellow);
        padding:14px 18px; border-radius:6px;
        font-size:14px; color:var(--muted); margin-top:24px;
    }
    .explain strong { color:var(--text); }
    .explain.hard { border-left-color:var(--red); }
    .explain.info { border-left-color:var(--accent); margin-top:0; margin-bottom:24px; }

    .footer { margin-top:32px; font-size:12px; color:var(--muted); text-align:center; }
</style>
</head>
<body>
<div class="container">

    <div class="header">
        <h1><?= htmlspecialchars($data['symbol']) ?></h1>
        <span class="ticker"><?= htmlspecialchars($symbol) ?></span>
        <span class="source-badge"><?= htmlspecialchars($sourceBadge) ?></span>
    </div>
    <div class="subtitle">Handelbarkeits-Check für deine Strategie</div>

    <div class="verdict <?= $verdict ?>">
        <div class="icon">
            <?= $verdict === 'accept' ? '✓' : ($verdict === 'limited' ? '!' : '✕') ?>
        </div>
        <div class="text">
            <?php if ($verdict === 'accept'): ?>
                Geeignet – alle Kriterien erfüllt
                <small>Du kannst diese Aktie in voller Ordergröße handeln.</small>
            <?php elseif ($verdict === 'limited'): ?>
                Begrenzt handelbar – <?= count($limitedSizes) ?> Seite(n) dünn
                <small>Der Spread ist okay, aber das Orderbuch hat an der Spitze
                       nur eine begrenzte Menge.</small>
            <?php else: ?>
                Nicht geeignet – <?= count($failed) ?> Kriterium(en) verletzt
                <small>Der Spread oder die Orderbuch-Tiefe machen einen sauberen
                       Ein- und Ausstieg unmöglich.</small>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($source === 'yahoo'): ?>
    <div class="explain info">
        <strong>Hinweis:</strong> Robinhood kennt dieses Symbol nicht.
        Die Daten stammen aus Yahoo Finance. Bid/Ask und Orderbuch-Tiefe
        stehen dort nicht zur Verfügung – Spread und Orderbuch sind „k.A.".
        Der Realismus-Check funktioniert weiterhin.
    </div>
    <?php endif; ?>

    <div class="price-row">
        <div class="price-box bid">
            <div class="label">Bid (Markt)</div>
            <div class="value"><?= $data['bid'] !== null ? number_format($data['bid'], 4) . ' $' : '–' ?></div>
        </div>
        <div class="price-box">
            <div class="label">Letzter Kurs</div>
            <div class="value"><?= $data['price'] !== null ? number_format($data['price'], 4) . ' $' : '–' ?></div>
        </div>
        <div class="price-box ask">
            <div class="label">Ask (Markt)</div>
            <div class="value"><?= $data['ask'] !== null ? number_format($data['ask'], 4) . ' $' : '–' ?></div>
        </div>
    </div>

    <h2>Prüfungen</h2>
    <?php foreach ($checks as $c): ?>
        <?php
            $cls = 'check ';
            if (!$c['ok']) $cls .= 'fail';
            elseif (!empty($c['limited'])) $cls .= 'ok limited';
            else $cls .= 'ok';
        ?>
        <div class="<?= $cls ?>">
            <div class="dot"></div>
            <div class="label"><?= htmlspecialchars($c['label']) ?></div>
            <div class="detail"><?= htmlspecialchars($c['detail']) ?></div>
        </div>
    <?php endforeach; ?>

    <h2>Trade-Rechner</h2>
    <div class="calc">
        <div class="calc-grid">
            <div>
                <label for="buy">Buy-Preis ($)</label>
                <input type="text" id="buy" inputmode="decimal" autocomplete="off"
                       value="<?= htmlspecialchars($buyPrefill) ?>">
            </div>
            <div>
                <label for="sell">Sell-Preis ($)</label>
                <input type="text" id="sell" inputmode="decimal" autocomplete="off" value="">
            </div>
        </div>

        <label>Ordervolumen eingeben als</label>
        <div class="radio-row">
            <label>
                <input type="radio" name="mode" value="shares" checked>
                Stückzahl
            </label>
            <label>
                <input type="radio" name="mode" value="money">
                Betrag in €
            </label>
        </div>

        <div class="calc-grid">
            <div>
                <label for="shares">Stückzahl</label>
                <input type="text" id="shares" inputmode="numeric" autocomplete="off" value="0">
            </div>
            <div>
                <label for="money">Betrag (€)</label>
                <input type="text" id="money" inputmode="decimal" autocomplete="off" value="0">
            </div>
        </div>

        <div class="result-grid">
            <div class="result-item">
                <span class="k">Kaufkosten</span>
                <span class="v" id="r-cost">–</span>
            </div>
            <div class="result-item">
                <span class="k">Verkaufserlös</span>
                <span class="v" id="r-revenue">–</span>
            </div>
            <div class="result-item">
                <span class="k">Gewinn / Verlust</span>
                <span class="v" id="r-profit">–</span>
            </div>
            <div class="result-item">
                <span class="k">Rendite</span>
                <span class="v" id="r-return">–</span>
            </div>
            <div class="result-item result-wide">
                <span class="k">Orderbuch-Deckung</span>
                <span class="v" id="r-cover">–</span>
            </div>
        </div>

        <div class="history-block">
            <button type="button" id="btn-history" class="btn-history" disabled>
                Historischen Realismus prüfen
            </button>
            <div class="history-result" id="history-result" style="display:none;"></div>
        </div>
    </div>

    <?php if (!empty($failed)): ?>
    <div class="explain hard">
        <strong>Was bedeutet das?</strong><br>
        <?php foreach ($failed as $c): ?>
            • <strong><?= htmlspecialchars($c['label']) ?></strong> –
              aktuell <?= htmlspecialchars($c['detail']) ?>.<br>
        <?php endforeach; ?>
        <?php if ($spreadPct !== null): ?>
        <br>
        Bei einem Spread von <?= number_format($spreadPct, 2) ?> %
        verlierst du beim Kauf und sofortigen Verkauf
        <?= number_format($spreadPct, 2) ?> % deines Einsatzes – noch bevor
        sich der Kurs überhaupt bewegt hat.
        <?php endif; ?>
    </div>
    <?php elseif (!empty($limitedSizes)): ?>
    <div class="explain">
        <strong>Begrenzt handelbar – was heißt das?</strong><br>
        <?php foreach ($limitedSizes as $c): ?>
            • <strong><?= htmlspecialchars($c['label']) ?></strong> –
              aktuell <?= htmlspecialchars($c['detail']) ?>.<br>
        <?php endforeach; ?>
        <br>
        Der Wert ist nicht illiquide – aber an der Orderbuch-Spitze liegt nur
        eine begrenzte Menge.
    </div>
    <?php endif; ?>

    <div class="footer">
        Stand: <?= htmlspecialchars($data['timestamp']) ?> ·
        Datenquelle: <?= htmlspecialchars($sourceBadge) ?>
    </div>

</div>

<script>
(function () {
    const MARKET_ASK_SIZE = <?= (int) ($data['ask_size'] ?? 0) ?>;
    const MARKET_BID_SIZE = <?= (int) ($data['bid_size'] ?? 0) ?>;
    const SYMBOL          = <?= json_encode($symbol) ?>;

    const $ = id => document.getElementById(id);
    const buyEl    = $('buy');
    const sellEl   = $('sell');
    const sharesEl = $('shares');
    const moneyEl  = $('money');
    const btnHistory   = $('btn-history');
    const historyBlock = $('history-result');

    function parseNum(v) {
        if (v === null || v === undefined) return 0;
        let s = String(v).trim();
        if (s === '') return 0;
        s = s.replace(/\s/g, '');
        const hasComma = s.includes(',');
        const hasDot   = s.includes('.');
        if (hasComma && hasDot) {
            if (s.lastIndexOf(',') > s.lastIndexOf('.')) {
                s = s.replace(/\./g, '').replace(',', '.');
            } else {
                s = s.replace(/,/g, '');
            }
        } else if (hasComma) {
            s = s.replace(',', '.');
        }
        const n = parseFloat(s);
        return isNaN(n) ? 0 : n;
    }

    function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, c => ({
            '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
        }[c]));
    }

    function currentMode() {
        return document.querySelector('input[name="mode"]:checked').value;
    }
    function getBuy()  { return parseNum(buyEl.value); }
    function getSell() { return parseNum(sellEl.value); }

    function getShares() {
        if (currentMode() === 'shares') return parseNum(sharesEl.value);
        const buy = getBuy();
        const money = parseNum(moneyEl.value);
        return buy > 0 ? money / buy : 0;
    }

    const fmtMoney = n =>
        n.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';

    function syncMoneyField() {
        const buy = getBuy();
        const shares = parseNum(sharesEl.value);
        const money = shares * buy;
        moneyEl.value = money > 0 ? money.toFixed(2) : '0';
    }

    function updateHistoryButton() {
        btnHistory.disabled = !(getSell() > 0);
    }

    btnHistory.addEventListener('click', async (e) => {
        e.preventDefault();
        const sell = getSell();
        if (!(sell > 0)) return;

        btnHistory.disabled = true;
        btnHistory.textContent = 'Prüfe …';
        historyBlock.style.display = 'none';

        try {
            const params = new URLSearchParams({
                action: 'history',
                symbol: SYMBOL,
                target: sell.toFixed(4),
                price:  (getBuy() > 0 ? getBuy() : 0).toFixed(4)
            });
            const res = await fetch('?' + params.toString(), {
                headers: { 'Accept': 'application/json' },
                cache:   'no-store'
            });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();

            if (data.error) {
                historyBlock.innerHTML =
                    '<div class="details">Fehler: ' + escapeHtml(data.error) + '</div>';
                historyBlock.style.display = 'block';
                return;
            }

            const ratingClass = (data.rating || '').replace('ö','oe');
            const trendClass  = (data.trend   || '').replace('ä','ae').replace(' ','-');
            const barWidth    = Math.min(100, data.score);

            // Perioden-Tabelle
            let periodRows = '';
            const order = ['1y','3y','5y'];
            const labels = { '1y':'12 Monate', '3y':'3 Jahre', '5y':'5 Jahre' };
            for (const key of order) {
                const p = data.periods[key];
                if (!p) continue;
                periodRows += `
                    <tr>
                        <td>${labels[key]}</td>
                        <td class="num">${p.reached} / ${p.total}</td>
                        <td class="num">${(p.pct).toFixed(2)} %</td>
                        <td class="num">${(p.max_high).toFixed(2)} $</td>
                    </tr>
                `;
            }

            const dd5 = data.drawdown_5y !== null
                ? data.drawdown_5y.toFixed(1) + ' %'
                : '–';

            historyBlock.innerHTML = `
                <div class="score-line">
                    <span class="score">${data.score} / 100</span>
                    <span class="rating ${ratingClass}">${escapeHtml(data.rating)}</span>
                </div>
                <div class="bar"><div style="width:${barWidth}%"></div></div>
                <table class="periods">
                    <thead>
                        <tr>
                            <th>Periode</th>
                            <th class="num">Ziel erreicht</th>
                            <th class="num">Anteil</th>
                            <th class="num">Max. Kurs</th>
                        </tr>
                    </thead>
                    <tbody>${periodRows}</tbody>
                </table>
                <div class="trend-line">
                    Trend: <span class="trend-tag ${trendClass}">${escapeHtml(data.trend)}</span>
                    · Drawdown vom 5J-Hoch: <strong>${dd5}</strong>
                </div>
                <div class="details">
                    ${escapeHtml(data.hint)}
                </div>
            `;
            historyBlock.style.display = 'block';
        } catch (err) {
            historyBlock.innerHTML =
                '<div class="details">Netzwerkfehler beim Abruf der Historie.</div>';
            historyBlock.style.display = 'block';
        } finally {
            btnHistory.textContent = 'Historischen Realismus prüfen';
            updateHistoryButton();
        }
    });

    function update() {
        const buy    = getBuy();
        const sell   = getSell();
        const shares = getShares();

        const cost    = shares * buy;
        const revenue = shares * sell;
        const profit  = revenue - cost;
        const ret     = cost > 0 ? (profit / cost) * 100 : 0;

        $('r-cost').textContent    = (shares > 0 && buy  > 0) ? fmtMoney(cost)    : '–';
        $('r-revenue').textContent = (shares > 0 && sell > 0) ? fmtMoney(revenue) : '–';

        const profitEl = $('r-profit');
        if (shares > 0 && buy > 0 && sell > 0) {
            profitEl.textContent = (profit >= 0 ? '+' : '') + fmtMoney(profit);
            profitEl.className = 'v ' + (profit >= 0 ? 'pos' : 'neg');
        } else {
            profitEl.textContent = '–';
            profitEl.className = 'v';
        }

        const retEl = $('r-return');
        if (shares > 0 && buy > 0 && sell > 0) {
            retEl.textContent = (ret >= 0 ? '+' : '') + ret.toFixed(2) + ' %';
            retEl.className = 'v ' + (ret >= 0 ? 'pos' : 'neg');
        } else {
            retEl.textContent = '–';
            retEl.className = 'v';
        }

        const coverEl = $('r-cover');
        if (shares > 0 && MARKET_ASK_SIZE > 0 && MARKET_BID_SIZE > 0) {
            const buyCover  = (shares / MARKET_ASK_SIZE) * 100;
            const sellCover = (shares / MARKET_BID_SIZE) * 100;
            coverEl.textContent =
                'Kauf: ' + buyCover.toFixed(1) + '% des Asks · ' +
                'Verkauf: ' + sellCover.toFixed(1) + '% des Bids';
            if (buyCover > 100 || sellCover > 100) {
                coverEl.className = 'v neg';
            } else if (buyCover > 50 || sellCover > 50) {
                coverEl.className = 'v warn';
            } else {
                coverEl.className = 'v pos';
            }
        } else {
            coverEl.textContent = '–';
            coverEl.className = 'v';
        }

        updateHistoryButton();
    }

    buyEl.addEventListener('input', () => {
        if (currentMode() === 'shares') syncMoneyField();
        else {
            const buy = getBuy();
            const money = parseNum(moneyEl.value);
            sharesEl.value = buy > 0 ? Math.floor(money / buy) : 0;
        }
        update();
    });

    sellEl.addEventListener('input', update);

    document.querySelectorAll('input[name="mode"]').forEach(r => {
        r.addEventListener('change', () => {
            const buy = getBuy();
            if (currentMode() === 'money') {
                const money = parseNum(moneyEl.value);
                sharesEl.value = buy > 0 ? Math.floor(money / buy) : 0;
            } else {
                const shares = parseNum(sharesEl.value);
                moneyEl.value = (shares * buy).toFixed(2);
            }
            update();
        });
    });

    sharesEl.addEventListener('input', () => {
        if (currentMode() === 'shares') syncMoneyField();
        update();
    });

    moneyEl.addEventListener('input', () => {
        if (currentMode() === 'money') {
            const buy = getBuy();
            const money = parseNum(moneyEl.value);
            sharesEl.value = buy > 0 ? Math.floor(money / buy) : 0;
        }
        update();
    });

    update();
})();
</script>
</body>
</html>