<?php
// stock_tester.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Return Tester</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: #f5f7fa; margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; }
        .card { background: white; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); padding: 24px; margin-bottom: 24px; }
        h1 { color: #1a1a2e; margin-top: 0; }
        .form-row { display: flex; flex-wrap: wrap; gap: 16px; align-items: flex-end; }
        .form-group { flex: 1; min-width: 150px; }
        .form-group label { display: block; font-weight: 600; font-size: 0.85rem; color: #444; margin-bottom: 4px; }
        .form-group input, .form-group select { width: 100%; padding: 10px 14px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 1rem; transition: 0.2s; background: white; }
        .form-group input:focus, .form-group select:focus { border-color: #4a6cf7; outline: none; }
        .btn { background: #4a6cf7; color: white; padding: 10px 28px; border: none; border-radius: 8px; font-weight: 600; font-size: 1rem; cursor: pointer; transition: 0.2s; }
        .btn:hover { background: #3a5bd9; transform: translateY(-1px); }
        .btn-secondary { background: #e8ecf1; color: #333; }
        .btn-secondary:hover { background: #d5dae3; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin: 16px 0; }
        .stat-card { background: #f8f9fc; padding: 16px; border-radius: 10px; text-align: center; border: 2px solid transparent; transition: 0.2s; }
        .stat-card .value { font-size: 1.8rem; font-weight: 700; color: #1a1a2e; }
        .stat-card .label { font-size: 0.8rem; color: #666; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-card.positive .value { color: #22c55e; }
        .stat-card.negative .value { color: #ef4444; }
        .stat-card.today-highlight { border-color: #4a6cf7; background: #f0f4ff; }
        .stat-card.today-highlight .label { color: #4a6cf7; font-weight: 700; }
        .comparison-badge { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 0.7rem; font-weight: 600; margin-left: 4px; }
        .comparison-badge.better { background: #22c55e; color: white; }
        .comparison-badge.worse { background: #ef4444; color: white; }
        .comparison-badge.same { background: #f59e0b; color: white; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th { background: #f0f2f5; text-align: left; padding: 12px 16px; font-weight: 600; color: #444; }
        td { padding: 10px 16px; border-bottom: 1px solid #eef0f4; }
        tr:hover td { background: #fafbff; }
        .chart-container { height: 350px; position: relative; margin-top: 16px; }
        .error { background: #fee2e2; color: #991b1b; padding: 16px; border-radius: 8px; margin: 12px 0; }
        .error strong { display: block; margin-bottom: 8px; }
        .error .suggestion { margin-top: 8px; padding: 8px; background: #fff5f5; border-radius: 4px; font-size: 0.9rem; }
        .info { background: #e0f2fe; color: #075985; padding: 16px; border-radius: 8px; margin: 12px 0; }
        .flex { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
        .loading { display: none; text-align: center; padding: 20px; color: #666; }
        .loading.active { display: block; }
        .spinner { display: inline-block; width: 30px; height: 30px; border: 3px solid #f3f3f3; border-top: 3px solid #4a6cf7; border-radius: 50%; animation: spin 1s linear infinite; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .preset-buttons { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
        .preset-btn { background: #eef2f7; border: none; padding: 6px 14px; border-radius: 6px; font-size: 0.85rem; cursor: pointer; transition: 0.2s; color: #333; }
        .preset-btn:hover { background: #d5dce6; transform: translateY(-1px); }
        .preset-btn.active { background: #4a6cf7; color: white; }
        
        .preview-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-top: 16px; padding: 16px; background: #f8f9fc; border-radius: 10px; border: 2px dashed #d5dce6; }
        .preview-item { text-align: center; }
        .preview-item .label { font-size: 0.75rem; color: #666; text-transform: uppercase; letter-spacing: 0.5px; }
        .preview-item .value { font-size: 1.4rem; font-weight: 700; color: #1a1a2e; }
        .preview-item .value.highlight { color: #4a6cf7; }
        .preview-item .value.positive { color: #22c55e; }
        .preview-item .value.negative { color: #ef4444; }
        .live-badge { display: inline-block; background: #22c55e; color: white; font-size: 0.7rem; padding: 2px 10px; border-radius: 12px; margin-left: 8px; animation: pulse 2s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.6; } 100% { opacity: 1; } }
        
        .comparison-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 16px; }
        @media (max-width: 600px) { .comparison-grid { grid-template-columns: 1fr; } }
        @media (max-width: 600px) { .form-group { min-width: 100%; } .stats-grid { grid-template-columns: 1fr 1fr; } }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <h1>📈 Stock Return Tester</h1>
        
        <div class="preset-buttons">
            <button class="preset-btn" onclick="setPreset('AAPL', '01/01/2024', 'today', 1, 1)">🍎 AAPL (Jan 2024 → today)</button>
            <button class="preset-btn" onclick="setPreset('MSFT', '01/06/2023', 'today', 5, 2)">💻 MSFT (Jun 2023 → today)</button>
            <button class="preset-btn" onclick="setPreset('GOOGL', '01/01/2022', '01/01/2024', 15, 1)">🔍 GOOGL (2022→2024)</button>
            <button class="preset-btn" onclick="setPreset('TSLA', '01/01/2023', 'today', 1, 1)">🚗 TSLA (2023→today)</button>
            <button class="preset-btn" onclick="setPreset('NVDA', '01/01/2023', 'today', 1, 1)">💻 NVDA (2023→today)</button>
            <button class="preset-btn" onclick="setPreset('AMZN', '01/01/2022', '01/01/2024', 1, 2)">📦 AMZN (2022→2024)</button>
            <button class="preset-btn" onclick="setPreset('SPY', '01/05/2024', '02/05/2024', 1, 5)">📊 SPY (May 2024)</button>
            <button class="preset-btn" onclick="setPreset('SPY5.DE', '01/05/2024', '02/05/2024', 1, 5)">🇩🇪 SPY5.DE (May 2024)</button>
        </div>

        <form method="GET" id="stockForm" class="form-row">
            <div class="form-group">
                <label>Ticker or ISIN</label>
                <input type="text" name="symbol" id="symbol" placeholder="e.g. AAPL, MSFT, SPY5.DE" value="<?= htmlspecialchars($_GET['symbol'] ?? 'AAPL') ?>" required oninput="updatePreview()">
            </div>
            <div class="form-group">
                <label>Start Date (DD/MM/YYYY)</label>
                <input type="text" name="start_date" id="start_date" placeholder="DD/MM/YYYY" value="<?= htmlspecialchars($_GET['start_date'] ?? getDefaultStartDate()) ?>" onchange="updatePreview()">
            </div>
            <div class="form-group">
                <label>End Date (DD/MM/YYYY or 'today')</label>
                <input type="text" name="end_date" id="end_date" placeholder="DD/MM/YYYY or 'today'" value="<?= htmlspecialchars($_GET['end_date'] ?? getDefaultEndDate()) ?>" onchange="updatePreview()">
            </div>
            <div class="form-group" style="min-width:100px;">
                <label>Day of Month</label>
                <input type="number" name="buy_day" id="buy_day" min="1" max="28" value="<?= htmlspecialchars($_GET['buy_day'] ?? 1) ?>" oninput="updatePreview()">
            </div>
            <div class="form-group" style="min-width:120px;">
                <label>Shares / Month</label>
                <input type="number" name="shares" id="shares" step="0.01" min="0.01" value="<?= htmlspecialchars($_GET['shares'] ?? 1) ?>" oninput="updatePreview()">
            </div>
            <div class="form-group">
                <button type="submit" class="btn" id="submitBtn">Test Returns</button>
            </div>
        </form>
        
        <div class="preview-grid" id="previewGrid">
            <div class="preview-item">
                <div class="label">💰 Total Invested</div>
                <div class="value highlight" id="previewInvested">$0.00</div>
            </div>
            <div class="preview-item">
                <div class="label">📊 Total Shares</div>
                <div class="value" id="previewShares">0.00</div>
            </div>
            <div class="preview-item">
                <div class="label">📈 Est. Monthly Investment</div>
                <div class="value" id="previewMonthly">$0.00</div>
            </div>
            <div class="preview-item">
                <div class="label">📅 Months Analyzed</div>
                <div class="value" id="previewMonths">0</div>
            </div>
            <div class="preview-item" style="grid-column: span 2;">
                <div class="label">🔮 Preview based on current settings <span class="live-badge">LIVE</span></div>
                <div style="font-size: 0.9rem; color: #666; margin-top: 4px;">
                    <span id="previewSummary">Enter a symbol to see estimated investment</span>
                </div>
            </div>
        </div>
        
        <div class="loading" id="loadingIndicator">
            <div class="spinner"></div>
            <p style="margin-top: 10px;">Fetching stock data...</p>
        </div>
    </div>

    <?php
    // ----- PHP BACKEND -----
    $symbol = $_GET['symbol'] ?? '';
    $startDateInput = $_GET['start_date'] ?? getDefaultStartDate();
    $endDateInput = $_GET['end_date'] ?? getDefaultEndDate();
    $buyDay = (int)($_GET['buy_day'] ?? 1);
    $sharesPerMonth = (float)($_GET['shares'] ?? 1);

    $hasData = false;
    $error = null;
    $prices = [];
    $dates = [];
    $monthlyData = [];
    $endDateObj = null;
    $endDateDisplay = '';
    $todayPrice = null;
    $todayDate = date('Y-m-d');

    $autoSubmit = isset($_GET['autosubmit']) && $_GET['autosubmit'] === '1';

    if ($symbol) {
        $startDateObj = DateTime::createFromFormat('d/m/Y', $startDateInput);
        if (!$startDateObj) {
            $error = "Invalid start date format. Please use DD/MM/YYYY.";
        } else {
            if (strtolower($endDateInput) === 'today') {
                $endDateObj = new DateTime();
                $endDateDisplay = 'today';
            } else {
                $endDateObj = DateTime::createFromFormat('d/m/Y', $endDateInput);
                if (!$endDateObj) {
                    $error = "Invalid end date format. Please use DD/MM/YYYY or 'today'.";
                } else {
                    $endDateDisplay = $endDateObj->format('d/m/Y');
                }
            }

            if (!$error && $endDateObj) {
                if ($endDateObj < $startDateObj) {
                    $error = "End date must be after start date.";
                } else {
                    $today = new DateTime();
                    $startDate = $startDateObj->format('Y-m-d');
                    $endDate = $endDateObj->format('Y-m-d');
                    
                    // Try multiple symbol formats if the first fails
                    $symbolsToTry = [$symbol];
                    
                    // If symbol has .DE, also try without it
                    if (strpos($symbol, '.DE') !== false) {
                        $symbolsToTry[] = str_replace('.DE', '', $symbol);
                    }
                    // If symbol doesn't have .DE, try with it (for German stocks)
                    if (strpos($symbol, '.DE') === false && strpos($symbol, '.') === false) {
                        $symbolsToTry[] = $symbol . '.DE';
                    }
                    
                    $foundData = false;
                    $usedSymbol = $symbol;
                    
                    foreach ($symbolsToTry as $trySymbol) {
                        $fullData = fetchYahooHistory($trySymbol, $startDate, $today->format('Y-m-d'));
                        
                        if ($fullData && count($fullData) > 0) {
                            $foundData = true;
                            $usedSymbol = $trySymbol;
                            $todayPrice = end($fullData);
                            
                            $data = fetchYahooHistory($trySymbol, $startDate, $endDate);
                            
                            if ($data && count($data) > 0) {
                                $hasData = true;
                                $prices = array_reverse($data);
                                $dates = array_keys($prices);
                                
                                $monthlyData = calculateMonthlyPurchases($prices, $startDateObj, $endDateObj, $buyDay, $sharesPerMonth, $todayPrice);
                                
                                $totalInvested = 0;
                                $totalShares = 0;
                                foreach ($monthlyData as $m) {
                                    $totalInvested += $m['invested'];
                                    $totalShares += $m['shares'];
                                }
                                $endPrice = end($prices);
                                $endValue = $totalShares * $endPrice;
                                $endReturnDollar = $endValue - $totalInvested;
                                $endReturnPercent = ($totalInvested > 0) ? ($endReturnDollar / $totalInvested) * 100 : 0;
                                
                                $todayValue = $totalShares * $todayPrice;
                                $todayReturnDollar = $todayValue - $totalInvested;
                                $todayReturnPercent = ($totalInvested > 0) ? ($todayReturnDollar / $totalInvested) * 100 : 0;
                                break;
                            }
                        }
                    }
                    
                    if (!$foundData) {
                        $error = "No data found for symbol '$symbol'. Please check the ticker or ISIN.";
                        $error .= "<div class='suggestion'>💡 <strong>Suggestions:</strong><br>";
                        $error .= "• For German stocks, try using the format <strong>{$symbol}.DE</strong><br>";
                        $error .= "• For US stocks, use the ticker symbol (e.g., AAPL, MSFT)<br>";
                        $error .= "• Check that the date range is correct (trading days only)";
                        $error .= "</div>";
                    } elseif (!$hasData) {
                        $error = "No data found for symbol '$symbol' in the specified date range.<br>";
                        $error .= "<div class='suggestion'>💡 Try expanding the date range or check if the market was open on those days.</div>";
                    }
                }
            }
        }
    }
    ?>

    <?php if ($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <?php if ($hasData && $monthlyData): ?>
        <?php
        $totalInvested = array_sum(array_column($monthlyData, 'invested'));
        $totalShares = array_sum(array_column($monthlyData, 'shares'));
        $endPrice = end($prices);
        $endValue = $totalShares * $endPrice;
        $endReturnDollar = $endValue - $totalInvested;
        $endReturnPercent = ($totalInvested > 0) ? ($endReturnDollar / $totalInvested) * 100 : 0;
        
        $todayValue = $totalShares * $todayPrice;
        $todayReturnDollar = $todayValue - $totalInvested;
        $todayReturnPercent = ($totalInvested > 0) ? ($todayReturnDollar / $totalInvested) * 100 : 0;
        ?>

        <div class="card" id="results">
            <div class="flex">
                <h2 style="margin:0;"><?= strtoupper(htmlspecialchars($symbol)) ?> — Results</h2>
                <span style="font-size:0.9rem; color:#666;">
                    <?= date('d/m/Y', strtotime($startDate)) ?> → 
                    <?= $endDateDisplay === 'today' ? 'Today' : $endDateDisplay ?>
                </span>
            </div>

            <?php if ($usedSymbol != $symbol): ?>
                <div class="info" style="margin-bottom:12px;">
                    ℹ️ Used symbol: <strong><?= htmlspecialchars($usedSymbol) ?></strong> (automatically adjusted from <?= htmlspecialchars($symbol) ?>)
                </div>
            <?php endif; ?>

            <div class="comparison-grid">
                <div class="stat-card <?= $endReturnDollar >= 0 ? 'positive' : 'negative' ?>">
                    <div class="label">📅 At End Date (<?= $endDateDisplay === 'today' ? 'Today' : $endDateDisplay ?>)</div>
                    <div class="value">$<?= number_format($endValue, 2) ?></div>
                    <div style="font-size:0.9rem; margin-top:4px; color: <?= $endReturnDollar >= 0 ? '#22c55e' : '#ef4444' ?>;">
                        <?= $endReturnDollar >= 0 ? '+' : '' ?><?= number_format($endReturnDollar, 2) ?> 
                        (<?= $endReturnPercent >= 0 ? '+' : '' ?><?= number_format($endReturnPercent, 2) ?>%)
                    </div>
                    <div style="font-size:0.7rem; color:#666; margin-top:4px;">
                        Price: $<?= number_format($endPrice, 2) ?>
                    </div>
                </div>
                
                <div class="stat-card today-highlight <?= $todayReturnDollar >= 0 ? 'positive' : 'negative' ?>">
                    <div class="label">📊 Today's Value (<?= date('d/m/Y') ?>)</div>
                    <div class="value">$<?= number_format($todayValue, 2) ?></div>
                    <div style="font-size:0.9rem; margin-top:4px; color: <?= $todayReturnDollar >= 0 ? '#22c55e' : '#ef4444' ?>;">
                        <?= $todayReturnDollar >= 0 ? '+' : '' ?><?= number_format($todayReturnDollar, 2) ?> 
                        (<?= $todayReturnPercent >= 0 ? '+' : '' ?><?= number_format($todayReturnPercent, 2) ?>%)
                        <?php if ($todayReturnDollar != $endReturnDollar): ?>
                            <span class="comparison-badge <?= $todayReturnDollar > $endReturnDollar ? 'better' : 'worse' ?>">
                                <?= $todayReturnDollar > $endReturnDollar ? '↑ Better' : '↓ Worse' ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div style="font-size:0.7rem; color:#666; margin-top:4px;">
                        Price: $<?= number_format($todayPrice, 2) ?>
                    </div>
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="label">Total Invested</div>
                    <div class="value">$<?= number_format($totalInvested, 2) ?></div>
                </div>
                <div class="stat-card">
                    <div class="label">Total Shares</div>
                    <div class="value"><?= number_format($totalShares, 2) ?></div>
                </div>
                <div class="stat-card <?= $todayReturnDollar >= 0 ? 'positive' : 'negative' ?>">
                    <div class="label">Today's Return ($)</div>
                    <div class="value"><?= $todayReturnDollar >= 0 ? '+' : '' ?><?= number_format($todayReturnDollar, 2) ?></div>
                </div>
                <div class="stat-card <?= $todayReturnPercent >= 0 ? 'positive' : 'negative' ?>">
                    <div class="label">Today's Return (%)</div>
                    <div class="value"><?= $todayReturnPercent >= 0 ? '+' : '' ?><?= number_format($todayReturnPercent, 2) ?>%</div>
                </div>
            </div>

            <div class="info" style="margin-top:12px;">
                <strong>📈 Price Change:</strong> 
                End date price: $<?= number_format($endPrice, 2) ?> → 
                Today's price: $<?= number_format($todayPrice, 2) ?> 
                (<?= $todayPrice >= $endPrice ? '+' : '' ?><?= number_format((($todayPrice - $endPrice) / $endPrice) * 100, 2) ?>%)
                <?php if ($todayPrice != $endPrice): ?>
                    <span style="margin-left:8px; font-weight:600; color: <?= $todayPrice > $endPrice ? '#22c55e' : '#ef4444' ?>;">
                        <?= $todayPrice > $endPrice ? '📈 Price increased since end date' : '📉 Price decreased since end date' ?>
                    </span>
                <?php endif; ?>
            </div>

            <div class="chart-container">
                <canvas id="priceChart"></canvas>
            </div>
        </div>

        <div class="card">
            <h3>Monthly Purchases</h3>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Buy Date</th>
                            <th>Price</th>
                            <th>Shares</th>
                            <th>Invested</th>
                            <th>Value at End</th>
                            <th>Return $</th>
                            <th>Return %</th>
                            <th>Today's Value</th>
                            <th>Today's Return</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($monthlyData as $m): ?>
                            <tr>
                                <td><?= $m['month'] ?></td>
                                <td><?= $m['buy_date'] ?></td>
                                <td>$<?= number_format($m['price'], 2) ?></td>
                                <td><?= number_format($m['shares'], 2) ?></td>
                                <td>$<?= number_format($m['invested'], 2) ?></td>
                                <td>$<?= number_format($m['end_value'], 2) ?></td>
                                <td class="<?= $m['end_return_dollar'] >= 0 ? 'positive' : 'negative' ?>" style="font-weight:600;">
                                    <?= $m['end_return_dollar'] >= 0 ? '+' : '' ?><?= number_format($m['end_return_dollar'], 2) ?>
                                </td>
                                <td class="<?= $m['end_return_percent'] >= 0 ? 'positive' : 'negative' ?>" style="font-weight:600;">
                                    <?= $m['end_return_percent'] >= 0 ? '+' : '' ?><?= number_format($m['end_return_percent'], 2) ?>%
                                </td>
                                <td>$<?= number_format($m['today_value'], 2) ?></td>
                                <td class="<?= $m['today_return_dollar'] >= 0 ? 'positive' : 'negative' ?>" style="font-weight:600;">
                                    <?= $m['today_return_dollar'] >= 0 ? '+' : '' ?><?= number_format($m['today_return_dollar'], 2) ?>
                                    <span style="font-size:0.7rem; color:#666;">
                                        (<?= $m['today_return_percent'] >= 0 ? '+' : '' ?><?= number_format($m['today_return_percent'], 2) ?>%)
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot style="font-weight:700; background:#f8f9fc;">
                        <tr>
                            <td colspan="4" style="text-align:right;">TOTAL</td>
                            <td>$<?= number_format($totalInvested, 2) ?></td>
                            <td>$<?= number_format($endValue, 2) ?></td>
                            <td class="<?= $endReturnDollar >= 0 ? 'positive' : 'negative' ?>"><?= $endReturnDollar >= 0 ? '+' : '' ?><?= number_format($endReturnDollar, 2) ?></td>
                            <td class="<?= $endReturnPercent >= 0 ? 'positive' : 'negative' ?>"><?= $endReturnPercent >= 0 ? '+' : '' ?><?= number_format($endReturnPercent, 2) ?>%</td>
                            <td>$<?= number_format($todayValue, 2) ?></td>
                            <td class="<?= $todayReturnDollar >= 0 ? 'positive' : 'negative' ?>">
                                <?= $todayReturnDollar >= 0 ? '+' : '' ?><?= number_format($todayReturnDollar, 2) ?>
                                <span style="font-size:0.7rem; color:#666;">
                                    (<?= $todayReturnPercent >= 0 ? '+' : '' ?><?= number_format($todayReturnPercent, 2) ?>%)
                                </span>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <script>
        // Chart.js graph
        (function() {
            const labels = <?= json_encode(array_keys($prices)) ?>;
            const data = <?= json_encode(array_values($prices)) ?>;

            const ctx = document.getElementById('priceChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Stock Price (USD)',
                        data: data,
                        borderColor: '#4a6cf7',
                        backgroundColor: 'rgba(74, 108, 247, 0.1)',
                        borderWidth: 2,
                        pointRadius: 1,
                        tension: 0.1,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return '$' + context.parsed.y.toFixed(2);
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            ticks: {
                                maxTicksLimit: 20,
                                autoSkip: true
                            }
                        },
                        y: {
                            beginAtZero: false,
                            ticks: {
                                callback: function(value) {
                                    return '$' + value.toFixed(2);
                                }
                            }
                        }
                    }
                }
            });
        })();
        </script>
    <?php endif; ?>
</div>

<script>
// ----- JAVASCRIPT -----

function updatePreview() {
    const symbol = document.getElementById('symbol').value.trim();
    const startDateStr = document.getElementById('start_date').value;
    const endDateStr = document.getElementById('end_date').value;
    const buyDay = parseInt(document.getElementById('buy_day').value) || 1;
    const sharesPerMonth = parseFloat(document.getElementById('shares').value) || 0;
    
    const previewInvested = document.getElementById('previewInvested');
    const previewShares = document.getElementById('previewShares');
    const previewMonthly = document.getElementById('previewMonthly');
    const previewMonths = document.getElementById('previewMonths');
    const previewSummary = document.getElementById('previewSummary');
    
    if (!symbol) {
        previewInvested.textContent = '$0.00';
        previewShares.textContent = '0.00';
        previewMonthly.textContent = '$0.00';
        previewMonths.textContent = '0';
        previewSummary.textContent = 'Enter a symbol to see estimated investment';
        return;
    }
    
    const startParts = startDateStr.split('/');
    if (startParts.length !== 3) {
        previewSummary.textContent = '⚠️ Invalid start date format. Use DD/MM/YYYY';
        return;
    }
    
    const startDate = new Date(startParts[2], startParts[1] - 1, startParts[0]);
    if (isNaN(startDate.getTime())) {
        previewSummary.textContent = '⚠️ Invalid start date';
        return;
    }
    
    let endDate;
    let endDisplay = '';
    if (endDateStr.toLowerCase() === 'today') {
        endDate = new Date();
        endDisplay = 'Today';
    } else {
        const endParts = endDateStr.split('/');
        if (endParts.length === 3) {
            endDate = new Date(endParts[2], endParts[1] - 1, endParts[0]);
            endDisplay = endDateStr;
        } else {
            previewSummary.textContent = '⚠️ Invalid end date format. Use DD/MM/YYYY or "today"';
            return;
        }
    }
    
    if (isNaN(endDate.getTime())) {
        previewSummary.textContent = '⚠️ Invalid end date';
        return;
    }
    
    if (endDate < startDate) {
        previewSummary.textContent = '⚠️ End date must be after start date';
        return;
    }
    
    let months = 0;
    let currentDate = new Date(startDate);
    while (currentDate <= endDate) {
        months++;
        currentDate.setMonth(currentDate.getMonth() + 1);
    }
    
    const totalShares = months * sharesPerMonth;
    const totalInvested = totalShares * 100;
    
    previewInvested.textContent = '$' + totalInvested.toFixed(2);
    previewShares.textContent = totalShares.toFixed(2);
    previewMonthly.textContent = '$' + (sharesPerMonth * 100).toFixed(2);
    previewMonths.textContent = months;
    
    if (months > 0 && sharesPerMonth > 0) {
        previewSummary.innerHTML = `
            <strong>${symbol.toUpperCase()}</strong> · 
            ${startDate.toLocaleDateString()} → ${endDisplay} · 
            ${months} months × ${sharesPerMonth} shares/month = 
            <strong>${totalShares.toFixed(2)}</strong> total shares · 
            ~$${totalInvested.toFixed(2)} invested (est.)
            <span style="color:#999; font-size:0.8rem; margin-left:8px;">
                (actual price varies)
            </span>
        `;
    } else {
        previewSummary.textContent = 'Adjust settings to see estimate';
    }
}

async function fetchRealTimePreview() {
    const symbol = document.getElementById('symbol').value.trim();
    if (!symbol) return;
    
    try {
        // Try both with and without .DE
        let symbolsToTry = [symbol];
        if (symbol.includes('.DE')) {
            symbolsToTry.push(symbol.replace('.DE', ''));
        } else if (!symbol.includes('.')) {
            symbolsToTry.push(symbol + '.DE');
        }
        
        let price = null;
        for (const trySymbol of symbolsToTry) {
            const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${trySymbol}?interval=1d&range=1d`);
            const data = await response.json();
            const p = data?.chart?.result?.[0]?.meta?.regularMarketPrice;
            if (p) {
                price = p;
                break;
            }
        }
        
        if (price) {
            const sharesPerMonth = parseFloat(document.getElementById('shares').value) || 0;
            const startDateStr = document.getElementById('start_date').value;
            const endDateStr = document.getElementById('end_date').value;
            
            const startParts = startDateStr.split('/');
            if (startParts.length === 3) {
                const startDate = new Date(startParts[2], startParts[1] - 1, startParts[0]);
                
                let endDate;
                let endDisplay = '';
                if (endDateStr.toLowerCase() === 'today') {
                    endDate = new Date();
                    endDisplay = 'Today';
                } else {
                    const endParts = endDateStr.split('/');
                    if (endParts.length === 3) {
                        endDate = new Date(endParts[2], endParts[1] - 1, endParts[0]);
                        endDisplay = endDateStr;
                    } else {
                        return;
                    }
                }
                
                if (!isNaN(startDate.getTime()) && !isNaN(endDate.getTime()) && endDate >= startDate) {
                    let months = 0;
                    let currentDate = new Date(startDate);
                    while (currentDate <= endDate) {
                        months++;
                        currentDate.setMonth(currentDate.getMonth() + 1);
                    }
                    
                    const totalShares = months * sharesPerMonth;
                    const totalInvested = totalShares * price;
                    
                    document.getElementById('previewInvested').textContent = '$' + totalInvested.toFixed(2);
                    document.getElementById('previewMonthly').textContent = '$' + (sharesPerMonth * price).toFixed(2);
                    document.getElementById('previewSummary').innerHTML = `
                        <strong>${symbol.toUpperCase()}</strong> · 
                        Current price: <strong>$${price.toFixed(2)}</strong> · 
                        ${months} months × ${sharesPerMonth} shares/month = 
                        <strong>${totalShares.toFixed(2)}</strong> total shares · 
                        <strong>$${totalInvested.toFixed(2)}</strong> invested
                        <span style="color:#22c55e; font-size:0.8rem; margin-left:8px;">
                            ● live
                        </span>
                    `;
                }
            }
        }
    } catch (error) {
        console.log('Could not fetch real-time price for preview');
    }
}

let previewTimeout;
function debouncedFetchPreview() {
    clearTimeout(previewTimeout);
    previewTimeout = setTimeout(fetchRealTimePreview, 500);
}

function setPreset(symbol, startDate, endDate, buyDay, shares) {
    document.getElementById('symbol').value = symbol;
    document.getElementById('start_date').value = startDate;
    document.getElementById('end_date').value = endDate;
    document.getElementById('buy_day').value = buyDay;
    document.getElementById('shares').value = shares;
    
    updatePreview();
    debouncedFetchPreview();
    document.getElementById('stockForm').submit();
}

document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const symbol = urlParams.get('symbol');
    const autosubmit = urlParams.get('autosubmit');
    
    updatePreview();
    
    if (symbol && autosubmit === '1') {
        document.getElementById('loadingIndicator').classList.add('active');
        document.getElementById('submitBtn').disabled = true;
        document.getElementById('submitBtn').textContent = 'Loading...';
    } else if (symbol) {
        debouncedFetchPreview();
    } else {
        // Auto-submit with default values on first load
        setTimeout(function() {
            document.getElementById('stockForm').submit();
        }, 500);
    }
});

document.getElementById('stockForm').addEventListener('submit', function() {
    document.getElementById('loadingIndicator').classList.add('active');
    document.getElementById('submitBtn').disabled = true;
    document.getElementById('submitBtn').textContent = 'Loading...';
});

document.getElementById('symbol').addEventListener('input', function() {
    updatePreview();
    if (this.value.trim()) {
        debouncedFetchPreview();
    }
});

document.getElementById('start_date').addEventListener('change', updatePreview);
document.getElementById('end_date').addEventListener('change', updatePreview);
document.getElementById('buy_day').addEventListener('input', updatePreview);
document.getElementById('shares').addEventListener('input', function() {
    updatePreview();
    if (document.getElementById('symbol').value.trim()) {
        debouncedFetchPreview();
    }
});

function getShareableUrl() {
    const symbol = document.getElementById('symbol').value;
    const startDate = document.getElementById('start_date').value;
    const endDate = document.getElementById('end_date').value;
    const buyDay = document.getElementById('buy_day').value;
    const shares = document.getElementById('shares').value;
    
    let url = window.location.pathname + '?';
    url += 'symbol=' + encodeURIComponent(symbol);
    url += '&start_date=' + encodeURIComponent(startDate);
    url += '&end_date=' + encodeURIComponent(endDate);
    url += '&buy_day=' + encodeURIComponent(buyDay);
    url += '&shares=' + encodeURIComponent(shares);
    url += '&autosubmit=1';
    
    return url;
}

function copyShareableLink() {
    const url = getShareableUrl();
    navigator.clipboard.writeText(window.location.origin + url).then(() => {
        alert('Shareable link copied to clipboard!');
    }).catch(() => {
        prompt('Copy this link to share:', window.location.origin + url);
    });
}

document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        const form = document.getElementById('stockForm');
        if (form) {
            form.submit();
        }
    }
});

updatePreview();
</script>

<?php
// ----- FUNCTIONS -----

function getDefaultStartDate() {
    $year = date('Y') - 1;
    return "01/01/{$year}";
}

function getDefaultEndDate() {
    $year = date('Y') - 1;
    return "01/02/{$year}";
}

function fetchYahooHistory($symbol, $startDate, $endDate) {
    // URL encode the symbol to handle special characters like .DE
    $encodedSymbol = urlencode($symbol);
    $url = "https://query1.finance.yahoo.com/v8/finance/chart/{$encodedSymbol}?period1=" . strtotime($startDate) . "&period2=" . strtotime($endDate) . "&interval=1d";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || !$response) {
        return null;
    }

    $data = json_decode($response, true);
    if (!isset($data['chart']['result'][0]['indicators']['quote'][0]['close'])) {
        return null;
    }

    $result = $data['chart']['result'][0];
    $timestamps = $result['timestamp'] ?? [];
    $closes = $result['indicators']['quote'][0]['close'] ?? [];

    $prices = [];
    foreach ($timestamps as $i => $ts) {
        if (isset($closes[$i]) && $closes[$i] !== null) {
            $date = date('Y-m-d', $ts);
            $prices[$date] = (float)$closes[$i];
        }
    }

    ksort($prices);
    return $prices;
}

function calculateMonthlyPurchases($prices, $startDateObj, $endDateObj, $buyDay, $sharesPerMonth, $todayPrice) {
    $result = [];
    $currentDate = clone $startDateObj;
    $currentDate->modify('first day of this month');

    while ($currentDate <= $endDateObj) {
        $buyDate = clone $currentDate;
        $buyDate->setDate($buyDate->format('Y'), $buyDate->format('m'), $buyDay);

        $lastDayOfMonth = (clone $currentDate)->modify('last day of this month');
        if ($buyDate > $lastDayOfMonth) {
            $buyDate = clone $lastDayOfMonth;
        }

        if ($buyDate < $startDateObj) {
            $currentDate->modify('first day of next month');
            continue;
        }

        if ($buyDate > $endDateObj) {
            break;
        }

        $buyDateStr = $buyDate->format('Y-m-d');
        $price = findClosestPrice($prices, $buyDateStr);
        if ($price === null) {
            $currentDate->modify('first day of next month');
            continue;
        }

        $invested = $sharesPerMonth * $price;
        $endPrice = end($prices);
        $endValue = $sharesPerMonth * $endPrice;
        $endReturnDollar = $endValue - $invested;
        $endReturnPercent = ($invested > 0) ? ($endReturnDollar / $invested) * 100 : 0;
        
        $todayValue = $sharesPerMonth * $todayPrice;
        $todayReturnDollar = $todayValue - $invested;
        $todayReturnPercent = ($invested > 0) ? ($todayReturnDollar / $invested) * 100 : 0;

        $result[] = [
            'month' => $buyDate->format('M Y'),
            'buy_date' => $buyDate->format('d/m/Y'),
            'price' => $price,
            'shares' => $sharesPerMonth,
            'invested' => $invested,
            'end_value' => $endValue,
            'end_return_dollar' => $endReturnDollar,
            'end_return_percent' => $endReturnPercent,
            'today_value' => $todayValue,
            'today_return_dollar' => $todayReturnDollar,
            'today_return_percent' => $todayReturnPercent,
        ];

        $currentDate->modify('first day of next month');
    }

    return $result;
}

function findClosestPrice($prices, $dateStr) {
    if (isset($prices[$dateStr])) {
        return $prices[$dateStr];
    }

    $date = new DateTime($dateStr);
    for ($i = 1; $i <= 7; $i++) {
        $date->modify('+1 day');
        $checkDate = $date->format('Y-m-d');
        if (isset($prices[$checkDate])) {
            return $prices[$checkDate];
        }
    }

    $date = new DateTime($dateStr);
    for ($i = 1; $i <= 7; $i++) {
        $date->modify('-1 day');
        $checkDate = $date->format('Y-m-d');
        if (isset($prices[$checkDate])) {
            return $prices[$checkDate];
        }
    }

    return null;
}
?>
</body>
</html>