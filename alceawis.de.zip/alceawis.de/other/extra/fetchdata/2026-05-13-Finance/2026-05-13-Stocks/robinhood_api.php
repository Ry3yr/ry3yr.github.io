<?php
/**
 * Robinhood Stock Data Fetcher (Unofficial API)
 * Usage: ?symbol=ILLR
 */

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type to JSON with proper formatting
header('Content-Type: application/json; charset=utf-8');

// Get symbol from URL parameter
$symbol = isset($_GET['symbol']) ? strtoupper(trim($_GET['symbol'])) : '';

if (empty($symbol)) {
    $error = [
        'error' => 'Missing symbol parameter. Usage: ?symbol=ILLR',
        'status' => 400
    ];
    echo json_encode($error, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// Fetch data from all API endpoints
$data = fetchAllRobinhoodData($symbol);

if (isset($data['error'])) {
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// Pretty print with proper formatting
echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK);

/**
 * Fetch all data from Robinhood API endpoints
 */
function fetchAllRobinhoodData($symbol) {
    // Step 1: Get instrument ID first
    $instrument = fetchInstrument($symbol);
    if (!$instrument) {
        return ['error' => 'Symbol not found', 'status' => 404];
    }
    
    $instrumentId = $instrument['id'] ?? null;
    
    // Step 2: Fetch all data
    $endpoints = [
        'quote' => "https://api.robinhood.com/quotes/{$symbol}/",
        'fundamentals' => "https://api.robinhood.com/fundamentals/{$symbol}/",
        'news' => "https://api.robinhood.com/news/{$symbol}/",
        'earnings' => "https://api.robinhood.com/earnings/{$symbol}/",
        'splits' => "https://api.robinhood.com/instruments/{$instrumentId}/splits/",
        'hours' => "https://api.robinhood.com/markets/XNAS/hours/" . date('Y-m-d') . "/",
    ];
    
    $results = [];
    foreach ($endpoints as $key => $url) {
        $results[$key] = callRobinhoodAPI($url);
    }
    
    // Step 3: Format all data
    return formatRobinhoodData($symbol, $instrument, $results);
}

/**
 * Get instrument info first
 */
function fetchInstrument($symbol) {
    $url = "https://api.robinhood.com/instruments/?symbol={$symbol}";
    $response = callRobinhoodAPI($url);
    
    if ($response && isset($response['results']) && count($response['results']) > 0) {
        return $response['results'][0];
    }
    return null;
}

/**
 * Make API call to Robinhood
 */
function callRobinhoodAPI($url) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_TIMEOUT => 10,
        CURLOPT_HTTPHEADER => ['Accept: application/json']
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        return null;
    }
    
    return json_decode($response, true);
}

/**
 * Format all API data into clean JSON
 */
function formatRobinhoodData($symbol, $instrument, $apiData) {
    // Start with base structure
    $result = [
        'symbol' => $symbol,
        'timestamp' => date('Y-m-d H:i:s'),
        'success' => true,
    ];
    
    // --- Instrument Data ---
    $result['instrument'] = array_filter([
        'id' => $instrument['id'] ?? null,
        'symbol' => $instrument['symbol'] ?? $symbol,
        'name' => $instrument['name'] ?? null,
        'simple_name' => $instrument['simple_name'] ?? null,
        'type' => $instrument['type'] ?? null,
        'state' => $instrument['state'] ?? null,
        'tradeable' => isset($instrument['tradeable']) ? (bool)$instrument['tradeable'] : null,
        'list_date' => $instrument['list_date'] ?? null,
        'country' => $instrument['country'] ?? null,
        'market' => $instrument['market'] ?? null,
    ], function($v) { return $v !== null; });
    
    // --- Quote Data ---
    if (isset($apiData['quote'])) {
        $q = $apiData['quote'];
        $result['quote'] = array_filter([
            'last_price' => isset($q['last_trade_price']) ? (float)$q['last_trade_price'] : null,
            'extended_hours_price' => isset($q['last_extended_hours_trade_price']) ? (float)$q['last_extended_hours_trade_price'] : null,
            'previous_close' => isset($q['previous_close']) ? (float)$q['previous_close'] : null,
            'open_price' => isset($q['open_price']) ? (float)$q['open_price'] : null,
            'high_price' => isset($q['high_price']) ? (float)$q['high_price'] : null,
            'low_price' => isset($q['low_price']) ? (float)$q['low_price'] : null,
            'bid_price' => isset($q['bid_price']) ? (float)$q['bid_price'] : null,
            'bid_size' => isset($q['bid_size']) ? (int)$q['bid_size'] : null,
            'ask_price' => isset($q['ask_price']) ? (float)$q['ask_price'] : null,
            'ask_size' => isset($q['ask_size']) ? (int)$q['ask_size'] : null,
            'volume' => isset($q['volume']) ? (float)$q['volume'] : null,
            'trading_halted' => isset($q['trading_halted']) ? (bool)$q['trading_halted'] : null,
            'has_traded' => isset($q['has_traded']) ? (bool)$q['has_traded'] : null,
            'updated_at' => $q['updated_at'] ?? null,
        ], function($v) { return $v !== null; });
    }
    
    // --- Fundamentals ---
    if (isset($apiData['fundamentals'])) {
        $f = $apiData['fundamentals'];
        $result['fundamentals'] = array_filter([
            'market_cap' => isset($f['market_cap']) ? (float)$f['market_cap'] : null,
            'shares_outstanding' => isset($f['shares_outstanding']) ? (float)$f['shares_outstanding'] : null,
            'pe_ratio' => isset($f['pe_ratio']) ? (float)$f['pe_ratio'] : null,
            'pb_ratio' => isset($f['pb_ratio']) ? (float)$f['pb_ratio'] : null,
            'dividend_yield' => isset($f['dividend_yield']) ? (float)$f['dividend_yield'] : null,
            'high_52_weeks' => isset($f['high_52_weeks']) ? (float)$f['high_52_weeks'] : null,
            'high_52_weeks_date' => $f['high_52_weeks_date'] ?? null,
            'low_52_weeks' => isset($f['low_52_weeks']) ? (float)$f['low_52_weeks'] : null,
            'low_52_weeks_date' => $f['low_52_weeks_date'] ?? null,
            'average_volume' => isset($f['average_volume']) ? (float)$f['average_volume'] : null,
            'description' => $f['description'] ?? null,
            'ceo' => $f['ceo'] ?? null,
            'headquarters' => trim(($f['headquarters_city'] ?? '') . ' ' . ($f['headquarters_state'] ?? '')),
            'sector' => $f['sector'] ?? null,
            'industry' => $f['industry'] ?? null,
            'num_employees' => isset($f['num_employees']) ? (int)$f['num_employees'] : null,
            'year_founded' => isset($f['year_founded']) ? (int)$f['year_founded'] : null,
            'financial_status' => $f['financial_status_description'] ?? null,
        ], function($v) { return $v !== null; });
    }
    
    // --- News ---
    if (isset($apiData['news']) && isset($apiData['news']['results'])) {
        $result['news'] = array_map(function($item) {
            return array_filter([
                'title' => $item['title'] ?? null,
                'source' => $item['source'] ?? null,
                'published_at' => $item['published_at'] ?? $item['date'] ?? null,
                'url' => $item['url'] ?? null,
                'image' => $item['image'] ?? null,
                'summary' => $item['summary'] ?? null,
            ], function($v) { return $v !== null && $v !== ''; });
        }, array_slice($apiData['news']['results'], 0, 10));
    }
    
    // --- Earnings ---
    if (isset($apiData['earnings']) && isset($apiData['earnings']['results'])) {
        $result['earnings'] = array_map(function($item) {
            return array_filter([
                'year' => $item['year'] ?? null,
                'quarter' => $item['quarter'] ?? null,
                'eps_actual' => isset($item['eps_actual']) ? (float)$item['eps_actual'] : null,
                'eps_estimate' => isset($item['eps_estimate']) ? (float)$item['eps_estimate'] : null,
                'revenue_actual' => isset($item['revenue_actual']) ? (float)$item['revenue_actual'] : null,
                'revenue_estimate' => isset($item['revenue_estimate']) ? (float)$item['revenue_estimate'] : null,
                'report_date' => $item['report_date'] ?? null,
                'report_timing' => $item['report_timing'] ?? null,
            ], function($v) { return $v !== null; });
        }, $apiData['earnings']['results']);
    }
    
    // --- Splits ---
    if (isset($apiData['splits']) && isset($apiData['splits']['results']) && !empty($apiData['splits']['results'])) {
        $result['splits'] = array_map(function($item) {
            return array_filter([
                'date' => $item['date'] ?? null,
                'ratio' => isset($item['ratio']) ? (float)$item['ratio'] : null,
                'type' => $item['type'] ?? null,
            ], function($v) { return $v !== null; });
        }, $apiData['splits']['results']);
    }
    
    // --- Market Hours ---
    if (isset($apiData['hours'])) {
        $h = $apiData['hours'];
        $result['market_hours'] = array_filter([
            'date' => $h['date'] ?? null,
            'is_open' => isset($h['is_open']) ? (bool)$h['is_open'] : null,
            'opens_at' => $h['opens_at'] ?? null,
            'closes_at' => $h['closes_at'] ?? null,
            'extended_opens_at' => $h['extended_opens_at'] ?? null,
            'extended_closes_at' => $h['extended_closes_at'] ?? null,
            'next_open_hours' => $h['next_open_hours'] ?? null,
        ], function($v) { return $v !== null; });
    }
    
    // Remove null values and empty arrays
    $result = array_filter($result, function($v) {
        if (is_array($v)) {
            return !empty($v);
        }
        return $v !== null;
    });
    
    return $result;
}