

<?php
/**
 * Stock Price Checker - FINAL VERSION
 * Session order: Pre-Market → Regular → Close → After-Hours
 * Close time: 22:00 (market close in UTC+01:00)
 * Pre-Market time: 08:30 (pre-market open in UTC+01:00)
 * All changes correctly calculated vs Previous Close
 */

class StockPriceChecker {
    private $stocksFile;
    private $currentTime;
    private $session;
    private $isCli = false;
    private $processedCount = 0;
    private $failedCount = 0;
    private $unusualCount = 0;
    private $totalStocks = 0;
    private $unusualResults = [];
    private $regularResults = [];

    private const API_BASE = 'https://query1.finance.yahoo.com/v8/finance/chart/';
    private const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';
    private const UNUSUAL_THRESHOLD_PERCENT = 3.0;
    private const MARKET_CLOSE_TIME = '22:00';
    private const PRE_MARKET_TIME = '08:30';

    public function __construct($stocksFile = 'stocks.json') {
        $this->stocksFile = $stocksFile;
        $this->currentTime = new DateTime('now', new DateTimeZone('Europe/Berlin'));
        $this->determineSession();
        $this->isCli = php_sapi_name() === 'cli';
    }

    private function determineSession(): void {
        $hour = (int)$this->currentTime->format('H');
        $minute = (int)$this->currentTime->format('i');

        if ($hour < 9 || ($hour == 9 && $minute < 30)) {
            $this->session = 'premarket';
        } elseif ($hour >= 9 && $hour < 15 || ($hour == 15 && $minute < 30)) {
            $this->session = 'regular';
        } elseif ($hour >= 15 && $hour < 22) {
            $this->session = 'postmarket';
        } else {
            $this->session = 'closed';
        }
    }

    public function getSession(): string { return $this->session; }
    public function getCurrentTime(): string { return $this->currentTime->format('Y-m-d H:i:s (T)'); }

    private function loadStocks(): array {
        if (!file_exists($this->stocksFile)) {
            throw new Exception("Stocks file not found: {$this->stocksFile}");
        }
        $content = file_get_contents($this->stocksFile);
        $stocks = json_decode($content, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON: " . json_last_error_msg());
        }
        return $stocks;
    }

    /**
     * Convert a unix timestamp to a DateTime in the given timezone, using
     * PHP's real timezone database so DST is handled correctly for both
     * Europe/Berlin and America/New_York year-round. Never rely on the
     * date()/H:i functions directly against a raw timestamp for anything
     * that needs a *specific* timezone — those depend on PHP's ambient
     * default timezone, which is not guaranteed to be UTC and was the
     * root cause of pre/post-market ticks being misclassified.
     */
    private function tsIn(int $ts, string $timezone): DateTime {
        $dt = new DateTime('@' . $ts);
        $dt->setTimezone(new DateTimeZone($timezone));
        return $dt;
    }

    private function cleanSymbol(string $symbol): string {
        if (preg_match('/^\d{4,6}\.(SS|SZ|HK|T)$/', $symbol)) {
            return $symbol;
        }
        return preg_replace('/\.[A-Z]{2,}$/', '', $symbol);
    }

    private function fetchStockDataWithFallback(string $symbol, int $retries = 2): ?array {
        $data = $this->fetchStockData($symbol, $retries);
        if ($data !== null) return $data;
        
        $cleanSymbol = preg_replace('/\.[A-Z]{2,}$/', '', $symbol);
        if ($cleanSymbol !== $symbol) {
            $data = $this->fetchStockData($cleanSymbol, 1);
            if ($data !== null) return $data;
        }
        
        return null;
    }

    private function fetchStockData(string $symbol, int $retries = 2): ?array {
        // interval=5m + range=2d gives enough intraday granularity to see
        // pre-market/after-hours ticks, and range=2d ensures the previous
        // day's regular close is included as a reference point.
        // includePrePost=true is REQUIRED — without it Yahoo omits
        // pre-market and after-hours ticks from the response entirely, so
        // no amount of local timestamp filtering can recover them.
        $query = http_build_query([
            'interval' => '5m',
            'range' => '2d',
            'includePrePost' => 'true',
        ]);
        $url = self::API_BASE . urlencode($symbol) . '?' . $query;

        for ($attempt = 0; $attempt <= $retries; $attempt++) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_USERAGENT => self::USER_AGENT,
                CURLOPT_TIMEOUT => 20,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);

            if (!$error && $httpCode === 200) {
                $data = json_decode($response, true);
                if (json_last_error() === JSON_ERROR_NONE && isset($data['chart']['result'][0])) {
                    return $data;
                }
            }
            if ($attempt < $retries) usleep(300000);
        }
        return null;
    }

    /**
     * Extract ALL price data with CORRECT change calculations
     */
    private function extractAllPrices(array $data): array {
        $result = [
            'previousClose' => null,
            'previousCloseTime' => self::MARKET_CLOSE_TIME,
            'regular' => null,
            'preMarket' => null,
            'postMarket' => null,
            'regularChange' => null,
            'regularChangePercent' => null,
            'preMarketChange' => null,
            'preMarketChangePercent' => null,
            'postMarketChange' => null,
            'postMarketChangePercent' => null,
            'volume' => null,
            'averageVolume' => null,
            'marketState' => null,
            'regularMarketTime' => null,
            'preMarketTime' => null,
            'postMarketTime' => null,
            'exchange' => null,
            'fullExchangeName' => null,
            'currency' => 'USD',
        ];

        if (!isset($data['chart']['result'][0])) return $result;

        $chart = $data['chart']['result'][0];
        $meta = $chart['meta'] ?? [];
        $indicators = $chart['indicators']['quote'][0] ?? [];
        $timestamps = $chart['timestamp'] ?? [];
        
        // === PREVIOUS CLOSE ===
        // A previousClose of 0 (or negative) is not a legitimate reference
        // price for an actively traded stock — it's Yahoo returning bad/
        // missing data (seen e.g. for EA, where previousClose came back as
        // 0 and made every "change" calculation compare against nothing).
        // Treat it as unavailable rather than a real baseline.
        $rawPrevClose = isset($meta['previousClose']) ? (float)$meta['previousClose'] : null;
        $result['previousClose'] = ($rawPrevClose !== null && $rawPrevClose > 0) ? $rawPrevClose : null;
        $result['previousCloseTime'] = self::MARKET_CLOSE_TIME;
        $result['volume'] = isset($meta['regularMarketVolume']) ? (int)$meta['regularMarketVolume'] : null;
        $result['averageVolume'] = isset($meta['averageVolume']) ? (int)$meta['averageVolume'] : null;
        $result['marketState'] = $meta['marketState'] ?? null;
        $result['exchange'] = $meta['exchangeName'] ?? null;
        $result['fullExchangeName'] = $meta['fullExchangeName'] ?? null;
        $result['currency'] = $meta['currency'] ?? 'USD';
        
        if (isset($meta['regularMarketTime'])) {
            $result['regularMarketTime'] = $this->tsIn((int)$meta['regularMarketTime'], 'Europe/Berlin')->format('H:i');
        }

        // === REGULAR MARKET PRICE ===
        $result['regular'] = isset($meta['regularMarketPrice']) ? (float)$meta['regularMarketPrice'] : null;
        
        if ($result['regular'] === null && !empty($indicators['close'])) {
            $lastClose = null;
            foreach (array_reverse($indicators['close']) as $price) {
                if ($price !== null) {
                    $lastClose = (float)$price;
                    break;
                }
            }
            $result['regular'] = $lastClose;
        }

        // === CORRECTLY CALCULATE REGULAR CHANGE VS PREVIOUS CLOSE ===
        $prevClose = $result['previousClose'] ?? null;
        if ($result['regular'] !== null && $prevClose !== null) {
            $result['regularChange'] = $result['regular'] - $prevClose;
            if ($prevClose != 0) {
                $result['regularChangePercent'] = ($result['regularChange'] / $prevClose) * 100;
            } else {
                $result['regularChangePercent'] = 0;
            }
        } else {
            $result['regularChange'] = 0;
            $result['regularChangePercent'] = 0;
        }

        // === PRE-MARKET DATA ===
        // Only trust genuine pre-market data returned by Yahoo. We no longer
        // fabricate a pre-market price by copying the regular price in when
        // no real pre-market data exists (many non-US exchanges don't have a
        // formal pre-market session at all, and this was making Pre-Market
        // and Regular render identically).
        $preMarketFound = false;

        // Method 1: Check meta for preMarketPrice
        if (isset($meta['preMarketPrice'])) {
            $result['preMarket'] = (float)$meta['preMarketPrice'];
            if (isset($meta['preMarketTime'])) {
                $result['preMarketTime'] = $this->tsIn((int)$meta['preMarketTime'], 'Europe/Berlin')->format('H:i');
            } else {
                $result['preMarketTime'] = self::PRE_MARKET_TIME;
            }
            $preMarketFound = true;
        }

        // Method 2: Try from chart data (before 9:30 AM ET, and strictly
        // before the regular session starts — not overlapping regular hours).
        // Bucketing is done by the exchange's own calendar date in ET, since
        // that's what "today's pre-market" actually means, regardless of
        // what date it already is in Berlin.
        if (!$preMarketFound && !empty($timestamps) && !empty($indicators['close'])) {
            $regularDateET = isset($meta['regularMarketTime'])
                ? $this->tsIn((int)$meta['regularMarketTime'], 'America/New_York')->format('Y-m-d')
                : $this->tsIn(time(), 'America/New_York')->format('Y-m-d');
            $preMarketPrices = [];
            $preMarketTimes = [];
            
            foreach ($timestamps as $i => $ts) {
                $etDt = $this->tsIn((int)$ts, 'America/New_York');
                $dateET = $etDt->format('Y-m-d');
                $hourET = (int)$etDt->format('H');
                $minuteET = (int)$etDt->format('i');
                $price = isset($indicators['close'][$i]) ? (float)$indicators['close'][$i] : null;
                
                if ($price === null) continue;
                
                if ($dateET === $regularDateET && ($hourET < 9 || ($hourET == 9 && $minuteET < 30))) {
                    $preMarketPrices[] = $price;
                    $preMarketTimes[] = $ts;
                }
            }
            
            if (!empty($preMarketPrices)) {
                $result['preMarket'] = end($preMarketPrices);
                // Display time stays in Europe/Berlin for consistency with
                // the rest of the UI, even though bucketing used ET above.
                $result['preMarketTime'] = $this->tsIn((int)end($preMarketTimes), 'Europe/Berlin')->format('H:i');
                $preMarketFound = true;
            }
        }

        // NOTE: previous "Method 3" that fell back to the regular price when
        // no pre-market data was found has been removed on purpose. If no
        // genuine pre-market data exists, preMarket / preMarketTime stay
        // null and the UI correctly shows "N/A" instead of a fake quote.

        // === CORRECTLY CALCULATE PRE-MARKET CHANGE VS PREVIOUS CLOSE ===
        if ($result['preMarket'] !== null && $prevClose !== null) {
            $result['preMarketChange'] = $result['preMarket'] - $prevClose;
            if ($prevClose != 0) {
                $result['preMarketChangePercent'] = ($result['preMarketChange'] / $prevClose) * 100;
            } else {
                $result['preMarketChangePercent'] = 0;
            }
        } else {
            // Leave null (not 0) so the UI shows "—" / N/A rather than a
            // misleading flat 0.00% for data that was never actually available.
            $result['preMarketChange'] = null;
            $result['preMarketChangePercent'] = null;
        }

        // === POST-MARKET DATA ===
        if (isset($meta['postMarketPrice'])) {
            $result['postMarket'] = (float)$meta['postMarketPrice'];
            if (isset($meta['postMarketTime'])) {
                $result['postMarketTime'] = $this->tsIn((int)$meta['postMarketTime'], 'Europe/Berlin')->format('H:i');
            }
        }

        // Try from chart data (strictly after 4:00 PM ET / market close —
        // bucketed by the exchange's ET calendar date, using the same
        // DST-aware conversion as pre-market, not a hardcoded UTC offset).
        if ($result['postMarket'] === null && !empty($timestamps) && !empty($indicators['close'])) {
            $regularDateET = isset($meta['regularMarketTime'])
                ? $this->tsIn((int)$meta['regularMarketTime'], 'America/New_York')->format('Y-m-d')
                : $this->tsIn(time(), 'America/New_York')->format('Y-m-d');
            $postMarketPrices = [];
            $postMarketTimes = [];
            
            foreach ($timestamps as $i => $ts) {
                $etDt = $this->tsIn((int)$ts, 'America/New_York');
                $dateET = $etDt->format('Y-m-d');
                $hourET = (int)$etDt->format('H');
                $price = isset($indicators['close'][$i]) ? (float)$indicators['close'][$i] : null;
                
                if ($price === null) continue;
                
                if ($dateET === $regularDateET && $hourET >= 16) {
                    $postMarketPrices[] = $price;
                    $postMarketTimes[] = $ts;
                }
            }
            
            if (!empty($postMarketPrices)) {
                $result['postMarket'] = end($postMarketPrices);
                $result['postMarketTime'] = $this->tsIn((int)end($postMarketTimes), 'Europe/Berlin')->format('H:i');
            }
        }

        // === CORRECTLY CALCULATE POST-MARKET CHANGE VS PREVIOUS CLOSE ===
        if ($result['postMarket'] !== null && $prevClose !== null) {
            $result['postMarketChange'] = $result['postMarket'] - $prevClose;
            if ($prevClose != 0) {
                $result['postMarketChangePercent'] = ($result['postMarketChange'] / $prevClose) * 100;
            } else {
                $result['postMarketChangePercent'] = 0;
            }
        } else {
            $result['postMarketChange'] = null;
            $result['postMarketChangePercent'] = null;
        }

        return $result;
    }

    private function detectUnusualActivity(array $prices): array {
        $unusual = [
            'premarket_unusual' => false,
            'postmarket_unusual' => false,
            'regular_unusual' => false,
            'description' => [],
            'score' => 0
        ];

        if ($prices['preMarketChangePercent'] !== null && abs($prices['preMarketChangePercent']) >= self::UNUSUAL_THRESHOLD_PERCENT) {
            $unusual['premarket_unusual'] = true;
            $unusual['description'][] = sprintf(
                "Pre-market %s %.1f%% vs close",
                $prices['preMarketChangePercent'] > 0 ? '🚀' : '📉',
                abs($prices['preMarketChangePercent'])
            );
            $unusual['score'] += abs($prices['preMarketChangePercent']);
        }

        if ($prices['postMarketChangePercent'] !== null && abs($prices['postMarketChangePercent']) >= self::UNUSUAL_THRESHOLD_PERCENT) {
            $unusual['postmarket_unusual'] = true;
            $unusual['description'][] = sprintf(
                "After-hours %s %.1f%% vs close",
                $prices['postMarketChangePercent'] > 0 ? '🚀' : '📉',
                abs($prices['postMarketChangePercent'])
            );
            $unusual['score'] += abs($prices['postMarketChangePercent']);
        }

        if ($prices['regularChangePercent'] !== null && abs($prices['regularChangePercent']) >= self::UNUSUAL_THRESHOLD_PERCENT) {
            $unusual['regular_unusual'] = true;
            $unusual['description'][] = sprintf(
                "Regular %s %.1f%%",
                $prices['regularChangePercent'] > 0 ? '🚀' : '📉',
                abs($prices['regularChangePercent'])
            );
            $unusual['score'] += abs($prices['regularChangePercent']);
        }

        if ($prices['volume'] !== null && $prices['averageVolume'] !== null && $prices['averageVolume'] > 0) {
            $ratio = $prices['volume'] / $prices['averageVolume'];
            if ($ratio >= 2.0) {
                $unusual['description'][] = sprintf("📊 Volume %.1fx avg", $ratio);
                $unusual['score'] += $ratio * 0.5;
            }
        }

        return $unusual;
    }

    /**
     * Process stocks with progressive output AND unusual priority
     */
    public function processWithProgressiveOutput(): void {
        try {
            $stocks = $this->loadStocks();
        } catch (Exception $e) {
            if ($this->isCli) {
                echo "Error: " . $e->getMessage() . "\n";
            } else {
                echo "<div class='error'>Error: " . htmlspecialchars($e->getMessage()) . "</div>";
            }
            return;
        }

        $this->totalStocks = count($stocks);

        if (!$this->isCli) {
            header('Content-Type: text/html; charset=utf-8');
            header('Cache-Control: no-cache, must-revalidate');
            header('X-Accel-Buffering: no');
            ob_implicit_flush(true);
            ob_end_flush();
            $this->renderHeaderHTML();
        } else {
            echo "\n" . str_repeat('=', 80) . "\n";
            echo "📈 STOCK PRICE CHECKER\n";
            echo "Time: " . $this->currentTime->format('Y-m-d H:i:s') . " (UTC+01:00)\n";
            echo "Session: " . strtoupper($this->session) . "\n";
            echo "Total stocks: " . $this->totalStocks . "\n";
            echo "Pre-Market: " . self::PRE_MARKET_TIME . " | Close: " . self::MARKET_CLOSE_TIME . "\n";
            echo str_repeat('=', 80) . "\n\n";
        }

        foreach ($stocks as $index => $stock) {
            $symbol = $stock['stock'] ?? null;
            if (!$symbol) continue;

            // Try the symbol exactly as given first — for non-US exchanges
            // (e.g. VNA.DE on Xetra) the suffix is required by Yahoo, not
            // noise to strip. Stripping it up front was causing the fetch to
            // silently resolve to a completely different, unrelated ticker.
            // Only fall back to a stripped version if the original fails.
            $cleanSymbol = $this->cleanSymbol($symbol);
            
            if (!$this->isCli) {
                $this->flushHTML("
                    <div class='processing-status' id='status-{$index}'>
                        ⏳ Processing <strong>{$symbol}</strong>...
                    </div>
                ");
            } else {
                echo "Processing ({$index}/{$this->totalStocks}): {$symbol}... ";
            }

            $data = $this->fetchStockDataWithFallback($symbol);
            
            if ($data === null) {
                $this->failedCount++;
                if (!$this->isCli) {
                    $this->flushHTML($this->renderErrorCard($symbol, $cleanSymbol, $index));
                    $this->flushHTML("<script>document.getElementById('status-{$index}')?.remove();</script>");
                    $this->flushHTML($this->updateSummaryScript());
                } else {
                    echo "❌ FAILED\n";
                }
                continue;
            }

            $prices = $this->extractAllPrices($data);
            $unusual = $this->detectUnusualActivity($prices);
            $hasUnusual = !empty($unusual['description']);
            if ($hasUnusual) {
                $this->unusualCount++;
            }

            $result = [
                'symbol' => $symbol,
                'clean_symbol' => $cleanSymbol,
                'prices' => $prices,
                'unusual' => $unusual,
                'original_stock' => $stock,
                'has_unusual' => $hasUnusual,
                'score' => $unusual['score'] ?? 0
            ];

            if ($hasUnusual) {
                $this->unusualResults[] = $result;
            } else {
                $this->regularResults[] = $result;
            }

            $this->processedCount++;

            if (!$this->isCli) {
                $this->flushHTML("<script>document.getElementById('status-{$index}')?.remove();</script>");
                $this->flushHTML($this->renderStockCard(
                    $result['symbol'],
                    $result['prices'],
                    $result['unusual'],
                    $result['original_stock'],
                    $hasUnusual ? 'stock-card unusual-card temp-unusual' : 'stock-card temp-regular'
                ));
                $this->flushHTML($this->updateSummaryScript());
                usleep(50000);
            } else {
                echo "✅ Done\n";
                if ($hasUnusual) {
                    echo "  ⚠️ " . implode('; ', $unusual['description']) . "\n";
                }
            }
        }

        if (!$this->isCli) {
            usort($this->unusualResults, function($a, $b) {
                return $b['score'] - $a['score'];
            });

            $this->flushHTML("<script>document.getElementById('stock-container').innerHTML = '';</script>");
            usleep(100000);

            if (!empty($this->unusualResults)) {
                $this->flushHTML("
                    <div class='unusual-section'>
                        <h2>⚠️ UNUSUAL ACTIVITY DETECTED <span class='count'>{$this->unusualCount}</span></h2>
                    </div>
                ");
                foreach ($this->unusualResults as $result) {
                    $this->flushHTML($this->renderStockCard(
                        $result['symbol'],
                        $result['prices'],
                        $result['unusual'],
                        $result['original_stock'],
                        'stock-card unusual-card'
                    ));
                    usleep(30000);
                }
                $this->flushHTML("<div class='divider'>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</div>");
            }

            if (!empty($this->regularResults)) {
                $this->flushHTML("
                    <div class='regular-section'>
                        <h2>📊 All Stocks <span class='count'>{$this->processedCount}</span></h2>
                    </div>
                ");
                foreach ($this->regularResults as $result) {
                    $this->flushHTML($this->renderStockCard(
                        $result['symbol'],
                        $result['prices'],
                        $result['unusual'],
                        $result['original_stock'],
                        'stock-card'
                    ));
                    usleep(20000);
                }
            }

            $this->renderFooterHTML();
        } else {
            echo "\n" . str_repeat('=', 80) . "\n";
            
            usort($this->unusualResults, function($a, $b) {
                return $b['score'] - $a['score'];
            });
            
            if (!empty($this->unusualResults)) {
                echo "⚠️ UNUSUAL ACTIVITY DETECTED ({$this->unusualCount} stocks)\n";
                echo str_repeat('-', 80) . "\n";
                foreach ($this->unusualResults as $result) {
                    $symbol = $result['symbol'];
                    $prices = $result['prices'];
                    $unusual = $result['unusual'];
                    echo sprintf(
                        "⚠️ %s | Pre: %s @ %s | Reg: %s @ %s | Close: %s @ %s | Post: %s @ %s | %s\n",
                        $symbol,
                        $prices['preMarket'] ?? 'N/A',
                        $prices['preMarketTime'] ?? 'N/A',
                        $prices['regular'] ?? 'N/A',
                        $prices['regularMarketTime'] ?? 'N/A',
                        $prices['previousClose'] ?? 'N/A',
                        $prices['previousCloseTime'] ?? 'N/A',
                        $prices['postMarket'] ?? 'N/A',
                        $prices['postMarketTime'] ?? 'N/A',
                        implode('; ', $unusual['description'])
                    );
                }
                echo str_repeat('-', 80) . "\n\n";
            }
            
            echo "📊 ALL STOCKS\n";
            echo str_repeat('-', 80) . "\n";
            foreach ($this->regularResults as $result) {
                $symbol = $result['symbol'];
                $prices = $result['prices'];
                echo sprintf(
                    "%s | Pre: %s @ %s | Reg: %s @ %s | Close: %s @ %s | Post: %s @ %s\n",
                    $symbol,
                    $prices['preMarket'] ?? 'N/A',
                    $prices['preMarketTime'] ?? 'N/A',
                    $prices['regular'] ?? 'N/A',
                    $prices['regularMarketTime'] ?? 'N/A',
                    $prices['previousClose'] ?? 'N/A',
                    $prices['previousCloseTime'] ?? 'N/A',
                    $prices['postMarket'] ?? 'N/A',
                    $prices['postMarketTime'] ?? 'N/A'
                );
            }
            echo str_repeat('-', 80) . "\n";
            echo "✅ Processing complete!\n";
            echo "Total: {$this->totalStocks}, Processed: {$this->processedCount}, Failed: {$this->failedCount}\n";
            echo "⚠️ Unusual: {$this->unusualCount}\n";
            echo str_repeat('=', 80) . "\n";
        }
    }

    private function flushHTML($html): void {
        echo $html;
        if (ob_get_level() > 0) {
            ob_flush();
        }
        flush();
    }

    private function updateSummaryScript(): string {
        return <<<HTML
        <script>
            if (document.getElementById('total-count')) {
                document.getElementById('total-count').textContent = '{$this->totalStocks}';
                document.getElementById('processed-count').textContent = '{$this->processedCount}';
                document.getElementById('failed-count').textContent = '{$this->failedCount}';
                document.getElementById('unusual-count').textContent = '{$this->unusualCount}';
                document.getElementById('progress-info').innerHTML = '⏳ Processing: {$this->processedCount}/{$this->totalStocks}';
            }
        </script>
HTML;
    }

    private function renderHeaderHTML(): void {
        $sessionClass = 'session-' . $this->session;
        echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📈 Live Stock Monitor</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a1a;
            color: #e0e0e0;
            padding: 15px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        .header {
            background: linear-gradient(135deg, #0f0f2a, #1a1a3e);
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 15px;
            border: 1px solid #2a2a5a;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .header h1 { 
            color: #00d4ff; 
            font-size: 22px; 
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .header h1 .live-badge {
            font-size: 11px;
            background: #ff1744;
            color: #fff;
            padding: 2px 12px;
            border-radius: 20px;
            animation: pulse 1s ease-in-out infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.4; }
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes glow {
            0%, 100% { box-shadow: 0 0 5px rgba(255,23,68,0.3); }
            50% { box-shadow: 0 0 20px rgba(255,23,68,0.6); }
        }
        .header-info {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 8px;
            font-size: 13px;
        }
        .header-info span {
            background: rgba(255,255,255,0.05);
            padding: 4px 12px;
            border-radius: 20px;
        }
        .session-badge {
            display: inline-block;
            padding: 2px 14px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 11px;
            text-transform: uppercase;
        }
        .session-premarket { background: #ff6b35; color: #0a0a1a; }
        .session-regular { background: #00c853; color: #0a0a1a; }
        .session-postmarket { background: #ffd600; color: #0a0a1a; }
        .session-closed { background: #666; color: #fff; }
        
        .processing-status {
            background: #1a1a3e;
            padding: 10px 16px;
            border-radius: 8px;
            margin-bottom: 10px;
            border-left: 3px solid #00d4ff;
            animation: slideIn 0.3s;
            color: #8899bb;
            font-size: 14px;
        }
        
        .unusual-section {
            margin-bottom: 15px;
            padding: 10px 15px;
            background: linear-gradient(135deg, #1a0a0a, #2a0a0a);
            border-radius: 10px;
            border: 1px solid #ff1744;
            animation: glow 2s ease-in-out infinite;
        }
        .unusual-section h2 {
            color: #ff6b6b;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .unusual-section h2 .count {
            background: #ff1744;
            color: #fff;
            padding: 0 10px;
            border-radius: 10px;
            font-size: 12px;
        }
        .divider {
            border-top: 2px solid #1a1a3e;
            margin: 20px 0;
            text-align: center;
            padding: 10px 0;
            color: #667799;
            font-size: 13px;
        }
        .regular-section h2 {
            color: #00d4ff;
            font-size: 16px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .regular-section h2 .count {
            background: rgba(0, 212, 255, 0.1);
            padding: 0 10px;
            border-radius: 10px;
            font-size: 12px;
            color: #00d4ff;
        }
        
        .stock-card {
            background: #12122e;
            border-radius: 10px;
            margin-bottom: 12px;
            overflow: hidden;
            border: 1px solid #1a1a4a;
            animation: slideIn 0.4s;
            transition: all 0.3s;
        }
        .stock-card:hover { border-color: #2a2a6a; }
        .stock-card.unusual-card {
            border-color: #ff1744;
            background: linear-gradient(135deg, #12122e, #1a0a1a);
        }
        .stock-card.unusual-card:hover { border-color: #ff6b6b; }
        .stock-card.temp-unusual {
            border-color: #ff6b6b;
            background: linear-gradient(135deg, #12122e, #1a0a1a);
        }
        .stock-card.temp-regular {
            border-color: #1a1a4a;
        }
        
        .stock-header {
            background: #1a1a3e;
            padding: 8px 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 6px;
        }
        .stock-card.unusual-card .stock-header {
            background: #2a0a1a;
            border-bottom: 1px solid #ff1744;
        }
        .stock-symbol {
            font-weight: bold;
            font-size: 16px;
            color: #00d4ff;
        }
        .stock-card.unusual-card .stock-symbol {
            color: #ff6b6b;
        }
        .stock-exchange {
            font-size: 11px;
            color: #667799;
            background: rgba(255,255,255,0.05);
            padding: 2px 8px;
            border-radius: 10px;
        }
        .unusual-indicator {
            display: inline-block;
            background: #ff1744;
            color: #fff;
            padding: 2px 10px;
            border-radius: 10px;
            font-size: 10px;
            font-weight: bold;
            animation: pulse 1.5s ease-in-out infinite;
        }
        .unusual-reason {
            padding: 6px 14px;
            background: rgba(255, 23, 68, 0.08);
            border-bottom: 1px solid #ff1744;
            color: #ff9b9b;
            font-size: 12px;
        }
        .badge-info {
            background: rgba(0, 212, 255, 0.1);
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 10px;
            color: #00d4ff;
        }
        .badge-unusual {
            background: rgba(255, 23, 68, 0.15);
            color: #ff6b6b;
        }
        .badge-close {
            background: rgba(255, 215, 0, 0.1);
            color: #ffd600;
        }
        
        .prices-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        .prices-table th {
            background: #0a0a1a;
            padding: 6px 10px;
            text-align: left;
            font-size: 10px;
            text-transform: uppercase;
            color: #667799;
            letter-spacing: 0.3px;
            border-bottom: 2px solid #1a1a4a;
        }
        .prices-table td {
            padding: 6px 10px;
            border-bottom: 1px solid #1a1a3a;
        }
        .prices-table tr:last-child td { border-bottom: none; }
        .prices-table tr:hover { background: rgba(255,255,255,0.02); }
        
        .row-premarket { border-left: 3px solid #ff6b35; }
        .row-regular { border-left: 3px solid #00c853; }
        .row-close { border-left: 3px solid #ffd600; background: rgba(255, 215, 0, 0.04); }
        .row-postmarket { border-left: 3px solid #ffd600; }
        .row-current { border-left: 3px solid #00d4ff; background: rgba(0, 212, 255, 0.04); }
        
        .session-label {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }
        .session-label .time {
            font-size: 10px;
            color: #667799;
            font-weight: normal;
        }
        
        .price-value { font-weight: 600; }
        .price-positive { color: #00c853; }
        .price-negative { color: #ff1744; }
        .price-neutral { color: #888; }
        .price-close { color: #ffd600; }
        
        .status-available { color: #00c853; }
        .status-unavailable { color: #666; }
        .status-reference { color: #ffd600; }
        
        .summary-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            background: #0a0a1a;
            padding: 10px 14px;
            border-radius: 8px;
            margin-bottom: 15px;
            border: 1px solid #1a1a3e;
            position: sticky;
            top: 60px;
            z-index: 99;
        }
        .summary-item {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
        }
        .summary-item .label { color: #667799; }
        .summary-item .value { font-weight: bold; color: #00d4ff; }
        .summary-item .value.warning { color: #ff1744; }
        .summary-item .value.success { color: #00c853; }
        
        .error-card {
            background: #2a0a0a;
            border: 1px solid #4a1a1a;
            border-radius: 8px;
            padding: 10px 14px;
            margin-bottom: 10px;
            color: #ff6b6b;
            font-size: 13px;
            animation: slideIn 0.3s;
        }
        .error-card .hint {
            color: #8899bb;
            font-size: 12px;
            margin-top: 4px;
        }
        
        .footer {
            text-align: center;
            padding: 15px;
            color: #667799;
            font-size: 12px;
            border-top: 1px solid #1a1a3e;
            margin-top: 15px;
        }
        
        @media (max-width: 768px) {
            .prices-table { font-size: 11px; }
            .prices-table th, .prices-table td { padding: 4px 6px; }
            .stock-symbol { font-size: 14px; }
            .header h1 { font-size: 18px; }
            .summary-bar { top: 50px; }
            .session-label .time { font-size: 9px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
                📈 Live Stock Monitor
                <span class="live-badge">● LIVE</span>
                <span class="live-counter" id="counter">Loading...</span>
            </h1>
            <div class="header-info">
                <span>🕐 {$this->currentTime->format('Y-m-d H:i:s')} (UTC+01:00)</span>
                <span><span class="session-badge {$sessionClass}">{$this->session}</span></span>
                <span id="progress-info">⏳ Loading stocks...</span>
                <span>⚠️ Threshold: " . self::UNUSUAL_THRESHOLD_PERCENT . "%</span>
                <span>📌 Pre: " . self::PRE_MARKET_TIME . "</span>
                <span>📌 Close: " . self::MARKET_CLOSE_TIME . "</span>
            </div>
        </div>
        <div class="summary-bar">
            <div class="summary-item">
                <span class="label">📊 Total:</span>
                <span class="value" id="total-count">0</span>
            </div>
            <div class="summary-item">
                <span class="label">✅ Processed:</span>
                <span class="value success" id="processed-count">0</span>
            </div>
            <div class="summary-item">
                <span class="label">❌ Failed:</span>
                <span class="value" id="failed-count">0</span>
            </div>
            <div class="summary-item">
                <span class="label">⚠️ Unusual:</span>
                <span class="value warning" id="unusual-count">0</span>
            </div>
        </div>
        <div id="stock-container">
HTML;
        flush();
    }

    private function renderErrorCard(string $symbol, string $cleanSymbol, int $index): string {
        $hint = '';
        if (str_ends_with($symbol, '.SS')) {
            $hint = '💡 Try using the numeric code without .SS (e.g., 688825)';
        } elseif (str_ends_with($symbol, '.DE') && preg_match('/^[A-Z]{3,4}\.DE$/', $symbol)) {
            $hint = '💡 Try removing .DE suffix';
        }
        
        return <<<HTML
        <div class="error-card">
            ❌ <strong>{$symbol}</strong> (as {$cleanSymbol}) - Failed to fetch data
            <div class="hint">{$hint}</div>
        </div>
HTML;
    }

    private function renderStockCard(string $symbol, array $prices, array $unusual, array $originalStock, string $cardClass): string {
        $hasUnusual = !empty($unusual['description']);
        $unusualDesc = $hasUnusual ? implode('; ', $unusual['description']) : '';
        
        // Prefer the exchange_market already present in stocks.json — it's
        // ground truth ("NASDAQ", "NYSE", "OTCMKTS") supplied by the data
        // source, rather than Yahoo's terser internal code (e.g. "NMS",
        // "PCX", "YHD") which isn't as readable and was being shown even
        // when better information already existed.
        $exchange = $originalStock['exchange_market'] ?? $prices['exchange'] ?? 'N/A';
        $isOtc = stripos($exchange, 'OTC') !== false;
        $currency = $prices['currency'] ?? $originalStock['currency'] ?? 'USD';
        $marketState = $prices['marketState'] ?? 'UNKNOWN';
        
        $currentRow = $this->session;
        if ($currentRow === 'closed') $currentRow = 'regular';

        // Get times for each session
        $preTime = $prices['preMarketTime'] ?? 'N/A';
        $regTime = $prices['regularMarketTime'] ?? 'N/A';
        $closeTime = $prices['previousCloseTime'] ?? self::MARKET_CLOSE_TIME;
        $postTime = $prices['postMarketTime'] ?? 'N/A';

        // Render rows in order: Pre-Market → Regular → Close → After-Hours.
        // OTC stocks (Pink Sheets etc.) generally have no formal pre/post
        // market session at all, so N/A there is expected — say so instead
        // of showing a bare, unexplained dash.
        $preRow = $this->renderPriceRow('Pre-Market', $preTime, 'premarket', $prices, 'preMarket', $currentRow, false, $isOtc);
        $regRow = $this->renderPriceRow('Regular', $regTime, 'regular', $prices, 'regular', $currentRow, false, false);
        $closeRow = $this->renderPriceRow('Close', $closeTime, 'close', $prices, 'previousClose', $currentRow, true, false);
        $postRow = $this->renderPriceRow('After-Hours', $postTime, 'postmarket', $prices, 'postMarket', $currentRow, false, $isOtc);

        $unusualBadge = $hasUnusual ? '<span class="unusual-indicator">⚠️ UNUSUAL</span>' : '';
        // Show WHY a stock is flagged as a visible line, not just a hover
        // tooltip — tooltips are invisible on mobile and in any plain-text
        // copy of the page, which was leaving the badge unexplained.
        $unusualReasonLine = $hasUnusual
            ? '<div class="unusual-reason">' . htmlspecialchars($unusualDesc) . '</div>'
            : '';

        return <<<HTML
        <div class="{$cardClass}" id="stock-{$symbol}">
            <div class="stock-header">
                <div>
                    <span class="stock-symbol">{$symbol}</span>
                    <span class="stock-exchange">{$exchange}</span>
                    <span class="badge-info">{$currency}</span>
                    <span class="badge-info">Market: {$marketState}</span>
                </div>
                <div>
                    {$unusualBadge}
                </div>
            </div>
            {$unusualReasonLine}
            <table class="prices-table">
                <thead>
                    <tr>
                        <th style="width:130px;">Session</th>
                        <th>Price</th>
                        <th>Change</th>
                        <th>Change %</th>
                        <th>Volume</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {$preRow}
                    {$regRow}
                    {$closeRow}
                    {$postRow}
                </tbody>
            </table>
        </div>
HTML;
    }

    private function renderPriceRow(string $label, string $time, string $type, array $prices, string $key, string $currentRow, bool $isClose, bool $otcNoSession = false): string {
        $price = $prices[$key] ?? null;
        $available = $price !== null;
        
        if ($isClose) {
            $priceDisplay = $available ? number_format($price, 4) : '—';
            return <<<HTML
            <tr class="row-close">
                <td>
                    <div class="session-label">
                        <strong>{$label}</strong>
                        <span class="time">{$time}</span>
                    </div>
                </td>
                <td><span class="price-value price-close">{$priceDisplay}</span></td>
                <td>—</td>
                <td>—</td>
                <td style="font-size:11px;color:#667799;">—</td>
                <td><span class="status-reference">📌 Reference</span></td>
            </tr>
HTML;
        }

        // For Regular, Pre-Market, After-Hours - all changes are vs Previous Close
        $changeKey = $key . 'Change';
        $changePercentKey = $key . 'ChangePercent';
        
        $change = $prices[$changeKey] ?? null;
        $changePercent = $prices[$changePercentKey] ?? null;
        $volume = $prices['volume'] ?? null;
        
        $rowClass = 'row-' . $type;
        if ($type === $currentRow) $rowClass .= ' row-current';
        
        $priceDisplay = $available ? number_format($price, 4) : '—';
        
        $priceClass = 'price-neutral';
        if ($available && $change !== null && $change != 0) {
            if ($change > 0) $priceClass = 'price-positive';
            elseif ($change < 0) $priceClass = 'price-negative';
        }
        
        $changeDisplay = ($change !== null && $change != 0) ? number_format($change, 4) : '—';
        $changeClass = 'price-neutral';
        if ($change !== null && $change != 0) {
            $changeClass = $change > 0 ? 'price-positive' : 'price-negative';
        }
        
        $changePercentDisplay = ($changePercent !== null && $changePercent != 0) ? number_format($changePercent, 2) . '%' : '—';
        $changePercentClass = 'price-neutral';
        if ($changePercent !== null && $changePercent != 0) {
            $changePercentClass = $changePercent > 0 ? 'price-positive' : 'price-negative';
        }
        
        // OTC/Pink Sheet stocks generally don't have a formal pre/post
        // market session at all — an honest "no session" beats a bare,
        // unexplained N/A that looks like a fetch failure.
        if (!$available && $otcNoSession) {
            $statusIcon = '➖';
            $statusText = 'No OTC session';
        } else {
            $statusIcon = $available ? '✅' : '❌';
            $statusText = $available ? 'Available' : 'N/A';
        }
        $statusClass = $available ? 'status-available' : 'status-unavailable';
        $volumeDisplay = $volume !== null ? number_format($volume) : '—';
        
        return <<<HTML
        <tr class="{$rowClass}">
            <td>
                <div class="session-label">
                    <strong>{$label}</strong>
                    <span class="time">{$time}</span>
                </div>
            </td>
            <td><span class="price-value {$priceClass}">{$priceDisplay}</span></td>
            <td><span class="{$changeClass}">{$changeDisplay}</span></td>
            <td><span class="{$changePercentClass}">{$changePercentDisplay}</span></td>
            <td style="font-size:11px;color:#667799;">{$volumeDisplay}</td>
            <td><span class="{$statusClass}">{$statusIcon} {$statusText}</span></td>
        </tr>
HTML;
    }

    private function renderFooterHTML(): void {
        echo <<<HTML
        </div>
        <div class="footer">
            ✅ All stocks processed &bull; 
            Total: {$this->totalStocks} &bull; 
            Processed: {$this->processedCount} &bull; 
            Failed: {$this->failedCount} &bull; 
            ⚠️ Unusual: {$this->unusualCount}
        </div>
    </div>
    <script>
        document.getElementById('total-count').textContent = '{$this->totalStocks}';
        document.getElementById('processed-count').textContent = '{$this->processedCount}';
        document.getElementById('failed-count').textContent = '{$this->failedCount}';
        document.getElementById('unusual-count').textContent = '{$this->unusualCount}';
        document.getElementById('progress-info').innerHTML = '✅ Complete';
        
        const unusualSection = document.querySelector('.unusual-section');
        if (unusualSection) {
            setTimeout(() => {
                unusualSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 500);
        }
    </script>
</body>
</html>
HTML;
        flush();
    }
}

// ==================== EXECUTION ====================

$checker = new StockPriceChecker('stocks.json');
$checker->processWithProgressiveOutput();
?>