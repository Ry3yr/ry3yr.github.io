<?php

// Function to recursively scan all directories and files
function scanDirectory($dir) {
    $results = [];
    
    // Open directory
    $files = scandir($dir);

    foreach ($files as $file) {
        // Skip . and ..
        if ($file == '.' || $file == '..') {
            continue;
        }

        $fullPath = $dir . DIRECTORY_SEPARATOR . $file;

        // If it's a directory, recursively scan it
        if (is_dir($fullPath)) {
            $results = array_merge($results, scanDirectory($fullPath));
        } else {
            // If it's a file, add it to the results
            $results[] = $fullPath;
        }
    }

    return $results;
}

// Function to check if CORS is correctly set in the .htaccess files
function checkCORSHeaders($filePath) {
    $issues = [];

    // Read the .htaccess file content
    $content = file_get_contents($filePath);
    
    // Check for specific CORS-related headers
    if (preg_match('/Header\s+always\s+set\s+Access-Control-Allow-Origin/i', $content)) {
        $issues[] = 'CORS header found in: ' . $filePath;
    } else {
        $issues[] = 'No CORS header set in: ' . $filePath;
    }

    // Additional checks for common misconfigurations or missing rules can go here.
    return $issues;
}

// Function to check all directories and .htaccess files
function checkHTACCESSFiles($rootDir) {
    $issues = [];

    // Recursively scan the root directory
    $files = scanDirectory($rootDir);

    // Iterate through all files to find .htaccess
    foreach ($files as $file) {
        // Check if the file is an .htaccess file
        if (basename($file) === '.htaccess') {
            $issues = array_merge($issues, checkCORSHeaders($file));
        }
    }

    return $issues;
}

// Main execution
$rootDir = $_SERVER['DOCUMENT_ROOT'];  // Get the root directory of the server
$issues = checkHTACCESSFiles($rootDir);

echo "<h1>HTACCESS CORS Check Results</h1>";

if (empty($issues)) {
    echo "<p>No CORS issues found! All .htaccess files seem fine.</p>";
} else {
    echo "<ul>";
    foreach ($issues as $issue) {
        echo "<li>" . htmlspecialchars($issue) . "</li>";
    }
    echo "</ul>";
}
?>
