<details><a target="_blank" href="z_listgen.php" style=color:blue>Refresh list</a></details><br><br>

<?php
// Path to the z_list.txt report
$reportPath = './z_list.txt';
// Read the contents of the z_list.txt report
$reportContent = file_get_contents($reportPath);
// Get the current directory
$currentDir = getcwd();
// Explode the report content into an array of filenames
$reportFiles = explode("\n", $reportContent);
// Get the file type from the query string
$fileType = isset($_GET['filetype']) ? $_GET['filetype'] : null;
// Initialize counters for files and folders
$fileCount = 0;
$folderCount = 0;
$okCount = 0;
$missingCount = 0;
// Iterate over the files in the current directory
foreach (scandir($currentDir) as $filename) {
    // Exclude hidden files and z_listcheck.php
    if ($filename[0] === '.' || $filename === 'z_listcheck.php') {
        continue;
    }
    // Check if the file is a directory
    if (is_dir($filename)) {
        // Increment folder count
        $folderCount++;
        // Move to the next iteration to list folders at the top
        continue;
    }
    if (empty($fileType) || pathinfo($filename, PATHINFO_EXTENSION) === $fileType) {
        // Increment file count
        $fileCount++;
        if (in_array($filename, $reportFiles)) {
            // Increment [ok] count
            $okCount++;
            // Display [ok] in green for matching files
            echo '<span style="color: green;">[ok]</span> <a href="' . $filename . '" target="_blank">' . $filename . '</a><br>';
        } else {
            // Increment missing count
            $missingCount++;
            // Display the filename in red for non-matching files
            echo '<span style="color: red;">[missing]</span> <a href="' . $filename . '" target="_blank">' . $filename . '</a><br>';
        }
    }
}
echo '<p>Total Files: ' . $fileCount . ' Total Folders: ' . $folderCount . '</p>';
//echo '<p>Total Folders: ' . $folderCount . '</p>';
echo '<hr>';
// Display the count of [ok] and missing files
echo '<p>Number [ok]: ' . $okCount;
if ($okCount === $fileCount) {
    echo ' (all)';
}
echo '</p>';
echo '<p>Number of missing: ' . $missingCount . '</p>';
?>