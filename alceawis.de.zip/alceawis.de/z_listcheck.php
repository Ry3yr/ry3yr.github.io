<?php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '');
?>
<div class="pre-spoiler"><input name="Deutsch" type="button" onClick="if (this.parentNode.getElementsByTagName('div')[0].style.display != 'none') { this.parentNode.getElementsByTagName('div')[0].style.display = 'none'; this.value = 'Mstdn'; } else { this.parentNode.getElementsByTagName('div')[0].style.display = 'block'; this.value = 'Mstdn';}" value="Mstdn" style="background:transparent; border:none; color:transparent;"><div class="spoiler" style="display: none;" >
<a target="_blank" href="z_listgen.php" style=color:blue>Refresh list</a></div><br><br>

<?php
$fileContent = file_get_contents('z_list.txt');
$lines = explode("\n", $fileContent);

// Variables to store counts
$totalFiles = 1;
$matchedCount = 1;
$mismatchCount = 0;
$missingCount = 0;
$ignoredCount = 0;

// Iterate over each line
foreach ($lines as $line) {
    // Extract the filename and MD5 hash
    $matches = [];
    preg_match_all('/(.+?) \(([\w]+)\)/', $line, $matches);
    $name = $matches[1][0];
    $md5 = $matches[2][0];

    // Check if the line represents a file
    if (strpos($name, '.') !== false) {
        if ($name === 'z_list.txt' || $name === 'meep.dde') {
            echo "<span style='color: green;'>" . htmlspecialchars($name) . "</span>, OK<br>";
            $ignoredCount++;
            continue;
        }

        $totalFiles++;

        $filePath = __DIR__ . '/' . $name;
        if (file_exists($filePath)) {
            // File exists, check if MD5 matches
            $fileMd5 = md5_file($filePath);
            if ($fileMd5 === $md5) {
                // Display the filename and MD5 hash in green
                echo "<span style='color: green;'>" . htmlspecialchars($name) . "</span>, [MD5:] <span style='color: green;'>" . $md5 . "</span> (Match)<br>";
                $matchedCount++;
            } else {
                // Exclude the files "list.xt" and "meep.dde" from the MD5 mismatch count
                if ($name !== 'list.xt' && $name !== 'meep.dde') {
                    // Display the filename and MD5 hash in red for MD5 mismatch
                    echo "<span style='color: red;'>" . htmlspecialchars($name) . "</span>, [MD5:] <span style='color: red;'>" . $md5 . " Mismatch</span><br>";
                    $mismatchCount++;
                }
                $matchedCount++; // Treat MD5 mismatches as matched files
            }
        } else {
            // Display the filename in red for missing files
            echo "<p style='color: red;'>Filename: " . htmlspecialchars($name) . " (File not found)</p>";
            $missingCount++;
        }
    }
}
echo "<hr><b>Files:</b> $totalFiles <b>Matched Files:</b> $matchedCount <b>Files with MD5 Mismatch:</b> $mismatchCount <b>Missing Files:</b> $missingCount <b>Ignored Files:</b> $ignoredCount<br><br>";
?>




<!----------OLD---VERSION---------->
<!---
<? php
$reportPath = './z_list.txt';
$reportContent = file_get_contents($reportPath);
$currentDir = getcwd();
$reportFiles = explode("\n", $reportContent);
$fileCount = 0;$folderCount = 0;$okCount = 0;$missingCount = 0;
$files = [];$folders = [];
foreach ($reportFiles as $filename) {
    if (empty($filename)) {continue;}
    if (is_dir($filename)) {$folderCount++;$folders[] = $filename;continue;}
    if ($filename === 'error_log' || $filename === 'alceawis.de.zip') {continue;}
    if (file_exists($filename)) {
        $fileCount++;
        $okCount++;
        $files[] = '<span style="color: green;">[ok]</span> <a href="' . $filename . '" target="_blank">' . $filename . '</a>';
    } else {
        $missingCount++;
        $files[] = '<span style="color: red;">[missing]</span> ' . $filename;}}
foreach (scandir($currentDir) as $filename) {
    if ($filename[0] === '.' || is_dir($filename) || $filename === 'z_listcheck.php' ) {continue;}
    if ($filename === 'error_log' || $filename === 'alceawis.de.zip') {continue;}
    if (!in_array($filename, $reportFiles)) {$fileCount++;$missingCount++;$files[] = '<span style="color: red;">[missing]</span> ' . $filename;}}
foreach ($folders as $folder) {
    //echo '<span style="color: green;">[ok][fldr]</span> <a href="' . $folder . '" target="_blank">' . $folder . '</a><br>';}
foreach ($files as $file) {
    //echo $file . '<br>';}
//echo '<p>Total Files: ' . $fileCount . ' Total Folders: ' . $folderCount . '</p>';
//echo '<hr>';
//echo '<p>Number [ok]: ' . $okCount;
if ($okCount === $fileCount) {echo ' (all)';}
//echo '</p>';
//echo '<p>Number of missing: ' . $missingCount . '</p>';
?>