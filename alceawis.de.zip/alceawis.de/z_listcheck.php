<?php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '');
?>

<!---Filecheck-->
<?php
$filename = "z_list.txt";
date_default_timezone_set('Europe/Berlin');
if (file_exists($filename)) {
    $timestamp = filectime($filename);
    $creation_date = date("Y-m-d H:i:s", $timestamp);
    echo "File creation date: " . $creation_date;
} else {
    echo "File not found.";}
?>

<!----LGn--------------->
   <script>
        function stringToArrayBuffer(str) {
            var encoder = new TextEncoder();
            return encoder.encode(str);
        }
        function arrayBufferToString(buffer) {
            var decoder = new TextDecoder();
            return decoder.decode(buffer);
        }
        async function decryptAES(ciphertext, key, iv) {
            var decrypted = await crypto.subtle.decrypt(
                {
                    name: "AES-CBC",
                    iv: iv
                },
                key,
                ciphertext
            );
            return new Uint8Array(decrypted);
        }
        async function handleDecrypt(event) {
            event.preventDefault();
            var password = document.getElementById("password").value;
            var encryptedHex = document.getElementById("encryptedOutput").value;
            var passwordBuffer = stringToArrayBuffer(password);
            var keyMaterial = await crypto.subtle.importKey(
                "raw",
                passwordBuffer,
                { name: "PBKDF2" },
                false,
                ["deriveKey"]
            );
            var aesKey = await crypto.subtle.deriveKey(
                {
                    name: "PBKDF2",
                    salt: new Uint8Array(16), // Use a random salt for real-world scenarios
                    iterations: 100000,
                    hash: "SHA-256"
                },
                keyMaterial,
                { name: "AES-CBC", length: 256 },
                true,
                ["encrypt", "decrypt"]
            );
            var ivHex = encryptedHex.substr(0, 32);
            var ciphertextHex = encryptedHex.substr(32);
            var ivBytes = new Uint8Array(ivHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
            var ciphertextBytes = new Uint8Array(ciphertextHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
            var decryptedBytes = await decryptAES(ciphertextBytes, aesKey, ivBytes);
            var decryptedHTML = arrayBufferToString(decryptedBytes);
            document.getElementById("decryptedOutput").innerHTML = decryptedHTML;
        }
    </script>
    <details><summary>-</summary><form onsubmit="handleDecrypt(event)">
        <input type="password" id="password" required>
        <textarea id="encryptedOutput" rows="10" cols="50" style="display: none;">da7c94de3b428148a1e476875e10ccc1bf63f3880c807c7d07a75f0d20b745b4bc21ae2a02d695506e5f945020f094b6c3b7bd89745c9802a7ce30a1822e2e522bdf30bcd4aee77d9d86378eaacdb6d5f96fd7ee6bc510c7f5527300e31da9f8
</textarea>
        <input type="submit" value="DC">
</form><div><div id="decryptedOutput"></div></div></details>
<!--------LGEnd------------------------------------>
<?php
$fileContent = file_get_contents('z_list.txt');
$lines = explode("\n", $fileContent);
// Variables to store counts
$totalFiles = 1;
$matchedCount = 1;
$mismatchCount = 0;
$missingCount = 0;
$ignoredCount = 0;

// Iterate over each line
foreach ($lines as $line) {
    // Extract the filename and MD5 hash
    $matches = [];
    preg_match_all('/(.+?) \(([\w]+)\)/', $line, $matches);
    $name = $matches[1][0];
    $md5 = $matches[2][0];

    // Check if the line represents a file
    if (strpos($name, '.') !== false) {
        if ($name === 'z_list.txt' || $name === 'meep.dde') {
            echo "<span style='color: green;'>" . htmlspecialchars($name) . "</span>, OK<br>";
            $ignoredCount++;
            continue;
        }

        $totalFiles++;

        $filePath = __DIR__ . '/' . $name;
        if (file_exists($filePath)) {
            // File exists, check if MD5 matches
            $fileMd5 = md5_file($filePath);
            if ($fileMd5 === $md5) {
                // Display the filename and MD5 hash in green
                echo "<span style='color: green;'>" . htmlspecialchars($name) . "</span>, [MD5:] <span style='color: green;'>" . $md5 . "</span> (Match)<br>";
                $matchedCount++;
            } else {
                // Exclude the files "list.xt" and "meep.dde" from the MD5 mismatch count
                if ($name !== 'list.xt' && $name !== 'meep.dde') {
                    // Display the filename and MD5 hash in red for MD5 mismatch
                    echo "<span style='color: red;'>" . htmlspecialchars($name) . "</span>, [MD5:] <span style='color: red;'>" . $md5 . " Mismatch</span><br>";
                    $mismatchCount++;
                }
                $matchedCount++; // Treat MD5 mismatches as matched files
            }
        } else {
            // Display the filename in red for missing files
            echo "<p style='color: red;'>Filename: " . htmlspecialchars($name) . " (File not found)</p>";
            $missingCount++;
        }
    }
}
echo "<hr><b>Files:</b> $totalFiles <b>Matched Files:</b> $matchedCount <b>Files with MD5 Mismatch:</b> $mismatchCount <b>Missing Files:</b> $missingCount <b>Ignored Files:</b> $ignoredCount<br><br>";
?>




<!----------OLD---VERSION---------->
<!---
<? php
$reportPath = './z_list.txt';
$reportContent = file_get_contents($reportPath);
$currentDir = getcwd();
$reportFiles = explode("\n", $reportContent);
$fileCount = 0;$folderCount = 0;$okCount = 0;$missingCount = 0;
$files = [];$folders = [];
foreach ($reportFiles as $filename) {
    if (empty($filename)) {continue;}
    if (is_dir($filename)) {$folderCount++;$folders[] = $filename;continue;}
    if ($filename === 'error_log' || $filename === 'alceawis.de.zip') {continue;}
    if (file_exists($filename)) {
        $fileCount++;
        $okCount++;
        $files[] = '<span style="color: green;">[ok]</span> <a href="' . $filename . '" target="_blank">' . $filename . '</a>';
    } else {
        $missingCount++;
        $files[] = '<span style="color: red;">[missing]</span> ' . $filename;}}
foreach (scandir($currentDir) as $filename) {
    if ($filename[0] === '.' || is_dir($filename) || $filename === 'z_listcheck.php' ) {continue;}
    if ($filename === 'error_log' || $filename === 'alceawis.de.zip') {continue;}
    if (!in_array($filename, $reportFiles)) {$fileCount++;$missingCount++;$files[] = '<span style="color: red;">[missing]</span> ' . $filename;}}
foreach ($folders as $folder) {
    //echo '<span style="color: green;">[ok][fldr]</span> <a href="' . $folder . '" target="_blank">' . $folder . '</a><br>';}
foreach ($files as $file) {
    //echo $file . '<br>';}
//echo '<p>Total Files: ' . $fileCount . ' Total Folders: ' . $folderCount . '</p>';
//echo '<hr>';
//echo '<p>Number [ok]: ' . $okCount;
if ($okCount === $fileCount) {echo ' (all)';}
//echo '</p>';
//echo '<p>Number of missing: ' . $missingCount . '</p>';
?>
