<details><a target="_blank" href="z_listgen.php" style=color:blue>Refresh list</a></details><br><br>

<?php
$reportPath = './z_list.txt';
$reportContent = file_get_contents($reportPath);
$currentDir = getcwd();
$reportFiles = explode("\n", $reportContent);
$fileCount = 0;
$folderCount = 0;
$okCount = 0;
$missingCount = 0;
$files = [];
$folders = [];
foreach ($reportFiles as $filename) {
    if (empty($filename)) {
        continue;
    }
    if (is_dir($filename)) {
        $folderCount++;
        $folders[] = $filename;
        continue;
    }
    if ($filename === 'error_log' || $filename === 'alceawis.de.zip') {
        continue;
    }
    if (file_exists($filename)) {
        $fileCount++;
        $okCount++;
        $files[] = '<span style="color: green;">[ok]</span> <a href="' . $filename . '" target="_blank">' . $filename . '</a>';
    } else {
        $missingCount++;
        $files[] = '<span style="color: red;">[missing]</span> ' . $filename;
    }
}
foreach (scandir($currentDir) as $filename) {
    if ($filename[0] === '.' || is_dir($filename) || $filename === 'z_listcheck.php' ) {
        continue;
    }
    if ($filename === 'error_log' || $filename === 'alceawis.de.zip') {
        continue;
    }
    if (!in_array($filename, $reportFiles)) {
        $fileCount++;
        $missingCount++;
        $files[] = '<span style="color: red;">[missing]</span> ' . $filename;
    }
}
foreach ($folders as $folder) {
    echo '<span style="color: green;">[ok]</span> <a href="' . $folder . '" target="_blank">' . $folder . '</a><br>';
}
foreach ($files as $file) {
    echo $file . '<br>';
}
echo '<p>Total Files: ' . $fileCount . ' Total Folders: ' . $folderCount . '</p>';
echo '<hr>';
echo '<p>Number [ok]: ' . $okCount;
if ($okCount === $fileCount) {
    echo ' (all)';
}
echo '</p>';
echo '<p>Number of missing: ' . $missingCount . '</p>';
?>
