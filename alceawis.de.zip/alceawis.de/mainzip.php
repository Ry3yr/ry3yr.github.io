<!--<a target=_blank href="alceawis.de.zip">(dld)</a><br>-->
<?php
$delfile = 'alceawis.de.zip';
if (file_exists($delfile)) {
    $fileModifiedTime = filemtime($delfile);
    $currentTime = time();
    $fifteenMinutesAgo = $currentTime - (15 * 60);
    if ($fileModifiedTime < $fifteenMinutesAgo) {
        unlink($delfile);
        echo "File deleted successfully.<br>";
    } else {
        echo "File is not older than 15 minutes.<br>";
    }
} else {
    echo "File does not exist.<br>";
}
?>


<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $zip = new ZipArchive();
    $zipFileName = __DIR__ . '/alceawis.de.zip';
    $intermediateFolderName = pathinfo($zipFileName, PATHINFO_FILENAME);

    if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator('.', RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $name => $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = $intermediateFolderName . '/' . substr($filePath, strlen(__DIR__) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }

        $zip->close();
         //$downloadLink = '<a target=_blank href="' . $zipFileName . '">Click here to download</a>';
         //$downloadLink = '<a target=_blank href="alceawis.de.zip">Click here to download the zip file</a>';
         $downloadLink = '<a target=_blank href="alceawis.de.zip?v=' . time() . '">Click here to download the zip file</a>';
        echo 'Files zipped successfully. ' . $downloadLink;
    } else {
        echo 'Failed to create zip file.';
    }
}
?>

<form method="POST">
    <button type="submit">Zip Files</button>
</form>

<!---delete-->
<?php
$file = 'alceawis.de.zip';
if (isset($_GET['delete'])) {
    if (file_exists($file)) {
        unlink($file);
        echo "File deleted successfully.";
    } else {
        echo "File not found.";
    }
}
?>
<a href="?delete=true">Click here to delete zip</a>



<!----old---
PD9waHAKJGRlbGZpbGUgPSAnYWxjZWF3aXMuZGUuemlwJzsKaWYgKGZpbGVfZXhpc3RzKCRkZWxmaWxlKSkgewogICAgdW5saW5rKCRkZWxmaWxlKTsKICAgIGVjaG8gIkZpbGUgZGVsZXRlZCBzdWNjZXNzZnVsbHkuPGJyPiI7Cn0gZWxzZSB7CiAgICBlY2hvICJGaWxlIGRvZXMgbm90IGV4aXN0Ljxicj4iOwp9CiR6aXAgPSBuZXcgWmlwQXJjaGl2ZSgpOwokemlwRmlsZU5hbWUgPSAnYWxjZWF3aXMuZGUuemlwJzsKJGludGVybWVkaWF0ZUZvbGRlck5hbWUgPSBwYXRoaW5mbygkemlwRmlsZU5hbWUsIFBBVEhJTkZPX0ZJTEVOQU1FKTsKaWYgKCR6aXAtPm9wZW4oJHppcEZpbGVOYW1lLCBaaXBBcmNoaXZlOjpDUkVBVEUgfCBaaXBBcmNoaXZlOjpPVkVSV1JJVEUpID09PSB0cnVlKSB7CiAgICAkZmlsZXMgPSBuZXcgUmVjdXJzaXZlSXRlcmF0b3JJdGVyYXRvcigKICAgICAgICBuZXcgUmVjdXJzaXZlRGlyZWN0b3J5SXRlcmF0b3IoJy4nLCBSZWN1cnNpdmVEaXJlY3RvcnlJdGVyYXRvcjo6U0tJUF9ET1RTKSwKICAgICAgICBSZWN1cnNpdmVJdGVyYXRvckl0ZXJhdG9yOjpMRUFWRVNfT05MWQogICAgKTsKICAgIGZvcmVhY2ggKCRmaWxlcyBhcyAkbmFtZSA9PiAkZmlsZSkgewogICAgICAgIGlmICghJGZpbGUtPmlzRGlyKCkpIHsKICAgICAgICAgICAgJGZpbGVQYXRoID0gJGZpbGUtPmdldFJlYWxQYXRoKCk7CiAgICAgICAgICAgICRyZWxhdGl2ZVBhdGggPSAkaW50ZXJtZWRpYXRlRm9sZGVyTmFtZSAuICcvJyAuIHN1YnN0cigkZmlsZVBhdGgsIHN0cmxlbihfX0RJUl9fKSArIDEpOwogICAgICAgICAgICAkemlwLT5hZGRGaWxlKCRmaWxlUGF0aCwgJHJlbGF0aXZlUGF0aCk7CiAgICAgICAgfQogICAgfQogICAgJHppcC0+Y2xvc2UoKTsKICAgICRkb3dubG9hZExpbmsgPSAnPGEgaHJlZj0iJyAuICR6aXBGaWxlTmFtZSAuICciPkNsaWNrIGhlcmUgdG8gZG93bmxvYWQgdGhlIHppcCBmaWxlPC9hPic7CiAgICBlY2hvICdGaWxlcyB6aXBwZWQgc3VjY2Vzc2Z1bGx5LiAnIC4gJGRvd25sb2FkTGluazsKfSBlbHNlIHsKICAgIGVjaG8gJ0ZhaWxlZCB0byBjcmVhdGUgemlwIGZpbGUuJzsKfQo/PgoKPCEtLS1kZWxldGUtLT4KPD9waHAKJGZpbGUgPSAnYWxjZWF3aXMuZGUuemlwJzsKaWYgKGlzc2V0KCRfR0VUWydkZWxldGUnXSkpIHsKICAgIGlmIChmaWxlX2V4aXN0cygkZmlsZSkpIHsKICAgICAgICB1bmxpbmsoJGZpbGUpOwogICAgICAgIGVjaG8gIkZpbGUgZGVsZXRlZCBzdWNjZXNzZnVsbHkuIjsKICAgIH0gZWxzZSB7CiAgICAgICAgZWNobyAiRmlsZSBub3QgZm91bmQuIjsKICAgIH0KfQo/Pgo8YSBocmVmPSI/ZGVsZXRlPXRydWUiPkNsaWNrIGhlcmUgdG8gZGVsZXRlIHppcDwvYT4K
--->
