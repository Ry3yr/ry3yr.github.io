<?php
$delfile = 'alceawis.de.zip';
if (file_exists($delfile)) {
    unlink($delfile);
    echo "File deleted successfully.<br>";
} else {
    echo "File does not exist.<br>";
}
$zip = new ZipArchive();
$zipFileName = 'alceawis.de.zip';
$intermediateFolderName = pathinfo($zipFileName, PATHINFO_FILENAME);
if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator('.', RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    foreach ($files as $name => $file) {
        if (!$file->isDir()) {
            $filePath = $file->getRealPath();
            $relativePath = $intermediateFolderName . '/' . substr($filePath, strlen(__DIR__) + 1);
            $zip->addFile($filePath, $relativePath);
        }
    }
    $zip->close();
    $downloadLink = '<a href="' . $zipFileName . '">Click here to download the zip file</a>';
    echo 'Files zipped successfully. ' . $downloadLink;
} else {
    echo 'Failed to create zip file.';
}
?>



<!---delete-->
<?php
$file = 'alceawis.de.zip';
if (isset($_GET['delete'])) {
    if (file_exists($file)) {
        unlink($file);
        echo "File deleted successfully.";
    } else {
        echo "File not found.";
    }
}
?>
<a href="?delete=true">Click here to delete zip</a>
