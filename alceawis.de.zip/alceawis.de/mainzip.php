<!--<a target=_blank href="alceawis.de.zip">(dld)</a><br>-->
<?php $phpVersion = phpversion();echo "PHP version: " . $phpVersion;?><!--(must be PHP version: 8.2.20 !)--> - <?php if (extension_loaded('zip')) { echo "Zip extension is enabled."; } else { echo "Zip extension is not enabled.";} ?><br><br>
<!--https://pb.todon.de/@alcea/112823560063665113--https://mastodonapp.uk/@gozzy/112823854328998071-->

<?php
$delfile = 'alceawis.de.zip';
if (file_exists($delfile)) {
    $fileModifiedTime = filemtime($delfile);
    $currentTime = time();
    $fifteenMinutesAgo = $currentTime - (15 * 60);
    if ($fileModifiedTime < $fifteenMinutesAgo) {
        unlink($delfile);
        echo "File deleted successfully.<br>";
    } else {
        echo "File is not older than 15 minutes.<br>";
    }
} else {
    echo "File does not exist.<br>";
}
?>

<?php
// Auto-backup trigger
if (isset($_GET['autobackup'])) {
    // Execute backup automatically
    $zip = new ZipArchive();
    $zipFileName = __DIR__ . '/alceawis.de.zip';
    $intermediateFolderName = pathinfo($zipFileName, PATHINFO_FILENAME);

    if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator('.', RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $name => $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = $intermediateFolderName . '/' . substr($filePath, strlen(__DIR__) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }

        $zip->close();
        $downloadLink = '<a target=_blank href="alceawis.de.zip?v=' . time() . '">Click here to download the zip file</a>';
        echo 'Files zipped successfully. ' . $downloadLink;
    } else {
        echo 'Failed to create zip file.';
    }
    exit; // Stop further execution to show only backup result
}
?>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $zip = new ZipArchive();
    $zipFileName = __DIR__ . '/alceawis.de.zip';
    $intermediateFolderName = pathinfo($zipFileName, PATHINFO_FILENAME);

    if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator('.', RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $name => $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = $intermediateFolderName . '/' . substr($filePath, strlen(__DIR__) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }

        $zip->close();
         //$downloadLink = '<a target=_blank href="' . $zipFileName . '">Click here to download</a>';
         //$downloadLink = '<a target=_blank href="alceawis.de.zip">Click here to download the zip file</a>';
         $downloadLink = '<a target=_blank href="alceawis.de.zip?v=' . time() . '">Click here to download the zip file</a>';
        echo 'Files zipped successfully. ' . $downloadLink;
    } else {
        echo 'Failed to create zip file.';
    }
}
?>

<form method="POST">
    <button type="submit">Zip Files</button>
</form>

<!---delete-->
<?php
$file = 'alceawis.de.zip';
if (isset($_GET['delete'])) {
    if (file_exists($file)) {
        unlink($file);
        echo "File deleted successfully.";
    } else {
        echo "File not found.";
    }
}
?>
<a href="?delete=true">Click here to delete zip</a>

<hr>
[You can <a target="_blank" href="">automate</a> the backup and copy to extSD n Webserver via <a target="_blank" href="https://ry3yr.github.io/tasker.zip">exec scripts in here</a>. Requires Tasker]
<br><br>
*<a target="_blank" href="tasker://AcwsBackup">=> Run</a> (requires <a target="_blank" href="https://alceawis.de/other/extra/scripts/fakesocialmedia/commentload.html?number=80000&text=Oh%20nice%20%0D%0Ahttps%3A%2F%2Fm.apkpure.com%2Ftasker-url-launcher%2Fcom.aled">Plugin</a>)
