<a target="_blank" href="https://m.youtube.com/playlist?list=PLURBlBqSzVmHPNZ4E7HYxp9foQRiyz_56" style=color:blue>Stellar Blade OST</a>
<a target="_blank" href="https://www.youtube.com/playlist?list=PLfRFOBVf8C8f6eGxrolKhZwtBzlQC8FQR" style=color:blue>Another Code Recollection</a>
<a target="_blank" href="https://vgmdb.net/album/128657">Sin Chronicle MEMORIAL SOUNDTRACK</a>
<a target="_blank" href="https://vgmdb.net/album/133710">Crymachina</a>