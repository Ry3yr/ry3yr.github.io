<?php
$files = glob('*'); // Get all files in the current directory
$newestFile = null;
$newestTime = 0;
foreach ($files as $file) {
    if (is_file($file)) { // Check if the item is a file
        $fileExtension = pathinfo($file, PATHINFO_EXTENSION);
        $fileName = pathinfo($file, PATHINFO_FILENAME);
        if ($fileExtension === 'zip' || $fileExtension === 'php' || strpos($fileName, 'error_log') !== false) {
            continue;
        }
        $fileTime = filemtime($file); // Get the last modified timestamp of the file
        if ($fileTime > $newestTime) {
            $newestTime = $fileTime;
            $newestFile = $file;
        }
    }
}
if ($newestFile !== null) {
    $lastModified = date("Y-m-d", $newestTime); // Format the last modified timestamp as yyyy-mm-dd
    $link = htmlspecialchars($newestFile); // Sanitize the filename for use in the hyperlink

    echo "$lastModified: <a href='$link' target='_blank'>$link</a> ";
}
?>
