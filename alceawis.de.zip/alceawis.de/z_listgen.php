<?php
// Get the current directory
$directory = __DIR__;
// Open the file for writing
$file = fopen('z_list.txt', 'w');
// Get all files and directories in the current directory
$items = scandir($directory);
// Iterate through each item
foreach ($items as $item) {
    // Exclude current and parent directory entries
    if ($item !== '.' && $item !== '..') {
        // Check if the item is a directory
        if (is_dir($directory . DIRECTORY_SEPARATOR . $item)) {
            // Write directory name to the file
            fwrite($file, $item . PHP_EOL);
        } else {
            // Write file name to the file
            fwrite($file, $item . PHP_EOL);
        }
    }
}
// Close the file
fclose($file);
echo 'File list generated and saved to z_list.txt.';
?>
