<?php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '');
?>

<?php
// Get the current directory
$directory = __DIR__;

// Get the initial MD5 hash of z_list.txt
$initialMd5 = md5_file('z_list.txt');

// Get all files and directories in the current directory
$items = scandir($directory);

// Initialize an array to hold the file list
$fileList = [];

// Iterate through each item
foreach ($items as $item) {
    // Exclude current and parent directory entries
    if ($item !== '.' && $item !== '..') {
        // Check if the item is a directory
        if (is_dir($directory . DIRECTORY_SEPARATOR . $item)) {
            // Add directory name to the file list
            $fileList[] = $item;
        } else {
            // Get file name and its MD5 hash
            $filePath = $directory . DIRECTORY_SEPARATOR . $item;
            $md5 = md5_file($filePath);
            // Add file name and its MD5 hash to the file list
            $fileList[] = $item . ' (' . $md5 . ')';
        }
    }
}

// Generate the file list as a string
$fileListString = implode(PHP_EOL, $fileList);

// Save the file list to z_list.txt
$result = file_put_contents('z_list.txt', $fileListString);

if ($result !== false) {
    // Get the final MD5 hash of z_list.txt
    $finalMd5 = md5_file('z_list.txt');
    echo 'File list generated and saved to z_list.txt.';
    echo 'Initial MD5 hash: ' . $initialMd5 . PHP_EOL;
    echo 'Final MD5 hash: ' . $finalMd5 . PHP_EOL;
} else {
    echo 'Failed to write file list to z_list.txt.';
}
?>


<!--v1--
Cjw/cGhwCi8vIEdldCB0aGUgY3VycmVudCBkaXJlY3RvcnkKJGRpcmVjdG9yeSA9IF9fRElSX187Ci8vIE9wZW4gdGhlIGZpbGUgZm9yIHdyaXRpbmcKJGZpbGUgPSBmb3Blbignel9saXN0LnR4dCcsICd3Jyk7Ci8vIEdldCBhbGwgZmlsZXMgYW5kIGRpcmVjdG9yaWVzIGluIHRoZSBjdXJyZW50IGRpcmVjdG9yeQokaXRlbXMgPSBzY2FuZGlyKCRkaXJlY3RvcnkpOwovLyBJdGVyYXRlIHRocm91Z2ggZWFjaCBpdGVtCmZvcmVhY2ggKCRpdGVtcyBhcyAkaXRlbSkgewogICAgLy8gRXhjbHVkZSBjdXJyZW50IGFuZCBwYXJlbnQgZGlyZWN0b3J5IGVudHJpZXMKICAgIGlmICgkaXRlbSAhPT0gJy4nICYmICRpdGVtICE9PSAnLi4nKSB7CiAgICAgICAgLy8gQ2hlY2sgaWYgdGhlIGl0ZW0gaXMgYSBkaXJlY3RvcnkKICAgICAgICBpZiAoaXNfZGlyKCRkaXJlY3RvcnkgLiBESVJFQ1RPUllfU0VQQVJBVE9SIC4gJGl0ZW0pKSB7CiAgICAgICAgICAgIC8vIFdyaXRlIGRpcmVjdG9yeSBuYW1lIHRvIHRoZSBmaWxlCiAgICAgICAgICAgIGZ3cml0ZSgkZmlsZSwgJGl0ZW0gLiBQSFBfRU9MKTsKICAgICAgICB9IGVsc2UgewogICAgICAgICAgICAvLyBXcml0ZSBmaWxlIG5hbWUgdG8gdGhlIGZpbGUKICAgICAgICAgICAgZndyaXRlKCRmaWxlLCAkaXRlbSAuIFBIUF9FT0wpOwogICAgICAgIH0KICAgIH0KfQovLyBDbG9zZSB0aGUgZmlsZQpmY2xvc2UoJGZpbGUpOwplY2hvICdGaWxlIGxpc3QgZ2VuZXJhdGVkIGFuZCBzYXZlZCB0byB6X2xpc3QudHh0Lic7Cj8+Cg==
-->