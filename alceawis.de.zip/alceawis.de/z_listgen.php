<?php
session_set_cookie_params(['secure' => true,'httponly' => true,'samesite' => 'Strict']);
session_start();
$session_lifetime = 3 * 60; // Session timeout
$correct_username = "admin";
$correct_password_hash = '$2y$10$S9naYnE6MqP14zVRfIsig.A98jBGzEImaGLgKVuiSGKpI7yr7XeGG'; // password: 4869
//echo password_hash("pass", PASSWORD_DEFAULT); //generate
if (isset($_GET['logout'])) {
session_unset();
session_destroy();
header("Location: " . $_SERVER['PHP_SELF']);
exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['heartbeat'])) {
$_SESSION['last_activity'] = time();
exit;
}
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
if ($username === $correct_username && password_verify($password, $correct_password_hash)) {
session_regenerate_id(true);
$_SESSION['logged_in'] = true;
$_SESSION['last_activity'] = time();
header("Location: " . $_SERVER['PHP_SELF']);
exit;
} else {
$error = "Invalid username or password.";
}
}
?>
<?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
<form method="post">
<label>Username: <input name="username" required></label><br>
<label>Password: <input type="password" name="password" required></label><br>
<button type="submit">Login</button>
</form>

<?php
exit;
}
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $session_lifetime) {
session_unset();
session_destroy();
header("Location: " . $_SERVER['PHP_SELF']);
exit;
}
$_SESSION['last_activity'] = time(); // Refresh session activity
$remaining_time = ($_SESSION['last_activity'] + $session_lifetime) - time();
?>
Welcome, you are logged in! <span id="countdown"></span><hr>
<a href="?logout=1">Logout</a>
<script>
let remaining = <?php echo $remaining_time; ?>;
function updateCountdown() {
if (remaining <= 0) {
clearInterval(timer);
alert("Session expired due to inactivity.");
location.reload();
return;
}
const minutes = Math.floor(remaining / 60);
const seconds = remaining % 60;
document.getElementById('countdown').textContent =
minutes + "m " + (seconds < 10 ? "0" : "") + seconds + "s";
remaining--;
}
updateCountdown();
const timer = setInterval(updateCountdown, 1000);
setInterval(() => {
fetch("", {
method: "POST",
headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
body: "heartbeat=1"
});
}, 30000);
</script>


<?php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '');
?>

<?php
// Get the current directory
$directory = __DIR__;

// Get the initial MD5 hash of z_list.txt
$initialMd5 = md5_file('z_list.txt');

// Get all files and directories in the current directory
$items = scandir($directory);

// Initialize an array to hold the file list
$fileList = [];

// Iterate through each item
foreach ($items as $item) {
    // Exclude current and parent directory entries
    if ($item !== '.' && $item !== '..') {
        // Check if the item is a directory
        if (is_dir($directory . DIRECTORY_SEPARATOR . $item)) {
            // Add directory name to the file list
            $fileList[] = $item;
        } else {
            // Get file name and its MD5 hash
            $filePath = $directory . DIRECTORY_SEPARATOR . $item;
            $md5 = md5_file($filePath);
            // Add file name and its MD5 hash to the file list
            $fileList[] = $item . ' (' . $md5 . ')';
        }
    }
}

// Generate the file list as a string
$fileListString = implode(PHP_EOL, $fileList);

// Save the file list to z_list.txt
$result = file_put_contents('z_list.txt', $fileListString);

if ($result !== false) {
    // Get the final MD5 hash of z_list.txt
    $finalMd5 = md5_file('z_list.txt');
    echo 'File list generated and saved to z_list.txt.';
    echo 'Initial MD5 hash: ' . $initialMd5 . PHP_EOL;
    echo 'Final MD5 hash: ' . $finalMd5 . PHP_EOL;
} else {
    echo 'Failed to write file list to z_list.txt.';
}
?>


<!--v1--
Cjw/cGhwCi8vIEdldCB0aGUgY3VycmVudCBkaXJlY3RvcnkKJGRpcmVjdG9yeSA9IF9fRElSX187Ci8vIE9wZW4gdGhlIGZpbGUgZm9yIHdyaXRpbmcKJGZpbGUgPSBmb3Blbignel9saXN0LnR4dCcsICd3Jyk7Ci8vIEdldCBhbGwgZmlsZXMgYW5kIGRpcmVjdG9yaWVzIGluIHRoZSBjdXJyZW50IGRpcmVjdG9yeQokaXRlbXMgPSBzY2FuZGlyKCRkaXJlY3RvcnkpOwovLyBJdGVyYXRlIHRocm91Z2ggZWFjaCBpdGVtCmZvcmVhY2ggKCRpdGVtcyBhcyAkaXRlbSkgewogICAgLy8gRXhjbHVkZSBjdXJyZW50IGFuZCBwYXJlbnQgZGlyZWN0b3J5IGVudHJpZXMKICAgIGlmICgkaXRlbSAhPT0gJy4nICYmICRpdGVtICE9PSAnLi4nKSB7CiAgICAgICAgLy8gQ2hlY2sgaWYgdGhlIGl0ZW0gaXMgYSBkaXJlY3RvcnkKICAgICAgICBpZiAoaXNfZGlyKCRkaXJlY3RvcnkgLiBESVJFQ1RPUllfU0VQQVJBVE9SIC4gJGl0ZW0pKSB7CiAgICAgICAgICAgIC8vIFdyaXRlIGRpcmVjdG9yeSBuYW1lIHRvIHRoZSBmaWxlCiAgICAgICAgICAgIGZ3cml0ZSgkZmlsZSwgJGl0ZW0gLiBQSFBfRU9MKTsKICAgICAgICB9IGVsc2UgewogICAgICAgICAgICAvLyBXcml0ZSBmaWxlIG5hbWUgdG8gdGhlIGZpbGUKICAgICAgICAgICAgZndyaXRlKCRmaWxlLCAkaXRlbSAuIFBIUF9FT0wpOwogICAgICAgIH0KICAgIH0KfQovLyBDbG9zZSB0aGUgZmlsZQpmY2xvc2UoJGZpbGUpOwplY2hvICdGaWxlIGxpc3QgZ2VuZXJhdGVkIGFuZCBzYXZlZCB0byB6X2xpc3QudHh0Lic7Cj8+Cg==
-->
