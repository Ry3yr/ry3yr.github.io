<?php
$htaccessPath = '.htaccess';

// Check if the .htaccess file exists
if (file_exists($htaccessPath)) {
    // Read the contents of the .htaccess file
    $htaccessContent = file_get_contents($htaccessPath);

    // Output the contents
    echo "<pre>{$htaccessContent}</pre>";
} else {
    echo "The .htaccess file does not exist.";
}
?>