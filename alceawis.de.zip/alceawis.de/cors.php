<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Function to fetch data from a URL
function fetchDataFromUrl($url, $method = 'GET', $headers = [], $body = null) {
    // Validate and sanitize the URL
    $url = filter_var($url, FILTER_SANITIZE_URL);
    
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return ['error' => 'Invalid URL'];
    }

    // Prepare HTTP context options
    $options = [
        'http' => [
            'method' => $method,
            'ignore_errors' => true,
            'header' => ''
        ]
    ];
    
    // Add custom headers
    if (!empty($headers)) {
        foreach ($headers as $key => $value) {
            $options['http']['header'] .= "$key: $value\r\n";
        }
    }
    
    // Add body for POST/PUT requests
    if ($body !== null && in_array($method, ['POST', 'PUT', 'PATCH'])) {
        $options['http']['content'] = $body;
        if (!isset($headers['Content-Length'])) {
            $options['http']['header'] .= "Content-Length: " . strlen($body) . "\r\n";
        }
    }
    
    $context = stream_context_create($options);
    $response = @file_get_contents($url, false, $context);
    
    if ($response === false) {
        return ['error' => 'Unable to fetch data from URL'];
    }
    
    return ['data' => $response, 'headers' => $http_response_header];
}

// Handle OPTIONS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Handle POST requests (MUST COME FIRST!)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents('php://input');
    
    if (!empty($input)) {
        $postData = json_decode($input, true);
        
        if (isset($postData['query'])) {
            $url = htmlspecialchars($postData['query']);
            $method = isset($postData['method']) ? $postData['method'] : 'GET';
            $headers = isset($postData['headers']) ? $postData['headers'] : [];
            $body = isset($postData['body']) ? $postData['body'] : null;
            
            $result = fetchDataFromUrl($url, $method, $headers, $body);
            
            if (isset($result['error'])) {
                header('Content-Type: application/json');
                echo json_encode($result);
                exit;
            }
            
            $contentType = 'text/plain';
            foreach ($result['headers'] as $header) {
                if (stripos($header, 'Content-Type:') === 0) {
                    $contentType = substr($header, strlen('Content-Type: '));
                    break;
                }
            }
            
            header('Content-Type: ' . $contentType);
            echo $result['data'];
            exit;
        }
        
        header('Content-Type: application/json');
        echo json_encode(['error' => 'No query parameter provided in POST data']);
        exit;
    }
    
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No POST data received']);
    exit;
}

// Handle GET requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['query'])) {
        $url = htmlspecialchars($_GET['query']);
        $result = fetchDataFromUrl($url);
        
        if (isset($result['error'])) {
            header('Content-Type: application/json');
            echo json_encode($result);
            exit;
        }
        
        $contentType = 'text/plain';
        foreach ($result['headers'] as $header) {
            if (stripos($header, 'Content-Type:') === 0) {
                $contentType = substr($header, strlen('Content-Type: '));
                break;
            }
        }
        
        header('Content-Type: ' . $contentType);
        echo $result['data'];
        exit;
    }
    
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No query parameter provided']);
    exit;
}

// Invalid method
header('Content-Type: application/json');
echo json_encode(['error' => 'Invalid request method']);
exit;
