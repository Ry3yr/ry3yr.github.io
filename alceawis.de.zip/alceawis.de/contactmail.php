
<!--ContactForm (utilizes email relay to send your message directly to moi email )<img class='filled' style='' src='https://alcea-wisteria.de/z_files/emoji/ablobdj.gif' alt='Rating' width='20px'><a target="_blank" href="/other/contact.log" style=color:transparent>-~</a><br><hr>-->
    <meta charset="utf-8">
<?php
if(isset($_POST['submit'])){
    $name = htmlspecialchars(stripslashes(trim($_POST['name'])));
    $subject = htmlspecialchars(stripslashes(trim($_POST['subject'])));
    $email = htmlspecialchars(stripslashes(trim($_POST['email'])));
    $message = htmlspecialchars(stripslashes(trim($_POST['message'])));

    // Validation
    if(!preg_match("/^[A-Za-z .'-]+$/", $name)){
        $name_error = 'Invalid name';
    }
    if(!preg_match("/^[A-Za-z .'-]+$/", $subject)){
        $subject_error = 'Invalid subject';
    }
    if(!preg_match("/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/", $email)){
        $email_error = 'Invalid email';
    }
    if(strlen($message) === 0){
        $message_error = 'Your message should not be empty';
    }

    // If there are no errors, proceed to send the email and log the information
    if(!isset($name_error) && !isset($subject_error) && !isset($email_error) && !isset($message_error)){
        $to = 'alceawisteria@proton.me'; // Your email address

        // Prepare email body
        $body = "Name: $name\nE-mail: $email\nMessage:\n$message";

        // Send the email
        if(mail($to, $subject, $body)){
            echo '<p style="color: green">Message sent</p>';

            // Log the contact form submission to a file
            $log_file = 'other/contact.log';

            // Prepare log entry
            $log_entry = "-------------------------\n";
            $log_entry .= "Timestamp: " . date("Y-m-d H:i:s") . "\n";
            $log_entry .= "Name: $name\n";
            $log_entry .= "Subject: $subject\n";
            $log_entry .= "Email: $email\n";
            $log_entry .= "Message: $message\n";
            $log_entry .= "-------------------------\n";

            // Prepend the log entry to the log file
            if(file_exists($log_file)){
                // If the file exists, prepend the log entry
                $existing_content = file_get_contents($log_file);
                $new_content = $log_entry . $existing_content;
                file_put_contents($log_file, $new_content);
            } else {
                // If the file does not exist, create it and write the log entry
                file_put_contents($log_file, $log_entry);
            }
        } else {
            echo '<p>Error occurred, please try again later</p>';
        }
    }
}
?>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
    <label for="name">Name:</label><br>
    <input type="text" name="name">
    <p><?php if(isset($name_error)) echo $name_error; ?></p>

    <label for="subject">Subject:</label><br>
    <input type="text" name="subject">
    <p><?php if(isset($subject_error)) echo $subject_error; ?></p>

    <label for="email">Email:</label><br>
    <input type="text" name="email">
    <p><?php if(isset($email_error)) echo $email_error; ?></p>

    <label for="message">Message:</label><br>
    <textarea name="message"></textarea>
    <p><?php if(isset($message_error)) echo $message_error; ?></p>

    <input type="submit" name="submit" value="Submit">
</form>
