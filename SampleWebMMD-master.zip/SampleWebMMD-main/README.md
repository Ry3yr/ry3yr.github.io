# SampleWebMMD
SampleWebMMD MikuMiku Dance render with most features of a standart renderer (pmx, vmd, mp3)

Animated Stage example: https://ry3yr.github.io/SampleWebMMD/?stage=/livestageclub/livestageclubanimated.pmx

A video can be seen here
https://m.youtube.com/watch?v=0n8qi34uMjQ&list=PLBva3abEZvyT-_ajETBGeOCGBA_AFBT5Z&index=18&pp=iAQB
