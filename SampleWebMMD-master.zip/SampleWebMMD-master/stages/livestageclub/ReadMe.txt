If Stage or vmd crashes, not load, try rename it to example

Stage: "Live_club.pmx" >>>>to >>>> "1.pmx"

VMD: "Stage_anim_full.vmd" >>>>to >>>> "1.vmd"

If this doens't work for vmd, Check "1_animation" Folder.
There is some of Animations to you loop by Yourself.

*Tips

If you want to animate this all by Yourself...
To get "Lines" and "color" Morphs Work Correctly, go to frame 50000 and Register "1.0000" ( Maximum level of the Morph)

______________________CREDITS______________________

-Modeling, Textures, Morps 
by Philippe-n-12
 https://www.deviantart.com/philippe-n-12

Please credit me when you use this Stage.

You can Edit, Take Parts but please, Remember to credit https://www.deviantart.com/philippe-n-12

AND
Have FUN!!