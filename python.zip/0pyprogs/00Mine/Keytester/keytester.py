import tkinter as tk
import keyboard

def get_key_info(event):
    key_code = event.keycode
    key_name = event.keysym
    print(f"Key code: {key_code}")
    print(f"Key name: {key_name}")

# Create the Tkinter window
window = tk.Tk()

# Create a label for instructions
label = tk.Label(window, text="Press a key:")
label.pack()

# Function to handle key presses
def handle_key_press(event):
    get_key_info(event)

# Bind key presses to the handle_key_press function
window.bind("<KeyPress>", handle_key_press)

# Start the Tkinter event loop
window.mainloop()