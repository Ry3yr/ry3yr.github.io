import subprocess
import tkinter as tk
from pynput import keyboard

def send_adb_command(command):
    ip_address = ip_entry.get()
    port = port_entry.get()
    adb_shell_command = f"adb -s {ip_address}:{port} shell am broadcast 'intent:#Intent;action=com.maxmpz.audioplayer.API_COMMAND;package=com.maxmpz.audioplayer;i.cmd={command};end'"
    subprocess.run(adb_shell_command, shell=True)

def restart():
    ip_address = ip_entry.get()
    port = port_entry.get()
    command = f'adb kill-server && adb start-server && adb connect {ip_address}:{port}'
    subprocess.Popen(['cmd.exe', '/c', 'start', 'cmd.exe', '/k', command])

def handle_key_press(key):
    if key == keyboard.Key.media_play_pause:
        send_adb_command(1)  # Play/Pause
    elif key == keyboard.Key.media_next:
        send_adb_command(4)  # Next Track
    elif key == keyboard.Key.media_previous:
        send_adb_command(5)  # Previous Track

# Create the main window
window = tk.Tk()
window.title("ADB Audio Player Control")

# Create IP address label and text entry
ip_label = tk.Label(window, text="IP Address:")
ip_label.pack()
ip_entry = tk.Entry(window)
ip_entry.insert(0, "192.168.0.101")  # Pre-fill with IP address
ip_entry.pack()

# Create port label and text entry
port_label = tk.Label(window, text="Port:")
port_label.pack()
port_entry = tk.Entry(window)
port_entry.insert(0, "5555")  # Pre-fill with port
port_entry.pack()

# Create previous track button
prev_button = tk.Button(window, text="Previous Track", command=lambda: send_adb_command(5))
prev_button.pack()

# Create play/pause button
play_pause_button = tk.Button(window, text="Play/Pause", command=lambda: send_adb_command(1))
play_pause_button.pack()

# Create next track button
next_button = tk.Button(window, text="Next Track", command=lambda: send_adb_command(4))
next_button.pack()

# Create restart button
restart_button = tk.Button(window, text="Restart", command=restart)
restart_button.pack()

# Bind key presses to button actions
def on_key_press(event):
    key = event.keysym.lower()
    if key == 'xf86audioplay':
        send_adb_command(1)  # Play/Pause
    elif key == 'xf86audionext':
        send_adb_command(4)  # Next Track
    elif key == 'xf86audioprev':
        send_adb_command(5)  # Previous Track

window.bind("<KeyPress>", on_key_press)

# Start the tkinter event loop
window.mainloop()