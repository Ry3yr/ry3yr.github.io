<?php
$file = fopen('xnotes.txt', 'r');
if ($file) {
    while (($line = fgets($file)) !== false) {
        $line = trim($line);
        $parts = explode('https://', $line, 2);
        $title = $parts[0];
        $url = 'https://' . $parts[1];
        echo "<a href=\"$url\" target=\"_blank\">$title</a><br>";
    }
    fclose($file);
} else {
    echo 'Failed to open the file.';
}
?>