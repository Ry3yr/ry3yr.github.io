<?php
$correct_username = "user";
$correct_password = "password"; // Use a strong password for production
session_start();
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
echo "Welcome, you are logged in!<hr>";
} else {
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$username = $_POST['username'];
$password = $_POST['password'];
if ($username === $correct_username && $password === $correct_password) {
$_SESSION['logged_in'] = true;
echo "Login successful. Welcome!";
header("Location: " . $_SERVER['PHP_SELF']);
exit;
} else {
echo "Invalid username or password.<hr>";
}
}
echo '<form method="post">
<label for="username">Username:</label>
<input type="text" id="username" name="username" required><br>
<label for="password">Password:</label>
<input type="password" id="password" name="password" required><br>
<button type="submit">Login</button>
</form>';
exit();
}
?>


    <h1>HTML Files in Current Directory</h1>
    <ul>
        <?php
        // Get the current directory
        $dir = '.';

        // Scan the directory for files
        $files = scandir($dir);

        // Loop through the files and list the HTML files
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) == 'html') {
                $file_path = "$dir/$file";
                echo "<li><a href=\"$file\" target=\"_blank\">$file</a> <a href=\"edit.php?edit=$file_path\" target=\"_blank\">-></a></li>";
            }
        }
        ?>
    </ul>
<!--Create--new-file-->
<!DOCTYPE html>
<html>
<head>
    <title>Create File</title>
</head>
<body>
    <h1>Create File</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="filename">Filename:</label>
        <input type="text" id="filename" name="filename" required>
        <br>
        <input type="submit" value="Create File">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $filename = $_POST["filename"];
        if (!empty($filename)) {
            $file = fopen($filename, "w");
            fclose($file);
            echo "File '$filename' created successfully.";
        } else {
            echo "Please enter a filename.";
        }
    }
    ?>