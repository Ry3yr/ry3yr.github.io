
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the HTML content from the POST request
    $htmlContent = $_POST['content'];

    // Check if a file parameter is present in the query string
    if (isset($_GET['file'])) {
        $fileName = $_GET['file'];
    } else {
        $fileName = 'saved_html.html';
    }

    // Save the HTML content to the specified file
    file_put_contents($fileName, $htmlContent);

    // Return a success message
    echo "HTML content saved to " . $fileName;
} else {
    // Return an error message for non-POST requests
    echo "Invalid request method";
}
?>