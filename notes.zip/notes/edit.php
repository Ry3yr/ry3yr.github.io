<?php
$correct_username = "user";
$correct_password = "password"; // Use a strong password for production
session_start();
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
echo "Welcome, you are logged in!<hr>";
} else {
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$username = $_POST['username'];
$password = $_POST['password'];
if ($username === $correct_username && $password === $correct_password) {
$_SESSION['logged_in'] = true;
echo "Login successful. Welcome!";
header("Location: " . $_SERVER['PHP_SELF']);
exit;
} else {
echo "Invalid username or password.<hr>";
}
}
echo '<form method="post">
<label for="username">Username:</label>
<input type="text" id="username" name="username" required><br>
<label for="password">Password:</label>
<input type="password" id="password" name="password" required><br>
<button type="submit">Login</button>
</form>';
exit();
}
?>


<details><summary>Fix Endcoding issues</summary>
<textarea><meta charset="utf-8"></textarea>
</details>

<?php
// Check if the "edit" query parameter is present
if (isset($_GET['edit'])) {
    $file_path = $_GET['edit'];

    // Check if the file exists
    if (file_exists($file_path)) {
        // Read the contents of the HTML file
        $html_content = file_get_contents($file_path);
        $original_timestamp = filemtime($file_path);

        // Display the WYSIWYG editor
        echo '<!DOCTYPE html>
        <html>
        <head>
            <title>Edit HTML File</title>
            <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
            <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
        </head>
        <body>
            <h1>Edit HTML File</h1>
            <textarea id="html-editor">' . $html_content . '</textarea>

            <script>
                $(document).ready(function() {
                    $("#html-editor").summernote({
                        height: 500,
                        toolbar: [
                            ["style", ["style"]],
                            ["font", ["bold", "underline", "clear"]],
                            ["color", ["color"]],
                            ["para", ["ul", "ol", "paragraph"]],
                            ["table", ["table"]],
                            ["insert", ["link", "picture", "video"]],
                            ["view", ["fullscreen", "codeview", "help"]]
                        ],
                        callbacks: {
                            onChange: function(contents, $editable) {
                                // Update the textarea with the current contents
                                $("#html-editor").val(contents);
                            }
                        }
                    });
                });
            </script>
        </body>
        </html>';
    } else {
        echo '<p>File not found: ' . $file_path . '</p>';
    }
} else {
    echo '<p>No file selected to edit.</p>';
}
?>


<!---------save----->

<button id="save-btn">Save</button>
<script>
  var htmlEditor = document.getElementById("html-editor");
  document.getElementById("save-btn").addEventListener("click", function() {
    var htmlContent = htmlEditor.value;
    localStorage.setItem("html-content", htmlContent);
    sendContentToServer(htmlContent);
  });

  function sendContentToServer(content) {
    // Get the current URL and extract the "edit" querystring
    var url = new URL(window.location.href);
    var editParam = url.searchParams.get("edit");

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "save.php?file=" + encodeURIComponent(editParam), true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send("content=" + encodeURIComponent(content));
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
        // Display the server response
        alert(xhr.responseText);
      }
    };
  }
</script>