<?php
$correct_username = "admin";
$correct_password = "4869"; // Use a strong password for production
session_start();
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
echo "Welcome, you are logged in!<hr>";
} else {
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$username = $_POST['username'];
$password = $_POST['password'];
if ($username === $correct_username && $password === $correct_password) {
$_SESSION['logged_in'] = true;
echo "Login successful. Welcome!";
header("Location: " . $_SERVER['PHP_SELF']);
exit;
} else {
echo "Invalid username or password.<hr>";
}
}
echo '<form method="post">
<label for="username">Username:</label>
<input type="text" id="username" name="username" required><br>
<label for="password">Password:</label>
<input type="password" id="password" name="password" required><br>
<button type="submit">Login</button>
</form>';
exit();
}
?>





<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $updateOnly = isset($_POST['update']);

    // Define upload directories
    $modelsDir = __DIR__ . '/models/';
    $imgsDir = __DIR__ . '/imgs/';
    $listFile = __DIR__ . '/list.txt';

    // Ensure directories exist
    if (!is_dir($modelsDir)) {
        mkdir($modelsDir, 0777, true);
    }
    if (!is_dir($imgsDir)) {
        mkdir($imgsDir, 0777, true);
    }

    // Handle ZIP file upload
    if (isset($_FILES['zip_file']) && $_FILES['zip_file']['error'] === UPLOAD_ERR_OK) {
        $zipPath = $modelsDir . basename($_FILES['zip_file']['name']);
        move_uploaded_file($_FILES['zip_file']['tmp_name'], $zipPath);
    }

    // Handle JPG file upload
    if (isset($_FILES['jpg_file']) && $_FILES['jpg_file']['error'] === UPLOAD_ERR_OK) {
        $jpgPath = $imgsDir . basename($_FILES['jpg_file']['name']);
        move_uploaded_file($_FILES['jpg_file']['tmp_name'], $jpgPath);
    }

    // Handle text prepend if "update" is not checked
    if (!$updateOnly && !empty($_POST['text_input'])) {
        $newLine = $_POST['text_input'] . PHP_EOL;

        // Prepend to list.txt
        $existingContent = file_exists($listFile) ? file_get_contents($listFile) : '';
        file_put_contents($listFile, $newLine . $existingContent);
    }

    echo "Upload completed successfully.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Form</title>
</head>
<body>
    <h1>Upload Form</h1>
    <form action="" method="POST" enctype="multipart/form-data">
        <label for="zip_file">ZIP File:</label>
        <input type="file" name="zip_file" id="zip_file" accept=".zip" required><br><br>
        <label for="jpg_file">JPG File:</label>
        <input type="file" name="jpg_file" id="jpg_file" accept=".jpg"><br><br>
        <label for="text_input">Text:</label>
        <input type="text" name="text_input" id="text_input">    <button id="fillButton">Fill</button><br><br>
        <label for="update">Update Only:</label>
        <input type="checkbox" name="update" id="update"><br><br>
        <button type="submit">Upload</button>
    </form>


<script>
    document.getElementById('fillButton').addEventListener('click', function() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const formattedText = `name * - (${year}|${month}|${day})`;
        document.getElementById('text_input').value = formattedText;
        event.preventDefault();
    });
</script>

</body>
</html>
