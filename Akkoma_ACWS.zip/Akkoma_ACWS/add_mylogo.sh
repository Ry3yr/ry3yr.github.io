#!/bin/bash

CONFIG_FILE="/etc/akkoma/config.exs"
LOGO_CONFIG='config :pleroma, :frontend_configurations,
  pleroma_fe: %{
    logo: "/static/mylogo.png"
  }'

# Check if the config snippet already exists
if grep -q "frontend_configurations" "$CONFIG_FILE"; then
  echo "Logo config already exists in $CONFIG_FILE"
else
  echo -e "\n# Custom logo config added by script\n$LOGO_CONFIG\n" >> "$CONFIG_FILE"
  echo "Logo config added to $CONFIG_FILE"
fi
