#mylogo
test -f /var/lib/akkoma/static/mylogo.png && echo "Logo exists" || echo "Logo NOT found"

