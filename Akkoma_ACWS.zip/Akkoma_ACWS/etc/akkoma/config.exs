# Pleroma instance configuration

# NOTE: This file should not be committed to a repo or otherwise made public
# without removing sensitive information.

import Config

config :pleroma, Pleroma.Web.Endpoint,
   url: [host: "alceawis.com", scheme: "https", port: 443],
   http: [ip: {127, 0, 0, 1}, port: 4000],
   secret_key_base: "Bq/svVRewTPoOz11hrtjSDXMGvyHIjE0BjyqOnJ8a6c+NQL4+L9P/jSqkjCbn27j",
   live_view: [signing_salt: "StViuANp"],
   signing_salt: "4ZJPf08Q"

config :pleroma, :instance,
  name: "AlceaWisteria",
  email: "alceawisteria@proton.me",
  notify_email: "alceawisteria@proton.me",
  limit: 5000,
  registrations_open: true

config :pleroma, :media_proxy,
  enabled: false,
  redirect_on_failure: true
  #base_url: "https://cache.pleroma.social"

config :pleroma, Pleroma.Repo,
  adapter: Ecto.Adapters.Postgres,
  username: "admin",
  password: "flashme91",
  database: "akkoma",
  hostname: "localhost"

# Configure web push notifications
config :web_push_encryption, :vapid_details,
  subject: "mailto:alceawisteria@proton.me",
  public_key: "BMHt_WC5acqkY8X3nZ91PKfufoV3exRk1OMBArYSk8rq84Vx5i72DLMndnbVuBX88MIjWo4wOunk7Vi8O5t01yU",
  private_key: "ed5-VizQVEjrYaemio7d0l4FfnzmSMBQwOKVktAv0_Y"

config :pleroma, :database, rum_enabled: true
config :pleroma, :instance, static_dir: "/var/lib/akkoma/static"
config :pleroma, Pleroma.Uploaders.Local, uploads: "/var/lib/akkoma/uploads"

# Enable Strict-Transport-Security once SSL is working:
# config :pleroma, :http_security,
#   sts: true

# Configure S3 support if desired.
# The public S3 endpoint (base_url) is different depending on region and provider,
# consult your S3 provider's documentation for details on what to use.
#
# config :pleroma, Pleroma.Upload,
#  uploader: Pleroma.Uploaders.S3,
#  base_url: "https://s3.amazonaws.com"
#
# config :pleroma, Pleroma.Uploaders.S3,
#   bucket: "some-bucket",
#   bucket_namespace: "my-namespace",
#   truncated_namespace: nil,
#   streaming_enabled: true
#
# Configure S3 credentials:
# config :ex_aws, :s3,
#   access_key_id: "xxxxxxxxxxxxx",
#   secret_access_key: "yyyyyyyyyyyy",
#   region: "us-east-1",
#   scheme: "https://"
#
# For using third-party S3 clones like wasabi, also do:
# config :ex_aws, :s3,
#   host: "s3.wasabisys.com"

config :joken, default_signer: "TE/Zct3TjVbkH+Tk+n4PW3hXvJmF8pT4YsYJTYJYiu8IC61wmtUDYFiTwQeb5XTH"

config :pleroma, configurable_from_database: true

config :pleroma, Pleroma.Upload,

  base_url: "https://alceawis.com/uploads"
config :pleroma, :database, rum_enabled: false

# Custom logo config added by script

config :pleroma, :frontend_configurations,
  pleroma_fe: %{
    theme: "mo-douga-pink"
  }

