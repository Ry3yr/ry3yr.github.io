The motion files in this directory are copied, not my own files.
Read each Readme file and follow their policies and licenses.
