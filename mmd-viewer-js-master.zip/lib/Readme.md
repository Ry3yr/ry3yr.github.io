The library files in this directory are copied, not my own files.
Read each Readme file, license file, and follow their policies and licenses.
