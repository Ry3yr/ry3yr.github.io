<?php
$parentDir = dirname(__DIR__); // Get the parent directory path

// Compressing the directory to a zip file
$zip = new ZipArchive();
$zipFileName = 'mmd-viewer-js-master.zip';

if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
    $dirPath = $parentDir . '/mmd-viewer-js-master'; // Path to the directory to be compressed

    // Add files to the zip file
    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dirPath));
    foreach ($files as $file) {
        if (!$file->isDir()) {
            $filePath = $file->getRealPath();
            $relativePath = substr($filePath, strlen($dirPath) + 1);
            $zip->addFile($filePath, $relativePath);
        }
    }

    $zip->close();

    // Downloading the zip file as a blob
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipFileName . '"');
    header('Content-Length: ' . filesize($zipFileName));
    readfile($zipFileName);

    // Deleting the zip file
    unlink($zipFileName);
} else {
    echo "Failed to create the zip file.";
}