The model files under this directory are copied, not my own files.
Read Readme file under each directory and follow their policies and licenses.

Note that I've changed some files for my MMD viewer to handle correctly.
- renamed Japanese filename to English filename
- converted *.tga files to *.png files
- changed image file size from non-power-of-2 to power-of-2
- put toon[00-10].bmp files into each directory from MMD Data directory
