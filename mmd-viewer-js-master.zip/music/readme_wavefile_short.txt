There is no readme for WAVEFILE shor ver.
So I noted the author and original musics info here.

Remember that he doesn't allow commercial use
of his works with no contact.

                                   by takahiro

-------------------------------------------------------

Author: ���}�[�YP(LamazeP)

His Piapro page
http://piapro.jp/shine_longer
His Nico profile
http://www.nicovideo.jp/user/2523470


Original musics:

WAVEFILE/�����~�N(Hatsune Miku) short ver.
http://www.nicovideo.jp/watch/sm11938255

WAVEFILE/�����~�N(Hatsune Miku) full ver.
http://www.nicovideo.jp/watch/sm14257396
