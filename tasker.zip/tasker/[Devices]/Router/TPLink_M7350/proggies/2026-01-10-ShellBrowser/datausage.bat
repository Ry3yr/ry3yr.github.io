start ms-settings:datausage
ping 127.0.0.1 -n 1
taskkill /im cmd.exe
