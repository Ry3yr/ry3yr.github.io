<a target="_blank" href="http://192.168.0.163:7860">VocalSynth</a> [<a target="_blank" href="https://alceawis.de/other/extra/scripts/ffmpeg/videoaudioannotate.html">AnnotationStudio</a>] <a target="_blank" href="http://192.168.0.163:1234/">PC File UpDownload</a>
<hr><br><?php
// voicebox.php - Complete Voicebox Studio
// Usage: voicebox.php?hostip=192.168.0.163 (optional)

$default_ip = '192.168.0.163';
$hostip = isset($_GET['hostip']) ? $_GET['hostip'] : $default_ip;
$VOICEBOX_URL = "http://{$hostip}:17493";

function voiceboxRequest($endpoint, $method = 'GET', $data = null) {
    global $VOICEBOX_URL;
    $ch = curl_init("$VOICEBOX_URL/$endpoint");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 120);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        }
    }
    
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function getDefaultProfileId() {
    $profiles = json_decode(voiceboxRequest('profiles'), true);
    return !empty($profiles) ? $profiles[0]['id'] : null;
}

// Handle generation with polling
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate'])) {
    $text = $_POST['text'];
    $profile_id = $_POST['profile_id'] ?? getDefaultProfileId();
    $language = $_POST['language'] ?? 'en';
    $model_size_raw = $_POST['model_size'] ?? '1.7B';
    
    // Clean model_size to match API expected format
    if (strpos($model_size_raw, '1.7B') !== false) {
        $model_size = '1.7B';
    } elseif (strpos($model_size_raw, '3B') !== false) {
        $model_size = '3B';
    } elseif (strpos($model_size_raw, '0.6B') !== false) {
        $model_size = '0.6B';
    } elseif (strpos($model_size_raw, '1B') !== false) {
        $model_size = '1B';
    } else {
        $model_size = '1.7B';
    }
    
    $response = voiceboxRequest('generate', 'POST', [
        'profile_id' => $profile_id,
        'text' => $text,
        'language' => $language,
        'model_size' => $model_size
    ]);
    
    $data = json_decode($response, true);
    $generation_id = $data['id'] ?? null;
    
    if ($generation_id) {
        $status = 'pending';
        $attempts = 0;
        while ($status !== 'completed' && $attempts < 30) {
            sleep(2);
            $statusData = json_decode(voiceboxRequest("history/$generation_id"), true);
            $status = $statusData['status'] ?? 'pending';
            $attempts++;
        }
        
        header('Content-Type: application/json');
        echo json_encode(['audio_url' => "{$VOICEBOX_URL}/audio/{$generation_id}"]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Generation failed: ' . $response]);
    }
    exit;
}

// API endpoints for frontend
if (isset($_GET['api'])) {
    header('Content-Type: application/json');
    $action = $_GET['api'];
    
    switch ($action) {
        case 'test':
            echo voiceboxRequest('');
            break;
        case 'profiles':
            echo voiceboxRequest('profiles');
            break;
        case 'history':
            echo voiceboxRequest('history');
            break;
        case 'models':
            echo json_encode(['models' => ['1.7B', '3B', '0.6B']]);
            break;
        case 'effects':
            echo json_encode(['effects' => ['No Effects', 'Studio Reverb', 'Warm Tube', 'Radio Filter', 'Hall Echo']]);
            break;
        case 'transcribe':
            if (isset($_FILES['audio'])) {
                $ch = curl_init("$VOICEBOX_URL/transcribe");
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ['file' => new CURLFile($_FILES['audio']['tmp_name'], $_FILES['audio']['type'], $_FILES['audio']['name'])]);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
                echo $response;
            }
            break;
    }
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voicebox Studio</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f0f1a; color: #eee; margin: 0; padding: 20px; }
        .container { max-width: 950px; margin: 0 auto; }
        h1 { text-align: center; color: #667eea; margin-bottom: 5px; }
        .subtitle { text-align: center; color: #888; margin-bottom: 20px; font-size: 14px; }
        .card { background: rgba(25, 25, 45, 0.95); border-radius: 16px; padding: 20px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.08); }
        .card h3 { margin-top: 0; color: #a0a0ff; margin-bottom: 15px; }
        button { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; color: white; padding: 10px 20px; border-radius: 8px; cursor: pointer; margin: 5px 5px 5px 0; font-size: 14px; }
        button.secondary { background: #2d3748; }
        button:disabled { opacity: 0.5; cursor: not-allowed; }
        select, textarea, input { width: 100%; padding: 10px; background: rgba(15,15,30,0.9); border: 1px solid rgba(255,255,255,0.15); border-radius: 8px; color: white; margin: 8px 0; font-size: 14px; }
        .status { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; }
        .status.online { background: #10b981; }
        .status.offline { background: #ef4444; }
        audio { width: 100%; margin-top: 12px; }
        .flex { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
        .flex > * { flex: 1; }
        .flex > button { flex: 0 0 auto; }
        .voice-card, .history-item { background: rgba(0,0,0,0.3); padding: 10px; border-radius: 10px; margin-bottom: 8px; cursor: pointer; }
        .voice-card:hover, .history-item:hover { background: rgba(102,126,234,0.2); }
        .voice-card.selected { background: rgba(102,126,234,0.4); border-left: 3px solid #667eea; }
        .voice-name { font-weight: bold; }
        pre { background: rgba(0,0,0,0.4); padding: 12px; border-radius: 8px; overflow-x: auto; font-size: 12px; max-height: 300px; overflow-y: auto; }
        .progress-bar { width: 100%; height: 4px; background: #2d3748; border-radius: 2px; margin-top: 10px; overflow: hidden; display: none; }
        .progress-fill { width: 0%; height: 100%; background: #667eea; transition: width 0.3s; }
        .model-badge, .effect-badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 10px; margin: 2px; }
        .model-badge { background: #3b82f6; }
        .effect-badge { background: #8b5cf6; }
        .grid-2col { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .loading-spinner { display: inline-block; width: 14px; height: 14px; border: 2px solid rgba(255,255,255,0.3); border-radius: 50%; border-top-color: #fff; animation: spin 0.8s linear infinite; margin-right: 8px; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .message { text-align: center; padding: 10px; border-radius: 8px; margin-top: 10px; }
        .message.success { background: rgba(16,185,129,0.2); color: #10b981; }
        .message.error { background: rgba(239,68,68,0.2); color: #ef4444; }
        .message.info { background: rgba(245,158,11,0.2); color: #f59e0b; }
        .ip-row { display: flex; gap: 10px; align-items: center; margin-top: 10px; }
        .ip-row input { flex: 3; margin: 0; }
        .ip-row button { flex: 1; margin: 0; }
    </style>
</head>
<body>
<div class="container">
    <h1>🎙️ Voicebox Studio</h1>
    <div class="subtitle" id="connectionInfo">Connected to: <?php echo $VOICEBOX_URL; ?></div>
    
    <div class="card">
        <div class="flex">
            <div id="status"><span class="status">🔌 Checking...</span></div>
            <button onclick="testConnection()" class="secondary">Test Connection</button>
            <button onclick="loadProfiles()" class="secondary">Load Voices</button>
            <button onclick="loadHistory()" class="secondary">Load History</button>
        </div>
        
        <div class="ip-row">
            <input type="text" id="ipInput" placeholder="PC IP Address" value="<?php echo htmlspecialchars($hostip); ?>">
            <button onclick="changeIP()" class="secondary">Change IP</button>
        </div>
    </div>
    
    <div class="card">
        <h3>🗣️ Text to Speech</h3>
        <textarea id="ttsText" rows="3" placeholder="Enter text to speak...">Hello, this is a test with my cloned voice!</textarea>
        
        <div class="grid-2col">
            <div>
                <label>🎤 Voice Profile</label>
                <select id="voiceSelect"></select>
            </div>
            <div>
                <label>🎚️ Model Size</label>
                <select id="modelSelect">
                    <option value="1.7B">1.7B (Qwen3-TTS)</option>
                    <option value="3B">3B</option>
                    <option value="0.6B">0.6B</option>
                </select>
            </div>
            <div>
                <label>🌍 Language</label>
                <select id="languageSelect">
                    <option value="en">English</option>
                    <option value="de">German</option>
                    <option value="fr">French</option>
                    <option value="es">Spanish</option>
                    <option value="it">Italian</option>
                    <option value="ja">Japanese</option>
                    <option value="zh">Chinese</option>
                    <option value="ko">Korean</option>
                    <option value="pt">Portuguese</option>
                    <option value="ru">Russian</option>
                </select>
            </div>
            <div>
                <label>✨ Effect</label>
                <select id="effectSelect"></select>
            </div>
        </div>
        
        <button id="generateBtn" onclick="generateSpeech()">🔊 Generate Speech</button>
        
        <div id="progressBar" class="progress-bar"><div id="progressFill" class="progress-fill"></div></div>
        <div id="statusMessage" class="message" style="display: none;"></div>
        
        <div id="audioContainer" style="display: none;">
            <audio id="audioPlayer" controls></audio>
        </div>
    </div>
    
    <div class="card">
        <h3>📦 Available Models &amp; Effects</h3>
        <div class="grid-2col">
            <div>
                <strong>🎚️ Models:</strong>
                <div id="modelsList">Loading...</div>
            </div>
            <div>
                <strong>✨ Effects:</strong>
                <div id="effectsList">Loading...</div>
            </div>
        </div>
    </div>
    
    <div class="card">
        <h3>🎤 Voice Profiles</h3>
        <div id="profilesList">Loading...</div>
    </div>
    
    <div class="card">
        <h3>📜 Generation History</h3>
        <div id="historyList">Loading...</div>
    </div>
    
    <div class="card">
        <h3>📝 Transcribe Audio</h3>
        <input type="file" id="transcribeFile" accept=".wav,.mp3,.m4a,.ogg">
        <button onclick="transcribeAudio()">Transcribe</button>
        <div id="transcriptionResult"></div>
    </div>
</div>

<script>
    let currentHost = '<?php echo htmlspecialchars($hostip); ?>';
    let VOICEBOX_URL = `http://${currentHost}:17493`;
    
    function updateAPIBase() {
        VOICEBOX_URL = `http://${currentHost}:17493`;
        document.getElementById('connectionInfo').innerHTML = `Connected to: <strong>${VOICEBOX_URL}</strong>`;
    }
    
    function changeIP() {
        const newIP = document.getElementById('ipInput').value.trim();
        if (!newIP) return;
        window.location.href = window.location.pathname + '?hostip=' + encodeURIComponent(newIP);
    }
    
    async function apiCall(action, formData = null) {
        let url = window.location.href.split('?')[0] + '?api=' + action + '&hostip=' + encodeURIComponent(currentHost);
        let options = { method: formData ? 'POST' : 'GET' };
        if (formData) options.body = formData;
        const response = await fetch(url, options);
        return response;
    }
    
    async function testConnection() {
        const statusDiv = document.getElementById('status');
        statusDiv.innerHTML = '<span class="status">🔄 Testing...</span>';
        try {
            const response = await apiCall('test');
            const data = await response.json();
            statusDiv.innerHTML = `<span class="status online">✅ Online - Voicebox ${data.version || 'unknown'}</span>`;
            return true;
        } catch(e) {
            statusDiv.innerHTML = `<span class="status offline">❌ Offline: ${e.message}</span>`;
            return false;
        }
    }
    
    async function loadModels() {
        try {
            const response = await apiCall('models');
            const data = await response.json();
            const modelsDiv = document.getElementById('modelsList');
            modelsDiv.innerHTML = data.models.map(m => `<span class="model-badge">${m}</span>`).join(' ');
        } catch(e) {
            document.getElementById('modelsList').innerHTML = `Error: ${e.message}`;
        }
    }
    
    async function loadEffects() {
        try {
            const response = await apiCall('effects');
            const data = await response.json();
            const select = document.getElementById('effectSelect');
            const effectsDiv = document.getElementById('effectsList');
            select.innerHTML = '';
            data.effects.forEach(effect => {
                const option = document.createElement('option');
                option.value = effect;
                option.textContent = effect;
                if (effect === 'No Effects') option.selected = true;
                select.appendChild(option);
            });
            effectsDiv.innerHTML = data.effects.map(e => `<span class="effect-badge">${e}</span>`).join(' ');
        } catch(e) {
            document.getElementById('effectsList').innerHTML = `Error: ${e.message}`;
        }
    }
    
    async function loadProfiles() {
        try {
            const response = await apiCall('profiles');
            const profiles = await response.json();
            const select = document.getElementById('voiceSelect');
            const profilesDiv = document.getElementById('profilesList');
            
            if (!profiles.length) {
                select.innerHTML = '<option>No profiles found</option>';
                profilesDiv.innerHTML = '<div class="message info">No voice profiles found.</div>';
                return;
            }
            
            select.innerHTML = '';
            profilesDiv.innerHTML = profiles.map(p => `
                <div class="voice-card" onclick="selectVoice('${p.id}')">
                    <div class="voice-name">🎤 ${p.name}</div>
                    <div>Language: ${p.language} | Generations: ${p.generation_count}</div>
                    <div style="font-size: 10px; color: #888;">${p.id.substring(0, 8)}...</div>
                </div>
            `).join('');
            
            profiles.forEach(p => {
                const option = document.createElement('option');
                option.value = p.id;
                option.textContent = `${p.name} (${p.language})`;
                select.appendChild(option);
            });
        } catch(e) {
            document.getElementById('profilesList').innerHTML = `Error: ${e.message}`;
        }
    }
    
    async function loadHistory() {
        try {
            const response = await apiCall('history');
            const data = await response.json();
            const historyDiv = document.getElementById('historyList');
            
            if (!data.items || data.items.length === 0) {
                historyDiv.innerHTML = '<div class="message info">No history found.</div>';
                return;
            }
            
            historyDiv.innerHTML = data.items.slice(0, 20).map(item => `
                <div class="history-item" onclick="playAudio('${item.id}')">
                    <div><strong>${item.text.substring(0, 60)}...</strong></div>
                    <div style="font-size: 11px;">${new Date(item.created_at).toLocaleString()} | ${item.duration ? item.duration.toFixed(1) + 's' : '...'} | ${item.status}</div>
                </div>
            `).join('');
        } catch(e) {
            document.getElementById('historyList').innerHTML = `Error: ${e.message}`;
        }
    }
    
    function selectVoice(voiceId) {
        document.getElementById('voiceSelect').value = voiceId;
    }
    
    function playAudio(generationId) {
        const audioUrl = `${VOICEBOX_URL}/audio/${generationId}`;
        const audioPlayer = document.getElementById('audioPlayer');
        const audioContainer = document.getElementById('audioContainer');
        audioPlayer.src = audioUrl;
        audioContainer.style.display = 'block';
        audioPlayer.play();
        audioContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    
    async function generateSpeech() {
        const text = document.getElementById('ttsText').value.trim();
        const profile_id = document.getElementById('voiceSelect').value;
        const language = document.getElementById('languageSelect').value;
        const model_size = document.getElementById('modelSelect').value;
        
        if (!text) { alert('Please enter text'); return; }
        if (!profile_id) { alert('Please select a voice'); return; }
        
        const btn = document.getElementById('generateBtn');
        const progressBar = document.getElementById('progressBar');
        const progressFill = document.getElementById('progressFill');
        const statusMsg = document.getElementById('statusMessage');
        const audioContainer = document.getElementById('audioContainer');
        
        btn.disabled = true;
        btn.textContent = '⏳ Generating...';
        progressBar.style.display = 'block';
        progressFill.style.width = '0%';
        statusMsg.style.display = 'block';
        statusMsg.className = 'message info';
        statusMsg.innerHTML = '<span class="loading-spinner"></span> Generating...';
        audioContainer.style.display = 'none';
        
        const formData = new FormData();
        formData.append('generate', '1');
        formData.append('text', text);
        formData.append('profile_id', profile_id);
        formData.append('language', language);
        formData.append('model_size', model_size);
        
        try {
            progressFill.style.width = '30%';
            statusMsg.innerHTML = '<span class="loading-spinner"></span> Generating audio...';
            
            const response = await fetch(window.location.href, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.audio_url) {
                progressFill.style.width = '100%';
                statusMsg.className = 'message success';
                statusMsg.innerHTML = '✅ Complete!';
                
                const audioPlayer = document.getElementById('audioPlayer');
                audioPlayer.src = data.audio_url;
                audioContainer.style.display = 'block';
                audioPlayer.play();
                
                loadHistory();
                
                setTimeout(() => {
                    progressBar.style.display = 'none';
                    statusMsg.style.display = 'none';
                }, 2000);
            } else {
                throw new Error(data.error || 'Generation failed');
            }
        } catch (error) {
            statusMsg.className = 'message error';
            statusMsg.innerHTML = `❌ Error: ${error.message}`;
            progressBar.style.display = 'none';
        } finally {
            btn.disabled = false;
            btn.textContent = '🔊 Generate Speech';
        }
    }
    
    async function transcribeAudio() {
        const fileInput = document.getElementById('transcribeFile');
        const resultDiv = document.getElementById('transcriptionResult');
        
        if (!fileInput.files[0]) {
            alert('Select a file');
            return;
        }
        
        resultDiv.innerHTML = '<div class="message info">Transcribing...</div>';
        const formData = new FormData();
        formData.append('audio', fileInput.files[0]);
        
        try {
            const response = await apiCall('transcribe', formData);
            const data = await response.json();
            resultDiv.innerHTML = `<div class="message success"><strong>📝 Transcription:</strong><br><pre>${data.text || JSON.stringify(data, null, 2)}</pre></div>`;
        } catch(e) {
            resultDiv.innerHTML = `<div class="message error">Error: ${e.message}</div>`;
        }
    }
    
    updateAPIBase();
    window.addEventListener('DOMContentLoaded', () => {
        testConnection();
        loadModels();
        loadEffects();
        loadProfiles();
        loadHistory();
    });
</script>
</body>
</html>
