#!/bin/sh
chmod +x /media/card/ext/cgi-bin/*.sh 2>/dev/null
echo "Fixed CGI permissions"
EOF