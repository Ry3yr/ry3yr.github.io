#!/bin/bash

# --- Configuration ---
ZIPURL="https://alceawis.de/alceawis.de.zip"
ZIPDIR="/sdcard/Download"               # system Download directory
ZIPFILE="$ZIPDIR/alceawis.de.zip"
FILENAME="data_akkoma.json"
TARGET_DIR="/mnt/media_rw/4041-393D/Z_html"

# --- Ensure download directory exists ---
mkdir -p "$ZIPDIR"

echo "Starting download from $ZIPURL..."
curl -L -# -o "$ZIPFILE" "$ZIPURL" || { echo "Download failed"; exit 1; }

echo "Download complete. Extracting..."
unzip -oq "$ZIPFILE" -d "$ZIPDIR" || { echo "Unzip failed"; exit 1; }

# --- Locate the target file in extracted archive ---
TARGET=$(find "$ZIPDIR" -type f -path "*/other/extra/scripts/fakesocialmedia/0ld/$FILENAME" | head -n 1)

if [ -z "$TARGET" ]; then
  echo "File '$FILENAME' not found in extracted archive"
  exit 1
fi

SIZE_BYTES=$(stat -c %s "$TARGET" 2>/dev/null || stat -f %z "$TARGET")
SIZE_KB=$((SIZE_BYTES / 1024))

echo "File found: $TARGET"
echo "Size: ${SIZE_KB} KB (${SIZE_BYTES} bytes)"

if [ "$SIZE_BYTES" -gt $((300 * 1024)) ]; then
  echo "Status: OK (above 300 KB threshold)"
else
  echo "Status: WARNING (below 300 KB threshold)"
fi

# --- Handle target directory ---
echo "Target directory: '$TARGET_DIR'"

if [ ! -d "$TARGET_DIR" ]; then
  echo "Directory does not exist. Creating..."
  mkdir -p "$TARGET_DIR" || { echo "Failed to create directory"; exit 1; }
fi

if [ ! -w "$TARGET_DIR" ]; then
  echo "Cannot write to '$TARGET_DIR'. Check permissions."
  exit 1
fi

# --- Move existing ZIP if present ---
if [ -f "$TARGET_DIR/alceawis.de.zip" ]; then
  ZIP_DATE=$(date -r "$TARGET_DIR/alceawis.de.zip" +%F 2>/dev/null || stat -f "%Sm" -t "%Y-%m-%d" "$TARGET_DIR/alceawis.de.zip")
  echo "Renaming existing file to ${ZIP_DATE}-alceawis.de.zip"
  mv "$TARGET_DIR/alceawis.de.zip" "$TARGET_DIR/${ZIP_DATE}-alceawis.de.zip" || { echo "Rename failed"; exit 1; }
fi

# --- Move the new ZIP to target directory ---
echo "Moving $ZIPFILE to $TARGET_DIR..."
mv -v "$ZIPFILE" "$TARGET_DIR/" || { echo "Failed to move new ZIP"; exit 1; }

echo "SUCCESS: New alceawis.de.zip moved to $TARGET_DIR"
