#!/bin/bash

REMOTE_FILE_URL="https://alceawis.de/alceawis.de.zip"
LOCAL_FILE_PATH="/mnt/media_rw/4041-393D/Z_html/alceawis.de.zip"
TEMP_FILE="/sdcard/Download/alceawis.de.zip"
BASE64_HTML="data:text/html;base64,PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ImVuIj4KPGhlYWQ+CiAgICA8bWV0YSBjaGFyc2V0PSJVVEYtOCI+CiAgICA8bWV0YSBuYW1lPSJ2aWV3cG9ydCIgY29udGVudD0id2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMCI+CiAgICA8dGl0bGU+QmFzZSBXZWIgUGFnZTwvdGl0bGU+CjwvaGVhZD4KPGJvZHk+CiAgICA8aDE+V2VsY29tZSB0byB0aGUgQmFzZSBXZWIgUGFnZTwvaDE+CiAgICA8YSBocmVmPSJodHRwOi8vMTI3LjAuMC4xOjgwODAvemlwZnMtc3ctd29ya2VyLmh0bWwiPlRlc3Q8L2E+CjwvYm9keT4KPC9odG1sPgo="
TARGET_DIR="/sdcard/pws/www"
TARGET_ZIP="$TARGET_DIR/alceawis.de.zip"
TEST_FILE="$TARGET_DIR/test.txt"

echo "=== File Comparison Report ==="
echo "Remote URL: $REMOTE_FILE_URL"
echo "Local Path: $LOCAL_FILE_PATH"
echo ""

cleanup() {
    if [ -f "$TEMP_FILE" ]; then
        rm -f "$TEMP_FILE"
    fi
}

copy_zip_and_log() {
    echo "   Copying ZIP file and creating log entry..."
    
    # Create target directory if it doesn't exist
    if [ ! -d "$TARGET_DIR" ]; then
        echo "   Creating directory: $TARGET_DIR"
        mkdir -p "$TARGET_DIR"
    fi
    
    # Copy the ZIP file
    if [ -f "$LOCAL_FILE_PATH" ]; then
        echo "   Copying $LOCAL_FILE_PATH to $TARGET_ZIP"
        cp "$LOCAL_FILE_PATH" "$TARGET_ZIP"
        
        if [ $? -eq 0 ]; then
            LOCAL_SIZE=$(stat -c%s "$LOCAL_FILE_PATH" 2>/dev/null || stat -f%z "$LOCAL_FILE_PATH")
            echo "   ✓ ZIP file copied successfully ($LOCAL_SIZE bytes)"
        else
            echo "   ✗ Failed to copy ZIP file"
            return 1
        fi
    else
        echo "   ✗ Source ZIP file not found: $LOCAL_FILE_PATH"
        return 1
    fi
    
    # Append to test.txt
    CURRENT_DATE=$(date "+%Y-%m-%d %H:%M:%S")
    echo "$CURRENT_DATE - test ran" >> "$TEST_FILE"
    
    if [ $? -eq 0 ]; then
        echo "   ✓ Log entry added to $TEST_FILE"
        echo "   Entry: \"$CURRENT_DATE - test ran\""
    else
        echo "   ✗ Failed to write to test.txt"
        return 1
    fi
    
    return 0
}

open_browser_with_base64() {
    echo "   Launching Chrome with base64 HTML..."
    echo "   Command: am start -a android.intent.action.VIEW -d \"$BASE64_HTML\" -n com.android.chrome/com.google.android.apps.chrome.Main"
    
    am start -a android.intent.action.VIEW -d "data:text/html;base64,PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ImVuIj4KPGhlYWQ+CiAgICA8bWV0YSBjaGFyc2V0PSJVVEYtOCI+CiAgICA8bWV0YSBuYW1lPSJ2aWV3cG9ydCIgY29udGVudD0id2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMCI+CiAgICA8dGl0bGU+QmFzZSBXZWIgUGFnZTwvdGl0bGU+CjwvaGVhZD4KPGJvZHk+CiAgICA8aDE+V2VsY29tZSB0byB0aGUgQmFzZSBXZWIgUGFnZTwvaDE+CiAgICA8YSBocmVmPSJodHRwOi8vMTI3LjAuMC4xOjgwODAvemlwZnMtc3ctd29ya2VyLmh0bWwiPlRlc3Q8L2E+CjwvYm9keT4KPC9odG1sPgo=" -n com.android.chrome/com.google.android.apps.chrome.Main
    
    if [ $? -eq 0 ]; then
        echo "   ✓ Browser launched successfully"
    else
        echo "   ✗ Failed to launch browser"
        return 1
    fi
}

trap cleanup EXIT

echo "1. Fetching remote file (will not keep it)..."
if curl -f -L --max-time 300 -o "$TEMP_FILE" "$REMOTE_FILE_URL" && [ -s "$TEMP_FILE" ]; then
    REMOTE_SIZE=$(stat -c%s "$TEMP_FILE" 2>/dev/null || stat -f%z "$TEMP_FILE")
    
    if [ "$REMOTE_SIZE" -lt 1024 ]; then
        echo "   WARNING: Remote file is very small ($REMOTE_SIZE bytes). Might not be a valid ZIP file."
    fi
    
    echo "   Calculating MD5 checksum..."
    REMOTE_MD5=$(md5sum "$TEMP_FILE" | cut -d' ' -f1)
    
    echo "   Successfully fetched remote file ($REMOTE_SIZE bytes)"
    echo "   File Size: $REMOTE_SIZE bytes"
    echo "   MD5 Checksum: $REMOTE_MD5"
    
    cleanup
else
    REMOTE_SIZE="N/A"
    REMOTE_MD5="N/A"
    echo "   ERROR: Failed to fetch remote file or file is empty"
    
    if [ $? -eq 28 ]; then
        echo "   (Timeout error - server took too long to respond)"
    elif [ $? -eq 22 ]; then
        echo "   (HTTP error - server returned 4xx/5xx status)"
    fi
fi
echo ""

echo "2. Local file information:"
if [ -f "$LOCAL_FILE_PATH" ] && [ -s "$LOCAL_FILE_PATH" ]; then
    LOCAL_SIZE=$(stat -c%s "$LOCAL_FILE_PATH" 2>/dev/null || stat -f%z "$LOCAL_FILE_PATH")
    
    echo "   Calculating MD5 checksum..."
    LOCAL_MD5=$(md5sum "$LOCAL_FILE_PATH" | cut -d' ' -f1)
    
    echo "   Local file exists and is not empty"
    echo "   File Size: $LOCAL_SIZE bytes"
    echo "   MD5 Checksum: $LOCAL_MD5"
else
    LOCAL_SIZE="N/A"
    LOCAL_MD5="N/A"
    echo "   ERROR: Local file does not exist or is empty"
fi
echo ""

echo "3. COMPARISON RESULTS:"
echo "   ------------------------------------------"
if [ "$REMOTE_SIZE" != "N/A" ] && [ "$LOCAL_SIZE" != "N/A" ]; then
    echo "   File Sizes:"
    echo "   - Remote: $REMOTE_SIZE bytes"
    echo "   - Local:  $LOCAL_SIZE bytes"
    
    SIZE_MATCH=false
    MD5_MATCH=false
    
    if [ "$REMOTE_SIZE" -eq "$LOCAL_SIZE" ]; then
        echo "   Sizes MATCH"
        SIZE_MATCH=true
    else
        echo "   Sizes DIFFER by $((LOCAL_SIZE - REMOTE_SIZE)) bytes"
    fi
    
    echo ""
    echo "   MD5 Checksums:"
    echo "   - Remote: $REMOTE_MD5"
    echo "   - Local:  $LOCAL_MD5"
    
    if [ "$REMOTE_MD5" = "$LOCAL_MD5" ]; then
        echo "   MD5 checksums MATCH - files are IDENTICAL"
        MD5_MATCH=true
    else
        echo "   MD5 checksums DIFFER - files are NOT the same"
    fi
    
    echo ""
    if [ "$SIZE_MATCH" = true ] && [ "$MD5_MATCH" = true ]; then
        echo "   Both file size and MD5 checksum match!"
        echo "   Copying files and logging test..."
        
        # Copy ZIP and log test before launching browser
        if copy_zip_and_log; then
            echo "   Launching browser..."
            open_browser_with_base64
        else
            echo "   ✗ Failed to copy files/log - browser launch aborted"
        fi
    else
        echo "   Files differ, browser will not be launched"
    fi
    
elif [ "$REMOTE_SIZE" = "N/A" ] && [ "$LOCAL_SIZE" != "N/A" ]; then
    echo "   Cannot compare - remote file unavailable"
    echo "   Local file exists: $LOCAL_SIZE bytes"
elif [ "$REMOTE_SIZE" != "N/A" ] && [ "$LOCAL_SIZE" = "N/A" ]; then
    echo "   Cannot compare - local file unavailable"
    echo "   Remote file available: $REMOTE_SIZE bytes"
else
    echo "   Cannot compare - both files unavailable"
fi
echo "   ------------------------------------------"
echo ""
echo "Report completed at $(date)"