#!/bin/sh

# Make Termux binaries accessible as root
export PATH=/data/data/com.termux/files/usr/bin:$PATH

# FTP server info
FTP_SERVER="192.168.0.1"
FTP_USER="anonymous"
FTP_PASS="anonymous@domain.com"

# Remote folder to upload to (use exact folder seen in ls)
FTP_PATH="Z_(HTML-Exthdd)/Z_WebsiteBackup"

# Local folder containing ZIPs (needs root to read)
SOURCE_DIR="/mnt/media_rw/4041-393D/Z_html"

echo "Uploading ZIP files from $SOURCE_DIR to $FTP_PATH on $FTP_SERVER..."

for f in "$SOURCE_DIR"/*.zip; do
    [ -f "$f" ] || continue
    echo "Uploading $(basename "$f")..."
    lftp -u "$FTP_USER","$FTP_PASS" "$FTP_SERVER" <<EOF
set ftp:passive-mode on
set ftp:ssl-allow no
lcd "$SOURCE_DIR"
cd "$FTP_PATH"
put "$(basename "$f")"
bye
EOF
done

echo "All uploads completed."
