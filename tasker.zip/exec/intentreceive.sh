#!/bin/bash

# URL of the script
SCRIPT_URL="https://alceawis.de/other/extra/scripts/fakesocialmedia/clip.txt"

# Fetch the script into a variable
SCRIPT=$(curl -fsSL "$SCRIPT_URL")

# Check if the script was successfully downloaded
if [ -n "$SCRIPT" ]; then
    echo "Script content (flashed):"
    echo "$SCRIPT"  # "Flash" the content directly to the terminal

    # Execute the command using su -c (with root privileges)
    su -c "$SCRIPT"

else
    echo "Failed to download script or script is empty."
fi
