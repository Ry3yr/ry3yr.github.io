<?php
ini_set('memory_limit', '256M');
set_time_limit(0);

$protocol   = isset($_GET['protocol']) ? $_GET['protocol'] : 'ftp';
$server     = isset($_GET['server']) ? $_GET['server'] : '';
$path       = isset($_GET['path']) ? $_GET['path'] : '';
$username   = isset($_GET['username']) ? $_GET['username'] : '';
$password   = isset($_GET['password']) ? $_GET['password'] : '';
$anonymous  = isset($_GET['anonymous']) && $_GET['anonymous'] == '1';

if ($anonymous) {
    $username = 'anonymous';
    $password = 'anonymous@domain.com';
}

if (!$server || !$path) {
    http_response_code(400);
    exit("Missing server/path");
}

// Determine file extension for content-type
$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
$mime = array(
    'mp3'  => 'audio/mpeg',
    'mp4'  => 'video/mp4',
    'png'  => 'image/png',
    'jpg'  => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'gif'  => 'image/gif'
);
$contentType = isset($mime[$ext]) ? $mime[$ext] : 'application/octet-stream';

// Build remote URL
$url = ($protocol === 'webdav' ? 'https' : $protocol) . "://$username:$password@$server$path";

// Stream to browser
header("Content-Type: $contentType");
header('Content-Disposition: inline; filename="' . basename($path) . '"');
readfile($url);
exit;
?>
