import bpy

# Iterate through all materials in the scene
for material in bpy.data.materials:
    if material.use_nodes:  # Check if the material uses nodes
        # Access the node tree of the material
        nodes = material.node_tree.nodes
        # Iterate through all nodes in the node tree
        for node in nodes:
            # Check if the node is an Image Texture node
            if node.type == 'TEX_IMAGE':
                # Remove the node from the material
                nodes.remove(node)

# Optionally, clear unused images from Blender's data
for image in bpy.data.images:
    bpy.data.images.remove(image)
    
print("All textures have been erased.")
