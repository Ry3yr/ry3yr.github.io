def execute(self, context):
    obdata = context.object.data

    if self.replace_active_layer and obdata.vertex_colors.active:
        vertex_colors = obdata.vertex_colors.active
    else:
        vertex_colors = obdata.vertex_colors.new(name="Baked UV texture")
    
        if not vertex_colors:
            # Can't add more than 17 VCol layers
            self.report({'ERROR'}, "Couldn't add another Vertex Color layer,\n"
                                   "Please remove an existing layer or replace active.")
            return {'CANCELLED'}
        
    obdata.vertex_colors.active = vertex_colors

    uv_images = {}
    for uv_tex in obdata.uv_textures.active.data:
        if uv_tex.image and uv_tex.image.name not in uv_images and uv_tex.image.pixels:
            
            uv_images[uv_tex.image.name] = (uv_tex.image.size[0],
                                            uv_tex.image.size[1],
                                            uv_tex.image.pixels[:]
                                           )
    
    for p in obdata.polygons:
        img = obdata.uv_textures.active.data[p.index].image
        if not img:
            continue
        
        image_size_x, image_size_y, uv_pixels = uv_images[img.name]
        
        for loop in p.loop_indices:
    
            co = obdata.uv_layers.active.data[loop].uv
            x_co = round(co[0] * (image_size_x - 1))
            y_co = round(co[1] * (image_size_y - 1))
            
            if x_co < 0 or x_co >= image_size_x or y_co < 0 or y_co >= image_size_y:
                if self.mappingMode == 'CLIP':
                    continue

                elif self.mappingMode == 'REPEAT':
                    x_co %= image_size_x
                    y_co %= image_size_y

                elif self.mappingMode == 'EXTEND':
                    if x_co > image_size_x - 1:
                        x_co = image_size_x - 1
                    if x_co < 0:
                        x_co = 0
                    if y_co > image_size_y - 1:
                        y_co = image_size_y - 1
                    if y_co < 0:
                        y_co = 0
            
            if self.mirror_x:
                 x_co = image_size_x -1 - x_co
                 
            if self.mirror_y:
                 y_co = image_size_y -1 - y_co
                 
            col_out = vertex_colors.data[loop].color
                
            pixelNumber = (image_size_x * y_co) + x_co
            r = uv_pixels[pixelNumber*4]
            g = uv_pixels[pixelNumber*4 + 1]
            b = uv_pixels[pixelNumber*4 + 2]
            a = uv_pixels[pixelNumber*4 + 3]
            
            col_in = r, g, b  # texture-color
            col_result = [r, g, b]  # existing / 'base' color
            
            if self.blendingMode == 'MIX':
                col_result = col_in
                
            # Add more blending modes here...

            # Add alpha color
            a_inverted = 1 - a
            alpha_color = context.scene.uv_bake_alpha_color
            col_result = (col_result[0] * a + alpha_color[0] * a_inverted,
                          col_result[1] * a + alpha_color[1] * a_inverted,
                          col_result[2] * a + alpha_color[2] * a_inverted)
            
            vertex_colors.data[loop].color = col_result

    # Remove the textures from the UV layer
    for uv_tex in obdata.uv_textures:
        uv_tex.active = False
        obdata.uv_textures.remove(uv_tex)

    # Remove the material texture links (both in node-based materials and legacy texture slots)
    for mat in context.object.data.materials:
        if mat.use_nodes:
            # If the material uses nodes, search for texture nodes
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE':  # Image Texture node
                    # Unlink the image texture from the material node
                    node.image = None
        else:
            # If the material doesn't use nodes, check the texture slots
            for i, texture_slot in enumerate(mat.texture_slots):
                if texture_slot:
                    # Remove the texture
                    mat.texture_slots[i] = None

    return {'FINISHED'}
