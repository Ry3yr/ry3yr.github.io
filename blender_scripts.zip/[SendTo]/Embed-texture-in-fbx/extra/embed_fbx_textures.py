import bpy
import sys

# Get the FBX file paths from the arguments
input_fbx = sys.argv[-2]
output_fbx = sys.argv[-1]

# Clear any existing objects
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Import the FBX file
bpy.ops.import_scene.fbx(filepath=input_fbx)

# Pack all external resources (textures) into the blend file
bpy.ops.file.pack_all()

# Export the FBX file with embedded textures
bpy.ops.export_scene.fbx(filepath=output_fbx, embed_textures=True)

print(f"Successfully embedded textures into: {output_fbx}")
