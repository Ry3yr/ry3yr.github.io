※This program needs VRM-Addon-for-Blender
https://github.com/saturday06/VRM-Addon-for-Blender


1.unzip this folder.

2.You must to work this prpgram in ENGLISH settings With preference.
Because the node name changes  the settings With preference.

3.open Blender.

4.import your FBX products that Rigged of ActorCore AccuRIG.

5.change the Blender layout to Scripting mode.

6.open py file from unziped this.

7.set the path of filepathjson to "humanbody2.json".

8.Run script so you can get VRM with choosing folder.