# Check it works at Blender 3.4.1
# You can change the path and name
filepathjson = "C:\\portableapps\\blender36\\scripts\\humanbody2.json"
filepathVRM = "C:\\portableapps\\blender36\\scripts\\VRM"
filenameVRM = "VRM"

# Main code is below the line.
#----------------------------------------------------------------------

import os
import bpy

# Ensure the VRM directory exists
try:
    os.makedirs(filepathVRM)
except FileExistsError:
    pass

# Deselect all objects in the scene
bpy.ops.object.select_all(action='DESELECT')

# Check if "Armature" exists before selecting it
if "Armature" in bpy.data.objects:
    object = bpy.data.objects["Armature"]
    object.select_set(True)
else:
    print("Object 'Armature' not found in the scene.")

# Rename bones for the armature
for obj in bpy.data.objects:
    if obj.type == 'ARMATURE':
        for bone in obj.pose.bones:
            bone.name = bone.name.replace("CC_Base_", "HumanBodyBones.")
            
        for bone in obj.pose.bones:
            if obj.name != "RL_BoneRoot":
                bone.name = bone.name.replace("L_", "Left")
            
        for bone in obj.pose.bones:
            bone.name = bone.name.replace("R_", "Right")

        for bone in obj.pose.bones:
            bone.name = bone.name.replace("Clavicle", "Shoulder")
                     
        for bone in obj.pose.bones:
            bone.name = bone.name.replace("Fore", "Lower")
                     
        for bone in obj.pose.bones:
            bone.name = bone.name.replace("ToeBase", "Toes")
            
        for bone in obj.pose.bones:
            bone.name = bone.name.replace("arm", "Arm")

        for bone in obj.pose.bones:
            bone.name = bone.name.replace("Thigh", "UpperLeg")

        for bone in obj.pose.bones:
            bone.name = bone.name.replace("Calf", "LowerLeg")

# Load human bone mappings from JSON
bpy.ops.vrm.load_human_bone_mappings(filepath=filepathjson)

# Deselect all objects again
bpy.ops.object.select_all(action='DESELECT')

# Check if "default" object exists before trying to select it
if "default" in bpy.data.objects:
    object = bpy.data.objects["default"]
    object.select_set(True)
else:
    print("Object 'default' not found in the scene.")

# Select all mesh objects (assuming you want to select all of them, not just 'default')
selectob = bpy.data.objects
for ob in selectob:
    if ob.type == 'MESH':
        ob.select_set(True)
        bpy.context.view_layer.objects.active = ob

# Switch to Shader Node Tree for material editing
bpy.context.area.ui_type = 'ShaderNodeTree'
bpy.context.object.active_material_index = 0
mat = bpy.context.active_object.material_slots[0].material

# Node tree for material setup
node_tree = bpy.context.active_object.material_slots[0].material.node_tree
nodes = node_tree.nodes
links = node_tree.links

# Create MToon Shader Node Group
mtoon = nodes.new("ShaderNodeGroup")
mtoon.node_tree = bpy.data.node_groups['MToon_unversioned']

# Get the Image Texture node
dif = node_tree.nodes["Image Texture"]

# Print and check nodes for debugging
print(dif)
for n in nodes:
    print(n)

# Get the Material Output node and link everything up
out1 = node_tree.nodes["Material Output"]
for l in links:
    links.remove(l)

# Link nodes
links.new(dif.outputs[0], mtoon.inputs[0])
links.new(mtoon.outputs[0], out1.inputs[0])

# Enable backface culling and set blend method
bpy.context.object.active_material.use_backface_culling = True
bpy.context.object.active_material.blend_method = 'OPAQUE'

# Export the scene to a VRM file
bpy.ops.export_scene.vrm(filepath=os.path.join(filepathVRM, filenameVRM + ".vrm"))

# Switch to Object mode
bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
